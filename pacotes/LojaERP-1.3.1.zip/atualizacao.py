"""Loja ERP — atualização automática.

Procura novas versões no repositório público de versões do GitHub, confere a assinatura digital
(Ed25519) e o SHA-256 do pacote, testa a nova versão antes de trocar os arquivos e mantém a versão
anterior para voltar atrás se algo der errado. Nenhum dado da loja é enviado: só o arquivo de
versão e o pacote são baixados.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

REPO_VERSOES = 'victorhugormoura/ERP-4Clouthes-atualizacoes'
URL_OFICIAL = f'https://raw.githubusercontent.com/{REPO_VERSOES}/main/'
# Para testes: só aceita outro endereço se for HTTPS ou um servidor neste próprio computador.
_url_teste = os.environ.get('LOJA_ERP_URL_ATUALIZACAO', '')
URL_BASE = _url_teste if re.match(r'(https://|http://127\.0\.0\.1:\d+/)', _url_teste) else URL_OFICIAL
# Chave pública de quem publica as versões. A chave privada nunca fica no programa nem no repositório.
CHAVE_PUBLICA = '40i52j050sipBYiHCadSGaa40sOquSlaCXC7M6y1qB4='
LIMITE_MANIFESTO = 64 * 1024
LIMITE_PACOTE = 60 * 1024 * 1024
INTERVALO_VERIFICACAO = 12 * 3600
ARQUIVOS_RAIZ = re.compile(r'[a-z_]+\.py')
NOMES_RESERVADOS = {'con', 'prn', 'aux', 'nul'} | {f'com{i}' for i in range(10)} | {f'lpt{i}' for i in range(10)}

# ---------------------------------------------------------------- Ed25519 (RFC 8032)
_q = 2 ** 255 - 19
_l = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _q - 2, _q) % _q
_I = pow(2, (_q - 1) // 4, _q)


def _xrec(y):
    xx = (y * y - 1) * pow(_d * y * y + 1, _q - 2, _q)
    x = pow(xx, (_q + 3) // 8, _q)
    if (x * x - xx) % _q != 0:
        x = x * _I % _q
    if x % 2 != 0:
        x = _q - x
    return x


_By = 4 * pow(5, _q - 2, _q) % _q
_B = (_xrec(_By) % _q, _By % _q, 1, _xrec(_By) * _By % _q)


def _soma(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _q
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _q
    C = 2 * P[3] * Q[3] * _d % _q
    D = 2 * P[2] * Q[2] % _q
    E, F, G, H = B - A, D - C, D + C, B + A
    return E * F % _q, G * H % _q, F * G % _q, E * H % _q


def _mult(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _soma(Q, P)
        P = _soma(P, P)
        s >>= 1
    return Q


def _iguais(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _q == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _q == 0


def _comprimir(P):
    zinv = pow(P[2], _q - 2, _q)
    x, y = P[0] * zinv % _q, P[1] * zinv % _q
    return int.to_bytes(y | ((x & 1) << 255), 32, 'little')


def _descomprimir(b):
    if len(b) != 32:
        raise ValueError('ponto inválido')
    y = int.from_bytes(b, 'little')
    sinal = y >> 255
    y &= (1 << 255) - 1
    if y >= _q:
        raise ValueError('ponto inválido')
    x = _xrec(y)
    if (x * x * -1 + y * y - 1 - _d * x * x * y * y) % _q != 0:
        raise ValueError('ponto fora da curva')
    if x == 0 and sinal:
        raise ValueError('ponto inválido')
    if (x & 1) != sinal:
        x = _q - x
    return x, y, 1, x * y % _q


def _h(m):
    return int.from_bytes(hashlib.sha512(m).digest(), 'little')


def _segredo(semente):
    h = hashlib.sha512(semente).digest()
    a = int.from_bytes(h[:32], 'little')
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def chave_publica(semente):
    a, _ = _segredo(semente)
    return _comprimir(_mult(a, _B))


def assinar(semente, mensagem):
    a, prefixo = _segredo(semente)
    A = _comprimir(_mult(a, _B))
    r = _h(prefixo + mensagem) % _l
    R = _comprimir(_mult(r, _B))
    s = (r + _h(R + A + mensagem) * a) % _l
    return R + int.to_bytes(s, 32, 'little')


def verificar_assinatura(publica, mensagem, assinatura):
    try:
        if len(assinatura) != 64:
            return False
        A = _descomprimir(publica)
        R = _descomprimir(assinatura[:32])
        s = int.from_bytes(assinatura[32:], 'little')
        if s >= _l:
            return False
        k = _h(assinatura[:32] + publica + mensagem) % _l
        return _iguais(_mult(s, _B), _soma(R, _mult(k, A)))
    except (ValueError, TypeError):
        return False


# ------------------------------------------------------------------ manifesto
def versao_tupla(v):
    try:
        return tuple(int(x) for x in str(v).split('.')[:3])
    except ValueError:
        return (0, 0, 0)


def ler_manifesto(texto, publica_b64=None):
    """Confere a assinatura e devolve os dados da versão publicada."""
    publica = base64.b64decode(publica_b64 or CHAVE_PUBLICA)
    try:
        m = json.loads(texto)
        dados = m['dados'].encode('utf-8')
        assinatura = base64.b64decode(m['assinatura'])
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ValueError('arquivo de versão inválido')
    if not verificar_assinatura(publica, dados, assinatura):
        raise ValueError('assinatura digital inválida — atualização recusada')
    info = json.loads(dados)
    if info.get('app') != 'LojaERP' or not re.fullmatch(r'\d+\.\d+\.\d+', str(info.get('versao', ''))) \
            or not re.fullmatch(r'pacotes/LojaERP-\d+\.\d+\.\d+\.zip', str(info.get('arquivo', ''))) \
            or not re.fullmatch(r'[0-9a-f]{64}', str(info.get('sha256', ''))):
        raise ValueError('arquivo de versão incompleto')
    return info


def montar_manifesto(semente, info):
    dados = json.dumps(info, ensure_ascii=False, sort_keys=True)
    return json.dumps({'dados': dados, 'assinatura': base64.b64encode(assinar(semente, dados.encode('utf-8'))).decode()},
                      ensure_ascii=False, indent=1)


def validar_pacote(conteudo):
    """Só aceita os arquivos do programa: módulos .py na raiz e a pasta web."""
    with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
        nomes = [i.filename for i in z.infolist()]
        if sum(i.file_size for i in z.infolist()) > 200 * 1024 * 1024:
            raise ValueError('pacote grande demais')
    if len({n.lower() for n in nomes}) != len(nomes):
        raise ValueError('pacote com nomes repetidos')
    if 'loja.py' not in nomes or 'web/index.html' not in nomes:
        raise ValueError('pacote sem os arquivos principais')
    for n in nomes:
        partes = n.split('/')
        if n.startswith('/') or '\\' in n or ':' in n or '..' in partes or any(p == '' for p in partes) \
                or any(p.split('.')[0].lower() in NOMES_RESERVADOS for p in partes):
            raise ValueError(f'caminho inválido no pacote: {n}')
        if not (ARQUIVOS_RAIZ.fullmatch(n) or partes[0] == 'web'):
            raise ValueError(f'arquivo inesperado no pacote: {n}')
    return nomes


# ------------------------------------------------------------------- atualizador
def copiar_arquivo(origem, destino):
    """Cópia simples por leitura e escrita (não depende de CopyFile2 do Windows, ausente em alguns ambientes)."""
    with open(origem, 'rb') as a, open(destino, 'wb') as b:
        shutil.copyfileobj(a, b, 1024 * 1024)
    return destino


class Atualizador:
    """Estado e passos da atualização de uma instalação (fica fora da pasta de dados, por computador)."""

    def __init__(self, pasta_programa, pasta_estado, versao_atual, log=print):
        self.programa = pasta_programa
        self.pasta = os.path.join(pasta_estado, 'atualizacao')
        self.arq_estado = os.path.join(self.pasta, 'estado.json')
        self.versao = versao_atual
        self.log = log
        self.trava = threading.Lock()
        self.estado = self._ler()

    # -- estado
    def _ler(self):
        try:
            with open(self.arq_estado, 'r', encoding='utf-8') as f:
                e = json.load(f)
                return e if isinstance(e, dict) else {}
        except (OSError, ValueError):
            return {}

    def salvar(self):
        os.makedirs(self.pasta, exist_ok=True)
        with open(self.arq_estado + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(self.estado, f, ensure_ascii=False, indent=1)
        os.replace(self.arq_estado + '.tmp', self.arq_estado)

    @property
    def automatica(self):
        return self.estado.get('automatica', True)

    def instalacao_de_desenvolvimento(self):
        return os.path.isdir(os.path.join(self.programa, '.git'))

    def resumo(self):
        e = self.estado
        pronta = e.get('pronta') if versao_tupla((e.get('pronta') or {}).get('versao')) > versao_tupla(self.versao) else None
        return {'versao': self.versao, 'automatica': self.automatica, 'ultima_verificacao': e.get('ultima_verificacao'),
                'disponivel': e.get('disponivel'), 'pronta': pronta, 'erro': e.get('erro', ''),
                'ultima_instalada': e.get('ultima_instalada'), 'desenvolvimento': self.instalacao_de_desenvolvimento(),
                'repositorio': f'https://github.com/{REPO_VERSOES}'}

    # -- rede
    @staticmethod
    def _baixar(url, limite):
        req = urllib.request.Request(url, headers={'User-Agent': 'LojaERP-atualizacao', 'Cache-Control': 'no-cache'})
        with urllib.request.urlopen(req, timeout=30) as r:
            dados = r.read(limite + 1)
        if len(dados) > limite:
            raise ValueError('arquivo maior que o esperado')
        return dados

    def verificar(self, baixar=True):
        """Consulta a versão publicada e, se for nova, baixa, confere e testa o pacote.
        Uma verificação por vez; se já houver outra em andamento, só devolve a situação."""
        if not self.trava.acquire(blocking=False):
            return dict(self.resumo(), verificando=True)
        try:
            return self._verificar(baixar)
        finally:
            self.trava.release()

    def _verificar(self, baixar):
        self.estado['ultima_verificacao'] = time.strftime('%Y-%m-%dT%H:%M:%S')
        try:
            info = ler_manifesto(self._baixar(URL_BASE + 'versao.json?t=' + str(int(time.time())), LIMITE_MANIFESTO).decode('utf-8'))
            # Manifesto mais antigo que um já visto = alguém servindo uma versão velha: ignora.
            if versao_tupla(info['versao']) < versao_tupla(self.estado.get('maior_vista', '0.0.0')):
                raise ValueError(f'o servidor ofereceu a versão {info["versao"]}, anterior a uma já publicada')
            if versao_tupla(info['versao']) > versao_tupla(self.estado.get('maior_vista', '0.0.0')):
                self.estado['maior_vista'] = info['versao']
            self.estado['erro'] = ''
            if versao_tupla(info['versao']) <= versao_tupla(self.versao):
                self.estado['disponivel'] = None
                return self.resumo()
            if versao_tupla(info.get('minimo', '0.0.0')) > versao_tupla(self.versao):
                self.estado['disponivel'] = dict(info, aviso='Esta versão precisa ser instalada pelo instalador novo.')
                return self.resumo()
            self.estado['disponivel'] = info
            if info['versao'] in self.estado.get('recusadas', []):
                self.estado['erro'] = f'A versão {info["versao"]} falhou ao iniciar neste computador e foi deixada de lado.'
            elif baixar and ((self.estado.get('pronta') or {}).get('versao') != info['versao'] or not self.pode_aplicar()):
                self.preparar(info)
        except (OSError, ValueError, zipfile.BadZipFile, subprocess.SubprocessError) as e:
            self.estado['erro'] = f'Não foi possível verificar ou baixar a atualização: {e}'
            self.log(self.estado['erro'])
        finally:
            self.salvar()
        return self.resumo()

    def preparar(self, info):
        conteudo = self._baixar(URL_BASE + info['arquivo'], LIMITE_PACOTE)
        if len(conteudo) != int(info.get('tamanho', -1)) or hashlib.sha256(conteudo).hexdigest() != info['sha256']:
            raise ValueError('o pacote baixado não confere com o publicado')
        validar_pacote(conteudo)
        destino = os.path.join(self.pasta, info['versao'])
        temporario = destino + '.baixando'
        shutil.rmtree(temporario, ignore_errors=True)
        os.makedirs(os.path.join(temporario, 'novo'))
        with open(os.path.join(temporario, 'pacote.zip'), 'wb') as f:
            f.write(conteudo)
        with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
            z.extractall(os.path.join(temporario, 'novo'))
        self.testar(os.path.join(temporario, 'novo'), info['versao'])
        shutil.rmtree(destino, ignore_errors=True)
        os.replace(temporario, destino)
        self.estado['pronta'] = {'versao': info['versao'], 'notas': info.get('notas', []), 'publicado_em': info.get('publicado_em', ''),
                                 'sha256': info['sha256']}
        self.log(f'Atualização {info["versao"]} baixada, conferida e testada.')

    @staticmethod
    def testar(pasta, versao):
        """Roda a nova versão em modo de verificação (não abre dados nem servidor) e confere a versão."""
        r = subprocess.run([sys.executable, os.path.join(pasta, 'loja.py'), '--verificar'], capture_output=True, text=True,
                           timeout=120, cwd=pasta, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if r.returncode != 0 or r.stdout.strip().splitlines()[-1:] != [f'VERIFICACAO-OK {versao}']:
            raise ValueError('a nova versão não passou no teste: ' + (r.stderr or r.stdout)[-300:])

    # -- aplicação
    def _arquivos_programa(self, pasta):
        return [n for n in os.listdir(pasta) if ARQUIVOS_RAIZ.fullmatch(n)] + (['web'] if os.path.isdir(os.path.join(pasta, 'web')) else [])

    def _copiar(self, origem, destino, nomes):
        # loja.py por último e com troca atômica: se algo interromper a cópia, ele continua inteiro.
        for n in sorted(nomes, key=lambda x: x == 'loja.py'):
            o, d = os.path.join(origem, n), os.path.join(destino, n)
            if os.path.isdir(o):
                temporario = d + '.novo'
                shutil.rmtree(temporario, ignore_errors=True)
                shutil.copytree(o, temporario, copy_function=copiar_arquivo)
                if os.path.isdir(d):
                    velho = d + '.velho'
                    shutil.rmtree(velho, ignore_errors=True)
                    os.replace(d, velho)
                    os.replace(temporario, d)
                    shutil.rmtree(velho, ignore_errors=True)
                else:
                    os.replace(temporario, d)
            else:
                copiar_arquivo(o, d + '.novo')
                os.replace(d + '.novo', d)

    def pode_aplicar(self):
        pronta = (self.estado.get('pronta') or {}).get('versao')
        if pronta and not os.path.isfile(os.path.join(self.pasta, pronta, 'pacote.zip')):
            self.estado['pronta'] = None   # pasta apagada por fora: baixa de novo na próxima verificação
            return False
        return bool(pronta) and versao_tupla(pronta) > versao_tupla(self.versao) \
            and pronta not in self.estado.get('recusadas', []) and not self.instalacao_de_desenvolvimento()

    def aplicar(self):
        """Guarda a versão atual em .anterior e copia a nova por cima. Devolve a versão instalada."""
        info = self.estado['pronta']
        # Confere de novo o pacote guardado e extrai do zero: nada que tenha mexido na pasta depois do teste entra.
        with open(os.path.join(self.pasta, info['versao'], 'pacote.zip'), 'rb') as f:
            conteudo = f.read()
        if hashlib.sha256(conteudo).hexdigest() != info.get('sha256'):
            self.estado['pronta'] = None
            raise ValueError('o pacote guardado foi alterado depois de conferido')
        validar_pacote(conteudo)
        novo = os.path.join(self.pasta, info['versao'], 'aplicar')
        shutil.rmtree(novo, ignore_errors=True)
        with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
            z.extractall(novo)
        nomes_novos = self._arquivos_programa(novo)
        if 'loja.py' not in nomes_novos:
            raise ValueError('pacote preparado incompleto')
        anterior = os.path.join(self.programa, '.anterior')
        shutil.rmtree(anterior, ignore_errors=True)
        os.makedirs(anterior)
        self._copiar(self.programa, anterior, self._arquivos_programa(self.programa))
        self.estado['copiando'] = info['versao']   # se cair a energia agora, a próxima abertura volta para .anterior
        self.salvar()
        self._copiar(novo, self.programa, nomes_novos)
        for n in os.listdir(self.programa):
            if ARQUIVOS_RAIZ.fullmatch(n) and n not in nomes_novos and n in os.listdir(anterior):
                os.remove(os.path.join(self.programa, n))
        self.estado['aplicando'] = {'versao': info['versao'], 'de': self.versao, 'quando': time.time(), 'notas': info.get('notas', [])}
        self.estado['copiando'] = None
        self.estado['pronta'] = None
        self.salvar()
        self.log(f'Atualização {info["versao"]} instalada (versão anterior guardada em .anterior).')
        return info['versao']

    def reverter(self, motivo):
        """Volta para a versão guardada em .anterior e marca a nova como recusada."""
        versao = (self.estado.get('aplicando') or {}).get('versao') or self.estado.get('copiando')
        anterior = os.path.join(self.programa, '.anterior')
        if not os.path.isfile(os.path.join(anterior, 'loja.py')):
            return False
        self._copiar(anterior, self.programa, self._arquivos_programa(anterior))
        if versao:
            self.estado.setdefault('recusadas', []).append(versao)
        self.estado['aplicando'] = self.estado['copiando'] = None
        self.estado['erro'] = f'A versão {versao or "nova"} não iniciou ({motivo}); a anterior foi restaurada.'
        self.salvar()
        self.log(self.estado['erro'])
        return True

    def confirmar_inicio(self):
        """Chamado quando o servidor da nova versão está no ar."""
        aplicando = self.estado.get('aplicando')
        if aplicando and aplicando.get('versao') == self.versao:
            self.estado['aplicando'] = None
            self.estado['ultima_instalada'] = {'versao': self.versao, 'de': aplicando.get('de'), 'notas': aplicando.get('notas', []),
                                               'quando': time.strftime('%Y-%m-%dT%H:%M:%S')}
            self.salvar()
