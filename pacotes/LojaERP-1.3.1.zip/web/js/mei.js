/* Loja ERP — Modo MEI: limite de faturamento, relatório mensal de receitas brutas e notas fiscais.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

function ehMei() { return (App.cfg.fiscal || {}).regime === 'mei'; }

/* Limite do ano: proporcional aos meses de atividade no ano de abertura (limite ÷ 12 por mês). */
function limiteMei(ano) {
  const m = App.cfg.mei || {};
  const anual = n(m.limite_anual) || 81000;
  if (m.abertura && m.abertura.slice(0, 4) === String(ano)) {
    const meses = 12 - +m.abertura.slice(5, 7) + 1;
    return { valor: anual / 12 * meses, proporcional: true, meses, anual };
  }
  return { valor: anual, proporcional: false, meses: 12, anual };
}

function faturamentoMei(ano) {
  const vendas = App.d.vendas.filter(v => v.status === 'concluida' && v.data.slice(0, 4) === String(ano));
  const porMes = Array.from({ length: 12 }, (_, k) => soma(vendas.filter(v => +v.data.slice(5, 7) === k + 1), v => v.total));
  return { total: soma(porMes, x => x), porMes };
}

function situacaoMei(ano = +hojeISO().slice(0, 4)) {
  const lim = limiteMei(ano), fat = faturamentoMei(ano);
  const mesAtual = String(ano) === hojeISO().slice(0, 4) ? +hojeISO().slice(5, 7) : 12;
  const inicio = lim.proporcional ? 12 - lim.meses + 1 : 1;
  const mesesDecorridos = Math.max(1, mesAtual - inicio + 1);
  const projecao = fat.total / mesesDecorridos * lim.meses;
  const pctUso = lim.valor ? fat.total / lim.valor * 100 : 0;
  let nivel = 'ok', texto = 'Dentro do limite do MEI.';
  if (pctUso >= 120) { nivel = 'erro'; texto = 'Faturamento acima de 20% do limite: o enquadramento como MEI é perdido desde janeiro deste ano. Procure seu contador com urgência.'; }
  else if (pctUso >= 100) { nivel = 'erro'; texto = 'Limite ultrapassado em até 20%: paga-se DAS complementar sobre o excesso e a empresa passa a ME a partir de janeiro do próximo ano. Fale com seu contador.'; }
  else if (pctUso >= 80 || projecao > lim.valor) { nivel = 'alerta'; texto = projecao > lim.valor ? `No ritmo atual, o ano deve fechar em ${moeda(projecao)}, acima do limite. Planeje com seu contador a mudança para ME.` : 'Mais de 80% do limite anual já foi usado.'; }
  return { ano, lim, fat, projecao, pctUso, nivel, texto, restante: lim.valor - fat.total };
}

/* Relatório Mensal das Receitas Brutas (obrigatório para o MEI guardar, com as notas do mês anexadas). */
function relatorioMensalMei(mes) {
  const vendas = App.d.vendas.filter(v => v.status === 'concluida' && v.data.slice(0, 7) === mes);
  let mercSem = 0, mercCom = 0, servSem = 0, servCom = 0;
  for (const v of vendas) {
    const bruto = soma(v.itens, i => i.total) || 1;
    const fator = v.total / bruto;
    const merc = soma(v.itens.filter(i => i.produto_id), i => i.total) * fator;
    const serv = soma(v.itens.filter(i => !i.produto_id), i => i.total) * fator;
    const comNota = !!(v.nota && v.nota.numero);
    if (comNota) { mercCom += merc; servCom += serv; } else { mercSem += merc; servSem += serv; }
  }
  return { mes, mercSem, mercCom, merc: mercSem + mercCom, servSem, servCom, serv: servSem + servCom, total: mercSem + mercCom + servSem + servCom, nVendas: vendas.length };
}

function relatorioMeiHTML(r) {
  const l = App.cfg.loja;
  const linha = (rot, v, forte) => `<tr><td>${rot}</td><td style="text-align:right;${forte ? 'font-weight:700' : ''}">${moeda(v)}</td></tr>`;
  return `<div class="documento"><h3 style="text-align:center;margin:0">RELATÓRIO MENSAL DAS RECEITAS BRUTAS</h3>
    <p><b>CNPJ:</b> ${esc(l.cnpj || '__________________')} &nbsp; <b>Empreendedor(a):</b> ${esc(l.razao_social || l.nome)}<br><b>Período de apuração:</b> ${mesLongo(r.mes)}</p>
    <table><tbody>
      <tr><td colspan="2"><b>RECEITA BRUTA MENSAL — REVENDA DE MERCADORIAS (COMÉRCIO)</b></td></tr>
      ${linha('I – Revenda de mercadorias com dispensa de emissão de documento fiscal', r.mercSem)}
      ${linha('II – Revenda de mercadorias com documento fiscal emitido', r.mercCom)}
      ${linha('III – Total das receitas com revenda de mercadorias (I + II)', r.merc, true)}
      <tr><td colspan="2"><b>RECEITA BRUTA MENSAL — VENDA DE PRODUTOS INDUSTRIALIZADOS (INDÚSTRIA)</b></td></tr>
      ${linha('IV – Venda de produtos industrializados com dispensa de emissão de documento fiscal', 0)}
      ${linha('V – Venda de produtos industrializados com documento fiscal emitido', 0)}
      ${linha('VI – Total das receitas com venda de produtos industrializados (IV + V)', 0, true)}
      <tr><td colspan="2"><b>RECEITA BRUTA MENSAL — PRESTAÇÃO DE SERVIÇOS</b></td></tr>
      ${linha('VII – Receita com prestação de serviços com dispensa de emissão de documento fiscal', r.servSem)}
      ${linha('VIII – Receita com prestação de serviços com documento fiscal emitido', r.servCom)}
      ${linha('IX – Total das receitas com prestação de serviços (VII + VIII)', r.serv, true)}
      ${linha('X – Total geral das receitas brutas no mês (III + VI + IX)', r.total, true)}
    </tbody></table>
    <p style="margin-top:24px">LOCAL E DATA: ${esc(l.cidade || '______________________')}, ${dataBR(ultimoDiaMes(r.mes))}</p>
    <p style="margin-top:40px">______________________________________<br>ASSINATURA DO EMPRESÁRIO</p>
    <p style="font-size:11px">ENCONTRAM-SE ANEXADOS A ESTE RELATÓRIO: os documentos fiscais comprobatórios das entradas de mercadorias e serviços tomados referentes ao período
    e as notas fiscais relativas às operações ou prestações realizadas eventualmente emitidas.</p></div>`;
}

App.paginas.mei = async (el, id, params) => {
  const ano = +(params.ano || hojeISO().slice(0, 4));
  const mesRel = params.mes || somarMeses(mesAtual(), -1);
  const s = situacaoMei(ano);
  const r = relatorioMensalMei(mesRel);
  const pendentes = App.d.vendas.filter(v => v.status === 'concluida' && v.nota && v.nota.pedida && !v.nota.numero).reverse();
  const tarefas = App.d.tarefas || [];
  const faltaDasn = !tarefas.some(t => /DASN/i.test(t.titulo));
  const cor = { ok: 'ok', alerta: 'alerta', erro: 'erro' }[s.nivel];
  el.innerHTML = `${ehMei() ? '' : '<div class="caixa-aviso alerta">O regime cadastrado não é MEI. Altere em Configurações › Impostos e taxas se a loja for MEI.</div>'}
    <div class="linha-acoes"><label class="campo"><span>Ano</span><select data-change="ano">${[0, 1, 2].map(k => { const a = +hojeISO().slice(0, 4) - k; return `<option ${a === ano ? 'selected' : ''}>${a}</option>`; }).join('')}</select></label>
      <span class="espaco"></span><button class="btn" data-click="config">Data de abertura e limite</button></div>
    <div class="kpis">${kpi('Faturamento no ano', moeda(s.fat.total), `${pct(s.pctUso, 0)} do limite`, `<div class="barra-prog"><div style="width:${Math.min(100, s.pctUso)}%;${s.nivel !== 'ok' ? 'background:var(--' + (s.nivel === 'erro' ? 'erro' : 'alerta') + ')' : ''}"></div></div>`)}
      ${kpi('Limite do ano', moeda(s.lim.valor), s.lim.proporcional ? `Proporcional: ${s.lim.meses} meses de atividade` : 'Limite anual do MEI')}
      ${kpi('Ainda pode faturar', `<span class="${s.restante < 0 ? 'negativo' : ''}">${moeda(s.restante)}</span>`, s.restante > 0 && String(ano) === hojeISO().slice(0, 4) ? `cerca de ${moeda(s.restante / Math.max(1, 12 - +hojeISO().slice(5, 7) + 1))} por mês até dezembro` : '')}
      ${kpi('Projeção do ano', moeda(s.projecao), 'no ritmo de vendas atual')}</div>
    <div class="caixa-aviso ${cor === 'ok' ? '' : cor}">${esc(s.texto)}</div>
    <div class="grade g-2-1"><div class="card"><h3>Faturamento por mês — ${ano}</h3>${graficoBarras(s.fat.porMes.map((v, k) => ({ rotulo: MESES_LONGOS[k], curto: MESES[k], valor: v, linha: s.lim.anual / 12 })), { linha: 'var(--alerta)' })}
        <small class="suave">Linha laranja: média mensal permitida (${moeda(s.lim.anual / 12)}).</small></div>
      <div class="card"><h3>Obrigações do MEI</h3>
        <div class="tarefa"><span style="flex:1"><b>DAS mensal</b><br><small class="suave">Vence todo dia 20. Pague pelo app MEI ou pelo Portal do Empreendedor.</small></span></div>
        <div class="tarefa"><span style="flex:1"><b>Relatório mensal de receitas</b><br><small class="suave">Preencha e guarde até o dia 20 do mês seguinte, com as notas de compra anexadas.</small></span></div>
        <div class="tarefa"><span style="flex:1"><b>DASN-SIMEI (declaração anual)</b><br><small class="suave">Entregue até 31 de maio, com o faturamento do ano anterior: ${moeda(faturamentoMei(ano - 1).total)} em ${ano - 1}.</small></span></div>
        ${faltaDasn ? '<button class="btn pequeno" data-click="lembretes" style="margin-top:8px">Adicionar lembretes à agenda</button>' : ''}</div></div>
    <div class="card"><div class="card-cab"><h3>Relatório mensal das receitas brutas</h3><div class="linha-acoes" style="margin:0">
        <select data-change="mesRel" class="input-inline">${Array.from({ length: 14 }, (_, k) => somarMeses(mesAtual(), -k)).map(m => `<option value="${m}" ${m === mesRel ? 'selected' : ''}>${mesLongo(m)}</option>`).join('')}</select>
        <button class="btn pri" data-click="imprimirRel">Imprimir</button></div></div>
      <div class="grade g2"><div class="totais">
        <div><span>Revenda de mercadorias sem nota</span><b>${moeda(r.mercSem)}</b></div><div><span>Revenda de mercadorias com nota</span><b>${moeda(r.mercCom)}</b></div>
        <div><span>Serviços sem nota</span><b>${moeda(r.servSem)}</b></div><div><span>Serviços com nota</span><b>${moeda(r.servCom)}</b></div>
        <div class="total"><span>Total do mês</span><span>${moeda(r.total)}</span></div></div>
        <p class="suave">Gerado a partir das ${r.nVendas} vendas de ${mesLongo(mesRel)}. Vendas com número de nota registrado entram como "com documento fiscal".
          Imprima, assine e guarde junto com as notas de compra de mercadorias do mês.</p></div></div>
    <div class="card"><h3>Notas fiscais pedidas</h3>
      <p class="suave">O MEI não precisa emitir nota na venda para pessoa física (consumidor), mas deve emitir quando a cliente pedir e sempre que vender para empresa (CNPJ).
        Marque "cliente pediu nota" no caixa, emita a nota no emissor do seu estado e registre o número aqui.</p><div id="tab-notas"></div></div>
    <div class="card"><h3>Mudanças previstas</h3><p class="suave">Situação em outubro de 2026 — confirme sempre com seu contador:<br>
      • A partir de 2027, a Resolução CGSN nº 195/2026 permite usar a DASN-SIMEI como documento fiscal eletrônico nas vendas para consumidor pessoa física.<br>
      • Foi noticiado um novo limite anual do MEI para 2027 (Lei Complementar nº 238/2026). Quando confirmado, atualize em "Data de abertura e limite".<br>
      • Ao deixar de ser MEI (virar ME), a emissão de NFC-e passa a ser obrigatória em São Paulo para vendas no balcão.</p></div>`;
  tabela(el.querySelector('#tab-notas'), {
    linhas: pendentes, busca: false, vazio: 'Nenhuma nota pendente.',
    colunas: [{ t: 'Venda', v: v => v.numero, cls: 'num' }, { t: 'Data', v: v => v.data, h: v => dataBR(v.data) }, { t: 'Cliente', v: v => v.cliente_nome || '' },
      { t: 'CPF/CNPJ', v: v => v.nota.documento || '', h: v => v.nota.documento ? (v.nota.documento.length === 14 ? etiqueta('CNPJ ' + v.nota.documento, 'alerta') : cpfFmt(v.nota.documento)) : '' },
      { t: 'Total', v: v => v.total, h: v => moeda(v.total), cls: 'num' }, { t: '', semOrdem: true, h: () => '<button class="btn pequeno pri" data-acao="nota">Registrar nº da nota</button>' }],
    acoes: { nota: v => registrarNota(v) }
  });
  ligar(el, {
    ano: s_ => ir(`#/mei?ano=${s_.value}&mes=${mesRel}`), mesRel: s_ => ir(`#/mei?ano=${ano}&mes=${s_.value}`),
    imprimirRel: () => imprimir(relatorioMeiHTML(r)),
    config: () => {
      const cs = [{ n: 'abertura', r: 'Data de abertura do MEI', t: 'date', w: 6, aj: 'No ano de abertura o limite é proporcional aos meses de atividade.' },
        { n: 'limite_anual', r: 'Limite anual (R$)', t: 'money', w: 6, aj: 'R$ 81.000 em 2026. Atualize se a lei mudar.' },
        { n: 'cnpj_avisar', r: 'Avisar no caixa quando a venda for para CNPJ', t: 'check', w: 12 }];
      modal({ titulo: 'Dados do MEI', corpo: formHTML(cs, App.cfg.mei || {}), botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => {
        await api('config', { config: { mei: { ...(App.cfg.mei || {}), ...lerForm(m, cs) } } }); await carregar([]); recarregarPagina(); } }] });
    },
    lembretes: async () => {
      await api('salvar/tarefas', { obj: { titulo: 'Entregar a DASN-SIMEI (declaração anual do MEI) — prazo 31/05', recorrencia: 'anual', data: '05-15', ativo: true, feitas: {} } });
      await api('salvar/tarefas', { obj: { titulo: 'Preencher o relatório mensal de receitas do MEI', recorrencia: 'mensal', dia_mes: 5, ativo: true, feitas: {} } });
      toast('Lembretes adicionados à agenda.', 'ok'); recarregarPagina();
    }
  });
};

function registrarNota(v) {
  const cs = [{ n: 'numero', r: 'Número da nota fiscal', w: 12, obr: 1, aj: 'Número da NF-e emitida no emissor do seu estado.' }];
  modal({ titulo: `Nota da venda nº ${v.numero}`, corpo: formHTML(cs, v.nota || {}), botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => {
    await api('venda/nota', { id: v.id, ...lerForm(m, cs) }); toast('Número da nota registrado.', 'ok'); recarregarPagina(); } }] });
}
