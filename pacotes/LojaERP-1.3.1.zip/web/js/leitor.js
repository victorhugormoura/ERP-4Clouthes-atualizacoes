/* Loja ERP — leitor de códigos pela câmera (celular ou webcam) e leitura de boleto e Pix.
   Usa o leitor nativo do navegador (BarcodeDetector) quando existe; senão, um decodificador próprio
   para Code 128 (etiquetas do sistema), EAN-13/EAN-8/UPC-A (código de fábrica) e ITF (boleto e caixa).
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const Leitor = (() => {
  /* ------------------------------------------------------------ utilidades de faixas */
  function faixas(linha, ini, fim) {
    // Binariza a linha com limiar local (meio entre o mais claro e o mais escuro por perto)
    // e devolve as larguras alternadas, começando por uma barra escura.
    const n = fim - ini, suave = new Float32Array(n);
    for (let i = 0; i < n; i++) suave[i] = linha[ini + i];
    let mn = 255, mx = 0;
    for (const v of suave) { if (v < mn) mn = v; if (v > mx) mx = v; }
    if (mx - mn < 40) return null;
    const janela = Math.max(12, Math.round(n / 60)), limiares = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      let lmn = 255, lmx = 0;
      for (let k = Math.max(0, i - janela); k < Math.min(n, i + janela); k++) { const v = suave[k]; if (v < lmn) lmn = v; if (v > lmx) lmx = v; }
      limiares[i] = lmx - lmn < (mx - mn) / 4 ? (mn + mx) / 2 : (lmn + lmx) / 2;
    }
    // Bordas com precisão de fração de pixel: interpola onde o sinal cruza o limiar.
    const larg = [];
    let cor = null, borda = 0, antes = 0, limAntes = 0;
    for (let i = 0; i < n; i++) {
      const limiar = limiares[i];
      const escuro = suave[i] < limiar;
      if (cor === null) { if (escuro) { cor = true; borda = i; } }
      else if (escuro !== cor) {
        const d = (suave[i] - limiar) - (antes - limAntes);
        const pos = i - 1 + (d ? Math.min(1, Math.max(0, -(antes - limAntes) / d)) : 0.5);
        larg.push(pos - borda); borda = pos; cor = escuro;
      }
      antes = suave[i]; limAntes = limiar;
    }
    if (cor) larg.push(n - borda);
    return larg.length > 20 ? larg : null;
  }

  function erro(trecho, padrao, modulos) {
    // Compara larguras e também somas de vizinhos (borda a borda), que não mudam quando a tinta
    // "engorda" as barras ou a imagem está desfocada.
    const soma = trecho.reduce((a, b) => a + b, 0), f = modulos / soma;
    let e = 0, b = 0;
    for (let i = 0; i < trecho.length; i++) {
      e += Math.abs(trecho[i] * f - padrao[i]);
      if (i) b += Math.abs((trecho[i] + trecho[i - 1]) * f - padrao[i] - padrao[i - 1]);
    }
    return b + 0.35 * e;
  }

  /* ------------------------------------------------------------------- Code 128 */
  const P128 = C128.map(p => p.split('').map(Number));
  function code128(r) {
    for (let i = 0; i + 30 < r.length; i += 2) {
      const ini = r.slice(i, i + 6);
      const inicio = [103, 104, 105].find(k => erro(ini, P128[k], 11) < 1.6);
      if (inicio === undefined) continue;
      const valores = [inicio];
      let j = i + 6, fim = false;
      while (j + 6 <= r.length) {
        if (j + 7 <= r.length && erro(r.slice(j, j + 7), P128[106], 13) < 2) { fim = true; break; }
        const t = r.slice(j, j + 6);
        let melhor = -1, menor = 9;
        for (let k = 0; k < 106; k++) { const e = erro(t, P128[k], 11); if (e < menor) { menor = e; melhor = k; } }
        if (menor > 2.2) break;
        valores.push(melhor); j += 6;
      }
      if (!fim || valores.length < 3) continue;
      const cs = valores.pop();
      let soma = valores[0];
      for (let k = 1; k < valores.length; k++) soma += valores[k] * k;
      if (soma % 103 !== cs) continue;
      let conj = { 103: 'A', 104: 'B', 105: 'C' }[valores[0]], txt = '', troca = null;
      for (let k = 1; k < valores.length; k++) {
        const v = valores[k], atual = troca || conj; troca = null;
        if (atual === 'C' && v < 100) { txt += String(v).padStart(2, '0'); continue; }
        if (v === 98 && atual !== 'C') { troca = atual === 'A' ? 'B' : 'A'; continue; }
        if (v === 99) { conj = 'C'; continue; }
        if (v === 100) { if (atual !== 'B') conj = 'B'; continue; }
        if (v === 101) { if (atual !== 'A') conj = 'A'; continue; }
        if (v === 102) continue;
        if (atual === 'A') txt += String.fromCharCode(v < 64 ? v + 32 : v - 64);
        else if (atual === 'B' && v < 96) txt += String.fromCharCode(v + 32);
      }
      if (txt) return { formato: 'code_128', texto: txt };
    }
    return null;
  }

  /* --------------------------------------------------------------- EAN / UPC */
  const L = ['3211', '2221', '2122', '1411', '1132', '1231', '1114', '1312', '1213', '3112'].map(p => p.split('').map(Number));
  const G = L.map(p => p.slice().reverse());
  const PARIDADE = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];
  function digito(t, comG) {
    let melhor = null, menor = 1.8;
    for (let d = 0; d < 10; d++) {
      const e = erro(t, L[d], 7); if (e < menor) { menor = e; melhor = { d, g: false }; }
      if (comG) { const e2 = erro(t, G[d], 7); if (e2 < menor) { menor = e2; melhor = { d, g: true }; } }
    }
    return melhor;
  }
  function verificaGTIN(s) {
    let soma = 0;
    for (let i = 0; i < s.length - 1; i++) soma += +s[s.length - 2 - i] * (i % 2 === 0 ? 3 : 1);
    return (10 - soma % 10) % 10 === +s[s.length - 1];
  }
  function ean(r) {
    for (let i = 0; i + 43 <= r.length; i += 2) {
      const m = (r[i] + r[i + 1] + r[i + 2]) / 3;
      if (Math.abs(r[i] - m) > m * 0.6 || Math.abs(r[i + 2] - m) > m * 0.6) continue;
      if (i > 0 && r[i - 1] < m * 5) continue;   // precisa de margem clara antes
      for (const [qtd, total, mods] of [[6, 59, 95], [4, 43, 67]]) {
        if (i + total > r.length) continue;
        // margem clara depois do código e largura total coerente com as guardas
        if (i + total < r.length && r[i + total] < m * 5) continue;
        let largura = 0;
        for (let k = i; k < i + total; k++) largura += r[k];
        if (largura / mods < m * 0.7 || largura / mods > m * 1.4) continue;
        let ok = true, txt = '', par = '';
        for (let k = 0; k < qtd && ok; k++) {
          const d = digito(r.slice(i + 3 + 4 * k, i + 7 + 4 * k), qtd === 6);
          if (!d) ok = false; else { txt += d.d; par += d.g ? 'G' : 'L'; }
        }
        if (!ok) continue;
        const meio = i + 3 + 4 * qtd;
        if (erro(r.slice(meio, meio + 5), [1, 1, 1, 1, 1], 5) > 2.2) continue;
        for (let k = 0; k < qtd && ok; k++) {
          const d = digito(r.slice(meio + 5 + 4 * k, meio + 9 + 4 * k), false);
          if (!d) ok = false; else txt += d.d;
        }
        if (!ok) continue;
        if (qtd === 6) {
          const pri = PARIDADE.indexOf(par);
          if (pri < 0) continue;
          txt = pri + txt;
        }
        if (verificaGTIN(txt)) return { formato: qtd === 6 ? 'ean_13' : 'ean_8', texto: txt };
      }
    }
    return null;
  }

  /* -------------------------------------------------------- ITF (intercalado 2 de 5) */
  const ITF = ['00110', '10001', '01001', '11000', '00101', '10100', '01100', '00011', '10010', '01010'];
  function itf(r) {
    for (let i = 0; i + 17 <= r.length; i += 2) {
      const n = (r[i] + r[i + 1] + r[i + 2] + r[i + 3]) / 4;
      if ([0, 1, 2, 3].some(k => Math.abs(r[i + k] - n) > n * 0.55)) continue;
      if (i > 0 && r[i - 1] < n * 6) continue;
      let j = i + 4, txt = '';
      while (j + 3 <= r.length) {
        if (r[j] > n * 1.8 && r[j + 1] < n * 1.8 && r[j + 2] < n * 1.8 && txt.length >= 2 &&
            (j + 3 === r.length || r[j + 3] > n * 6)) break;
        if (j + 10 > r.length) { txt = ''; break; }
        const bar = [r[j], r[j + 2], r[j + 4], r[j + 6], r[j + 8]], esp = [r[j + 1], r[j + 3], r[j + 5], r[j + 7], r[j + 9]];
        const cod = x => {
          const ord = x.slice().sort((a, b) => b - a);
          if (ord[1] < ord[2] * 1.5) return -1;
          const lim = (ord[1] + ord[2]) / 2;
          return ITF.indexOf(x.map(v => (v > lim ? '1' : '0')).join(''));
        };
        const a = cod(bar), b = cod(esp);
        if (a < 0 || b < 0) { txt = ''; break; }
        txt += a + '' + b; j += 10;
      }
      if (txt.length === 14 && verificaGTIN(txt)) return { formato: 'itf', texto: txt };
      if (txt.length === 44 && Pagamento.boletoValido(txt)) return { formato: 'itf', texto: txt };
    }
    return null;
  }

  function decodificarImagem(dados, largura, altura) {
    // Linhas horizontais pela faixa central da imagem; tenta nos dois sentidos.
    const linha = new Uint8ClampedArray(largura);
    const passos = 17, linhas = [];
    for (let k = 0; k < passos; k++) {
      const y = Math.round(altura * (0.3 + 0.4 * k / (passos - 1)));
      for (let x = 0; x < largura; x++) {
        const p = (y * largura + x) * 4;
        linha[x] = (dados[p] * 77 + dados[p + 1] * 150 + dados[p + 2] * 29) >> 8;
      }
      const r = faixas(linha, Math.round(largura * 0.02), Math.round(largura * 0.98));
      if (!r) continue;
      linhas.push(r, r.slice().reverse());
    }
    // Code 128 primeiro em todas as linhas (é o das etiquetas); depois EAN e ITF, que têm menos conferência.
    for (const decod of [code128, ean, itf]) {
      for (const seq of linhas) { const achado = decod(seq); if (achado) return achado; }
    }
    return null;
  }

  /* --------------------------------------------------------------- câmera */
  function disponivel() { return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.isSecureContext); }

  async function nativo() {
    if (!('BarcodeDetector' in window)) return null;
    try {
      const suportados = await BarcodeDetector.getSupportedFormats();
      const queremos = ['qr_code', 'code_128', 'ean_13', 'ean_8', 'upc_a', 'itf'].filter(f => suportados.includes(f));
      return queremos.length ? new BarcodeDetector({ formats: queremos }) : null;
    } catch (e) { return null; }
  }

  /* Abre a câmera e devolve o texto lido (ou null se a pessoa fechar). */
  function ler({ titulo = 'Ler código', dica = 'Aponte a câmera para o código de barras ou QR Code.', digitar = true } = {}) {
    return new Promise(async resolver => {
      let terminado = false, fluxo = null, detector = null, timer = null;
      const m = modal({ titulo, largura: 'largo', corpo: `<div class="leitor">
          <div class="leitor-video"><video playsinline muted></video><div class="leitor-mira"></div></div>
          <p class="suave" id="leitor-dica">${esc(dica)}</p>
          ${digitar ? `<form class="linha-acoes" id="leitor-form"><input id="leitor-texto" placeholder="Ou digite / cole o código aqui" autocomplete="off" style="flex:1">
          <button class="btn">Usar</button></form>` : ''}</div>`, botoes: [{ texto: 'Fechar' }] });
      const acabar = valor => {
        if (terminado) return; terminado = true;
        clearTimeout(timer);
        if (fluxo) fluxo.getTracks().forEach(t => t.stop());
        if (m.isConnected) m.fechar();
        resolver(valor);
      };
      new MutationObserver((_, obs) => { if (!m.isConnected) { obs.disconnect(); acabar(null); } }).observe(document.getElementById('modais'), { childList: true });
      const form = m.querySelector('#leitor-form');
      if (form) form.onsubmit = e => { e.preventDefault(); const v = m.querySelector('#leitor-texto').value.trim(); if (v) acabar(v); };
      if (!disponivel()) {
        m.querySelector('.leitor-video').hidden = true;
        m.querySelector('#leitor-dica').textContent = 'A câmera não está disponível nesta tela. Digite o código abaixo.';
        return;
      }
      const video = m.querySelector('video');
      try {
        fluxo = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
      } catch (e) {
        m.querySelector('.leitor-video').hidden = true;
        m.querySelector('#leitor-dica').textContent = e.name === 'NotAllowedError'
          ? 'A câmera foi bloqueada. Toque no cadeado da barra de endereço, permita a câmera e tente de novo — ou digite o código abaixo.'
          : 'Não foi possível abrir a câmera. Digite o código abaixo.';
        return;
      }
      if (terminado) { fluxo.getTracks().forEach(t => t.stop()); return; }
      video.srcObject = fluxo;
      await video.play().catch(() => {});
      detector = await nativo();
      const tela = document.createElement('canvas'), ctx = tela.getContext('2d', { willReadFrequently: true });
      let iguais = 0, anterior = '';
      const quadro = async () => {
        if (terminado) return;
        let achado = null;
        try {
          if (detector) {
            const r = await detector.detect(video);
            if (r.length) achado = { formato: r[0].format, texto: r[0].rawValue };
          }
          if (!achado && video.videoWidth) {
            const w = Math.min(1920, video.videoWidth), h = Math.round(video.videoHeight * w / video.videoWidth);
            tela.width = w; tela.height = h;
            ctx.drawImage(video, 0, 0, w, h);
            achado = decodificarImagem(ctx.getImageData(0, 0, w, h).data, w, h);
          }
        } catch (e) { /* quadro incompleto: tenta o próximo */ }
        if (achado) {
          // Leitura própria precisa se repetir em dois quadros para evitar engano; a nativa já confere.
          if (detector || achado.texto === anterior) { iguais = 2; } else { anterior = achado.texto; iguais = 1; }
          if (iguais >= 2) { if (navigator.vibrate) navigator.vibrate(80); return acabar(achado.texto); }
        }
        timer = setTimeout(quadro, 120);
      };
      quadro();
    });
  }

  /* Botão "Câmera" ao lado de um campo: lê e coloca o valor no campo. */
  function botao(campo, aoLer, titulo) {
    if (!disponivel() || campo.dataset.camera) return;
    campo.dataset.camera = '1';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'btn pequeno btn-camera'; b.textContent = 'Câmera'; b.title = 'Ler com a câmera';
    b.onclick = async () => {
      const v = await ler({ titulo: titulo || 'Ler código de barras' });
      if (v === null) return;
      campo.value = v;
      campo.dispatchEvent(new Event('input', { bubbles: true }));
      if (aoLer) aoLer(v);
    };
    campo.insertAdjacentElement('afterend', b);
  }

  return { ler, botao, disponivel, decodificarImagem };
})();

/* ------------------------------------------------- boleto, convênio e Pix (contas a pagar) */
const Pagamento = (() => {
  const so = s => String(s || '').replace(/\D/g, '');
  function mod10(num) {
    let soma = 0, peso = 2;
    for (let i = num.length - 1; i >= 0; i--) { let p = +num[i] * peso; if (p > 9) p = Math.floor(p / 10) + (p % 10); soma += p; peso = peso === 2 ? 1 : 2; }
    return (10 - soma % 10) % 10;
  }
  function mod11(num, arrecadacao) {
    let soma = 0, peso = 2;
    for (let i = num.length - 1; i >= 0; i--) { soma += +num[i] * peso; peso = peso === 9 ? 2 : peso + 1; }
    const r = soma % 11;
    if (arrecadacao) return r === 0 || r === 1 ? 0 : (r === 10 ? 1 : 11 - r);
    const d = 11 - r;
    return d === 0 || d === 10 || d === 11 ? 1 : d;
  }
  function boletoValido(b) {
    if (!/^\d{44}$/.test(b)) return false;
    if (b[0] === '8') {
      const sem = b.slice(0, 3) + b.slice(4);
      return (['6', '7'].includes(b[2]) ? mod10(sem) : mod11(sem, true)) === +b[3];
    }
    return mod11(b.slice(0, 4) + b.slice(5)) === +b[4];
  }
  function linhaParaBarras(l) {
    if (l.length === 47) return l.slice(0, 4) + l[32] + l.slice(33, 47) + l.slice(4, 9) + l.slice(10, 20) + l.slice(21, 31);
    if (l.length === 48) return l.slice(0, 11) + l.slice(12, 23) + l.slice(24, 35) + l.slice(36, 47);
    return l;
  }
  function vencimentoPorFator(fator) {
    if (!fator) return '';
    const dia = 86400000, hoje = Date.now();
    const candidatos = [Date.UTC(1997, 9, 7) + fator * dia, Date.UTC(2025, 1, 22) + (fator - 1000) * dia];
    const melhor = candidatos.reduce((a, b) => (Math.abs(b - hoje) < Math.abs(a - hoje) ? b : a));
    return new Date(melhor).toISOString().slice(0, 10);
  }
  const BANCOS = { '001': 'Banco do Brasil', '033': 'Santander', '104': 'Caixa', '237': 'Bradesco', '341': 'Itaú', '077': 'Inter',
    '260': 'Nubank', '336': 'C6 Bank', '748': 'Sicredi', '756': 'Sicoob', '422': 'Safra', '041': 'Banrisul', '208': 'BTG Pactual', '212': 'Banco Original' };
  function boleto(texto) {
    const b = linhaParaBarras(so(texto));
    if (!boletoValido(b)) return null;
    if (b[0] === '8') {
      const efetivo = ['6', '8'].includes(b[2]);
      const seg = { 1: 'Prefeitura', 2: 'Saneamento', 3: 'Energia e gás', 4: 'Telecomunicações', 5: 'Órgão público', 6: 'Carnê/convênio', 7: 'Multa de trânsito', 9: 'Uso exclusivo do banco' }[b[1]] || 'Convênio';
      return { tipo: 'convenio', codigo: b, valor: efetivo ? +b.slice(4, 15) / 100 : 0, vencimento: '', descricao: `Conta de ${seg}` };
    }
    return { tipo: 'boleto', codigo: b, valor: +b.slice(9, 19) / 100, vencimento: vencimentoPorFator(+b.slice(5, 9)),
      descricao: `Boleto ${BANCOS[b.slice(0, 3)] || 'banco ' + b.slice(0, 3)}` };
  }
  function tlv(s) {
    const r = {};
    for (let i = 0; i + 4 <= s.length;) {
      const id = s.slice(i, i + 2), n = +s.slice(i + 2, i + 4);
      if (Number.isNaN(n)) break;
      r[id] = s.slice(i + 4, i + 4 + n); i += 4 + n;
    }
    return r;
  }
  function pix(texto) {
    const s = String(texto || '').trim();
    if (!s.startsWith('000201') || !/6304[0-9A-Fa-f]{4}$/.test(s)) return null;
    if (crc16(s.slice(0, -4)).toUpperCase() !== s.slice(-4).toUpperCase()) return null;
    const t = tlv(s), conta = tlv(t['26'] || '');
    const nome = (t['59'] || '').trim();
    return { tipo: 'pix', codigo: s, valor: t['54'] ? +t['54'] : 0, vencimento: hojeISO(), recebedor: nome, cidade: t['60'] || '',
      chave: conta['01'] || '', dinamico: !!conta['25'], descricao: nome ? `Pix para ${nome}` : 'Pagamento Pix' };
  }
  function interpretar(texto) { return pix(texto) || boleto(texto); }
  return { interpretar, boleto, pix, boletoValido, linhaParaBarras, vencimentoPorFator };
})();

/* Lê um boleto, conta de consumo ou QR Code Pix e abre a conta a pagar já preenchida. */
async function contaPorCodigo() {
  const lido = await Leitor.ler({ titulo: 'Ler boleto ou Pix', dica: 'Boleto: deite o celular e enquadre o código de barras inteiro. Pix: aponte para o QR Code. Também dá para colar a linha digitável ou o "Pix copia e cola".' });
  if (lido === null) return;
  const info = Pagamento.interpretar(lido);
  if (!info) return toast('Não reconheci esse código como boleto, conta ou Pix. Confira e tente de novo.', 'erro');
  const obs = info.tipo === 'pix' ? `Pix copia e cola: ${info.codigo}` : `Código de barras: ${info.codigo}`;
  const forn = info.recebedor ? (App.d.fornecedores.find(f => semAcento(f.nome).includes(semAcento(info.recebedor).slice(0, 12))) || {}).id : '';
  novoLancamento('pagar', { descricao: info.descricao, valor: info.valor || '', vencimento: info.vencimento || hojeISO(),
    forma: info.tipo === 'pix' ? 'pix' : 'boleto', obs, fornecedor_id: forn || '' });
  if (!info.valor) toast('Este código não traz o valor. Preencha o valor da conta.', 'alerta');
}
