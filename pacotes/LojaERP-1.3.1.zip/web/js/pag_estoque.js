/* Loja ERP — produtos, estoque, entradas de mercadoria, movimentações, inventário e etiquetas.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const GENEROS = [['Feminino', 'Feminino'], ['Masculino', 'Masculino'], ['Unissex', 'Unissex'], ['Infantil', 'Infantil']];

/* ---------------------------------------------------------------- produtos */
App.paginas.produtos = async (el, id, params) => {
  const st = { cat: params.cat || '', col: '', situacao: 'ativos' };
  el.innerHTML = `<div class="card"><div class="linha-acoes">
      <label class="campo"><span>Categoria</span><select data-change="cat"><option value="">Todas</option>${opcoes(App.d.categorias).map(([k, t]) => `<option value="${k}" ${k === st.cat ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>
      <label class="campo"><span>Coleção</span><select data-change="col"><option value="">Todas</option>${opcoes(App.d.colecoes).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></label>
      <label class="campo"><span>Situação</span><select data-change="sit"><option value="ativos">Ativos</option><option value="inativos">Inativos</option><option value="todos">Todos</option></select></label>
      <span class="espaco"></span><a class="btn" href="#/etiquetas">Etiquetas</a><a class="btn pri" href="#/produto/novo">Novo produto</a></div><div id="tab-prod"></div></div>`;
  const filtrar = () => App.d.produtos.filter(p => (!st.cat || p.categoria_id === st.cat) && (!st.col || p.colecao_id === st.col) &&
    (st.situacao === 'todos' || (st.situacao === 'ativos' ? p.ativo !== false : p.ativo === false)));
  const t = tabela(el.querySelector('#tab-prod'), {
    linhas: filtrar(), exportar: 'produtos', placeholder: 'Nome, SKU, cor, código de barras...',
    textoBusca: p => p.variacoes.map(v => `${v.cor} ${v.codigo_barras}`).join(' ') + ' ' + (p.tags || ''),
    colunas: [
      { t: '', semOrdem: true, h: p => fotoHTML(p) },
      { t: 'SKU', v: p => p.sku }, { t: 'Produto', v: p => p.nome, h: p => `<b>${esc(p.nome)}</b>${p.ativo === false ? ' ' + etiqueta('inativo') : ''}<br><small class="suave">${esc([...new Set(p.variacoes.map(v => v.tamanho))].join(' ') + ' · ' + [...new Set(p.variacoes.map(v => v.cor))].join(', '))}</small>` },
      { t: 'Categoria', v: p => (App.idx.cat[p.categoria_id] || {}).nome || '' }, { t: 'Coleção', v: p => (App.idx.col[p.colecao_id] || {}).nome || '' },
      { t: 'Custo', v: p => n(p.custo), h: p => moeda(p.custo), cls: 'num' }, { t: 'Preço', v: p => n(p.preco), h: p => `<b>${moeda(p.preco)}</b>`, cls: 'num' },
      { t: 'Markup', v: p => p.custo ? p.preco / p.custo : 0, h: p => p.custo ? numBR(p.preco / p.custo, 2) + 'x' : '—', cls: 'num' },
      { t: 'Margem contrib.', v: p => analisePreco(n(p.custo), n(p.preco)).margemContribuicao, h: p => { const m = analisePreco(n(p.custo), n(p.preco)).margemContribuicao; return `<span class="${m < 25 ? 'negativo' : ''}">${pct(m)}</span>`; }, cls: 'num' },
      { t: 'Estoque', v: p => estoqueProduto(p), h: p => { const e = estoqueProduto(p); const baixo = p.variacoes.some(v => v.estoque <= n(v.estoque_min)); return `<span class="${e <= 0 ? 'negativo' : baixo ? 'forte' : ''}">${e}</span>`; }, cls: 'num' }
    ],
    aoClicar: p => ir('#/produto/' + p.id)
  });
  ligar(el, { cat: s => { st.cat = s.value; t.atualizar(filtrar()); }, col: s => { st.col = s.value; t.atualizar(filtrar()); }, sit: s => { st.situacao = s.value; t.atualizar(filtrar()); } });
};

App.paginas.produto = async (el, id, params) => {
  const orig = id && id !== 'novo' ? App.idx.prod[id] : null;
  const base = params.copiar ? App.idx.prod[params.copiar] : null;
  if (id && id !== 'novo' && !orig) { el.innerHTML = '<div class="card vazio">Produto não encontrado.</div>'; return; }
  const p = orig ? JSON.parse(JSON.stringify(orig)) : base ? { ...JSON.parse(JSON.stringify(base)), id: null, sku: '', nome: base.nome + ' (cópia)', variacoes: base.variacoes.map(v => ({ tamanho: v.tamanho, cor: v.cor, estoque_min: v.estoque_min })) } :
    { ativo: true, genero: 'Feminino', variacoes: [], custo: '', preco: '' };
  const st = { vars: p.variacoes.map(v => ({ ...v })) };
  document.getElementById('titulo').textContent = orig ? `Produto ${orig.sku}` : 'Novo produto';
  const campos = [
    { sec: 'Identificação' },
    { n: 'nome', r: 'Nome do produto', w: 8, obr: 1, ph: 'ex.: Vestido Midi Floral' }, { n: 'sku', r: 'Código (SKU)', w: 4, ph: 'automático' },
    { n: 'categoria_id', r: 'Categoria', t: 'select', w: 4, op: () => opcoes(App.d.categorias), obr: 1, dataChange: 'precos' },
    { n: 'colecao_id', r: 'Coleção', t: 'select', w: 4, op: () => opcoes(App.d.colecoes) }, { n: 'genero', r: 'Público', t: 'select', w: 4, op: GENEROS, vazio: false },
    { n: 'marca_id', r: 'Marca', t: 'select', w: 4, op: () => opcoes(App.d.marcas) }, { n: 'fornecedor_id', r: 'Fornecedor', t: 'select', w: 4, op: () => opcoes(App.d.fornecedores) },
    { n: 'referencia', r: 'Referência do fornecedor', w: 4 },
    { n: 'tags', r: 'Palavras-chave', w: 8, ph: 'ex.: festa, linho, verão', aj: 'Ajudam na busca do caixa.' }, { n: 'localizacao', r: 'Localização na loja', w: 4, ph: 'ex.: arara 3' },
    { n: 'ncm', r: 'NCM (opcional)', w: 4, aj: 'Para quando emitir nota fiscal.' }, { n: 'ativo', r: 'Produto ativo (aparece no caixa)', t: 'check', w: 8 },
    { n: 'descricao', r: 'Descrição / tecido / cuidados', t: 'textarea', w: 12 },
    { sec: 'Preço' },
    { n: 'custo', r: 'Custo unitário (R$)', t: 'money', w: 4, dataInput: 'precos', aj: orig ? 'Atualizado automaticamente pelo custo médio das entradas.' : 'Valor pago ao fornecedor por peça.' },
    { n: 'preco', r: 'Preço de venda (R$)', t: 'money', w: 4, obr: 1, dataInput: 'precos' }
  ];
  el.innerHTML = `<div class="grade g-2-1"><div class="card" id="form-prod">${formHTML(campos, p)}
      <div id="analise" style="margin-top:12px"></div>
      <div class="titulo-secao" style="margin-top:18px;font-weight:600;border-bottom:1px solid var(--borda);padding-bottom:4px">Grade (tamanhos e cores)</div>
      <div class="grade-form" style="margin-top:10px">
        <label class="campo w4"><span>Grade de tamanhos</span><select id="g-grade" data-change="grade">${Object.entries(App.cfg.grades || {}).map(([k, v]) => `<option value="${esc(v)}">${esc(k)} (${esc(v)})</option>`).join('')}<option value="">Personalizada…</option></select>
          <input id="g-pers" placeholder="ex.: 36,38,40" hidden style="margin-top:6px"></label>
        <label class="campo w5"><span>Cores (separadas por vírgula)</span><input id="g-cores" list="lista-cores" placeholder="ex.: Preto, Off-white"></label>
        <label class="campo w3"><span>Estoque inicial por variação</span><input id="g-qtd" type="number" min="0" value="0"></label>
        <datalist id="lista-cores">${String(App.cfg.cores || '').split(',').map(c => `<option value="${esc(c.trim())}">`).join('')}</datalist>
        <div class="w12"><button class="btn" data-click="gerar">Gerar variações</button> <button class="btn" data-click="addVar">Adicionar uma variação</button></div>
      </div>
      <div id="vars" style="margin-top:12px"></div>
      <div class="linha-acoes" style="margin-top:18px"><a class="btn" href="#/produtos">Voltar</a>
        ${orig ? `<button class="btn" data-click="copiar">Duplicar</button><button class="btn" data-click="etiquetas">Etiquetas</button><button class="btn perigo" data-click="excluir">Excluir</button>` : ''}
        <span class="espaco"></span><button class="btn pri grande" data-click="salvar">Salvar produto</button></div></div>
    <div><div class="card"><h3>Foto</h3><div class="foto-produto" id="foto">${p.foto ? `<img src="/fotos/${esc(p.foto)}" alt="">` : 'Sem foto'}</div>
      <input type="file" accept="image/*" id="foto-arq" style="margin-top:10px"><input type="hidden" name="foto" value="${esc(p.foto || '')}" form="x">
      ${p.foto ? '<button class="btn pequeno perigo" data-click="semFoto" style="margin-top:8px">Remover foto</button>' : ''}</div>
      ${orig ? `<div class="card"><h3>Histórico</h3>${resumoHistoricoProduto(orig)}</div>` : ''}</div></div>`;
  const form = el.querySelector('#form-prod');
  let foto = p.foto || '';
  function analise() {
    const custo = n(form.querySelector('[name=custo]').value), preco = n(form.querySelector('[name=preco]').value);
    const cat = form.querySelector('[name=categoria_id]').value;
    const s = sugestaoPreco(custo, cat), a = analisePreco(custo, preco);
    el.querySelector('#analise').innerHTML = custo > 0 ? `<div class="preco-sugestao"><div class="grade g2">
      <div><div class="linha"><span>Pela margem (${pct(s.margem, 0)} lucro + ${pct(s.custosPct, 1)} custos)</span><span><b>${moeda(s.porMargem)}</b> <button class="btn pequeno" data-usar="${s.porMargem}">Usar</button></span></div>
        <div class="linha"><span>Pelo markup (${numBR(s.markup, 2)}x)</span><span><b>${moeda(s.porMarkup)}</b> <button class="btn pequeno" data-usar="${s.porMarkup}">Usar</button></span></div>
        <small class="suave">Custos considerados: imposto ${pct(impostoVendaPct())}, cartão ${pct(n(App.cfg.precificacao.taxa_cartao_media))}, comissão ${pct(n(App.cfg.precificacao.comissao))}, despesas fixas ${pct(n(App.cfg.precificacao.despesas_fixas_pct))}. Ajuste em Configurações.</small></div>
      <div>${preco > 0 ? `<div class="linha"><span>Markup</span><b>${numBR(a.markup, 2)}x</b></div><div class="linha"><span>Margem bruta</span><b>${pct(a.margemBruta)}</b></div>
        <div class="linha"><span>Margem de contribuição</span><b>${moeda(a.contribuicao)} (${pct(a.margemContribuicao)})</b></div>
        <div class="linha"><span>Lucro líquido estimado por peça</span><b class="${a.lucroLiquido < 0 ? 'negativo' : 'positivo'}">${moeda(a.lucroLiquido)} (${pct(a.margemLiquida)})</b></div>` : '<span class="suave">Informe o preço para ver a análise.</span>'}</div></div></div>` : '<small class="suave">Informe o custo para ver o preço sugerido.</small>';
    el.querySelectorAll('[data-usar]').forEach(b => b.onclick = () => { form.querySelector('[name=preco]').value = b.dataset.usar; analise(); });
  }
  function lerVars() {
    el.querySelectorAll('#vars tr[data-k]').forEach(tr => {
      const v = st.vars[+tr.dataset.k];
      tr.querySelectorAll('[data-c]').forEach(inp => { v[inp.dataset.c] = ['estoque_min', 'estoque_inicial'].includes(inp.dataset.c) ? Math.max(0, Math.round(n(inp.value))) : inp.value.trim(); });
    });
  }
  function renderVars() {
    el.querySelector('#vars').innerHTML = st.vars.length ? `<div class="tabela-wrap"><table class="tab"><thead><tr><th>Tamanho</th><th>Cor</th><th>Código de barras</th><th class="th-num">Estoque</th><th class="th-num">Mínimo</th><th></th></tr></thead><tbody>
      ${st.vars.map((v, k) => `<tr data-k="${k}"><td><input data-c="tamanho" value="${esc(v.tamanho || '')}" style="width:80px"></td><td><input data-c="cor" list="lista-cores" value="${esc(v.cor || '')}"></td>
        <td><input data-c="codigo_barras" value="${esc(v.codigo_barras || '')}" placeholder="automático"></td>
        <td class="num">${v.id ? `<b>${v.estoque}</b>` : `<input type="number" min="0" class="input-qtd" data-c="estoque_inicial" value="${v.estoque_inicial || 0}" title="Estoque inicial">`}</td>
        <td class="num"><input type="number" min="0" class="input-qtd" data-c="estoque_min" value="${v.estoque_min ?? 1}"></td>
        <td><button class="btn pequeno perigo" data-rem="${k}" ${v.id && v.estoque ? 'disabled title="Zere o estoque antes"' : ''}>Remover</button></td></tr>`).join('')}</tbody></table></div>
      <small class="suave">O estoque de variações existentes só muda por entradas, vendas e ajustes — assim tudo fica registrado.</small>` : '<p class="vazio">Nenhuma variação. Escolha a grade e as cores e clique em "Gerar variações".</p>';
    el.querySelectorAll('[data-rem]').forEach(b => b.onclick = () => { lerVars(); st.vars.splice(+b.dataset.rem, 1); renderVars(); });
    if (App.celular) el.querySelectorAll('#vars [data-c=codigo_barras]').forEach(i => Leitor.botao(i, null, 'Código de barras da peça'));
  }
  el.querySelector('#foto-arq').onchange = async e => {
    const arq = e.target.files[0]; if (!arq) return;
    try { const img = await redimensionarImagem(arq); const r = await api('foto', { imagem: img }); foto = r.arquivo; el.querySelector('#foto').innerHTML = `<img src="/fotos/${esc(foto)}" alt="">`; toast('Foto carregada. Salve o produto.', 'ok'); }
    catch (err) { toast(err.message, 'erro'); }
  };
  ligar(el, {
    precos: () => analise(),
    grade: s => { const p = el.querySelector('#g-pers'); p.hidden = !!s.value; if (!s.value) p.focus(); },
    gerar: () => {
      lerVars();
      const grade = el.querySelector('#g-grade').value || el.querySelector('#g-pers').value;
      const tams = grade.split(',').map(x => x.trim()).filter(Boolean);
      const cores = (el.querySelector('#g-cores').value || 'Única').split(',').map(x => x.trim()).filter(Boolean);
      const qtd = Math.max(0, Math.round(n(el.querySelector('#g-qtd').value)));
      let novos = 0;
      for (const c of cores) for (const t of tams) {
        if (!st.vars.some(v => String(v.tamanho).toUpperCase() === t.toUpperCase() && String(v.cor).toUpperCase() === c.toUpperCase())) { st.vars.push({ tamanho: t, cor: c, estoque_inicial: qtd, estoque_min: 1 }); novos++; }
      }
      renderVars(); toast(`${novos} variação(ões) adicionada(s).`);
    },
    addVar: () => { lerVars(); st.vars.push({ tamanho: '', cor: '', estoque_inicial: 0, estoque_min: 1 }); renderVars(); },
    semFoto: () => { foto = ''; el.querySelector('#foto').innerHTML = 'Sem foto'; },
    copiar: () => ir('#/produto/novo?copiar=' + orig.id),
    etiquetas: () => { App.etiquetasPre = orig.variacoes.map(v => ({ variacao_id: v.id, qtd: Math.max(1, v.estoque) })); ir('#/etiquetas'); },
    excluir: async () => {
      if (!await confirmar(`Excluir "${orig.nome}"? Se o produto tiver vendas ou compras, ele será apenas desativado.`, 'Excluir', 'perigo')) return;
      const r = await api('produto/excluir', { id: orig.id }); toast(r.mensagem, 'ok'); ir('#/produtos');
    },
    salvar: async () => {
      lerVars();
      const o = lerForm(form, campos.filter(c => c.n));
      o.id = orig ? orig.id : null; o.foto = foto; o.variacoes = st.vars;
      if (!o.preco) throw new Error('Informe o preço de venda.');
      const r = await api('produto/salvar', { obj: o });
      toast('Produto salvo.', 'ok');
      if (params.voltar === 'entrada') ir('#/entrada'); else ir('#/produto/' + r.id);
    }
  });
  renderVars(); analise();
};

function resumoHistoricoProduto(p) {
  const vendas = App.d.vendas.filter(v => v.status === 'concluida').flatMap(v => v.itens.filter(i => i.produto_id === p.id).map(i => ({ ...i, data: v.data })));
  const qtd = soma(vendas, i => i.qtd), receita = soma(vendas, i => i.total);
  const ult = vendas.reduce((m, i) => i.data > m ? i.data : m, '');
  const entradas = App.d.movimentos.filter(m => m.produto_id === p.id && (m.tipo === 'entrada' || m.tipo === 'estoque_inicial'));
  const recebidas = soma(entradas, m => m.qtd);
  return `<div class="totais"><div><span>Peças vendidas</span><b>${qtd}</b></div><div><span>Receita</span><b>${moeda(receita)}</b></div>
    <div><span>Lucro bruto</span><b>${moeda(receita - soma(vendas, i => i.custo_unit * i.qtd))}</b></div><div><span>Última venda</span><b>${ult ? dataBR(ult) : '—'}</b></div>
    <div><span>Peças recebidas</span><b>${recebidas}</b></div><div><span>Sell-through</span><b>${recebidas ? pct(qtd / recebidas * 100) : '—'}</b></div>
    ${p.ultimo_custo_compra ? `<div><span>Último custo de compra</span><b>${moeda(p.ultimo_custo_compra)}</b></div>` : ''}</div>
    <a class="btn pequeno" style="margin-top:8px" href="#/movimentacoes?produto=${p.id}">Ver movimentações</a>`;
}

/* ----------------------------------------------------------------- estoque */
App.paginas.estoque = async (el, id, params) => {
  const st = { filtro: params.filtro || 'todos', cat: '' };
  const ind = indicadoresEstoque();
  el.innerHTML = `<div class="kpis">${kpi('Peças em estoque', numBR(ind.pecas))}${kpi('Valor a custo', moeda(ind.custo))}${kpi('Valor a preço de venda', moeda(ind.venda), `Lucro potencial ${moeda(ind.venda - ind.custo)}`)}
      ${kpi('Cobertura', ind.cobertura ? numBR(ind.cobertura) + ' dias' : '—', 'Quanto tempo o estoque dura no ritmo atual')}${kpi('Giro anual', ind.giro ? numBR(ind.giro, 1) + 'x' : '—', 'Ideal para moda: 3x a 5x')}</div>
    <div class="linha-acoes"><a class="btn pri" href="#/entrada">Entrada de mercadorias</a><button class="btn" data-click="ajuste">Ajuste / perda</button>
      <a class="btn" href="#/inventario">Inventário</a><a class="btn" href="#/etiquetas">Etiquetas</a><a class="btn" href="#/movimentacoes">Movimentações</a></div>
    <div class="card"><div class="linha-acoes"><div class="chips">${[['todos', 'Todas'], ['baixo', 'Estoque baixo'], ['zerado', 'Zeradas'], ['parado', 'Paradas +' + (App.cfg.estoque.dias_parado || 90) + ' dias']].map(([k, t]) => `<button class="chip ${k === st.filtro ? 'ativo' : ''}" data-click="filtro" data-k="${k}">${t}</button>`).join('')}</div>
      <span class="espaco"></span><select data-change="cat" class="input-inline"><option value="">Todas as categorias</option>${opcoes(App.d.categorias).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></div><div id="tab-est"></div></div>`;
  const ult = ultimaVendaPorProduto(), limite = somarDias(hojeISO(), -n(App.cfg.estoque.dias_parado || 90));
  const linhas = () => App.d.produtos.filter(p => p.ativo !== false && (!st.cat || p.categoria_id === st.cat)).flatMap(p => p.variacoes.map(v => ({ p, v })))
    .filter(({ p, v }) => st.filtro === 'baixo' ? v.estoque > 0 && v.estoque <= n(v.estoque_min) : st.filtro === 'zerado' ? v.estoque <= 0 : st.filtro === 'parado' ? v.estoque > 0 && (ult[p.id] || p.criado_em || '') < limite : true);
  const t = tabela(el.querySelector('#tab-est'), {
    linhas: linhas(), exportar: 'estoque',
    colunas: [{ t: 'SKU', v: x => x.p.sku }, { t: 'Produto', v: x => x.p.nome }, { t: 'Tamanho', v: x => x.v.tamanho }, { t: 'Cor', v: x => x.v.cor },
      { t: 'Código', v: x => x.v.codigo_barras }, { t: 'Estoque', v: x => x.v.estoque, h: x => `<b class="${x.v.estoque <= 0 ? 'negativo' : ''}">${x.v.estoque}</b>`, cls: 'num', total: l => numBR(soma(l, x => x.v.estoque)) },
      { t: 'Mínimo', v: x => n(x.v.estoque_min), cls: 'num' }, { t: 'Valor a custo', v: x => r2(Math.max(0, x.v.estoque) * n(x.p.custo)), h: x => moeda(Math.max(0, x.v.estoque) * n(x.p.custo)), cls: 'num', total: true },
      { t: 'Última venda', v: x => ult[x.p.id] || '', h: x => ult[x.p.id] ? dataBR(ult[x.p.id]) : '—' }],
    aoClicar: x => ir('#/produto/' + x.p.id)
  });
  ligar(el, { filtro: b => { st.filtro = b.dataset.k; el.querySelectorAll('[data-click=filtro]').forEach(c => c.classList.toggle('ativo', c === b)); t.atualizar(linhas()); },
    cat: s => { st.cat = s.value; t.atualizar(linhas()); }, ajuste: () => modalAjuste() });
};

function modalAjuste() {
  let sel = null;
  const m = modal({ titulo: 'Ajuste de estoque', largura: 'largo', corpo: `<div id="aj-sel"></div><div id="aj-escolhido" class="caixa-aviso" style="margin-top:10px">Escolha a peça (tamanho/cor) acima.</div>
    ${formHTML([{ n: 'tipo', r: 'Tipo', t: 'select', w: 6, vazio: false, op: [['perda', 'Perda (sumiu/estragou)'], ['defeito', 'Defeito'], ['furto', 'Furto'], ['uso_interno', 'Uso interno / vitrine'], ['brinde', 'Brinde / permuta'], ['devolucao_fornecedor', 'Devolução ao fornecedor'], ['ajuste_saida', 'Correção — retirar do estoque'], ['ajuste_entrada', 'Correção — adicionar ao estoque']] },
      { n: 'qtd', r: 'Quantidade', t: 'number', w: 3, min: 1, padrao: 1, obr: 1 }, { n: 'obs', r: 'Motivo / observação', w: 12 }])}`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Registrar ajuste', classe: 'pri', acao: async mm => {
      if (!sel) throw new Error('Escolha a peça.');
      const d = lerForm(mm, [{ n: 'tipo' }, { n: 'qtd', t: 'number', r: 'Quantidade', obr: 1 }, { n: 'obs' }]);
      await api('ajuste', { produto_id: sel.p.id, variacao_id: sel.v.id, ...d }); toast('Ajuste registrado.', 'ok'); recarregarPagina();
    } }] });
  seletorProduto(m.querySelector('#aj-sel'), { permitirZerado: true, inativos: true, aoEscolher: (p, v) => { sel = { p, v }; m.querySelector('#aj-escolhido').innerHTML = `<b>${esc(p.nome)}</b> — ${esc(v.tamanho)}/${esc(v.cor)} · estoque atual <b>${v.estoque}</b>`; } });
}

/* ---------------------------------------------------------------- entradas */
App.paginas.entradas = async el => {
  el.innerHTML = `<div class="linha-acoes"><a class="btn pri" href="#/entrada">Nova entrada de mercadorias</a></div><div class="card" id="tab-ent"></div>`;
  tabela(el.querySelector('#tab-ent'), {
    linhas: App.d.entradas.slice().reverse(), exportar: 'entradas',
    textoBusca: e => e.itens.map(i => i.nome).join(' '),
    colunas: [{ t: 'Nº', v: e => e.numero, cls: 'num' }, { t: 'Data', v: e => e.data, h: e => dataBR(e.data) }, { t: 'Fornecedor', v: e => (App.idx.forn[e.fornecedor_id] || {}).nome || '' },
      { t: 'Nota', v: e => e.nota }, { t: 'Peças', v: e => soma(e.itens, i => i.qtd), cls: 'num' }, { t: 'Frete/outros', v: e => r2(e.frete + e.outras - e.desconto), h: e => moeda(e.frete + e.outras - e.desconto), cls: 'num' },
      { t: 'Total', v: e => e.total, h: e => `<b>${moeda(e.total)}</b>`, cls: 'num', total: true }, { t: 'Situação', v: e => e.status, h: e => e.status === 'ativa' ? etiqueta('Lançada', 'ok') : etiqueta('Cancelada', 'erro') }],
    aoClicar: e => modal({ titulo: `Entrada nº ${e.numero} — ${dataBR(e.data)}`, largura: 'largo', corpo: `<p>Fornecedor: <b>${esc((App.idx.forn[e.fornecedor_id] || {}).nome || '—')}</b> · NF ${esc(e.nota || 's/n')}</p>
      <table class="tab"><thead><tr><th>Produto</th><th>Var.</th><th class="th-num">Qtd</th><th class="th-num">Custo nota</th><th class="th-num">Custo c/ frete</th></tr></thead><tbody>
      ${e.itens.map(i => `<tr><td>${esc(i.nome)}</td><td>${esc(i.tamanho)}/${esc(i.cor)}</td><td class="num">${i.qtd}</td><td class="num">${moeda(i.custo_unit)}</td><td class="num">${moeda(i.custo_efetivo)}</td></tr>`).join('')}</tbody></table>
      <div class="totais" style="margin-top:10px"><div><span>Produtos</span><span>${moeda(e.total_produtos)}</span></div><div><span>Frete</span><span>${moeda(e.frete)}</span></div><div><span>Outras despesas</span><span>${moeda(e.outras)}</span></div><div><span>Desconto</span><span>−${moeda(e.desconto)}</span></div><div class="total"><span>Total</span><span>${moeda(e.total)}</span></div></div>`,
      botoes: [...(e.status === 'ativa' ? [{ texto: 'Estornar entrada', classe: 'perigo', acao: async () => {
        if (!await confirmar('Estornar esta entrada? As peças saem do estoque e as parcelas pendentes são canceladas. O custo médio não é recalculado.', 'Estornar', 'perigo')) return false;
        await api('entrada/cancelar', { id: e.id }); toast('Entrada estornada.', 'ok'); recarregarPagina();
      } }] : []), { texto: 'Fechar' }] })
  });
};

App.paginas.entrada = async el => {
  const r = App.rascunhoEntrada || (App.rascunhoEntrada = { fornecedor_id: '', nota: '', data: hojeISO(), frete: 0, outras: 0, desconto: 0, produtos: [], modo: 'parcelado', parcelas: 1, primeiro: somarDias(hojeISO(), 30), intervalo: 30, forma: 'boleto' });
  const forn = App.idx.forn[r.fornecedor_id];
  el.innerHTML = `<div class="card"><div class="grade-form">
      <label class="campo w4"><span>Fornecedor</span><select data-change="campo" data-c="fornecedor_id"><option value="">—</option>${opcoes(App.d.fornecedores).map(([k, t]) => `<option value="${k}" ${k === r.fornecedor_id ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>
      <label class="campo w3"><span>Nº da nota / pedido</span><input data-change="campo" data-c="nota" value="${esc(r.nota)}"></label>
      <label class="campo w3"><span>Data de chegada</span><input type="date" data-change="campo" data-c="data" value="${r.data}"></label>
      <div class="w2" style="align-self:end"><a class="btn" href="#/fornecedores">+ Fornecedor</a></div>
      ${forn ? `<div class="w12"><small class="suave">Condição habitual: ${esc(forn.prazo_pagamento || '—')} · pedido mínimo ${moeda(forn.pedido_minimo)}</small></div>` : ''}
    </div></div>
    <div class="card"><div class="card-cab"><h3>Produtos recebidos</h3><a class="btn pequeno" href="#/produto/novo?voltar=entrada">Cadastrar produto novo</a></div>
      <div id="ent-sel"></div><div id="ent-itens" style="margin-top:12px"></div></div>
    <div class="grade g2"><div class="card"><h3>Custos da nota</h3><div class="grade-form">
        <label class="campo w4"><span>Frete</span><input type="number" step="0.01" min="0" data-input="campo" data-c="frete" value="${r.frete}"></label>
        <label class="campo w4"><span>Outras despesas</span><input type="number" step="0.01" min="0" data-input="campo" data-c="outras" value="${r.outras}"></label>
        <label class="campo w4"><span>Desconto</span><input type="number" step="0.01" min="0" data-input="campo" data-c="desconto" value="${r.desconto}"></label></div>
        <p class="suave" style="margin-top:8px">Frete e despesas são rateados no custo de cada peça (proporcional ao valor). O custo do produto vira um custo médio ponderado.</p>
        <div class="totais" id="ent-tot"></div></div>
      <div class="card"><h3>Pagamento ao fornecedor</h3><div class="grade-form">
        <label class="campo w12"><span>Condição</span><select data-change="campo" data-c="modo"><option value="parcelado" ${r.modo === 'parcelado' ? 'selected' : ''}>A prazo (gera contas a pagar)</option><option value="avista" ${r.modo === 'avista' ? 'selected' : ''}>Pago à vista agora</option><option value="nenhum" ${r.modo === 'nenhum' ? 'selected' : ''}>Não lançar no financeiro (consignado/já lançado)</option></select></label>
        ${r.modo === 'parcelado' ? `<label class="campo w3"><span>Parcelas</span><input type="number" min="1" max="24" data-input="campo" data-c="parcelas" value="${r.parcelas}"></label>
          <label class="campo w4"><span>1º vencimento</span><input type="date" data-change="campo" data-c="primeiro" value="${r.primeiro}"></label>
          <label class="campo w2"><span>Intervalo (dias)</span><input type="number" min="1" data-input="campo" data-c="intervalo" value="${r.intervalo}"></label>` : ''}
        ${r.modo !== 'nenhum' ? `<label class="campo w3"><span>Forma</span><select data-change="campo" data-c="forma">${['boleto', 'pix', 'transferencia', 'dinheiro', 'cartao'].map(f => `<option ${f === r.forma ? 'selected' : ''}>${f}</option>`).join('')}</select></label>` : ''}
      </div><div class="linha-acoes" style="margin-top:16px"><button class="btn" data-click="descartar">Descartar</button><span class="espaco"></span><button class="btn pri grande" data-click="lancar">Lançar entrada</button></div></div></div>`;
  seletorProduto(el.querySelector('#ent-sel'), { modo: 'produto', inativos: true, ph: 'Buscar produto para adicionar (nome, SKU, código)',
    aoEscolher: p => {
      if (r.produtos.some(x => x.produto_id === p.id)) { toast('Produto já está na lista.'); return; }
      r.produtos.push({ produto_id: p.id, custo: n(p.ultimo_custo_compra || p.custo), qtds: {}, atualizar: false, novo_preco: 0 }); itens();
    } });
  function calc() {
    const totalProd = soma(r.produtos, x => soma(Object.values(x.qtds), q => q) * x.custo);
    const extra = n(r.frete) + n(r.outras) - n(r.desconto);
    return { totalProd, extra, fator: totalProd > 0 ? extra / totalProd : 0, total: totalProd + extra };
  }
  function itens() {
    const c = calc();
    el.querySelector('#ent-itens').innerHTML = r.produtos.length ? r.produtos.map((x, k) => {
      const p = App.idx.prod[x.produto_id];
      const q = soma(Object.values(x.qtds), v => v);
      const efetivo = x.custo * (1 + c.fator);
      const atual = soma(p.variacoes, v => Math.max(0, v.estoque));
      const medio = atual + q ? (atual * n(p.custo) + q * efetivo) / (atual + q) : efetivo;
      const sug = sugestaoPreco(medio, p.categoria_id).sugerido;
      return `<div class="card compacto" style="background:#fcfafb"><div class="card-cab"><b>${esc(p.nome)} <small class="suave">${esc(p.sku)}</small></b><button class="btn pequeno perigo" data-rem="${k}">Remover</button></div>
        <div class="grade-form"><label class="campo w3"><span>Custo unitário na nota</span><input type="number" step="0.01" min="0" data-k="${k}" data-f="custo" value="${x.custo}"></label>
        <div class="w9"><span class="suave" style="font-size:12px">Quantidade recebida por variação</span><div class="chips">${p.variacoes.map(v => `<label class="chip" style="cursor:default">${esc(v.tamanho)}/${esc(v.cor)} <input type="number" min="0" class="input-qtd" style="width:56px;padding:2px 4px" data-k="${k}" data-v="${v.id}" value="${x.qtds[v.id] || ''}"></label>`).join('')}</div></div></div>
        <div style="margin-top:8px;font-size:12.5px" class="suave">${q} peça(s) · custo com rateio ${moeda(efetivo)} · custo médio novo ${moeda(medio)} (atual ${moeda(p.custo)}) · preço atual <b>${moeda(p.preco)}</b> · sugerido <b>${moeda(sug)}</b></div>
        <label class="check" style="margin-top:6px"><input type="checkbox" data-k="${k}" data-f="atualizar" ${x.atualizar ? 'checked' : ''}><span>Atualizar preço de venda para</span>
          <input type="number" step="0.01" class="input-num" data-k="${k}" data-f="novo_preco" value="${x.novo_preco || sug}"></label></div>`;
    }).join('') : '<p class="vazio">Busque os produtos da nota acima. Se for um produto novo, cadastre primeiro (o rascunho desta entrada fica guardado).</p>';
    el.querySelectorAll('#ent-itens [data-v]').forEach(inp => inp.oninput = () => { r.produtos[+inp.dataset.k].qtds[inp.dataset.v] = Math.max(0, Math.round(n(inp.value))); totais(); });
    el.querySelectorAll('#ent-itens [data-f]').forEach(inp => inp.addEventListener(inp.type === 'checkbox' ? 'change' : 'input', () => {
      const x = r.produtos[+inp.dataset.k];
      x[inp.dataset.f] = inp.type === 'checkbox' ? inp.checked : n(inp.value);
      if (inp.dataset.f === 'novo_preco') x.atualizar = true;
      totais();
    }));
    el.querySelectorAll('#ent-itens [data-f=custo]').forEach(inp => inp.onchange = () => itens());
    el.querySelectorAll('#ent-itens [data-rem]').forEach(b => b.onclick = () => { r.produtos.splice(+b.dataset.rem, 1); itens(); });
    totais();
  }
  function totais() {
    const c = calc();
    el.querySelector('#ent-tot').innerHTML = `<div><span>Produtos (${soma(r.produtos, x => soma(Object.values(x.qtds), q => q))} peças)</span><span>${moeda(c.totalProd)}</span></div>
      <div><span>Rateio sobre o custo</span><span>${pct(c.fator * 100)}</span></div><div class="total"><span>Total da nota</span><span>${moeda(c.total)}</span></div>
      ${r.modo === 'parcelado' && r.parcelas > 1 ? `<div><span>${r.parcelas} parcelas de</span><span>${moeda(c.total / r.parcelas)}</span></div>` : ''}`;
  }
  ligar(el, {
    campo: inp => { const c = inp.dataset.c; r[c] = ['frete', 'outras', 'desconto', 'parcelas', 'intervalo'].includes(c) ? n(inp.value) : inp.value; if (['modo', 'fornecedor_id'].includes(c)) recarregarPagina(); else if (['frete', 'outras', 'desconto'].includes(c)) itens(); else totais(); },
    descartar: async () => { if (await confirmar('Descartar este rascunho de entrada?', 'Descartar', 'perigo')) { App.rascunhoEntrada = null; ir('#/entradas'); } },
    lancar: async () => {
      const itensEnv = r.produtos.flatMap(x => Object.entries(x.qtds).filter(([, q]) => q > 0).map(([vid, q]) => ({ produto_id: x.produto_id, variacao_id: vid, qtd: q, custo_unit: x.custo })));
      if (!itensEnv.length) throw new Error('Informe as quantidades recebidas.');
      const novos_precos = {};
      r.produtos.filter(x => x.atualizar && x.novo_preco > 0).forEach(x => { novos_precos[x.produto_id] = x.novo_preco; });
      const res = await api('entrada', { fornecedor_id: r.fornecedor_id, nota: r.nota, data: r.data, frete: r.frete, outras: r.outras, desconto: r.desconto, itens: itensEnv, novos_precos,
        pagamento: { modo: r.modo, parcelas: r.parcelas, primeiro_vencimento: r.primeiro, intervalo_dias: r.intervalo, forma: r.forma } });
      App.rascunhoEntrada = null;
      toast(`Entrada nº ${res.numero} lançada. Estoque e custos atualizados.`, 'ok');
      if (await confirmar('Deseja imprimir as etiquetas das peças recebidas?', 'Imprimir etiquetas')) {
        App.etiquetasPre = itensEnv.map(i => ({ variacao_id: i.variacao_id, qtd: i.qtd })); ir('#/etiquetas');
      } else ir('#/entradas');
    }
  });
  itens();
};

/* ---------------------------------------------------------- movimentações */
App.paginas.movimentacoes = async (el, id, params) => {
  const st = { de: params.produto ? '2000-01-01' : somarDias(hojeISO(), -30), ate: hojeISO(), tipo: '' };
  el.innerHTML = `<div class="card"><div class="linha-acoes"><label class="campo"><span>De</span><input type="date" data-change="de" value="${st.de}"></label>
    <label class="campo"><span>Até</span><input type="date" data-change="ate" value="${st.ate}"></label>
    <label class="campo"><span>Tipo</span><select data-change="tipo"><option value="">Todos</option>${Object.entries(TIPOS_MOV).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select></label>
    ${params.produto ? `<span class="etiqueta et-pri">${esc((App.idx.prod[params.produto] || {}).nome || '')}</span> <a href="#/movimentacoes" class="btn pequeno">Limpar filtro</a>` : ''}</div><div id="tab-mov"></div></div>`;
  const filtrar = () => App.d.movimentos.filter(m => m.data.slice(0, 10) >= st.de && m.data.slice(0, 10) <= st.ate && (!st.tipo || m.tipo === st.tipo) && (!params.produto || m.produto_id === params.produto)).slice().reverse();
  const t = tabela(el.querySelector('#tab-mov'), { linhas: filtrar(), exportar: 'movimentacoes',
    colunas: [{ t: 'Data', v: m => m.data, h: m => dataHoraBR(m.data) }, { t: 'Tipo', v: m => TIPOS_MOV[m.tipo] || m.tipo }, { t: 'Produto', v: m => m.produto_nome }, { t: 'Variação', v: m => m.variacao },
      { t: 'Qtd', v: m => m.qtd, h: m => `<b class="${m.qtd < 0 ? 'negativo' : 'positivo'}">${m.qtd > 0 ? '+' : ''}${m.qtd}</b>`, cls: 'num' }, { t: 'Saldo', v: m => m.saldo, cls: 'num' },
      { t: 'Custo un.', v: m => m.custo_unit, h: m => moeda(m.custo_unit), cls: 'num' }, { t: 'Documento', v: m => m.doc }, { t: 'Obs.', v: m => m.obs || '' }, { t: 'Usuária', v: m => m.usuario || '' }] });
  ligar(el, { de: i => { st.de = i.value; t.atualizar(filtrar()); }, ate: i => { st.ate = i.value; t.atualizar(filtrar()); }, tipo: s => { st.tipo = s.value; t.atualizar(filtrar()); } });
};

/* -------------------------------------------------------------- inventário */
App.paginas.inventario = async el => {
  const st = { cat: '', contagens: {} };
  el.innerHTML = `<div class="caixa-aviso">Conte as peças fisicamente e digite a quantidade encontrada. Deixe em branco o que não contou. Só as diferenças geram ajuste (tipo "Inventário"), e o valor delas entra como perda/sobra no DRE.</div>
    <div class="card"><div class="linha-acoes"><select data-change="cat" class="input-inline"><option value="">Todas as categorias</option>${opcoes(App.d.categorias).map(([k, t]) => `<option value="${k}">${esc(t)}</option>`).join('')}</select>
    <button class="btn" data-click="imprimirLista">Imprimir lista de contagem</button><span class="espaco"></span><button class="btn pri" data-click="aplicar">Aplicar contagem</button></div><div id="inv"></div></div>`;
  const lista = () => App.d.produtos.filter(p => p.ativo !== false && (!st.cat || p.categoria_id === st.cat)).sort((a, b) => a.nome.localeCompare(b.nome)).flatMap(p => p.variacoes.map(v => ({ p, v })));
  function render() {
    el.querySelector('#inv').innerHTML = `<div class="tabela-wrap"><table class="tab"><thead><tr><th>Produto</th><th>Tam./Cor</th><th>Código</th><th>Local</th><th class="th-num">Sistema</th><th class="th-num">Contado</th><th class="th-num">Diferença</th></tr></thead><tbody>
      ${lista().map(({ p, v }) => { const c = st.contagens[v.id]; const dif = c === undefined || c === '' ? '' : n(c) - v.estoque;
        return `<tr><td>${esc(p.nome)}</td><td>${esc(v.tamanho)}/${esc(v.cor)}</td><td><small>${esc(v.codigo_barras)}</small></td><td><small>${esc(p.localizacao || '')}</small></td><td class="num">${v.estoque}</td>
        <td class="num"><input type="number" min="0" class="input-qtd" data-v="${v.id}" value="${c ?? ''}"></td><td class="num ${dif < 0 ? 'negativo' : dif > 0 ? 'positivo' : ''}" data-dif="${v.id}">${dif === '' ? '' : (dif > 0 ? '+' : '') + dif}</td></tr>`; }).join('')}</tbody></table></div>`;
    el.querySelectorAll('[data-v]').forEach(inp => inp.oninput = () => {
      st.contagens[inp.dataset.v] = inp.value;
      const v = App.idx.var[inp.dataset.v].v, td = el.querySelector(`[data-dif="${inp.dataset.v}"]`), dif = inp.value === '' ? '' : n(inp.value) - v.estoque;
      td.textContent = dif === '' ? '' : (dif > 0 ? '+' : '') + dif; td.className = 'num ' + (dif < 0 ? 'negativo' : dif > 0 ? 'positivo' : '');
    });
  }
  ligar(el, {
    cat: s => { st.cat = s.value; render(); },
    imprimirLista: () => imprimir(`<div class="documento"><h3>Lista de contagem — ${esc(App.cfg.loja.nome)} — ${dataBR(hojeISO())}</h3><table><thead><tr><th>Produto</th><th>Tam./Cor</th><th>Local</th><th>Contado</th></tr></thead><tbody>
      ${lista().map(({ p, v }) => `<tr><td>${esc(p.nome)}</td><td>${esc(v.tamanho)}/${esc(v.cor)}</td><td>${esc(p.localizacao || '')}</td><td style="width:25mm"></td></tr>`).join('')}</tbody></table></div>`),
    aplicar: async () => {
      const contagens = Object.entries(st.contagens).filter(([, c]) => c !== '').map(([vid, c]) => ({ produto_id: App.idx.var[vid].p.id, variacao_id: vid, contado: n(c) }));
      if (!contagens.length) throw new Error('Nenhuma quantidade informada.');
      const difs = contagens.filter(c => c.contado !== App.idx.var[c.variacao_id].v.estoque).length;
      if (!await confirmar(`${contagens.length} item(ns) contado(s), ${difs} com diferença. Aplicar ajustes?`, 'Aplicar')) return;
      const r = await api('inventario', { contagens, obs: 'Inventário ' + dataBR(hojeISO()) });
      toast(`${r.ajustados} item(ns) ajustado(s).`, 'ok'); st.contagens = {}; render();
    }
  });
  render();
};

/* -------------------------------------------------------------- etiquetas */
App.paginas.etiquetas = async el => {
  const itens = (App.etiquetasPre || []).filter(i => App.idx.var[i.variacao_id]);
  App.etiquetasPre = null;
  el.innerHTML = `<div class="grade g-2-1"><div class="card"><h3>Peças para etiquetar</h3><div id="etq-sel"></div><div id="etq-lista" style="margin-top:10px"></div></div>
    <div class="card"><h3>Formato</h3>${formHTML([{ n: 'formato', r: 'Papel', t: 'select', w: 12, vazio: false, op: [['rolo', 'Rolo térmico 50 × 30 mm'], ['a4', 'Folha A4 (Pimaco 6180/6280 — 3 × 7)']] },
      { n: 'mostrarPreco', r: 'Mostrar preço', t: 'check', w: 12, padrao: true }, { n: 'promo', r: 'Mostrar preço "de/por" com promoção vigente da peça', t: 'check', w: 12 }])}
      <div class="linha-acoes" style="margin-top:14px"><button class="btn" data-click="limpar">Limpar</button><span class="espaco"></span><button class="btn pri" data-click="imprimir">Imprimir etiquetas</button></div>
      <p class="suave">O código de barras usa o padrão Code 128, lido por qualquer leitor USB comum.</p></div></div>`;
  seletorProduto(el.querySelector('#etq-sel'), { permitirZerado: true, aoEscolher: (p, v) => { const ex = itens.find(i => i.variacao_id === v.id); if (ex) ex.qtd++; else itens.push({ variacao_id: v.id, qtd: Math.max(1, v.estoque) }); lista(); } });
  function lista() {
    el.querySelector('#etq-lista').innerHTML = itens.length ? `<table class="tab"><tbody>${itens.map((i, k) => { const { p, v } = App.idx.var[i.variacao_id];
      return `<tr><td>${esc(p.nome)} — ${esc(v.tamanho)}/${esc(v.cor)}</td><td class="num">${moeda(p.preco)}</td><td class="num"><input type="number" min="0" class="input-qtd" data-k="${k}" value="${i.qtd}"></td><td><button class="btn pequeno perigo" data-rem="${k}">×</button></td></tr>`; }).join('')}</tbody></table>
      <small class="suave">${soma(itens, i => i.qtd)} etiqueta(s)</small>` : '<p class="vazio">Busque as peças acima.</p>';
    el.querySelectorAll('[data-k]').forEach(inp => inp.oninput = () => { itens[+inp.dataset.k].qtd = Math.max(0, Math.round(n(inp.value))); });
    el.querySelectorAll('[data-rem]').forEach(b => b.onclick = () => { itens.splice(+b.dataset.rem, 1); lista(); });
  }
  ligar(el, {
    limpar: () => { itens.length = 0; lista(); },
    imprimir: () => {
      const f = lerForm(el, [{ n: 'formato' }, { n: 'mostrarPreco', t: 'check' }, { n: 'promo', t: 'check' }]);
      const html = [];
      for (const i of itens) {
        const { p, v } = App.idx.var[i.variacao_id];
        let precoHTML = '';
        if (f.mostrarPreco) {
          const c = f.promo ? calcularCarrinho({ itens: [{ produto_id: p.id, variacao_id: v.id, qtd: 1, preco_unit: n(p.preco) }], cupom: '', desc_manual: 0 }) : null;
          const promo = c && c.linhas[0].desconto > 0 ? c.linhas[0].total : 0;
          precoHTML = promo ? `<div><small><s>${moeda(p.preco)}</s></small> <span class="preco">${moeda(promo)}</span></div>` : `<div class="preco">${moeda(p.preco)}</div>`;
        }
        for (let k = 0; k < i.qtd; k++) html.push(`<div class="etq ${f.formato}"><div class="loja">${esc(App.cfg.loja.nome)}</div><div class="nome">${esc(p.nome)}</div>
          <div class="var">Tam. <b>${esc(v.tamanho)}</b> · ${esc(v.cor)} · ${esc(p.sku)}</div>${precoHTML}${code128SVG(v.codigo_barras)}<div class="cod">${esc(v.codigo_barras)}</div></div>`);
      }
      if (!html.length) throw new Error('Nenhuma etiqueta para imprimir.');
      imprimir(`<div class="etiquetas-folha">${html.join('')}</div>`, f.formato === 'rolo' ? 'size: 50mm 30mm; margin: 0;' : 'size: A4; margin: 15mm 7mm;');
    }
  });
  lista();
};
