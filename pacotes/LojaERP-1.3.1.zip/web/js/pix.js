/* Loja ERP — gerador de QR Code (ISO/IEC 18004) e cobrança Pix (BR Code, padrão EMV do Banco Central).
   Implementação própria, sem bibliotecas externas.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const QRCode = (() => {
  // Tabelas por nível de correção [L, M, Q, H] e versão (índice 0 não usado).
  const ECC_POR_BLOCO = [
    [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
  ];
  const BLOCOS = [
    [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]
  ];
  const BITS_FORMATO = [1, 0, 3, 2];

  function modulosDados(ver) {
    let r = (16 * ver + 128) * ver + 64;
    if (ver >= 2) { const na = Math.floor(ver / 7) + 2; r -= (25 * na - 10) * na - 55; if (ver >= 7) r -= 36; }
    return r;
  }
  function palavrasDados(ver, ecl) { return Math.floor(modulosDados(ver) / 8) - ECC_POR_BLOCO[ecl][ver] * BLOCOS[ecl][ver]; }
  function mult(x, y) { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11d); z ^= ((y >>> i) & 1) * x; } return z & 0xff; }
  function divisor(grau) {
    const r = new Array(grau - 1).fill(0).concat([1]);
    let raiz = 1;
    for (let i = 0; i < grau; i++) {
      for (let j = 0; j < r.length; j++) { r[j] = mult(r[j], raiz); if (j + 1 < r.length) r[j] ^= r[j + 1]; }
      raiz = mult(raiz, 0x02);
    }
    return r;
  }
  function resto(dados, div) {
    const r = div.map(() => 0);
    for (const b of dados) { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => { r[i] ^= mult(c, f); }); }
    return r;
  }
  function posicoesAlinhamento(ver, tam) {
    if (ver === 1) return [];
    const n = Math.floor(ver / 7) + 2;
    const passo = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
    const r = [6];
    for (let p = tam - 7; r.length < n; p -= passo) r.splice(1, 0, p);
    return r;
  }

  function gerar(texto, ecl = 1) {
    const bytes = Array.from(new TextEncoder().encode(texto));
    let ver = 1;
    for (; ver <= 40; ver++) {
      const usados = 4 + (ver <= 9 ? 8 : 16) + bytes.length * 8;
      if (usados <= palavrasDados(ver, ecl) * 8) break;
    }
    if (ver > 40) throw new Error('Texto longo demais para QR Code.');
    const bits = [];
    const add = (v, n) => { for (let i = n - 1; i >= 0; i--) bits.push((v >>> i) & 1); };
    add(4, 4); add(bytes.length, ver <= 9 ? 8 : 16); bytes.forEach(b => add(b, 8));
    const cap = palavrasDados(ver, ecl) * 8;
    add(0, Math.min(4, cap - bits.length));
    add(0, (8 - bits.length % 8) % 8);
    for (let p = 0xec; bits.length < cap; p ^= 0xec ^ 0x11) add(p, 8);
    const dados = [];
    for (let i = 0; i < bits.length; i += 8) dados.push(parseInt(bits.slice(i, i + 8).join(''), 2));

    const nBlocos = BLOCOS[ecl][ver], eccLen = ECC_POR_BLOCO[ecl][ver];
    const brutas = Math.floor(modulosDados(ver) / 8);
    const curtos = nBlocos - brutas % nBlocos, tamCurto = Math.floor(brutas / nBlocos);
    const div = divisor(eccLen), blocos = [];
    for (let i = 0, k = 0; i < nBlocos; i++) {
      const d = dados.slice(k, k + tamCurto - eccLen + (i < curtos ? 0 : 1));
      k += d.length;
      const e = resto(d, div);
      if (i < curtos) d.push(0);
      blocos.push(d.concat(e));
    }
    const final = [];
    for (let i = 0; i < blocos[0].length; i++) blocos.forEach((b, j) => { if (i !== tamCurto - eccLen || j >= curtos) final.push(b[i]); });

    const tam = ver * 4 + 17;
    const m = Array.from({ length: tam }, () => new Array(tam).fill(false));
    const fn = Array.from({ length: tam }, () => new Array(tam).fill(false));
    const set = (x, y, v) => { m[y][x] = v; fn[y][x] = true; };
    for (let i = 0; i < tam; i++) { set(6, i, i % 2 === 0); set(i, 6, i % 2 === 0); }
    const finder = (cx, cy) => {
      for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
        const x = cx + dx, y = cy + dy, d = Math.max(Math.abs(dx), Math.abs(dy));
        if (x >= 0 && x < tam && y >= 0 && y < tam) set(x, y, d !== 2 && d !== 4);
      }
    };
    finder(3, 3); finder(tam - 4, 3); finder(3, tam - 4);
    const al = posicoesAlinhamento(ver, tam);
    al.forEach((ax, i) => al.forEach((ay, j) => {
      if ((i === 0 && j === 0) || (i === 0 && j === al.length - 1) || (i === al.length - 1 && j === 0)) return;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) set(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }));
    const formato = mascara => {
      const dado = BITS_FORMATO[ecl] << 3 | mascara;
      let r = dado;
      for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
      const b = (dado << 10 | r) ^ 0x5412, bit = i => ((b >>> i) & 1) !== 0;
      for (let i = 0; i <= 5; i++) set(8, i, bit(i));
      set(8, 7, bit(6)); set(8, 8, bit(7)); set(7, 8, bit(8));
      for (let i = 9; i < 15; i++) set(14 - i, 8, bit(i));
      for (let i = 0; i < 8; i++) set(tam - 1 - i, 8, bit(i));
      for (let i = 8; i < 15; i++) set(8, tam - 15 + i, bit(i));
      set(8, tam - 8, true);
    };
    formato(0);
    if (ver >= 7) {
      let r = ver;
      for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1f25);
      const b = ver << 12 | r;
      for (let i = 0; i < 18; i++) { const v = ((b >>> i) & 1) !== 0, a = tam - 11 + i % 3, c = Math.floor(i / 3); set(a, c, v); set(c, a, v); }
    }
    let i = 0;
    for (let dir = tam - 1; dir >= 1; dir -= 2) {
      if (dir === 6) dir = 5;
      for (let v = 0; v < tam; v++) for (let j = 0; j < 2; j++) {
        const x = dir - j, sobe = ((dir + 1) & 2) === 0, y = sobe ? tam - 1 - v : v;
        if (!fn[y][x] && i < final.length * 8) { m[y][x] = ((final[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0; i++; }
      }
    }
    const condicao = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, x => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
      (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => x * y % 2 + x * y % 3 === 0,
      (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
    const aplicar = k => { for (let y = 0; y < tam; y++) for (let x = 0; x < tam; x++) if (!fn[y][x] && condicao[k](x, y)) m[y][x] = !m[y][x]; };
    const penalidade = () => {
      let p = 0, escuros = 0;
      for (let a = 0; a < tam; a++) {
        for (const linha of [false, true]) {
          let cor = null, seq = 0;
          for (let b = 0; b < tam; b++) {
            const v = linha ? m[a][b] : m[b][a];
            if (v === cor) { seq++; if (seq === 5) p += 3; else if (seq > 5) p++; } else { cor = v; seq = 1; }
          }
        }
      }
      for (let y = 0; y < tam; y++) for (let x = 0; x < tam; x++) {
        if (m[y][x]) escuros++;
        if (x < tam - 1 && y < tam - 1) { const c = m[y][x]; if (c === m[y][x + 1] && c === m[y + 1][x] && c === m[y + 1][x + 1]) p += 3; }
      }
      const total = tam * tam;
      return p + (Math.ceil(Math.abs(escuros * 20 - total * 10) / total) - 1) * 10;
    };
    let melhor = 0, menor = Infinity;
    for (let k = 0; k < 8; k++) { aplicar(k); formato(k); const pen = penalidade(); if (pen < menor) { menor = pen; melhor = k; } aplicar(k); }
    aplicar(melhor); formato(melhor);
    return m;
  }

  function svg(matriz, borda = 4) {
    const t = matriz.length + borda * 2;
    let d = '';
    matriz.forEach((linha, y) => linha.forEach((v, x) => { if (v) d += `M${x + borda},${y + borda}h1v1h-1z`; }));
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${t} ${t}" shape-rendering="crispEdges"><rect width="${t}" height="${t}" fill="#ffffff"/><path d="${d}" fill="#000000"/></svg>`;
  }
  function canvas(matriz, escala = 12, borda = 4, rodape = '') {
    const t = (matriz.length + borda * 2) * escala;
    const extra = rodape ? 60 : 0;
    const c = document.createElement('canvas');
    c.width = t; c.height = t + extra;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.fillStyle = '#000';
    matriz.forEach((linha, y) => linha.forEach((v, x) => { if (v) ctx.fillRect((x + borda) * escala, (y + borda) * escala, escala, escala); }));
    if (rodape) { ctx.font = 'bold 26px Arial'; ctx.textAlign = 'center'; ctx.fillText(rodape, t / 2, t + 36); }
    return c;
  }
  return { gerar, svg, canvas };
})();

/* --------------------------------------------------------------- BR Code */
function textoPix(s, max) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\x20-\x7e]/g, '').trim().slice(0, max);
}
function crc16(str) {
  let crc = 0xffff;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}
function normalizarChavePix(chave, tipo) {
  const c = String(chave || '').trim();
  switch (tipo) {
    case 'cpf': case 'cnpj': return c.replace(/\D/g, '');
    case 'telefone': { const d = c.replace(/\D/g, ''); return '+' + (d.startsWith('55') && d.length > 11 ? d : '55' + d); }
    case 'email': return c.toLowerCase();
    default: return c;
  }
}
function payloadPix({ chave, tipo, nome, cidade, valor, txid, mensagem }) {
  const tlv = (id, v) => id + String(v.length).padStart(2, '0') + v;
  const k = normalizarChavePix(chave, tipo);
  if (!k) throw new Error('Configure a chave Pix da loja em Configurações > Pix.');
  let conta = tlv('00', 'br.gov.bcb.pix') + tlv('01', k);
  const msg = textoPix(mensagem, Math.max(0, 99 - conta.length - 4));
  if (msg) conta += tlv('02', msg);
  const id = textoPix(txid, 25).replace(/[^A-Za-z0-9]/g, '') || '***';
  let p = tlv('00', '01') + tlv('26', conta) + tlv('52', '0000') + tlv('53', '986');
  if (n(valor) > 0) p += tlv('54', n(valor).toFixed(2));
  p += tlv('58', 'BR') + tlv('59', textoPix(nome, 25) || 'LOJA') + tlv('60', textoPix(String(cidade || '').split('/')[0].split(' - ')[0], 15) || 'BRASIL') + tlv('62', tlv('05', id)) + '6304';
  return p + crc16(p);
}

function modalPix(valor = 0, descricao = '', txid = '') {
  const pix = App.cfg.pix || {};
  if (!pix.chave) {
    modal({ titulo: 'Pix não configurado', corpo: '<p>Cadastre a chave Pix da loja para gerar QR Codes.</p>', botoes: [{ texto: 'Fechar' }, { texto: 'Configurar agora', classe: 'pri', acao: () => ir('#/config?aba=pix') }] });
    return;
  }
  const m = modal({ titulo: 'Cobrança Pix', largura: 'largo', corpo: `<div class="grade g2"><div>
      ${formHTML([{ n: 'valor', r: 'Valor (R$)', t: 'money', w: 6, padrao: valor ? r2(valor) : '' }, { n: 'txid', r: 'Identificador', w: 6, padrao: txid, ph: 'ex.: VENDA125' },
        { n: 'mensagem', r: 'Mensagem para o pagador', w: 12, padrao: descricao }])}
      <p class="suave" style="margin-top:10px">Recebedor: <b>${esc(pix.nome || App.cfg.loja.nome)}</b> · ${esc(pix.cidade || '')}<br>Chave (${esc(pix.tipo_chave)}): ${esc(pix.chave)}</p>
      <p class="suave">Este é um QR Code estático: confira o recebimento no aplicativo do banco antes de liberar a mercadoria.</p></div>
      <div><div class="qr-box" id="qr"></div><div style="margin-top:8px"><small class="suave">Pix copia e cola:</small><div class="copia-cola" id="cc"></div></div></div></div>`,
    botoes: [{ texto: 'Copiar código', acao: async () => { await navigator.clipboard.writeText(atual).catch(() => {}); toast('Código copiado.', 'ok'); return false; } },
      { texto: 'Baixar SVG', acao: () => { baixarArquivo(`pix-${nomeArq()}.svg`, new Blob([QRCode.svg(matriz)], { type: 'image/svg+xml' })); return false; } },
      { texto: 'Baixar JPG', acao: () => { QRCode.canvas(matriz, 12, 4, rotulo()).toBlob(b => baixarArquivo(`pix-${nomeArq()}.jpg`, b), 'image/jpeg', 0.95); return false; } },
      { texto: 'Imprimir', acao: () => { imprimir(`<div class="recibo">${cabecalhoLoja()}<hr><div class="c"><b>PAGUE COM PIX</b></div><div style="width:60mm;margin:6px auto">${QRCode.svg(matriz)}</div><div class="c" style="font-size:16px"><b>${rotulo()}</b></div></div>`, 'size: 80mm auto; margin: 3mm;'); return false; } },
      { texto: 'Fechar', classe: 'pri' }] });
  let atual = '', matriz = null;
  const ler = () => lerForm(m, [{ n: 'valor', t: 'money' }, { n: 'txid' }, { n: 'mensagem' }]);
  const rotulo = () => { const v = ler().valor; return v > 0 ? moeda(v) : 'Valor livre'; };
  const nomeArq = () => (ler().txid || 'cobranca').replace(/[^A-Za-z0-9]/g, '') + (ler().valor ? '-' + String(ler().valor).replace('.', '_') : '');
  const atualizar = () => {
    try {
      const d = ler();
      atual = payloadPix({ chave: pix.chave, tipo: pix.tipo_chave, nome: pix.nome || App.cfg.loja.nome, cidade: pix.cidade || App.cfg.loja.cidade, valor: d.valor, txid: d.txid, mensagem: d.mensagem });
      matriz = QRCode.gerar(atual, 1);
      m.querySelector('#qr').innerHTML = QRCode.svg(matriz);
      m.querySelector('#cc').textContent = atual;
    } catch (e) { m.querySelector('#qr').innerHTML = `<p class="negativo">${esc(e.message)}</p>`; }
  };
  m.querySelectorAll('input').forEach(i => i.addEventListener('input', atualizar));
  atualizar();
}

App.paginas.pix = async el => {
  const pix = App.cfg.pix || {};
  el.innerHTML = `<div class="grade g2"><div class="card"><h3>Gerar QR Code Pix</h3>
      <p class="suave">Gere QR Codes para cobrar no balcão, mandar por WhatsApp ou imprimir para deixar no caixa (sem valor, a cliente digita).</p>
      ${pix.chave ? `<p>Chave: <b>${esc(pix.chave)}</b> (${esc(pix.tipo_chave)}) · ${esc(pix.nome || App.cfg.loja.nome)}</p>` : '<div class="caixa-aviso alerta">Chave Pix ainda não cadastrada.</div>'}
      <div class="linha-acoes"><button class="btn pri" data-click="gerar">Gerar cobrança</button><button class="btn" data-click="balcao">QR do balcão (valor livre)</button><a class="btn" href="#/config?aba=pix">Configurar chave</a></div></div>
    <div class="card"><h3>Dicas</h3><ul class="suave"><li>O QR Code segue o padrão BR Code do Banco Central e funciona em qualquer banco.</li>
      <li>Com valor preenchido, a cliente só confirma. Sem valor, ela digita.</li><li>No caixa, ao escolher Pix como pagamento, o botão <b>QR</b> gera o código já com o valor da venda.</li>
      <li>QR estático não confirma o pagamento sozinho: confira no app do banco.</li></ul></div></div>`;
  ligar(el, { gerar: () => modalPix(), balcao: () => modalPix(0, '', 'BALCAO') });
};
