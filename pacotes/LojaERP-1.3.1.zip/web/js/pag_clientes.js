/* Loja ERP — clientes, fornecedores, ofertas/cupons/fidelidade e serviços.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

/* ---------------------------------------------------------------- clientes */
const CAMPOS_CLIENTE = [
  { sec: 'Dados pessoais' },
  { n: 'nome', r: 'Nome completo', w: 8, obr: 1 }, { n: 'apelido', r: 'Como gosta de ser chamada', w: 4 },
  { n: 'telefone', r: 'WhatsApp / telefone', t: 'tel', w: 4, ph: '(11) 99999-0000' }, { n: 'cpf', r: 'CPF', w: 4, aj: 'Opcional. Necessário para crediário.' },
  { n: 'nascimento', r: 'Data de nascimento', t: 'date', w: 4 }, { n: 'email', r: 'E-mail', t: 'email', w: 6 }, { n: 'instagram', r: 'Instagram', w: 6, ph: '@usuario' },
  { n: 'endereco', r: 'Endereço completo', w: 12 },
  { sec: 'Preferências de moda' },
  { n: 'tam_superior', r: 'Tamanho (blusas)', w: 3 }, { n: 'tam_inferior', r: 'Tamanho (calças/saias)', w: 3 }, { n: 'tam_calcado', r: 'Calçado', w: 2 },
  { n: 'estilo', r: 'Estilo', t: 'select', w: 4, op: [['Básico', 'Básico'], ['Casual', 'Casual'], ['Clássico / trabalho', 'Clássico / trabalho'], ['Romântico', 'Romântico'], ['Moderno / fashion', 'Moderno / fashion'], ['Esportivo', 'Esportivo'], ['Festa', 'Festa']] },
  { n: 'preferencias', r: 'Cores, marcas e peças favoritas', w: 8 }, { n: 'como_conheceu', r: 'Como conheceu a loja', t: 'select', w: 4, op: [['Instagram', 'Instagram'], ['Indicação', 'Indicação'], ['Passou na frente', 'Passou na frente'], ['Google', 'Google'], ['WhatsApp', 'WhatsApp'], ['Outro', 'Outro']] },
  { n: 'tags', r: 'Etiquetas', w: 12, ph: 'ex.: VIP, revendedora, gosta de festa' },
  { sec: 'Crédito e consentimento' },
  { n: 'limite_crediario', r: 'Limite de crediário (R$)', t: 'money', w: 4, aj: '0 = sem limite definido' },
  { n: 'aceita_mensagens', r: 'Autoriza receber mensagens de novidades e promoções (LGPD)', t: 'check', w: 8, padrao: true },
  { n: 'observacoes', r: 'Observações', t: 'textarea', w: 12 }, { n: 'ativo', r: 'Cadastro ativo', t: 'check', w: 12, padrao: true }
];

function formCliente(cli, aoSalvar) {
  modal({ titulo: cli ? 'Editar cliente' : 'Nova cliente', largura: 'largo',
    corpo: `<div class="caixa-aviso">CPF, telefone, e-mail, endereço, nascimento e observações ficam criptografados no arquivo de dados.</div>${formHTML(CAMPOS_CLIENTE, cli || {})}`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => {
      const o = lerForm(m, CAMPOS_CLIENTE);
      o.id = cli ? cli.id : null;
      const r = await api('cliente/salvar', { obj: o });
      toast('Cliente salva.', 'ok');
      if (aoSalvar) aoSalvar(App.idx.cli[r.id]); else recarregarPagina();
    } }] });
}

App.paginas.clientes = async (el, id, params) => {
  const st = { filtro: params.filtro || 'todas' };
  const mes = hojeISO().slice(5, 7);
  const filtros = [['todas', 'Todas'], ['aniversario', 'Aniversariantes do mês'], ['VIP', 'VIP'], ['Em risco', 'Em risco'], ['Inativa', 'Inativas'], ['Sem compras', 'Sem compras'], ['crediario', 'Com crediário'], ['cashback', 'Com cashback']];
  el.innerHTML = `<div class="linha-acoes"><div class="chips">${filtros.map(([k, t]) => `<button class="chip ${k === st.filtro ? 'ativo' : ''}" data-click="filtro" data-k="${k}">${t}</button>`).join('')}</div>
    <span class="espaco"></span><button class="btn" data-click="campanha">Campanha WhatsApp</button><button class="btn pri" data-click="nova">Nova cliente</button></div>
    <div class="card" id="tab-cli"></div>
    <div class="card"><h3>Segmentos</h3><p class="suave"><b>VIP</b>: 10% que mais compram (2+ compras). <b>Nova</b>: 1ª compra há menos de 30 dias. <b>Em risco</b>: sem comprar há 60–120 dias.
      <b>Inativa</b>: mais de 120 dias. Use os filtros para campanhas de reativação e aniversário.</p></div>`;
  const filtrar = () => App.d.clientes.filter(c => !c.anonimizada).filter(c => {
    if (st.filtro === 'todas') return true;
    if (st.filtro === 'aniversario') return c.nascimento && c.nascimento.slice(5, 7) === mes;
    if (st.filtro === 'crediario') return crediarioAberto(c.id).length > 0;
    if (st.filtro === 'cashback') return cashbackDisponivel(c) > 0;
    return segmentoCliente(c)[0] === st.filtro;
  });
  const t = tabela(el.querySelector('#tab-cli'), {
    linhas: filtrar(), exportar: 'clientes', placeholder: 'Nome, telefone, CPF, Instagram, etiqueta...',
    textoBusca: c => `${c.cpf} ${c.instagram} ${c.tags} ${c.apelido} ${c.email}`,
    colunas: [{ t: 'Nome', v: c => c.nome, h: c => `<b>${esc(c.nome)}</b>${c.ativo === false ? ' ' + etiqueta('inativo') : ''}${c.tags ? `<br><small class="suave">${esc(c.tags)}</small>` : ''}` },
      { t: 'Telefone', v: c => fone(c.telefone) }, { t: 'Aniversário', v: c => c.nascimento ? c.nascimento.slice(5) : '', h: c => c.nascimento ? `${c.nascimento.slice(8)}/${c.nascimento.slice(5, 7)}` : '' },
      { t: 'Segmento', v: c => segmentoCliente(c)[0], h: c => etiqueta(...segmentoCliente(c)) },
      { t: 'Compras', v: c => (App.idx.cliStats[c.id] || {}).compras || 0, cls: 'num' }, { t: 'Total gasto', v: c => r2((App.idx.cliStats[c.id] || {}).total || 0), h: c => moeda((App.idx.cliStats[c.id] || {}).total), cls: 'num' },
      { t: 'Última compra', v: c => (App.idx.cliStats[c.id] || {}).ultima || '', h: c => dataBR((App.idx.cliStats[c.id] || {}).ultima) },
      { t: 'Cashback', v: c => cashbackDisponivel(c), h: c => cashbackDisponivel(c) ? moeda(cashbackDisponivel(c)) : '', cls: 'num' },
      { t: '', semOrdem: true, h: c => c.telefone ? '<button class="btn pequeno" data-acao="whats">WhatsApp</button>' : '' }],
    acoes: { whats: c => modalMensagem(c) },
    aoClicar: c => fichaCliente(c)
  });
  ligar(el, {
    filtro: b => { st.filtro = b.dataset.k; el.querySelectorAll('[data-click=filtro]').forEach(x => x.classList.toggle('ativo', x === b)); t.atualizar(filtrar()); },
    nova: () => formCliente(null),
    campanha: () => campanhaWhatsApp(filtrar().filter(c => c.telefone && c.aceita_mensagens !== false))
  });
};

function modalMensagem(c, modeloPadrao = 'novidades') {
  const modelos = App.cfg.whatsapp || {};
  const nomes = { aniversario: 'Aniversário', novidades: 'Novidades', cobranca: 'Cobrança de crediário', condicional: 'Lembrete de condicional', reativacao: 'Reativação', cashback: 'Lembrete de cashback', recibo: 'Agradecimento' };
  const parc = crediarioAberto(c.id).sort((a, b) => a.vencimento.localeCompare(b.vencimento))[0];
  const cond = App.d.condicionais.find(x => x.cliente_id === c.id && x.status === 'aberto');
  const vars = { nome: c.apelido || c.nome.split(' ')[0], valor: parc ? moeda(parc.valor) : moeda(cashbackDisponivel(c)), vencimento: parc ? dataBR(parc.vencimento) : '',
    prazo: cond ? dataBR(cond.prazo) : '', validade: dataBR(c.cashback_validade), numero: '' };
  const m = modal({ titulo: `Mensagem para ${c.nome}`, corpo: `${c.aceita_mensagens === false ? '<div class="caixa-aviso alerta">Esta cliente não autorizou mensagens promocionais. Envie apenas mensagens de serviço (cobrança, condicional).</div>' : ''}
    <label class="campo"><span>Modelo</span><select id="mdl">${Object.keys(modelos).map(k => `<option value="${k}" ${k === modeloPadrao ? 'selected' : ''}>${esc(nomes[k] || k)}</option>`).join('')}</select></label>
    <label class="campo" style="margin-top:10px"><span>Mensagem</span><textarea id="msg" rows="5"></textarea></label>`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Abrir no WhatsApp', classe: 'pri', acao: mm => abrirWhatsApp(c.telefone, mm.querySelector('#msg').value) }] });
  const atualizar = () => { m.querySelector('#msg').value = textoModelo(m.querySelector('#mdl').value, vars); };
  m.querySelector('#mdl').onchange = atualizar; atualizar();
}

function campanhaWhatsApp(lista) {
  if (!lista.length) throw new Error('Nenhuma cliente com telefone e autorização neste filtro.');
  const m = modal({ titulo: `Campanha — ${lista.length} cliente(s)`, largura: 'largo', corpo: `<p class="suave">O WhatsApp não permite envio automático em massa sem a API oficial. Aqui você abre uma conversa por vez, com a mensagem pronta — use {nome} para personalizar.</p>
    <label class="campo"><span>Mensagem</span><textarea id="msg" rows="4">${esc(textoModelo('novidades', { nome: '{nome}' }))}</textarea></label>
    <div style="margin-top:10px;max-height:300px;overflow:auto">${lista.map((c, k) => `<div class="tarefa"><span style="flex:1">${esc(c.nome)} <small>${esc(fone(c.telefone))}</small></span><button class="btn pequeno" data-k="${k}">Abrir</button></div>`).join('')}</div>`,
    botoes: [{ texto: 'Fechar' }] });
  m.querySelectorAll('[data-k]').forEach(b => b.onclick = () => {
    const c = lista[+b.dataset.k];
    abrirWhatsApp(c.telefone, m.querySelector('#msg').value.replace(/\{nome\}/g, c.apelido || c.nome.split(' ')[0]).replace(/\{loja\}/g, App.cfg.loja.nome));
    b.textContent = 'Aberto'; b.classList.add('ok');
  });
}

function fichaCliente(c) {
  const s = App.idx.cliStats[c.id] || { total: 0, compras: 0, pecas: 0 };
  const vendas = App.d.vendas.filter(v => v.cliente_id === c.id).sort((a, b) => b.data.localeCompare(a.data));
  const cred = crediarioAberto(c.id);
  const conds = App.d.condicionais.filter(x => x.cliente_id === c.id && x.status === 'aberto');
  const vales = App.d.vales.filter(v => v.cliente_id === c.id && v.status === 'ativo');
  const cats = [...agrupar(vendas.filter(v => v.status === 'concluida').flatMap(v => v.itens), i => (App.idx.cat[i.categoria_id] || {}).nome || 'Serviços')].map(([k, l]) => [k, soma(l, i => i.qtd)]).sort((a, b) => b[1] - a[1]).slice(0, 4);
  modal({ titulo: c.nome, largura: 'xlargo', corpo: `
    <div class="kpis">${kpi('Total gasto', moeda(s.total), `${s.compras} compra(s) · ${s.pecas} peça(s)`)}${kpi('Ticket médio', moeda(s.compras ? s.total / s.compras : 0))}
      ${kpi('Última compra', s.ultima ? dataBR(s.ultima) : '—', s.ultima ? `há ${diasEntre(s.ultima, hojeISO())} dias` : '')}${kpi('Cashback', moeda(cashbackDisponivel(c)), c.cashback_validade ? 'válido até ' + dataBR(c.cashback_validade) : '')}
      ${kpi('Crediário em aberto', moeda(soma(cred, f => f.valor)), c.limite_crediario ? 'limite ' + moeda(c.limite_crediario) : '')}</div>
    <div class="grade g2"><div><h3>Dados ${etiqueta(...segmentoCliente(c))}</h3>
      <div>Telefone: <b>${esc(fone(c.telefone)) || '—'}</b></div><div>CPF: ${esc(cpfFmt(c.cpf)) || '—'}</div><div>E-mail: ${esc(c.email) || '—'}</div>
      <div>Nascimento: ${dataBR(c.nascimento) || '—'}</div><div>Instagram: ${esc(c.instagram) || '—'}</div><div>Endereço: ${esc(c.endereco) || '—'}</div>
      <div>Tamanhos: ${esc([c.tam_superior, c.tam_inferior, c.tam_calcado].filter(Boolean).join(' / ')) || '—'} · Estilo: ${esc(c.estilo) || '—'}</div>
      <div>Preferências: ${esc(c.preferencias) || '—'}</div>${c.observacoes ? `<div>Obs.: ${esc(c.observacoes)}</div>` : ''}
      <div>Mensagens: ${c.aceita_mensagens === false ? etiqueta('não autorizou', 'erro') : etiqueta('autorizou', 'ok')}</div></div>
      <div><h3>O que mais compra</h3>${barrasH(cats.map(([k, q]) => ({ rotulo: k, valor: q })), v => v + ' pç')}
        ${cred.length ? `<h3 style="margin-top:12px">Parcelas em aberto</h3>${cred.map(f => `<div class="tarefa"><span style="flex:1">${esc(f.parcela)} · venc. ${dataBR(f.vencimento)}</span>${etiqueta(...statusFin(f))}<b>${moeda(f.valor)}</b></div>`).join('')}` : ''}
        ${conds.length ? `<h3 style="margin-top:12px">Condicional em aberto</h3>${conds.map(x => `<div>Nº ${x.numero} · ${soma(x.itens, i => i.qtd)} peça(s) · até ${dataBR(x.prazo)}</div>`).join('')}` : ''}
        ${vales.length ? `<h3 style="margin-top:12px">Vales-troca</h3>${vales.map(v => `<div>${esc(v.codigo)} · saldo ${moeda(v.saldo)} · até ${dataBR(v.validade)}</div>`).join('')}` : ''}</div></div>
    <h3 style="margin-top:14px">Histórico de compras</h3>
    <table class="tab"><thead><tr><th>Nº</th><th>Data</th><th>Peças</th><th class="th-num">Total</th><th>Situação</th></tr></thead><tbody>
      ${vendas.slice(0, 30).map(v => `<tr><td>${v.numero}</td><td>${dataBR(v.data)}</td><td>${esc(v.itens.map(i => `${i.qtd}x ${i.nome} ${i.tamanho}`).join(', '))}</td><td class="num">${moeda(v.total)}</td><td>${v.status === 'concluida' ? '' : etiqueta('cancelada', 'erro')}</td></tr>`).join('') || '<tr><td colspan="5" class="vazio">Nenhuma compra ainda.</td></tr>'}</tbody></table>`,
    botoes: [
      { texto: 'Excluir dados (LGPD)', classe: 'perigo', acao: async () => {
        if (!await confirmar('Anonimizar esta cliente? Nome e dados pessoais serão apagados de forma definitiva; o histórico de vendas é mantido sem identificação. Use quando a cliente pedir exclusão dos dados.', 'Anonimizar', 'perigo')) return false;
        await api('cliente/excluir', { id: c.id }); toast('Dados da cliente removidos.', 'ok'); recarregarPagina();
      } },
      ...(c.telefone ? [{ texto: 'WhatsApp', acao: () => { modalMensagem(c, cred.length ? 'cobranca' : aniversarianteMes(c) ? 'aniversario' : 'novidades'); return false; } }] : []),
      { texto: 'Vender para ela', acao: () => { App.carrinho.cliente_id = c.id; ir('#/pdv'); } },
      { texto: 'Editar', classe: 'pri', acao: () => formCliente(c) }
    ] });
}

/* ----------------------------------------------------------- fornecedores */
const CAMPOS_FORNECEDOR = [
  { sec: 'Identificação' },
  { n: 'nome', r: 'Razão social / nome', w: 8, obr: 1 }, { n: 'fantasia', r: 'Nome fantasia', w: 4 },
  { n: 'cnpj', r: 'CNPJ / CPF', w: 4 }, { n: 'ie', r: 'Inscrição estadual', w: 4 }, { n: 'tipo', r: 'Tipo', t: 'select', w: 4, op: [['Confecção / fábrica', 'Confecção / fábrica'], ['Atacadista', 'Atacadista'], ['Representante', 'Representante'], ['Importador', 'Importador'], ['Brechó / consignado', 'Brechó / consignado'], ['Serviços', 'Serviços (costureira, frete...)'], ['Outro', 'Outro']] },
  { sec: 'Contato' },
  { n: 'contato', r: 'Pessoa de contato / representante', w: 6 }, { n: 'whatsapp', r: 'WhatsApp', t: 'tel', w: 3 }, { n: 'telefone', r: 'Telefone', t: 'tel', w: 3 },
  { n: 'email', r: 'E-mail', t: 'email', w: 6 }, { n: 'site', r: 'Site / Instagram / catálogo', w: 6 },
  { n: 'endereco', r: 'Endereço', w: 8 }, { n: 'cidade', r: 'Cidade/UF', w: 4 },
  { sec: 'Condições comerciais' },
  { n: 'prazo_pagamento', r: 'Prazo de pagamento', w: 4, ph: 'ex.: 30/60/90' }, { n: 'pedido_minimo', r: 'Pedido mínimo (R$)', t: 'money', w: 4 }, { n: 'prazo_entrega', r: 'Prazo de entrega', w: 4, ph: 'ex.: 7 dias úteis' },
  { n: 'frete', r: 'Frete', t: 'select', w: 4, op: [['CIF (fornecedor paga)', 'CIF (fornecedor paga)'], ['FOB (loja paga)', 'FOB (loja paga)'], ['Retira no local', 'Retira no local']] },
  { n: 'desconto_avista', r: 'Desconto à vista (%)', t: 'pct', w: 4 }, { n: 'aceita_troca', r: 'Aceita troca de peças com defeito', t: 'check', w: 4 },
  { n: 'fornece', r: 'O que fornece', w: 12, ph: 'ex.: jeans, alfaiataria, plus size' },
  { n: 'dados_bancarios', r: 'Dados para pagamento (chave Pix / banco)', w: 12 },
  { n: 'avaliacao', r: 'Avaliação', t: 'select', w: 4, op: [['5', '★★★★★ Excelente'], ['4', '★★★★ Bom'], ['3', '★★★ Regular'], ['2', '★★ Ruim'], ['1', '★ Péssimo']] },
  { n: 'obs', r: 'Observações (qualidade, atrasos, grade, modelagem...)', t: 'textarea', w: 12 }, { n: 'ativo', r: 'Ativo', t: 'check', w: 12, padrao: true }
];

App.paginas.fornecedores = async el => {
  el.innerHTML = `<div class="linha-acoes"><span class="espaco"></span><button class="btn pri" data-click="novo">Novo fornecedor</button></div><div class="card" id="tab-forn"></div>`;
  const compras = {};
  for (const e of App.d.entradas) if (e.status === 'ativa' && e.fornecedor_id) {
    const c = compras[e.fornecedor_id] || (compras[e.fornecedor_id] = { total: 0, n: 0, ultima: '' });
    c.total += e.total; c.n++; if (e.data > c.ultima) c.ultima = e.data;
  }
  const aPagar = id => soma(App.d.financeiro.filter(f => f.fornecedor_id === id && f.tipo === 'pagar' && f.status === 'pendente'), f => f.valor);
  tabela(el.querySelector('#tab-forn'), {
    linhas: App.d.fornecedores, exportar: 'fornecedores', textoBusca: f => `${f.cnpj} ${f.fornece} ${f.contato} ${f.cidade}`,
    colunas: [{ t: 'Fornecedor', v: f => f.nome, h: f => `<b>${esc(f.fantasia || f.nome)}</b>${f.ativo === false ? ' ' + etiqueta('inativo') : ''}<br><small class="suave">${esc(f.fornece || '')}</small>` },
      { t: 'Contato', v: f => f.contato || '', h: f => `${esc(f.contato || '')}<br><small>${esc(fone(f.whatsapp || f.telefone))}</small>` }, { t: 'Cidade', v: f => f.cidade || '' },
      { t: 'Prazo', v: f => f.prazo_pagamento || '' }, { t: 'Avaliação', v: f => n(f.avaliacao), h: f => f.avaliacao ? '★'.repeat(+f.avaliacao) : '' },
      { t: 'Compras', v: f => (compras[f.id] || {}).total || 0, h: f => compras[f.id] ? `${moeda(compras[f.id].total)}<br><small>${compras[f.id].n} entrada(s)</small>` : '—', cls: 'num' },
      { t: 'Última compra', v: f => (compras[f.id] || {}).ultima || '', h: f => dataBR((compras[f.id] || {}).ultima) },
      { t: 'A pagar', v: f => aPagar(f.id), h: f => aPagar(f.id) ? `<b>${moeda(aPagar(f.id))}</b>` : '', cls: 'num' },
      { t: '', semOrdem: true, h: f => f.whatsapp ? '<button class="btn pequeno" data-acao="whats">WhatsApp</button>' : '' }],
    acoes: { whats: f => abrirWhatsApp(f.whatsapp, `Olá, ${f.contato || ''}! Aqui é da ${App.cfg.loja.nome}. `) },
    aoClicar: f => formFornecedor(f)
  });
  ligar(el, { novo: () => formFornecedor(null) });
};

function formFornecedor(f) {
  const hist = f ? App.d.entradas.filter(e => e.fornecedor_id === f.id && e.status === 'ativa').slice(-8).reverse() : [];
  modal({ titulo: f ? f.nome : 'Novo fornecedor', largura: 'largo', corpo: formHTML(CAMPOS_FORNECEDOR, f || {}) +
    (hist.length ? `<h3 style="margin-top:14px">Últimas compras</h3>${hist.map(e => `<div class="tarefa"><span style="flex:1">Entrada ${e.numero} · ${dataBR(e.data)} · NF ${esc(e.nota || 's/n')} · ${soma(e.itens, i => i.qtd)} peças</span><b>${moeda(e.total)}</b></div>`).join('')}` : ''),
    botoes: [...(f ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { if (!await confirmar('Excluir este fornecedor?', 'Excluir', 'perigo')) return false; await api('excluir/fornecedores', { id: f.id }); recarregarPagina(); } }] : []),
      { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => {
        const o = lerForm(m, CAMPOS_FORNECEDOR); o.id = f ? f.id : undefined;
        await api('salvar/fornecedores', { obj: { ...(f || {}), ...o } }); toast('Fornecedor salvo.', 'ok'); recarregarPagina();
      } }] });
}

/* ---------------------------------------------------------------- serviços */
App.paginas.servicos = async el => {
  el.innerHTML = `<div class="caixa-aviso">Serviços aparecem como botões no caixa e não mexem no estoque (ex.: ajuste de barra, embalagem para presente, entrega). O custo informado entra no DRE como custo da venda.</div>
    <div class="linha-acoes"><span class="espaco"></span><button class="btn pri" data-click="novo">Novo serviço</button></div><div class="card" id="tab-serv"></div>`;
  const campos = [{ n: 'nome', r: 'Serviço', w: 8, obr: 1 }, { n: 'preco', r: 'Preço cobrado', t: 'money', w: 4, obr: 1 }, { n: 'custo', r: 'Custo (ex.: costureira)', t: 'money', w: 4 },
    { n: 'descricao', r: 'Descrição', w: 8 }, { n: 'ativo', r: 'Ativo (aparece no caixa)', t: 'check', w: 12, padrao: true }];
  const form = s => modal({ titulo: s ? s.nome : 'Novo serviço', corpo: formHTML(campos, s || {}), botoes: [
    ...(s ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { await api('excluir/servicos', { id: s.id }); recarregarPagina(); } }] : []),
    { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => { await api('salvar/servicos', { obj: { ...(s || {}), ...lerForm(m, campos) } }); recarregarPagina(); } }] });
  const vendidos = {};
  App.d.vendas.filter(v => v.status === 'concluida').forEach(v => v.itens.filter(i => i.servico_id).forEach(i => { vendidos[i.servico_id] = (vendidos[i.servico_id] || 0) + i.qtd; }));
  tabela(el.querySelector('#tab-serv'), { linhas: App.d.servicos, busca: false,
    colunas: [{ t: 'Serviço', v: s => s.nome, h: s => `<b>${esc(s.nome)}</b>${s.ativo === false ? ' ' + etiqueta('inativo') : ''}<br><small class="suave">${esc(s.descricao || '')}</small>` },
      { t: 'Preço', v: s => n(s.preco), h: s => moeda(s.preco), cls: 'num' }, { t: 'Custo', v: s => n(s.custo), h: s => moeda(s.custo), cls: 'num' },
      { t: 'Margem', v: s => n(s.preco) ? (n(s.preco) - n(s.custo)) / n(s.preco) * 100 : 0, h: s => pct(n(s.preco) ? (n(s.preco) - n(s.custo)) / n(s.preco) * 100 : 0), cls: 'num' },
      { t: 'Vendidos', v: s => vendidos[s.id] || 0, cls: 'num' }],
    aoClicar: s => form(s) });
  ligar(el, { novo: () => form(null) });
};

/* ------------------------------------------------------------------ ofertas */
App.paginas.ofertas = async el => {
  const fid = App.cfg.fidelidade || {};
  el.innerHTML = `<div class="caixa-aviso">As ofertas ativas são aplicadas automaticamente no caixa. Por item vale o maior desconto (ou a soma, se marcada como cumulativa); no total da compra, o mesmo.
    As datas comemorativas já vêm programadas para o próximo ano — revise os percentuais.</div>
    <div class="linha-acoes"><span class="espaco"></span><button class="btn pri" data-click="nova">Nova oferta ou cupom</button></div>
    <div class="card" id="tab-promo"></div>
    <div class="card"><div class="card-cab"><h3>Programa de fidelidade (cashback)</h3>${fid.ativo ? etiqueta('Ativo', 'ok') : etiqueta('Desativado')}</div>
      <div id="f-fid">${formHTML(CAMPOS_FIDELIDADE, fid)}</div><button class="btn pri" style="margin-top:12px" data-click="salvarFid">Salvar fidelidade</button></div>`;
  const usos = {};
  App.d.vendas.filter(v => v.status === 'concluida').forEach(v => (v.promocoes || []).forEach(p => { usos[p] = usos[p] || { n: 0, desc: 0 }; usos[p].n++; usos[p].desc += v.desconto_itens + v.desconto_carrinho; }));
  tabela(el.querySelector('#tab-promo'), {
    linhas: App.d.promocoes.slice().sort((a, b) => (statusPromo(a)[1] === 'ok' ? 0 : 1) - (statusPromo(b)[1] === 'ok' ? 0 : 1)), exportar: 'ofertas',
    colunas: [{ t: 'Oferta', v: p => p.nome, h: p => `<b>${esc(p.nome)}</b>${p.codigo ? ` <code>${esc(p.codigo)}</code>` : ''}<br><small class="suave">${esc(p.descricao || '')}</small>` },
      { t: 'Tipo', v: p => TIPOS_PROMO[p.tipo] }, { t: 'Regra', v: p => regraPromo(p) },
      { t: 'Período', v: p => p.inicio || '', h: p => p.inicio || p.fim ? `${dataBR(p.inicio) || '…'} a ${dataBR(p.fim) || '…'}` : 'Sempre' },
      { t: 'Situação', v: p => statusPromo(p)[0], h: p => etiqueta(...statusPromo(p)) },
      { t: 'Vendas', v: p => (usos[p.nome] || {}).n || 0, cls: 'num' },
      { t: '', semOrdem: true, h: p => `<button class="btn pequeno" data-acao="alternar">${p.ativo ? 'Desativar' : 'Ativar'}</button>` }],
    acoes: { alternar: async p => { await api('salvar/promocoes', { obj: { ...p, ativo: !p.ativo } }); recarregarPagina(); } },
    aoClicar: p => formPromo(p)
  });
  ligar(el, {
    nova: () => formPromo(null),
    salvarFid: async () => { const f = lerForm(el.querySelector('#f-fid'), CAMPOS_FIDELIDADE); await api('config', { config: { fidelidade: f } }); await carregar([]); toast('Fidelidade salva.', 'ok'); recarregarPagina(); }
  });
};
const CAMPOS_FIDELIDADE = [
  { n: 'ativo', r: 'Gerar cashback nas compras de clientes identificadas', t: 'check', w: 12 },
  { n: 'cashback_pct', r: 'Cashback (% da compra)', t: 'pct', w: 3 }, { n: 'validade_dias', r: 'Validade (dias)', t: 'number', w: 3 },
  { n: 'uso_minimo_compra', r: 'Compra mínima para usar (R$)', t: 'money', w: 3 }, { n: 'uso_max_pct', r: 'Uso máximo (% da compra)', t: 'pct', w: 3 }
];
function regraPromo(p) {
  const esc_ = p.escopo && p.escopo.tipo !== 'todos' ? ` em ${(p.escopo.ids || []).map(id => ({ categoria: App.idx.cat, colecao: App.idx.col, marca: App.idx.marca, produto: App.idx.prod }[p.escopo.tipo][id] || {}).nome).filter(Boolean).join(', ')}` : '';
  switch (p.tipo) {
    case 'percentual': return `${pct(p.percentual, 0)} off${esc_}`;
    case 'leve_pague': return `Leve ${p.leve}, pague ${p.pague}${esc_}`;
    case 'progressivo': return (p.faixas || []).map(f => `${f.qtd}+ pç: ${pct(f.percentual, 0)}`).join(' · ') + esc_;
    case 'valor_minimo': return `${pct(p.percentual, 0)} acima de ${moeda(p.minimo)}`;
    case 'cupom': return `${n(p.valor_fixo) ? moeda(p.valor_fixo) : pct(p.percentual, 0)} off${n(p.minimo) ? ' acima de ' + moeda(p.minimo) : ''}${n(p.max_usos) ? ` · ${p.usos || 0}/${p.max_usos} usos` : ''}`;
    default: return `${pct(p.percentual, 0)} off`;
  }
}
function formPromo(p) {
  const o = p ? JSON.parse(JSON.stringify(p)) : { tipo: 'percentual', ativo: true, escopo: { tipo: 'todos', ids: [] }, dias_semana: [], faixas: [{ qtd: 2, percentual: 5 }, { qtd: 3, percentual: 10 }] };
  const m = modal({ titulo: p ? p.nome : 'Nova oferta', largura: 'largo', corpo: `<div id="fp"></div>`, botoes: [
    ...(p ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { if (!await confirmar('Excluir esta oferta?', 'Excluir', 'perigo')) return false; await api('excluir/promocoes', { id: p.id }); recarregarPagina(); } }] : []),
    { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async () => { ler(); if (!o.nome) throw new Error('Dê um nome à oferta.'); await api('salvar/promocoes', { obj: o }); toast('Oferta salva.', 'ok'); recarregarPagina(); } }] });
  const box = m.querySelector('#fp');
  function ler() {
    const g = s => box.querySelector(s);
    o.nome = g('[name=nome]').value.trim(); o.tipo = g('[name=tipo]').value; o.descricao = g('[name=descricao]').value;
    o.ativo = g('[name=ativo]').checked; o.cumulativa = g('[name=cumulativa]').checked;
    o.inicio = g('[name=inicio]').value; o.fim = g('[name=fim]').value;
    o.dias_semana = [...box.querySelectorAll('[name=dia]:checked')].map(x => +x.value);
    ['percentual', 'minimo', 'leve', 'pague', 'max_usos', 'valor_fixo'].forEach(k => { const e = g(`[name=${k}]`); if (e) o[k] = n(e.value); });
    const cod = g('[name=codigo]'); if (cod) o.codigo = cod.value.trim().toUpperCase();
    const et = g('[name=escopo_tipo]'); if (et) o.escopo = { tipo: et.value, ids: [...box.querySelectorAll('[name=escopo_id]:checked')].map(x => x.value) };
    if (o.tipo === 'pagamento') o.formas = [...box.querySelectorAll('[name=forma]:checked')].map(x => x.value);
    if (o.tipo === 'progressivo') o.faixas = [...box.querySelectorAll('[data-faixa]')].map(r => ({ qtd: n(r.querySelector('[data-q]').value), percentual: n(r.querySelector('[data-p]').value) })).filter(f => f.qtd > 0);
  }
  function render() {
    const temEscopo = PROMO_ITEM.includes(o.tipo);
    const lista = { categoria: App.d.categorias, colecao: App.d.colecoes, marca: App.d.marcas, produto: App.d.produtos.filter(x => x.ativo !== false) }[o.escopo.tipo] || [];
    box.innerHTML = `${formHTML([{ n: 'nome', r: 'Nome da oferta', w: 8, obr: 1 }, { n: 'tipo', r: 'Tipo', t: 'select', w: 4, vazio: false, op: Object.entries(TIPOS_PROMO), dataChange: 'tipo' },
      { n: 'descricao', r: 'Descrição (aparece para você)', w: 12 }], o)}
      <div class="grade-form" style="margin-top:10px">
        ${o.tipo === 'cupom' ? campoHTML({ n: 'codigo', r: 'Código do cupom', w: 4 }, o.codigo) + campoHTML({ n: 'valor_fixo', r: 'Desconto em R$ (ou deixe 0 e use %)', t: 'money', w: 4 }, o.valor_fixo) + campoHTML({ n: 'max_usos', r: 'Limite de usos (0 = ilimitado)', t: 'number', w: 4 }, o.max_usos) : ''}
        ${o.tipo === 'leve_pague' ? campoHTML({ n: 'leve', r: 'Leve', t: 'number', w: 3, min: 2 }, o.leve || 3) + campoHTML({ n: 'pague', r: 'Pague', t: 'number', w: 3, min: 1 }, o.pague || 2) : ''}
        ${!['leve_pague', 'progressivo'].includes(o.tipo) ? campoHTML({ n: 'percentual', r: 'Desconto (%)', t: 'pct', w: 3 }, o.percentual) : ''}
        ${['valor_minimo', 'cupom'].includes(o.tipo) ? campoHTML({ n: 'minimo', r: 'Compra mínima (R$)', t: 'money', w: 3 }, o.minimo) : ''}
        ${o.tipo === 'pagamento' ? `<div class="w12">Formas aceitas: ${['pix', 'dinheiro', 'debito'].map(f => `<label class="check" style="display:inline-flex;margin-right:12px"><input type="checkbox" name="forma" value="${f}" ${(o.formas || ['pix', 'dinheiro']).includes(f) ? 'checked' : ''}>${FORMAS_PAG[f]}</label>`).join('')}</div>` : ''}
        ${o.tipo === 'progressivo' ? `<div class="w12"><b>Faixas</b>${(o.faixas || []).map(f => `<div data-faixa style="display:flex;gap:8px;align-items:center;margin-top:6px">A partir de <input type="number" class="input-qtd" data-q value="${f.qtd}"> peças: <input type="number" class="input-qtd" data-p value="${f.percentual}">%</div>`).join('')}
          <button class="btn pequeno" data-click="faixa" style="margin-top:6px">+ faixa</button></div>` : ''}
      </div>
      ${temEscopo ? `<div class="grade-form" style="margin-top:10px">${campoHTML({ n: 'escopo_tipo', r: 'Vale para', t: 'select', w: 4, vazio: false, op: [['todos', 'Todos os produtos'], ['categoria', 'Categorias'], ['colecao', 'Coleções'], ['marca', 'Marcas'], ['produto', 'Produtos específicos']], dataChange: 'escopo' }, o.escopo.tipo)}
        ${o.escopo.tipo !== 'todos' ? `<div class="w12" style="max-height:180px;overflow:auto;border:1px solid var(--borda);border-radius:8px;padding:8px">${lista.map(x => `<label class="check"><input type="checkbox" name="escopo_id" value="${x.id}" ${(o.escopo.ids || []).includes(x.id) ? 'checked' : ''}>${esc(x.nome)}</label>`).join('')}</div>` : ''}</div>` : ''}
      <div class="grade-form" style="margin-top:10px">${campoHTML({ n: 'inicio', r: 'Início (opcional)', t: 'date', w: 3 }, o.inicio)}${campoHTML({ n: 'fim', r: 'Fim (opcional)', t: 'date', w: 3 }, o.fim)}
        <div class="w6"><span class="suave" style="font-size:12px">Somente nos dias (vazio = todos)</span><div>${DIAS_SEMANA.map((d, k) => `<label class="check" style="display:inline-flex;margin-right:8px"><input type="checkbox" name="dia" value="${k}" ${(o.dias_semana || []).includes(k) ? 'checked' : ''}>${d.slice(0, 3)}</label>`).join('')}</div></div>
        ${campoHTML({ n: 'ativo', r: 'Ativa', t: 'check', w: 4 }, o.ativo)}${campoHTML({ n: 'cumulativa', r: 'Cumulativa (soma com outras ofertas)', t: 'check', w: 8 }, o.cumulativa)}</div>`;
    ligar(box, { tipo: () => { ler(); render(); }, escopo: () => { ler(); o.escopo.ids = []; render(); }, faixa: () => { ler(); o.faixas.push({ qtd: (o.faixas.slice(-1)[0] || { qtd: 1 }).qtd + 1, percentual: 0 }); render(); } });
  }
  render();
}
