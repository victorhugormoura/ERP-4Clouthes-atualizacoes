/* Loja ERP — usar o celular como terminal: tela de conexão (no computador) e tela inicial (no celular).
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

App.paginas.celular = async el => (App.celular ? inicioCelular(el) : conectarCelular(el));

/* ------------------------------------------------------------------ no celular */
function inicioCelular(el) {
  const gestao = App.papel !== 'vendedora';
  const blocos = [
    ['consultar', 'Consultar peça', 'Leia a etiqueta e veja preço, tamanhos e estoque.'],
    ['vender', 'Vender', 'Abre o caixa; o botão Câmera lê as etiquetas.'],
    ...(gestao ? [['cadastrar', 'Cadastrar produto', 'Tire a foto e leia o código de fábrica da peça.'],
      ['conta', 'Conta a pagar', 'Leia o boleto, a conta de luz ou o QR Code Pix do fornecedor.']] : []),
    ['clientes', 'Clientes', 'Busque, cadastre e chame no WhatsApp.'],
    ['painel', 'Painel', 'Resumo do dia e avisos.']];
  el.innerHTML = `<div class="cel-inicio">${blocos.map(([k, t, d]) => `<button class="cel-bloco" data-click="${k}"><b>${t}</b><span>${d}</span></button>`).join('')}</div>
    <p class="suave cel-dica">Dica: no menu do navegador, toque em <b>Adicionar à tela inicial</b> para abrir o Loja ERP como um aplicativo.</p>`;
  ligar(el, {
    consultar: () => consultarPeca(),
    vender: () => ir('#/pdv'),
    cadastrar: () => ir('#/produto/novo'),
    conta: () => contaPorCodigo(),
    clientes: () => ir('#/clientes'),
    painel: () => ir('#/painel')
  });
}

async function consultarPeca() {
  const cod = await Leitor.ler({ titulo: 'Consultar peça', dica: 'Aponte para a etiqueta ou para o código de barras da peça.' });
  if (cod === null) return;
  const achado = App.idx.cod[cod.trim().toUpperCase()];
  const lista = achado ? [achado.p] : buscaProdutos(cod.trim(), 2);
  if (lista.length !== 1) {
    toast(lista.length ? 'Mais de uma peça com esse código. Busque pelo nome em Produtos.' : `Nenhuma peça com o código ${cod}.`, 'erro');
    if (!lista.length && App.papel !== 'vendedora' && await confirmar(`Nenhuma peça cadastrada com o código ${cod}. Cadastrar agora?`, 'Cadastrar')) {
      ir('#/produto/novo');
      toast(`Depois de gerar a grade, coloque o código ${cod} na variação certa (botão Câmera).`);
    }
    return;
  }
  const p = lista[0], v = achado ? achado.v : null, pr = p.preco;
  modal({ titulo: p.nome, corpo: `<div class="cel-peca">${fotoHTML(p, 'foto-grande')}
      <div class="cel-preco">${moeda(pr)}</div><div class="suave">${esc(p.sku)} · ${esc((App.idx.cat[p.categoria_id] || {}).nome || '')}</div></div>
      <table class="tab"><thead><tr><th>Tamanho / cor</th><th class="th-num">Estoque</th></tr></thead><tbody>
      ${p.variacoes.map(x => `<tr class="${v && x.id === v.id ? 'destaque' : ''}"><td>${esc(x.tamanho)} / ${esc(x.cor)}</td><td class="num"><b class="${x.estoque <= 0 ? 'negativo' : ''}">${x.estoque}</b></td></tr>`).join('')}</tbody></table>`,
    botoes: [{ texto: 'Fechar' },
      ...(App.papel !== 'vendedora' ? [{ texto: 'Abrir cadastro / foto', acao: () => { ir(`#/produto/${p.id}`); } }] : []),
      { texto: 'Vender', classe: 'pri', acao: () => { App.buscaPendente = v ? v.codigo_barras : p.sku; ir('#/pdv'); } }] });
}

/* --------------------------------------------------------------- no computador */
async function conectarCelular(el) {
  if (App.papel === 'vendedora') {
    el.innerHTML = '<div class="card caixa-aviso">Peça à proprietária ou à gerente para conectar o seu celular.</div>';
    return;
  }
  const st = await api('celular');
  const lista = st.aparelhos.length ? `<div class="tabela-wrap"><table class="tab"><thead><tr><th>Aparelho</th><th>Conectado em</th><th>Último uso</th><th></th></tr></thead><tbody>
      ${st.aparelhos.map(a => `<tr><td>${esc(a.nome)}</td><td>${dataHoraBR(a.criado_em)}</td><td>${dataHoraBR(a.ultimo_uso)}</td>
      <td><button class="btn pequeno perigo" data-click="remover" data-id="${esc(a.id)}">Desconectar</button></td></tr>`).join('')}</tbody></table></div>
      <div class="linha-acoes" style="margin-top:10px"><span class="espaco"></span><button class="btn pequeno perigo" data-click="removerTodos">Desconectar todos</button></div>`
    : '<p class="vazio">Nenhum celular conectado ainda.</p>';
  el.innerHTML = `<div class="grade g-2-1"><div>
    <div class="card"><div class="card-cab"><h3>Usar o celular como terminal</h3>${etiqueta(st.ativo ? 'ligado' : 'desligado', st.ativo ? 'ok' : 'alerta')}</div>
      <p>Com o celular conectado ao mesmo Wi-Fi da loja, dá para <b>consultar peças lendo a etiqueta</b>, <b>vender</b>, <b>cadastrar produtos com foto</b>
        e <b>lançar contas lendo o boleto ou o Pix</b> — tudo direto neste computador, sem internet e sem instalar aplicativo.</p>
      ${st.ativo ? `<div class="linha-acoes"><button class="btn pri grande" data-click="parear">Conectar um celular</button><span class="espaco"></span>
        <button class="btn" data-click="desligar">Desligar acesso</button></div>
        <p class="suave">Endereço na rede: ${st.ips.map(ip => `<b>https://${esc(ip)}:${st.porta}</b>`).join(' ou ')}</p>`
      : `<div class="linha-acoes"><button class="btn pri grande" data-click="ligar">Ligar acesso pelo celular</button></div>
        <p class="suave">Fica desligado até você ligar. Só aparelhos da rede local e conectados por QR Code conseguem entrar, e cada pessoa ainda entra com o próprio usuário e senha.</p>`}
    </div>
    ${st.pendentes.length ? `<div class="card"><h3>Pedidos de conexão</h3>${st.pendentes.map(p => `<div class="tarefa"><span style="flex:1"><b>${esc(p.nome)}</b> — código <b>${esc(p.conferencia)}</b></span>
      <button class="btn pequeno pri" data-click="permitir" data-id="${esc(p.id)}">Permitir</button> <button class="btn pequeno perigo" data-click="recusar" data-id="${esc(p.id)}">Recusar</button></div>`).join('')}</div>` : ''}
    <div class="card"><h3>Celulares conectados</h3>${lista}</div></div>
    <div><div class="card"><h3>O celular não abre?</h3><ol class="lista-passos">
      <li>Confira se o celular está no <b>mesmo Wi-Fi</b> da loja (não na rede de visitantes nem no 4G/5G).</li>
      ${st.ativo && st.ips.length ? `<li>Teste o endereço aqui no computador: <a class="btn pequeno" href="https://${esc(st.ips[0])}:${st.porta}/" target="_blank" rel="noopener">Abrir ${esc(st.ips[0])}</a>
        Se aparecer "Celular não conectado" (depois do aviso de segurança), o computador está pronto e o problema é a rede ou o celular.</li>` : ''}
      <li>No celular, feche as abas antigas do Loja ERP e gere um QR Code novo.</li>
      <li>Se o Windows perguntar sobre o <b>Firewall</b>, deixe marcado só <b>Redes privadas</b> e clique em <b>Permitir acesso</b>.</li>
      ${st.windows ? '<li>Ainda não abre? <button class="btn pequeno" data-click="firewall">Liberar no firewall do Windows</button> (o Windows vai pedir confirmação).</li>' : ''}
      <li>O aviso de "conexão não é particular" é esperado: veja o passo a passo ao conectar.</li></ol></div>
    ${st.ativo ? `<div class="card"><div class="card-cab"><h3>Diagnóstico da conexão</h3><button class="btn pequeno" data-click="diagnostico">Verificar</button></div>
      <p class="suave">Tente abrir o QR Code no celular e depois clique em <b>Verificar</b>: o sistema mostra se o celular chegou até este computador e o que pode estar bloqueando.</p>
      <div id="diag-celular">${st.ultimo_contato ? `<div class="diag ok">Último contato de um aparelho: ${esc(st.ultimo_contato.ip)}, há ${st.ultimo_contato.segundos} s.</div>` : ''}</div></div>` : ''}
    <div class="card"><h3>Segurança</h3><p class="suave">A conexão é criptografada com um certificado criado neste computador.
      O QR Code vale por 2 minutos e só uma vez, e cada celular só entra depois que alguém clica em <b>Permitir</b> aqui no computador, conferindo o código.
      Use o Wi-Fi da loja (não o de visitantes) e desconecte aqui o celular que for perdido ou trocado.
      ${st.impressao ? `<br>Código do certificado: <b>${esc(st.impressao)}</b>` : ''}</p></div></div></div>`;
  ligar(el, {
    ligar: async () => { await api('celular/ativar', { ativo: true }); toast('Acesso pelo celular ligado.', 'ok'); recarregarPagina(); },
    desligar: async () => { if (!await confirmar('Desligar o acesso pelo celular? Os celulares conectados param de funcionar até você ligar de novo.', 'Desligar')) return; await api('celular/ativar', { ativo: false }); recarregarPagina(); },
    parear: () => modalPareamento(st),
    permitir: async b => { await api('celular/permitir', { id: b.dataset.id, permitir: true }); toast('Celular conectado.', 'ok'); recarregarPagina(); },
    recusar: async b => { await api('celular/permitir', { id: b.dataset.id, permitir: false }); recarregarPagina(); },
    remover: async b => { if (!await confirmar('Desconectar este celular? Para usar de novo, será preciso ler um novo QR Code.', 'Desconectar', 'perigo')) return; await api('celular/remover', { id: b.dataset.id }); recarregarPagina(); },
    removerTodos: async () => { if (!await confirmar('Desconectar todos os celulares?', 'Desconectar todos', 'perigo')) return; await api('celular/remover', { todos: true }); recarregarPagina(); },
    firewall: async b => { b.disabled = true; b.textContent = 'Aguardando o Windows...'; try { const r = await api('celular/firewall', {}); toast(r.mensagem, 'ok'); } catch (e) { toast(e.message, 'erro'); } b.disabled = false; b.textContent = 'Liberar no firewall do Windows'; const d = el.querySelector('[data-click=diagnostico]'); if (d) d.click(); },
    diagnostico: async b => {
      const caixa = el.querySelector('#diag-celular');
      b.disabled = true; b.textContent = 'Verificando...'; caixa.innerHTML = '<p class="suave">Conferindo a rede e o firewall (pode levar alguns segundos)...</p>';
      try {
        const r = await api('celular/diagnostico', {});
        caixa.innerHTML = r.itens.map(i => `<div class="diag ${esc(i.nivel)}"><b>${esc(i.titulo)}</b>${i.detalhe ? `<br><span>${esc(i.detalhe)}</span>` : ''}</div>`).join('');
      } catch (e) { caixa.innerHTML = `<div class="diag erro">${esc(e.message)}</div>`; }
      b.disabled = false; b.textContent = 'Verificar';
    }
  });
}

async function modalPareamento(st) {
  const r = await api('celular/parear', {});
  const qtdAntes = st.aparelhos.length;
  let fim = Date.now() + r.validade * 1000, timer = null;
  const m = modal({ titulo: 'Conectar um celular', largura: 'largo', corpo: `<div class="grade g2 pareamento">
      <div class="c"><div id="qr-celular" class="qr-celular"></div>
        ${r.enderecos.length > 1 ? `<label class="campo"><span>Rede</span><select id="rede-celular">${r.enderecos.map((u, i) => `<option value="${i}">${esc(new URL(u).hostname)}</option>`).join('')}</select></label>` : ''}
        <p class="suave">Vale por <b id="qr-tempo">2:00</b> e só uma vez.</p></div>
      <ol class="lista-passos">
        <li>Conecte o celular ao <b>mesmo Wi-Fi</b> da loja.</li>
        <li>Abra a <b>câmera</b> do celular, aponte para o QR Code e toque no link que aparecer.</li>
        <li>Vai aparecer um aviso de <b>"Sua conexão não é particular"</b> (ou "não é segura"). É esperado: o endereço é deste computador, não um site da internet.
          <br>Android/Chrome: toque em <b>Avançado</b> e depois em <b>Ir para … (não seguro)</b>.
          <br>iPhone: toque em <b>Mostrar detalhes</b> e depois em <b>visitar este site</b>.</li>
        <li>O celular mostra um <b>código de 4 números</b>. Ele aparece aqui também: se for igual, clique em <b>Permitir</b>.</li>
        <li>Entre com <b>seu usuário e senha</b>. Pronto!</li></ol></div><div id="pedido-celular"></div>`,
    botoes: [{ texto: 'Fechar' }] });
  const desenhar = i => { m.querySelector('#qr-celular').innerHTML = QRCode.svg(QRCode.gerar(r.enderecos[i], 1)); };
  desenhar(0);
  const sel = m.querySelector('#rede-celular');
  if (sel) sel.onchange = () => desenhar(+sel.value);
  const ciclo = async () => {
    if (!m.isConnected) return;
    const resta = Math.max(0, Math.round((fim - Date.now()) / 1000));
    m.querySelector('#qr-tempo').textContent = `${Math.floor(resta / 60)}:${String(resta % 60).padStart(2, '0')}`;
    if (!resta && m.querySelector('#qr-celular svg')) m.querySelector('#qr-celular').innerHTML = '<p class="vazio">QR Code vencido. Feche e toque em "Conectar um celular" de novo.</p>';
    if (Date.now() - fim > 300000) return;
    try {
      const atual = await api('celular');
      if (atual.aparelhos.length > qtdAntes) { m.fechar(); toast(`Celular conectado: ${atual.aparelhos[atual.aparelhos.length - 1].nome}.`, 'ok'); recarregarPagina(); return; }
      const caixa = m.querySelector('#pedido-celular');
      caixa.innerHTML = atual.pendentes.map(p => `<div class="caixa-aviso alerta pedido"><b>${esc(p.nome)}</b> pediu para entrar. Código no celular: <b class="cod-pedido">${esc(p.conferencia)}</b>
        <div class="linha-acoes" style="margin:8px 0 0"><button class="btn pri" data-sim="${esc(p.id)}">Permitir</button><button class="btn perigo" data-nao="${esc(p.id)}">Recusar</button>
        <span class="suave">Só permita se o código for o mesmo do celular.</span></div></div>`).join('');
      caixa.querySelectorAll('[data-sim],[data-nao]').forEach(b => b.onclick = async () => {
        await api('celular/permitir', { id: b.dataset.sim || b.dataset.nao, permitir: !!b.dataset.sim }).catch(e => toast(e.message, 'erro'));
        if (!b.dataset.sim) toast('Pedido recusado.');
      });
    } catch (e) { /* tenta de novo no próximo ciclo */ }
    timer = setTimeout(ciclo, 2000);
  };
  ciclo();
  new MutationObserver((_, obs) => { if (!m.isConnected) { obs.disconnect(); clearTimeout(timer); } }).observe(document.getElementById('modais'), { childList: true });
}
