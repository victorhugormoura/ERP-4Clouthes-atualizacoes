/* Loja ERP — backup, restauração, saúde dos dados e tela de recuperação.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const NIVEIS_SAUDE = { ok: ['Dados protegidos', 'et-ok'], alerta: ['Atenção aos dados', 'et-alerta'], erro: ['Problema nos dados', 'et-erro'] };

async function atualizarSaude() {
  if (App.papel === 'vendedora') return;
  try {
    App.saude = await api('saude');
    const el = document.getElementById('topo-saude');
    const [texto, classe] = NIVEIS_SAUDE[App.saude.nivel];
    el.className = 'etiqueta ' + classe;
    el.textContent = texto;
    el.title = App.saude.mensagens.join('\n') || 'Backup de hoje feito e conferido.';
    el.hidden = false;
  } catch (e) { /* a próxima verificação tenta de novo */ }
}

function tamanhoArquivo(bytes) {
  return bytes > 1048576 ? numBR(bytes / 1048576, 1) + ' MB' : numBR(Math.max(1, bytes / 1024)) + ' KB';
}

function lerArquivo(arquivo) {
  return new Promise((res, rej) => {
    const leitor = new FileReader();
    leitor.onload = () => res(leitor.result);
    leitor.onerror = () => rej(new Error('Não foi possível ler o arquivo.'));
    leitor.readAsArrayBuffer(arquivo);
  });
}

async function enviarBackup(arquivo) {
  const conteudo = await lerArquivo(arquivo);
  const resp = await fetch('/api/backup/enviar', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-Loja': '1' }, body: conteudo });
  const j = await resp.json();
  if (!resp.ok) throw new Error(j.erro || 'Falha ao enviar o backup.');
  return j.nome;
}

/* Pede usuário + senha (ou código de recuperação) e restaura. */
function modalRestaurar(backup, { pedirUsuario = false, aoConcluir } = {}) {
  const campos = [
    ...(pedirUsuario ? [{ n: 'login', r: 'Usuário', w: 12, aj: 'Seu usuário na época do backup. Deixe em branco se for usar o código de recuperação.' }] : []),
    { n: 'segredo', r: 'Senha ou código de recuperação', t: 'password', w: 12, obr: 1 }
  ];
  modal({ titulo: 'Restaurar backup', largura: 'largo', corpo: `
    <p>Backup de <b>${dataHoraBR(backup.criado_em)}</b>${backup.loja ? ` — ${esc(backup.loja)}` : ''}.</p>
    <div class="caixa-aviso alerta">A loja volta exatamente como estava nesse momento. O que foi feito depois disso deixa de aparecer no sistema.
      Os dados atuais <b>não são apagados</b>: ficam guardados ao lado, numa pasta chamada "dados-antes-da-restauracao".</div>
    ${formHTML(campos)}`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Restaurar agora', classe: 'pri', acao: async m => {
      const d = lerForm(m, campos);
      const r = await api('restaurar', { nome: backup.nome, login: d.login, segredo: d.segredo });
      modal({ titulo: 'Backup restaurado', corpo: `<p>${esc(r.mensagem)}</p>`, botoes: [{ texto: 'Entrar', classe: 'pri' }] });
      App.carrinho = novoCarrinho();
      if (aoConcluir) aoConcluir(); else mostrarEntrada();
    } }] });
}

/* Tela exibida quando os arquivos de dados não puderam ser lidos. */
function telaRecuperacao(tela, est) {
  tela.innerHTML = `<div class="entrada-box largo"><img class="logo" src="img/icone.svg" alt="">
    <h1>Vamos recuperar seus dados</h1>
    <div class="caixa-aviso erro">O sistema não conseguiu ler os arquivos da loja.<br><small>${esc(est.recuperacao)}</small></div>
    <p>Escolha o backup mais recente abaixo e informe sua senha (ou o código de recuperação). Os arquivos atuais ficam guardados, nada é apagado.</p>
    <div id="lista-rec"></div>
    <p class="suave" style="margin-top:14px">Tem o arquivo de backup em um pendrive ou e-mail? <label class="btn pequeno">Escolher arquivo<input type="file" id="arq-rec" accept=".lojabkp" hidden></label></p>
    <div class="credito">Pasta da loja: ${esc(est.pasta_loja)}</div></div>`;
  listaBackupsPublicos(tela.querySelector('#lista-rec'), est.backups, true);
  tela.querySelector('#arq-rec').onchange = async e => {
    try { const nome = await enviarBackup(e.target.files[0]); modalRestaurar({ nome, criado_em: '' }, { pedirUsuario: true }); }
    catch (err) { toast(err.message, 'erro'); }
  };
}

function listaBackupsPublicos(el, backups, pedirUsuario) {
  el.innerHTML = backups.length ? backups.slice(0, 15).map((b, i) => `<div class="tarefa"><span style="flex:1"><b>${dataHoraBR(b.criado_em)}</b>
      <small class="suave"> · ${tamanhoArquivo(b.tamanho)}${b.loja ? ' · ' + esc(b.loja) : ''}${b.danificado ? ' · danificado' : ''}</small></span>
      <button class="btn pequeno ${i === 0 ? 'pri' : ''}" data-i="${i}" ${b.danificado ? 'disabled' : ''}>Restaurar</button></div>`).join('')
    : '<p class="suave">Nenhum backup encontrado na pasta da loja.</p>';
  el.querySelectorAll('[data-i]').forEach(b => b.onclick = () => modalRestaurar(backups[+b.dataset.i], { pedirUsuario }));
}

/* Aba Configurações › Backup e dados. */
async function renderBackup(box) {
  const [saude, lista] = await Promise.all([api('saude'), api('backups')]);
  App.saude = saude;
  const dona = App.papel === 'dona';
  const temExemplo = Object.values(App.d).some(l => Array.isArray(l) && l.some(x => x.exemplo));
  const cor = { ok: 'ok', alerta: 'alerta', erro: 'erro' }[saude.nivel];
  box.innerHTML = `
    <div class="card"><div class="card-cab"><h3>Situação dos dados</h3>${etiqueta(NIVEIS_SAUDE[saude.nivel][0], cor)}</div>
      <ul class="alertas">${saude.mensagens.map(m => `<li class="${cor}"><span>${esc(m)}</span></li>`).join('') || '<li class="ok"><span>Backup de hoje feito e conferido.</span></li>'}</ul>
      <div class="totais" style="margin-top:8px">
        <div><span>Pasta da loja</span><b style="text-align:right">${esc(saude.pasta_loja)}</b></div>
        <div><span>Nuvem</span><b>${saude.nuvem ? esc(saude.nuvem) + (saude.app_nuvem_ativo === false ? ' (aplicativo fechado)' : saude.app_nuvem_ativo ? ' (sincronizando)' : '') : 'Não está na nuvem'}</b></div>
        <div><span>Último backup</span><b>${saude.ultimo_backup ? dataHoraBR(saude.ultimo_backup.criado_em) + (saude.ultimo_backup.verificado ? ' · conferido' : '') : '—'}</b></div></div>
      ${saude.conflitos.length ? `<h4>Arquivos de conflito</h4><p class="suave">O Drive/OneDrive criou cópias porque o sistema foi usado em dois computadores ao mesmo tempo.
        Os dados válidos são os arquivos sem o número entre parênteses. Mova as cópias para a quarentena (elas não são apagadas).</p>
        ${saude.conflitos.map(n => `<div class="tarefa"><span style="flex:1">${esc(n)}</span><button class="btn pequeno" data-click="conflito" data-n="${esc(n)}">Mover para quarentena</button></div>`).join('')}` : ''}
      ${!saude.nuvem ? '<p class="suave">Para ter cópia na nuvem: instale o Google Drive para computador e execute o instalador do Loja ERP de novo, escolhendo uma pasta dentro do "Meu Drive" (copie antes a pasta "dados" para lá).</p>' : ''}
    </div>
    <div class="card"><div class="card-cab"><h3>Backups</h3><div class="linha-acoes" style="margin:0">
        ${dona ? '<label class="btn">Restaurar de um arquivo<input type="file" id="arq-bkp" accept=".lojabkp" hidden></label>' : ''}
        <button class="btn pri" data-click="backup">Fazer backup agora</button></div></div>
      <p class="suave">Um backup <b>compactado e criptografado</b> é feito todo dia automaticamente e conferido logo depois de gravado. São mantidos todos os dos últimos 14 dias,
        um por semana nas últimas 12 semanas e um por mês nos últimos 2 anos. Só abre com a senha da proprietária ou da gerente, ou com o código de recuperação.</p>
      <div id="tab-bkp"></div></div>
    <div class="grade g2"><div class="card"><h3>Exportar para Excel</h3><p class="suave">Planilhas CSV (abrem no Excel) com os dados atuais.</p>
        <div class="chips">${['produtos', 'clientes', 'vendas', 'financeiro', 'movimentos', 'fornecedores'].map(k => `<button class="chip" data-click="exp" data-k="${k}">${k}</button>`).join('')}</div></div>
      <div class="card"><h3>Dados de exemplo</h3>${temExemplo && dona ? `<p>Há produtos, clientes e vendas fictícias. Quando for começar de verdade, remova-os — cadastros, ofertas e configurações são mantidos.</p>
        <button class="btn perigo" data-click="limpar">Remover dados de exemplo</button>` : '<p class="suave">Não há dados de exemplo.</p>'}</div></div>`;
  tabela(box.querySelector('#tab-bkp'), {
    linhas: lista.arquivos, busca: false, porPagina: 15,
    colunas: [{ t: 'Data', v: b => b.criado_em, h: b => dataHoraBR(b.criado_em) }, { t: 'Tipo', v: b => b.motivo || b.formato },
      { t: 'Tamanho', v: b => b.tamanho, h: b => tamanhoArquivo(b.tamanho), cls: 'num' },
      { t: 'Conferido', v: b => b.verificado ? 'sim' : '', h: b => b.verificado ? etiqueta('Conferido', 'ok') : b.verificado === false ? etiqueta('Falhou', 'erro') : etiqueta(b.formato === 'cifrado' ? 'De outro computador' : 'Formato antigo') },
      { t: '', semOrdem: true, h: b => `${b.nome.startsWith('backup-') && b.formato === 'cifrado' ? `<a class="btn pequeno" href="/api/backup/${encodeURIComponent(b.nome)}" download>Baixar</a>` : ''}
        ${dona ? ' <button class="btn pequeno" data-acao="restaurar">Restaurar</button>' : ''}` }],
    acoes: { restaurar: b => modalRestaurar(b) }
  });
  const arq = box.querySelector('#arq-bkp');
  if (arq) arq.onchange = async e => { const nome = await enviarBackup(e.target.files[0]).catch(err => { toast(err.message, 'erro'); }); if (nome) modalRestaurar({ nome, criado_em: '' }, { pedirUsuario: true }); };
  ligar(box, {
    backup: async b => { b.disabled = true; b.textContent = 'Fazendo backup...'; const r = await api('backup', {}); toast('Backup feito e conferido: ' + r.arquivo, 'ok'); await atualizarSaude(); renderBackup(box); },
    conflito: async b => { await api('conflito/mover', { nome: b.dataset.n }); toast('Arquivo movido para a quarentena.', 'ok'); await atualizarSaude(); renderBackup(box); },
    limpar: async () => { const s = await pedirSenha('Remover dados de exemplo', 'Um backup será feito antes. Confirme sua senha.'); if (!s) return; await api('limpar_exemplo', { senha: s }); App.carrinho = novoCarrinho(); toast('Dados de exemplo removidos.', 'ok'); ir('#/painel'); },
    exp: b => exportarColecao(b.dataset.k)
  });
}
