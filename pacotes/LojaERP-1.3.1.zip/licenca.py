"""Loja ERP — licença de uso (teste grátis, loja piloto e licenças de 3, 6 e 12 meses pagas no Pix).

A chave de licença é um texto assinado digitalmente (Ed25519) pela Infinity Technology. O programa
confere a assinatura com a chave pública abaixo, sem internet. A licença nunca impede a loja de ver,
exportar ou fazer backup dos próprios dados: depois do vencimento e da carência, só ficam bloqueados
os lançamentos novos (vendas, cadastros, financeiro) até a renovação.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import base64
import datetime as dt
import json
import re

import atualizacao   # verificação Ed25519 já usada nas atualizações

# Chave pública das licenças (a privada fica só com o autor, fora de qualquer repositório).
CHAVE_PUBLICA_LICENCA = '469Ap3vKzd//mJ7gXMxFy0GGtAfWllvoMAeFEiokJsU='
PREFIXO = 'LJ1'

PLANOS = {
    'teste': 'Teste grátis',
    'piloto': 'Loja piloto',
    'trimestral': 'Licença de 3 meses',
    'semestral': 'Licença de 6 meses',
    'anual': 'Licença de 12 meses',
    'cortesia': 'Cortesia',
}
# Licenças à venda depois do teste grátis: pagamento único no Pix, sem cobrança automática.
OFERTAS = (
    {'plano': 'trimestral', 'meses': 3, 'preco': 29.97},
    {'plano': 'semestral', 'meses': 6, 'preco': 54.90},
    {'plano': 'anual', 'meses': 12, 'preco': 100.00},
)
PRECOS = {o['plano']: o['preco'] for o in OFERTAS}
PAGAMENTO = 'Pix, pagamento único, sem cobrança automática'
DIAS_TESTE = 183          # 6 meses grátis a partir da configuração inicial
DIAS_AVISO = 15           # avisa antes de vencer
DIAS_CARENCIA = 10        # depois de vencer, continua funcionando por estes dias

CONTATO = {
    'empresa': 'Infinity Technology',
    'nome': 'Victor Hugo R. Moura',
    'email': 'victorhugormoura@gmail.com',
    'whatsapp': '5518996535921',
    'site': 'https://sistemalojaerp.com.br',
}

# Com a licença vencida (depois da carência), estas operações continuam liberadas.
LIBERADAS_SEM_LICENCA = {
    'login', 'logout', 'senha', 'recuperar', 'setup', 'licenca/ativar', 'backup', 'backup/enviar', 'restaurar',
    'encerrar', 'nova_recuperacao', 'conflito/mover', 'atualizacao/verificar', 'atualizacao/instalar',
    'atualizacao/config', 'config', 'celular/ativar', 'celular/parear', 'celular/permitir', 'celular/remover',
    'celular/firewall', 'celular/diagnostico', 'usuario/senha',
}


def _b32d(texto):
    texto = texto.upper()
    return base64.b32decode(texto + '=' * (-len(texto) % 8))


# Nomes curtos dentro da chave, para ela ficar menor.
_CURTOS = {'id': 'i', 'plano': 'p', 'loja': 'l', 'doc': 'd', 'inicio': 's', 'valida_ate': 'v', 'emitida': 'e'}
_LONGOS = {v: k for k, v in _CURTOS.items()}


def emitir(semente, dados):
    """Gera a chave de licença (usado só pela ferramenta do autor)."""
    dados = {_CURTOS.get(k, k): v for k, v in dados.items() if v not in ('', None)}
    corpo = json.dumps(dados, ensure_ascii=False, separators=(',', ':'), sort_keys=True).encode('utf-8')
    assinatura = atualizacao.assinar(semente, b'loja-erp/licenca' + corpo)
    # Base32 (letras e números, sem diferença entre maiúsculas e minúsculas) em blocos de 5: fácil de copiar.
    bruto = base64.b32encode(len(corpo).to_bytes(2, 'big') + corpo + assinatura).decode().rstrip('=')
    return PREFIXO + '-' + '-'.join(bruto[i:i + 5] for i in range(0, len(bruto), 5))


_conferidas = {}


def ler_chave(texto, publica_b64=None):
    """Confere a assinatura e devolve os dados da licença. Aceita a chave com espaços e quebras de linha."""
    limpo = re.sub(r'\s+', '', str(texto or ''))
    if publica_b64 is None and limpo in _conferidas:
        return dict(_conferidas[limpo])
    if not limpo.upper().startswith(PREFIXO + '-'):
        raise ValueError('Esta não é uma chave de licença do Loja ERP (começa com LJ1-).')
    try:
        bruto = _b32d(limpo[len(PREFIXO) + 1:].replace('-', ''))
        tamanho = int.from_bytes(bruto[:2], 'big')
        corpo, assinatura = bruto[2:2 + tamanho], bruto[2 + tamanho:]
        dados = {_LONGOS.get(k, k): v for k, v in json.loads(corpo.decode('utf-8')).items()}
    except (ValueError, UnicodeDecodeError, AttributeError, base64.binascii.Error):
        raise ValueError('A chave está incompleta. Copie e cole a chave inteira, do LJ1- até o fim.')
    publica = base64.b64decode(publica_b64 or CHAVE_PUBLICA_LICENCA)
    if not atualizacao.verificar_assinatura(publica, b'loja-erp/licenca' + corpo, assinatura):
        raise ValueError('Chave de licença inválida (a assinatura não confere). Confira se copiou certo.')
    # Plano desconhecido (de uma versão mais nova) continua valendo: o que manda é a data assinada.
    if not re.fullmatch(r'[a-z0-9_]{1,20}', str(dados.get('plano', ''))) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', str(dados.get('valida_ate', ''))):
        raise ValueError('Chave de licença com dados incompletos.')
    if publica_b64 is None:
        _conferidas[limpo] = dict(dados)
    return dados


def _data(texto):
    try:
        return dt.date.fromisoformat(str(texto)[:10])
    except ValueError:
        return None


def situacao(registro, hoje=None):
    """Situação da licença a partir do que está guardado na configuração da loja.

    registro: {'chave': 'LJ1-...', 'inicio_teste': 'AAAA-MM-DD'}.
    estado: 'ativa', 'aviso' (vence em breve), 'carencia' (vencida, ainda funcionando) ou 'bloqueada'."""
    hoje = hoje or dt.date.today()
    dados, erro_chave = None, ''
    if registro.get('chave'):
        try:
            dados = ler_chave(registro['chave'])
        except ValueError as e:
            erro_chave = str(e)
    if dados:
        plano, ate = dados['plano'], _data(dados['valida_ate'])
        titular = dados.get('loja', '')
    else:
        plano = 'teste'
        inicio = _data(registro.get('inicio_teste')) or hoje
        ate = inicio + dt.timedelta(days=DIAS_TESTE)
        titular = ''
    restantes = (ate - hoje).days
    if restantes > DIAS_AVISO:
        estado = 'ativa'
    elif restantes >= 0:
        estado = 'aviso'
    elif restantes >= -DIAS_CARENCIA:
        estado = 'carencia'
    else:
        estado = 'bloqueada'
    nome = PLANOS.get(plano, 'Licença')
    data_br = ate.strftime('%d/%m/%Y')
    renove = 'Escolha uma licença' if plano == 'teste' else 'Renove'
    if estado == 'ativa':
        mensagem = f'{nome}: vale até {data_br}.'
    elif estado == 'aviso':
        quando = 'hoje' if restantes == 0 else f'em {restantes} dia(s)'
        mensagem = f'{nome} vence {quando} ({data_br}). {renove} para continuar usando sem interrupção.'
    elif estado == 'carencia':
        limite = (ate + dt.timedelta(days=DIAS_CARENCIA)).strftime('%d/%m/%Y')
        mensagem = (f'{nome} venceu em {data_br}. O sistema continua funcionando até {limite}; '
                    f'depois disso fica só para consulta até a renovação.')
    else:
        mensagem = (f'{nome} venceu em {data_br}. O sistema está em modo de consulta: seus dados continuam '
                    f'disponíveis para ver, exportar e fazer backup. {renove} para voltar a lançar.')
    return {
        'plano': plano, 'nome_plano': nome, 'titular': titular, 'valida_ate': ate.isoformat(),
        'dias_restantes': restantes, 'estado': estado, 'mensagem': mensagem, 'erro_chave': erro_chave,
        'id': (dados or {}).get('id', ''), 'precos': PRECOS, 'ofertas': ofertas(), 'pagamento': PAGAMENTO, 'dias_teste': DIAS_TESTE, 'dias_carencia': DIAS_CARENCIA,
        'contato': CONTATO,
    }


def ofertas():
    """Licenças à venda com o valor por mês e a economia em relação à de 3 meses (valores em reais)."""
    base = OFERTAS[0]['preco'] / OFERTAS[0]['meses']
    lista = []
    for o in OFERTAS:
        lista.append({**o, 'nome': PLANOS[o['plano']], 'por_mes': round(o['preco'] / o['meses'], 2),
                      'economia': round(base * o['meses'] - o['preco'], 2)})
    return lista


def operacao_permitida(rota, estado):
    return estado != 'bloqueada' or rota in LIBERADAS_SEM_LICENCA
