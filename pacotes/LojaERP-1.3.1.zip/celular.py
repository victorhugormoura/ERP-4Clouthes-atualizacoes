"""Loja ERP — acesso pelo celular na rede local.

Certificado TLS próprio (ECDSA P-256), gerado só com a biblioteca padrão do Python, para que o
celular converse com o computador por HTTPS: os dados não trafegam abertos no Wi-Fi e o navegador
do celular libera a câmera (leitor de código de barras), que só funciona em conexão segura.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import datetime as dt
import hashlib
import ipaddress
import json
import os
import secrets
import socket
import ssl
import subprocess
import sys

# ------------------------------------------------------------ curva P-256 (FIPS 186-4)
_P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
_A = _P - 3
_B = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
_N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
_G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
      0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)


def _somar(p, q):
    if p is None:
        return q
    if q is None:
        return p
    if p[0] == q[0]:
        if (p[1] + q[1]) % _P == 0:
            return None
        m = (3 * p[0] * p[0] + _A) * pow(2 * p[1], -1, _P) % _P
    else:
        m = (q[1] - p[1]) * pow(q[0] - p[0], -1, _P) % _P
    x = (m * m - p[0] - q[0]) % _P
    return x, (m * (p[0] - x) - p[1]) % _P


def _multiplicar(k, ponto):
    resultado = None
    while k:
        if k & 1:
            resultado = _somar(resultado, ponto)
        ponto = _somar(ponto, ponto)
        k >>= 1
    return resultado


def _no_curva(ponto):
    x, y = ponto
    return (y * y - (x * x * x + _A * x + _B)) % _P == 0


def _assinar(d, mensagem):
    z = int.from_bytes(hashlib.sha256(mensagem).digest(), 'big')
    while True:
        k = secrets.randbelow(_N - 1) + 1
        r = _multiplicar(k, _G)[0] % _N
        s = pow(k, -1, _N) * (z + r * d) % _N
        if r and s:
            return r, s


# ------------------------------------------------------------------- DER mínimo
def _tlv(tag, conteudo):
    n = len(conteudo)
    if n < 0x80:
        tam = bytes([n])
    else:
        b = n.to_bytes((n.bit_length() + 7) // 8, 'big')
        tam = bytes([0x80 | len(b)]) + b
    return bytes([tag]) + tam + conteudo


def _seq(*partes):
    return _tlv(0x30, b''.join(partes))


def _inteiro(v):
    b = v.to_bytes(max(1, (v.bit_length() + 8) // 8), 'big')
    return _tlv(0x02, b)


def _oid(texto):
    n = [int(x) for x in texto.split('.')]
    corpo = bytes([40 * n[0] + n[1]])
    for v in n[2:]:
        partes = [v & 0x7f]
        v >>= 7
        while v:
            partes.append(0x80 | (v & 0x7f))
            v >>= 7
        corpo += bytes(reversed(partes))
    return _tlv(0x06, corpo)


def _bits(b):
    return _tlv(0x03, b'\x00' + b)


def _data(d):
    return _tlv(0x17, d.strftime('%y%m%d%H%M%SZ').encode())


def _nome(texto):
    return _seq(_tlv(0x31, _seq(_oid('2.5.4.3'), _tlv(0x0c, texto.encode('utf-8')))))


def _pem(rotulo, der):
    import base64
    b = base64.b64encode(der).decode()
    linhas = [b[i:i + 64] for i in range(0, len(b), 64)]
    return f'-----BEGIN {rotulo}-----\n' + '\n'.join(linhas) + f'\n-----END {rotulo}-----\n'


def gerar_certificado(ips, nome='Loja ERP (este computador)', anos=10):
    """Devolve (certificado PEM, chave PEM) autoassinados para os IPs informados."""
    d = secrets.randbelow(_N - 1) + 1
    qx, qy = _multiplicar(d, _G)
    publica = b'\x04' + qx.to_bytes(32, 'big') + qy.to_bytes(32, 'big')
    alg = _seq(_oid('1.2.840.10045.4.3.2'))
    agora = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
    nomes_alt = b''.join(_tlv(0x87, ipaddress.ip_address(ip).packed) for ip in ips) + _tlv(0x82, b'localhost')
    extensoes = _seq(
        _seq(_oid('2.5.29.17'), _tlv(0x04, _seq(nomes_alt))),
        _seq(_oid('2.5.29.15'), _tlv(0x01, b'\xff'), _tlv(0x04, _tlv(0x03, b'\x07\x80'))),
        _seq(_oid('2.5.29.37'), _tlv(0x04, _seq(_oid('1.3.6.1.5.5.7.3.1')))),
    )
    tbs = _seq(
        _tlv(0xa0, _inteiro(2)),
        _inteiro(int.from_bytes(secrets.token_bytes(16), 'big') >> 1),
        alg,
        _nome(nome),
        _seq(_data(agora - dt.timedelta(days=1)), _data(agora + dt.timedelta(days=365 * anos))),
        _nome(nome),
        _seq(_seq(_oid('1.2.840.10045.2.1'), _oid('1.2.840.10045.3.1.7')), _bits(publica)),
        _tlv(0xa3, extensoes),
    )
    r, s = _assinar(d, tbs)
    certificado = _seq(tbs, alg, _bits(_seq(_inteiro(r), _inteiro(s))))
    chave = _seq(_inteiro(1), _tlv(0x04, d.to_bytes(32, 'big')),
                 _tlv(0xa0, _oid('1.2.840.10045.3.1.7')), _tlv(0xa1, _bits(publica)))
    return _pem('CERTIFICATE', certificado), _pem('EC PRIVATE KEY', chave)


def impressao_digital(cert_pem):
    """SHA-256 do certificado, em blocos fáceis de comparar."""
    der = ssl.PEM_cert_to_DER_cert(cert_pem)
    h = hashlib.sha256(der).hexdigest().upper()
    return ' '.join(h[i:i + 4] for i in range(0, 16, 4))


def preparar_certificado(pasta, ips):
    """Cria (uma vez) o certificado desta instalação e devolve o contexto TLS e a impressão digital."""
    os.makedirs(pasta, exist_ok=True)
    arq_cert = os.path.join(pasta, 'celular-certificado.pem')
    arq_chave = os.path.join(pasta, 'celular-chave.pem')
    if not (os.path.isfile(arq_cert) and os.path.isfile(arq_chave)):
        cert, chave = gerar_certificado(ips)
        descritor = os.open(arq_chave, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descritor, 'w', encoding='ascii') as f:
            f.write(chave)
        with open(arq_cert, 'w', encoding='ascii') as f:
            f.write(cert)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(arq_cert, arq_chave)
    with open(arq_cert, 'r', encoding='ascii') as f:
        return ctx, impressao_digital(f.read())


# ------------------------------------------------------------------- rede local
def ip_privado(ip):
    try:
        a = ipaddress.ip_address(ip.split('%')[0])
    except ValueError:
        return False
    if a.version == 6 and a.ipv4_mapped:
        a = a.ipv4_mapped
    excluidas = ('169.254.0.0/16', '198.18.0.0/15', '240.0.0.0/4', 'fe80::/10')
    if any(a in ipaddress.ip_network(r) for r in excluidas if ipaddress.ip_network(r).version == a.version):
        return False
    return a.is_private and not a.is_unspecified and not a.is_multicast


# Faixas de placas virtuais (VirtualBox, Docker, WSL/Hyper-V): ficam por último na lista de endereços.
_VIRTUAIS = [ipaddress.ip_network(r) for r in ('192.168.56.0/24', '192.168.99.0/24', '172.16.0.0/12', '10.0.75.0/24')]


def ips_locais():
    """IPs IPv4 privados deste computador; o da saída padrão (Wi-Fi ou cabo da loja) vem primeiro."""
    vistos = []
    for destino in ('8.8.8.8', '10.255.255.255'):   # UDP "connect" não envia nada: só consulta a rota
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect((destino, 53))
                vistos.append(s.getsockname()[0])
        except OSError:
            pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            vistos.append(info[4][0])
    except OSError:
        pass
    saida = []
    for ip in vistos:
        a = ipaddress.ip_address(ip)
        if ip not in saida and ip_privado(ip) and not a.is_loopback and not a.is_link_local:
            saida.append(ip)
    principal = saida[:1]
    resto = sorted(saida[1:], key=lambda ip: any(ipaddress.ip_address(ip) in r for r in _VIRTUAIS))
    return principal + resto


def nome_aparelho(agente):
    """Nome curto do aparelho a partir do navegador (ex.: "Android SM-A145M", "iPhone")."""
    a = agente or ''
    if 'iPhone' in a:
        return 'iPhone'
    if 'iPad' in a:
        return 'iPad'
    if 'Android' in a:
        try:
            trecho = a.split('Android', 1)[1].split(')', 1)[0]
            partes = [p.strip() for p in trecho.split(';') if p.strip()]
            modelo = next((p for p in reversed(partes) if p not in ('K', 'wv') and not p[0].isdigit()), '').split(' Build')[0]
            return f'Android {modelo}'.strip()[:40]
        except IndexError:
            return 'Android'
    return 'Navegador'


PORTAS_CELULAR = '8780-8799'
FAIXAS_LOCAIS = '10.0.0.0/8,172.16.0.0/12,192.168.0.0/16'


def programas_python():
    """python.exe e pythonw.exe da instalação (o sistema roda pelo pythonw; o python é usado em testes)."""
    pasta = os.path.dirname(sys.executable)
    return [os.path.join(pasta, n) for n in ('pythonw.exe', 'python.exe') if os.path.isfile(os.path.join(pasta, n))]


def _executar_como_admin(arquivo, parametros, espera_ms=120000):
    """Abre a confirmação de administrador do Windows e devolve o código de saída (None se negada)."""
    import ctypes
    from ctypes import wintypes

    class INFO(ctypes.Structure):
        _fields_ = [('cbSize', wintypes.DWORD), ('fMask', ctypes.c_ulong), ('hwnd', wintypes.HWND),
                    ('lpVerb', wintypes.LPCWSTR), ('lpFile', wintypes.LPCWSTR), ('lpParameters', wintypes.LPCWSTR),
                    ('lpDirectory', wintypes.LPCWSTR), ('nShow', ctypes.c_int), ('hInstApp', wintypes.HINSTANCE),
                    ('lpIDList', ctypes.c_void_p), ('lpClass', wintypes.LPCWSTR), ('hkeyClass', wintypes.HKEY),
                    ('dwHotKey', wintypes.DWORD), ('hIcon', wintypes.HANDLE), ('hProcess', wintypes.HANDLE)]

    info = INFO(cbSize=ctypes.sizeof(INFO), fMask=0x40, lpVerb='runas', lpFile=arquivo,
                lpParameters=parametros, nShow=0)   # 0x40 = SEE_MASK_NOCLOSEPROCESS
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(info)) or not info.hProcess:
        return None
    kernel = ctypes.windll.kernel32
    kernel.WaitForSingleObject(info.hProcess, espera_ms)
    codigo = wintypes.DWORD(1)
    kernel.GetExitCodeProcess(info.hProcess, ctypes.byref(codigo))
    kernel.CloseHandle(info.hProcess)
    return codigo.value


def liberar_firewall(porta=None):
    """Windows: com a confirmação de administrador, apaga as regras de entrada que o próprio Windows criou
    para o Python do Loja ERP (inclusive as de BLOQUEIO, criadas quando alguém clica em "Cancelar" ou deixa
    a rede pública desmarcada no aviso do firewall) e cria a liberação só para endereços da rede local."""
    if sys.platform != 'win32':
        return False, 'Disponível apenas no Windows.'
    programas = programas_python()
    if not programas or any('"' in p or '%' in p for p in programas):
        return False, 'Não encontrei o programa para liberar. Reinstale o Loja ERP.'
    comandos = []
    for p in programas:
        comandos.append(f'netsh advfirewall firewall delete rule name=all dir=in program="{p}" >nul')
    comandos.append('netsh advfirewall firewall delete rule name="Loja ERP (celular)" >nul')
    for p in programas:
        comandos.append(f'netsh advfirewall firewall add rule name="Loja ERP (celular)" dir=in action=allow enable=yes '
                        f'program="{p}" protocol=TCP localport={PORTAS_CELULAR} remoteip={FAIXAS_LOCAIS} profile=any')
    # "&" entre as remoções (podem não achar nada) e "&&" nas criações: o código de saída é o da última criação.
    linha = ' & '.join(comandos[:-len(programas)]) + ' & ' + ' && '.join(comandos[-len(programas):])
    codigo = _executar_como_admin('cmd.exe', '/c ' + linha)
    if codigo is None:
        return False, 'O Windows não liberou (a confirmação de administrador foi negada ou fechada).'
    if codigo != 0:
        return False, f'O firewall do Windows recusou a regra (código {codigo}).'
    return True, 'Liberado: as regras antigas do Windows para o programa foram trocadas pela liberação da rede local.'


def diagnostico_windows():
    """Perfil da rede, regras de firewall que valem para o Python do Loja ERP e firewalls de outros fabricantes.
    Só leitura (não pede administrador)."""
    if sys.platform != 'win32':
        return {'disponivel': False}
    pasta = os.path.dirname(sys.executable).replace("'", "''")
    script = (
        "$ErrorActionPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.Encoding]::UTF8;"
        f"$p='{pasta}';"
        "$perfis=@(Get-NetConnectionProfile|%{@{nome=[string]$_.Name;interface=[string]$_.InterfaceAlias;categoria=[string]$_.NetworkCategory}});"
        "$regras=@(Get-NetFirewallApplicationFilter -PolicyStore ActiveStore|?{$_.Program -and [Environment]::ExpandEnvironmentVariables($_.Program).StartsWith($p,[StringComparison]::OrdinalIgnoreCase)}|%{"
        "$prog=$_.Program;$_|Get-NetFirewallRule|?{[string]$_.Direction -eq 'Inbound'}|%{"
        "@{nome=[string]$_.DisplayName;acao=[string]$_.Action;ativa=[string]$_.Enabled;perfil=[string]$_.Profile;programa=$prog}}});"
        "$fw=@(Get-NetFirewallProfile|%{@{perfil=[string]$_.Name;ativo=[string]$_.Enabled}});"
        "$outros=@(Get-CimInstance -Namespace root/SecurityCenter2 -ClassName FirewallProduct|%{[string]$_.displayName});"
        "@{perfis=$perfis;regras=$regras;firewall=$fw;outros=$outros}|ConvertTo-Json -Depth 5 -Compress")
    try:
        r = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script],
                           capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=90, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        dados = json.loads(r.stdout.strip() or '{}')
    except (OSError, subprocess.SubprocessError, ValueError) as e:
        return {'disponivel': False, 'erro': str(e)}
    for k in ('perfis', 'regras', 'firewall', 'outros'):
        v = dados.get(k) or []
        dados[k] = v if isinstance(v, list) else [v]
    dados['disponivel'] = True
    return dados
