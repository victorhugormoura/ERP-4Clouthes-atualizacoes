/* Loja ERP — integrações opcionais (nota fiscal, Pix por API), conciliação de banco e cartões e pacote do contador.
   Tudo opcional: sem integração o sistema funciona como sempre.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

function integ(secao) { return ((App.cfg.integracoes || {})[secao]) || {}; }
function nfeAtiva() { return Boolean(integ('nfe').ativo); }
function pixApiAtivo() { return Boolean(integ('pix').ativo); }

/* ------------------------------------------------------------ configuração */
async function renderIntegracoes(box) {
  const dona = App.papel === 'dona';
  const nfe = integ('nfe'), pix = integ('pix');
  const segredo = (secao, campo, rotulo, tipo = 'password') => {
    const tem = integ(secao)['tem_' + campo];
    return `<label class="campo w12"><span>${esc(rotulo)} ${tem ? etiqueta('guardado', 'ok') : ''}</span>
      ${tipo === 'textarea' ? `<textarea data-segredo="${campo}" rows="3" placeholder="${tem ? 'Guardado. Cole de novo só para trocar.' : ''}" autocomplete="off"></textarea>`
        : `<input type="password" data-segredo="${campo}" placeholder="${tem ? 'Guardado. Digite só para trocar.' : ''}" autocomplete="new-password">`}</label>`;
  };
  const camposNfe = [
    { n: 'ambiente', r: 'Ambiente', t: 'select', w: 4, vazio: false, op: [['homologacao', 'Homologação (testes, nota sem valor)'], ['producao', 'Produção (nota válida)']] },
    { n: 'emitir', r: 'Emitir a nota', t: 'select', w: 4, vazio: false, op: [['perguntar', 'Quando marcar no pagamento'], ['sempre', 'Em toda venda']] },
    { n: 'ncm_padrao', r: 'NCM padrão', w: 4, ph: 'ex.: 6109.10.00', aj: 'Código fiscal da mercadoria, usado quando o produto e a categoria não têm NCM. Peça ao contador os NCM das suas peças.' },
    { n: 'csosn', r: 'CSOSN (Simples Nacional)', w: 3, aj: 'Situação tributária do ICMS no Simples. O mais comum no varejo é 102. Confirme com o contador.' },
    { n: 'cfop', r: 'CFOP', w: 3, aj: '5102 = venda de mercadoria comprada de terceiros, dentro do estado.' },
    { n: 'pis_cst', r: 'CST PIS', w: 3 }, { n: 'cofins_cst', r: 'CST COFINS', w: 3 },
    { n: 'informacoes_adicionais', r: 'Informações adicionais na nota (opcional)', w: 12 }
  ];
  const camposPix = [
    { n: 'provedor', r: 'Onde a loja recebe o Pix', t: 'select', w: 6, vazio: false, op: [['mercadopago', 'Mercado Pago'], ['banco', 'API Pix do meu banco (padrão Banco Central)']] },
    { n: 'minutos', r: 'O QR Code vale por (minutos)', t: 'number', w: 6, min: 5 },
    { n: 'email_pagador', r: 'E-mail para o Mercado Pago', t: 'email', w: 12, aj: 'O Mercado Pago pede um e-mail em cada Pix. Se ficar vazio, usa o e-mail da loja.' }
  ];
  const bancos = (App.cfg.integracoes || {}).bancos_pix || {};
  const camposBanco = [
    { n: 'banco', r: 'Banco', w: 6, ph: 'ex.: Banco Inter' }, { n: 'chave_pix', r: 'Chave Pix da conta', w: 6 },
    { n: 'modo_token', r: 'Como o banco pede o token', t: 'select', w: 12, vazio: false, op: [['basic_form', 'Padrão OAuth2 (Basic + formulário) — a maioria'], ['corpo_form', 'Client ID e Secret no formulário (Banco Inter)'], ['basic_json', 'Basic + JSON (Efí)']] },
    { n: 'url_api', r: 'Endereço da API Pix', w: 12, ph: 'https://...', aj: 'Está no portal de desenvolvedor do banco. Use o endereço de produção quando terminar os testes.' },
    { n: 'url_token', r: 'Endereço do token (OAuth)', w: 12, ph: 'https://...' },
    { n: 'client_id', r: 'Client ID', w: 6 }, { n: 'escopo', r: 'Escopos', w: 6, ph: 'cob.write cob.read pix.read' },
    { n: 'parametro_url', r: 'Parâmetro extra no endereço (se o banco pedir)', w: 12, ph: 'ex.: gw-dev-app-key=...' }
  ];
  box.innerHTML = `
    <div class="caixa-aviso">Integrações são <b>opcionais</b>: ligue só o que a loja contratou. Sem elas o sistema continua funcionando igual.
      As senhas e tokens ficam guardados criptografados neste computador e nunca aparecem na tela. ${dona ? '' : '<b>Só a proprietária altera esta tela.</b>'}</div>
    <div class="card" id="int-nfe"><div class="card-cab"><h3>Nota fiscal eletrônica (NFC-e) ${etiqueta('recomendado', 'ok')}</h3>${etiqueta(nfe.ativo ? (nfe.ambiente === 'producao' ? 'ligada — produção' : 'ligada — homologação') : 'desligada', nfe.ativo ? 'ok' : '')}</div>
      <p class="suave">Emite a NFC-e (nota do consumidor) direto do caixa pela <b>Focus NFe</b>, um emissor autorizado. Você contrata a Focus, cadastra nela o certificado digital A1 e o CSC da Sefaz, e cola aqui o token.
        Comece em <b>homologação</b> (notas de teste, sem valor) e só passe para produção depois de conferir com o contador o NCM, o CSOSN e o CFOP.</p>
      <label class="check"><input type="checkbox" name="ativo" ${nfe.ativo ? 'checked' : ''}><span>Ligar a emissão de nota pelo sistema</span></label>
      <div data-form="nfe">${formHTML(camposNfe, nfe)}</div>${segredo('nfe', 'token', 'Token da Focus NFe (do ambiente escolhido)')}
      ${dona ? `<div class="linha-acoes" style="margin-top:10px"><button class="btn" data-click="testar" data-s="nfe">Testar conexão</button><span class="espaco"></span><button class="btn pri" data-click="salvar" data-s="nfe">Salvar</button></div>` : ''}</div>
    <div class="card" id="int-pix"><div class="card-cab"><h3>Pix com confirmação automática ${etiqueta('recomendado', 'ok')}</h3>${etiqueta(pix.ativo ? 'ligado' : 'desligado', pix.ativo ? 'ok' : '')}</div>
      <p class="suave">No caixa, o QR Code do Pix é criado pelo banco com o valor da venda e o sistema mostra <b>"Pix recebido"</b> sozinho quando a cliente paga. Sem esta integração, o QR Code continua funcionando, mas você confere o recebimento no app do banco.</p>
      <label class="check"><input type="checkbox" name="ativo" ${pix.ativo ? 'checked' : ''}><span>Ligar o Pix com confirmação automática</span></label>
      <div data-form="pix">${formHTML(camposPix, pix)}</div>
      <div id="pix-mp">${segredo('pix', 'token', 'Access Token do Mercado Pago (Suas integrações › Credenciais de produção)')}</div>
      <div id="pix-banco"><label class="campo"><span>Preencher com os endereços conferidos de</span><select id="preset-banco"><option value="">— outro banco: preencher à mão —</option>${Object.entries(bancos).map(([k, x]) => `<option value="${k}">${esc(x.nome)}</option>`).join('')}</select></label>
        <div data-form="banco">${formHTML(camposBanco, pix)}</div>${segredo('pix', 'client_secret', 'Client Secret')}
        ${segredo('pix', 'certificado', 'Certificado do banco (PEM: -----BEGIN CERTIFICATE-----)', 'textarea')}${segredo('pix', 'chave_certificado', 'Chave do certificado (PEM: -----BEGIN PRIVATE KEY-----)', 'textarea')}
        <small class="suave">Se o banco entregou o certificado em .p12 ou .pfx, converta para PEM (o contador ou quem cuida da informática faz em um minuto). O certificado é guardado criptografado.</small></div>
      ${dona ? `<div class="linha-acoes" style="margin-top:10px"><button class="btn" data-click="testar" data-s="pix">Testar conexão</button><span class="espaco"></span><button class="btn pri" data-click="salvar" data-s="pix">Salvar</button></div>` : ''}</div>
    <div class="card"><h3>Banco e maquininhas: conciliação ${etiqueta('recomendado', 'ok')}</h3>
      <p class="suave">Importe o extrato do banco (arquivo OFX, de qualquer banco) e o relatório de vendas da maquininha (CSV do portal da PagBank, Stone, Cielo, Rede, Mercado Pago e outras).
        O sistema confere com o financeiro, mostra a taxa que a maquininha cobrou de verdade e dá baixa no que caiu na conta. Não precisa de senha do banco.</p>
      <a class="btn pri" href="#/conciliacao">Abrir a conciliação</a></div>
    <div class="card"><h3>Contador</h3><p class="suave">Todo mês, gere o <b>pacote do contador</b> em Financeiro › DRE e indicadores: um arquivo .zip com o DRE, as vendas, as notas (XML), o financeiro, os vales e o extrato conferido.</p>
      <a class="btn" href="#/dre">Ir para o DRE</a></div>`;
  const mostrarPix = () => {
    const p = box.querySelector('#int-pix [name=provedor]').value;
    box.querySelector('#pix-mp').hidden = p !== 'mercadopago';
    box.querySelector('[name=email_pagador]').closest('.campo').hidden = p !== 'mercadopago';
    box.querySelector('#pix-banco').hidden = p !== 'banco';
  };
  box.querySelector('#int-pix [name=provedor]').addEventListener('change', mostrarPix);
  box.querySelector('#preset-banco').addEventListener('change', e => {
    const x = bancos[e.target.value]; if (!x) return;
    const f = box.querySelector('[data-form=banco]');
    f.querySelector('[name=banco]').value = x.nome; f.querySelector('[name=url_api]').value = x.url_api;
    f.querySelector('[name=url_token]').value = x.url_token; f.querySelector('[name=modo_token]').value = x.modo_token;
  });
  mostrarPix();
  if (!dona) box.querySelectorAll('input, select, textarea').forEach(i => { i.disabled = true; });
  const ler = s => {
    const card = box.querySelector('#int-' + s);
    const dados = { ativo: card.querySelector('[name=ativo]').checked, ...lerForm(card.querySelector(`[data-form=${s}]`), s === 'nfe' ? camposNfe : camposPix) };
    if (s === 'pix') Object.assign(dados, lerForm(card.querySelector('[data-form=banco]'), camposBanco));
    card.querySelectorAll('[data-segredo]').forEach(i => { if (i.value.trim()) dados[i.dataset.segredo] = i.value.trim(); });
    return dados;
  };
  ligar(box, {
    salvar: async b => {
      const s = b.dataset.s, dados = ler(s);
      if (s === 'nfe' && dados.ativo && dados.ambiente === 'producao' && !(nfe.ativo && nfe.ambiente === 'producao')
        && !await confirmar('Ligar a nota em PRODUÇÃO? As notas passam a ter valor fiscal e vão para a Sefaz. Faça antes os testes em homologação e confira NCM, CSOSN e CFOP com o contador.', 'Ligar em produção')) return;
      const r = await api('integracoes/salvar', { secao: s, dados });
      App.cfg.integracoes = r.integracoes;
      toast('Integração salva.', 'ok'); recarregarPagina();
    },
    testar: async b => {
      b.disabled = true; const texto = b.textContent; b.textContent = 'Testando...';
      try {
        await api('integracoes/salvar', { secao: b.dataset.s, dados: ler(b.dataset.s) });
        const r = await api('integracoes/testar', { secao: b.dataset.s });
        toast(`Conexão funcionando${r.resultado && r.resultado.conta ? ' (conta ' + r.resultado.conta + ')' : ''}.`, 'ok');
      } finally { b.disabled = false; b.textContent = texto; }
    }
  });
}

/* ------------------------------------------------------------ nota fiscal */
async function emitirNotaVenda(v, documento = '') {
  try {
    const r = await api('nfe/emitir', { venda_id: v.id, documento });
    await carregar(['vendas']);
    if (r.nfe.status === 'autorizado') toast(`NFC-e nº ${r.nfe.numero} autorizada${r.nfe.ambiente === 'homologacao' ? ' (homologação, sem valor fiscal)' : ''}.`, 'ok');
    else if (r.nfe.status === 'processando_autorizacao') toast('A nota está em processamento na Sefaz. Consulte daqui a pouco em Vendas.', 'alerta');
    else toast(`Nota não autorizada: ${r.nfe.mensagem || r.nfe.status}. A venda está registrada; corrija e tente de novo em Vendas.`, 'erro', { tempo: 15000 });
    return App.idx.venda[v.id] || v;
  } catch (e) {
    toast(`Nota não emitida: ${e.message} A venda está registrada; tente de novo em Vendas.`, 'erro', { tempo: 15000 });
    await carregar(['vendas']).catch(() => {});
    return App.idx.venda[v.id] || v;
  }
}

function situacaoNota(nfe) {
  return { autorizado: ['NFC-e autorizada', 'ok'], cancelado: ['NFC-e cancelada', ''], processando_autorizacao: ['NFC-e em processamento', 'alerta'],
    enviando: ['NFC-e enviada, sem resposta', 'alerta'], erro_autorizacao: ['NFC-e rejeitada', 'erro'], erro_comunicacao: ['NFC-e sem resposta do emissor', 'erro'], nao_encontrada: ['NFC-e não encontrada no emissor', 'erro'] }[nfe.status] || [nfe.status || '', ''];
}

function notaVendaHTML(v) {
  const nfe = v.nfe;
  if (!nfe) return '';
  const [txt, cls] = situacaoNota(nfe);
  return `<div style="margin-top:8px">${etiqueta(txt, cls)}${nfe.ambiente === 'homologacao' ? ' ' + etiqueta('homologação') : ''}
    ${nfe.numero ? ` nº ${esc(String(nfe.numero))} série ${esc(String(nfe.serie))}` : ''}${nfe.chave ? `<br><small class="suave">Chave ${esc(nfe.chave)}</small>` : ''}
    ${nfe.mensagem && nfe.status !== 'autorizado' ? `<br><small class="negativo">${esc(nfe.mensagem)}</small>` : ''}</div>`;
}

function botoesNotaVenda(v) {
  if (!nfeAtiva() && !v.nfe) return [];
  const nfe = v.nfe || {}, st = nfe.status;
  const lista = [];
  if (v.status === 'concluida' && nfeAtiva() && (!st || ['erro_autorizacao', 'erro_comunicacao', 'nao_encontrada'].includes(st)))
    lista.push({ texto: st ? 'Emitir nota de novo' : 'Emitir NFC-e', acao: async () => { await emitirNotaVenda(v, (v.nota || {}).documento || ''); recarregarPagina(); } });
  if (['processando_autorizacao', 'enviando'].includes(st))
    lista.push({ texto: 'Consultar nota', acao: async () => { const r = await api('nfe/consultar', { venda_id: v.id }); await carregar(['vendas']); toast(situacaoNota(r.nfe)[0], r.nfe.status === 'autorizado' ? 'ok' : 'alerta'); recarregarPagina(); } });
  if (st === 'autorizado') {
    lista.push({ texto: 'Imprimir DANFE', acao: async () => { await imprimirDanfe(v); return false; } });
    if (gestora()) lista.push({ texto: 'Cancelar nota', classe: 'perigo', acao: () => { cancelarNota(v); } });
  }
  return lista;
}

async function imprimirDanfe(v) {
  const r = await api('nfe/danfe', { venda_id: v.id });
  const bytes = Uint8Array.from(atob(r.arquivo), c => c.charCodeAt(0));
  if (r.tipo === 'pdf') { baixarArquivo(`nfce-${v.numero}.pdf`, new Blob([bytes], { type: 'application/pdf' })); return; }
  const doc = new DOMParser().parseFromString(new TextDecoder('utf-8').decode(bytes), 'text/html');
  doc.querySelectorAll('script, iframe, object, embed, link[rel=import]').forEach(x => x.remove());
  doc.querySelectorAll('*').forEach(x => [...x.attributes].forEach(a => { if (/^on/i.test(a.name) || /^\s*javascript:/i.test(a.value)) x.removeAttribute(a.name); }));
  imprimir(`<div class="recibo">${doc.body.innerHTML}</div>`, 'size: 80mm auto; margin: 3mm;');
}

function cancelarNota(v) {
  modal({ titulo: `Cancelar a NFC-e da venda nº ${v.numero}`, corpo: `<p>Use quando a venda foi desfeita. A Sefaz só aceita o cancelamento por pouco tempo depois da emissão; passado o prazo, o contador orienta a nota de devolução.</p>
    ${formHTML([{ n: 'justificativa', r: 'Motivo (15 a 255 letras)', t: 'textarea', w: 12, obr: 1, padrao: 'Venda desfeita a pedido da cliente' }])}`,
    botoes: [{ texto: 'Voltar' }, { texto: 'Cancelar a nota', classe: 'perigo', acao: async m => {
      await api('nfe/cancelar', { venda_id: v.id, justificativa: m.querySelector('[name=justificativa]').value });
      await carregar(['vendas']); toast('Nota cancelada na Sefaz.', 'ok'); recarregarPagina();
    } }] });
}

/* ------------------------------------------------------- Pix por API (caixa) */
/* Cria a cobrança no banco, mostra o QR Code e espera a confirmação. Resolve com a cobrança paga ou null. */
function cobrarPixApi(valor, descricao) {
  return new Promise(async resolve => {
    let cob, fim = false, timer;
    let r;
    try { r = await api('pix/cobrar', { valor, descricao }); } catch (e) { toast(e.message, 'erro'); resolve(null); return; }
    cob = r.cobranca;
    const matriz = QRCode.gerar(cob.copia_cola, 1);
    const m = modal({ titulo: `Pix de ${moeda(valor)}`, corpo: `<div style="display:flex;flex-direction:column;align-items:center;gap:8px">
        <div class="qr-box" style="width:240px">${QRCode.svg(matriz)}</div><div id="pix-st" class="caixa-aviso" style="width:100%;text-align:center">Aguardando o pagamento...</div>
        <small class="suave">Pix copia e cola:</small><div class="copia-cola" style="max-width:100%">${esc(cob.copia_cola)}</div></div>`,
      botoes: [{ texto: 'Copiar código', acao: async () => { await navigator.clipboard.writeText(cob.copia_cola).catch(() => {}); toast('Código copiado.', 'ok'); return false; } },
        { texto: 'Desistir deste Pix', classe: 'perigo' }] });
    const encerrar = async pago => {
      if (fim) return; fim = true; clearTimeout(timer);
      if (!pago) {
        // Cancela no banco e confere: se a cliente pagou no último instante, o Pix vale.
        const r = await api('pix/cancelar', { id: cob.id }).catch(() => null);
        if (r && r.cobranca && r.cobranca.status === 'paga') { cob = r.cobranca; pago = true; toast('O Pix foi pago antes do cancelamento e entrou na venda.', 'ok'); }
      }
      await carregar(['cobrancas']).catch(() => {});
      resolve(pago ? cob : null);
    };
    new MutationObserver((_, obs) => { if (!m.isConnected) { obs.disconnect(); encerrar(cob.status === 'paga'); } }).observe(document.getElementById('modais'), { childList: true });
    const verificar = async () => {
      if (fim) return;
      try {
        const s = await api('pix/status', { id: cob.id });
        cob = s.cobranca;
        if (cob.status === 'paga') {
          m.querySelector('#pix-st').className = 'caixa-aviso ok'; m.querySelector('#pix-st').innerHTML = '<b>Pix recebido!</b> Confirmado pelo banco.';
          setTimeout(() => m.fechar(), 1200);
          return;
        }
        if (cob.status !== 'aguardando') { m.querySelector('#pix-st').className = 'caixa-aviso erro'; m.querySelector('#pix-st').textContent = 'Este Pix expirou ou foi cancelado. Gere outro.'; return; }
      } catch (e) { /* sem conexão por um instante: tenta de novo */ }
      timer = setTimeout(verificar, 3000);
    };
    timer = setTimeout(verificar, 3000);
  });
}

/* ------------------------------------------------------------- conciliação */
App.paginas.conciliacao = async (el, id, params) => {
  const aba = params.aba || 'extrato';
  const hist = (App.d.conciliacoes || []).slice().reverse();
  el.innerHTML = `${abas([['extrato', 'Extrato do banco (OFX)'], ['cartoes', 'Relatório da maquininha (CSV)'], ['historico', 'Importações feitas']], aba)}<div id="conc"></div>`;
  ligar(el, { aba: b => ir('#/conciliacao?aba=' + b.dataset.k) });
  const box = el.querySelector('#conc');
  if (aba === 'historico') {
    box.innerHTML = '<div class="card" id="t"></div>';
    tabela(box.querySelector('#t'), { linhas: hist, colunas: [{ t: 'Quando', v: c => c.em, h: c => dataHoraBR(c.em) }, { t: 'Tipo', v: c => c.tipo === 'extrato' ? 'Extrato do banco' : 'Maquininha' },
      { t: 'Origem', v: c => c.tipo === 'extrato' ? `${c.banco || ''} ${c.conta ? 'final ' + c.conta : ''}` : c.provedor }, { t: 'Arquivo', v: c => c.arquivo },
      { t: 'Período / casadas', v: c => c.tipo === 'extrato' ? `${dataBR(c.inicio)} a ${dataBR(c.fim)} · ${c.transacoes.filter(t => t.ids.length).length} casadas` : `${c.casadas} casadas` },
      { t: 'Sem par', v: c => c.tipo === 'extrato' ? c.transacoes.filter(t => !t.ids.length && !t.lancado).length : (c.so_no_relatorio || []).length, cls: 'num' }],
      aoClicar: c => { if (c.tipo === 'extrato') pendenciasExtrato(c); } });
    return;
  }
  const extrato = aba === 'extrato';
  box.innerHTML = `<div class="card"><h3>${extrato ? 'Extrato do banco' : 'Relatório de vendas da maquininha'}</h3>
    <p class="suave">${extrato ? 'No site ou app do banco, exporte o extrato da conta da loja em <b>OFX</b> (às vezes chamado "Money" ou "Quicken"). Funciona com qualquer banco. Importar o mesmo período de novo não duplica nada.'
      : 'No portal da maquininha, exporte as vendas (ou os recebíveis) do período em <b>CSV</b>. O sistema reconhece as colunas mais comuns; se não reconhecer, você escolhe.'}</p>
    <div class="grade-form">${extrato ? '' : `<label class="campo w4"><span>Maquininha</span><select name="provedor">${['PagBank', 'Stone', 'Cielo', 'Rede', 'Mercado Pago', 'SumUp', 'InfinitePay', 'Ton', 'Outra'].map(p => `<option>${p}</option>`).join('')}</select></label>`}
      <label class="campo w8"><span>Arquivo</span><input type="file" name="arquivo" accept="${extrato ? '.ofx,.OFX' : '.csv,.txt'}"></label></div>
    <div class="linha-acoes" style="margin-top:10px"><span class="espaco"></span><button class="btn pri" data-click="ler">Conferir</button></div></div><div id="resultado"></div>`;
  let enviado = null;
  const arquivoB64 = async () => {
    const f = box.querySelector('[name=arquivo]').files[0];
    if (!f) throw new Error('Escolha o arquivo.');
    const bytes = new Uint8Array(await f.arrayBuffer());
    let bin = ''; for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return { nome: f.name, arquivo: btoa(bin) };
  };
  const ler = async (aplicar, mapa) => {
    if (!enviado) enviado = await arquivoB64();
    const corpo = { ...enviado, aplicar };
    if (extrato && Array.isArray(mapa)) corpo.ignorar = mapa;
    if (!extrato) { corpo.provedor = box.querySelector('[name=provedor]').value; if (mapa) corpo.mapa = mapa; }
    return api(extrato ? 'conciliacao/extrato' : 'conciliacao/cartoes', corpo);
  };
  box.querySelector('[name=arquivo]').addEventListener('change', () => { enviado = null; box.querySelector('#resultado').innerHTML = ''; });
  ligar(box, { ler: async () => {
    const r = await ler(false);
    (extrato ? mostrarExtrato : mostrarCartoes)(box.querySelector('#resultado'), r, async mapa => {
      const a = await ler(true, mapa); await carregar(['financeiro', 'conciliacoes', 'vendas']);
      toast(`Conciliação aplicada: ${extrato ? a.casadas.length : a.casadas} lançamento(s) conferido(s).`, 'ok');
      if (extrato && a.sem_par.length) pendenciasExtrato(App.d.conciliacoes.find(c => c.id === a.conciliacao_id));
      else recarregarPagina();
    }, async mapa => mostrarCartoes(box.querySelector('#resultado'), await ler(false, mapa), null));
  } });
};

function mostrarExtrato(el, r, aplicar) {
  const entradas = soma(r.sem_par.filter(t => t.valor > 0), t => t.valor), saidas = soma(r.sem_par.filter(t => t.valor < 0), t => -t.valor);
  el.innerHTML = `<div class="card"><h3>${esc(r.banco || 'Banco')} ${r.conta ? '· conta final ' + esc(r.conta) : ''} · ${dataBR(r.inicio)} a ${dataBR(r.fim)}</h3>
    <div class="kpis">${kpi('Movimentações', r.total, r.repetidas ? `${r.repetidas} já importada(s) antes` : '')}${kpi('Casaram com o financeiro', r.casadas.length, soma(r.casadas, c => c.baixar) + ' baixa(s) a dar')}
      ${kpi('Sem par', r.sem_par.length, `entradas ${moeda(entradas)} · saídas ${moeda(saidas)}`)}</div>
    ${r.casadas.length ? `<h3 style="margin-top:12px">Vai conferir</h3><p class="suave">Desmarque o que não estiver certo: vai para "sem par".</p><table class="tab"><thead><tr><th></th><th>Data</th><th>No extrato</th><th class="th-num">Valor</th><th>No sistema</th></tr></thead><tbody>
      ${r.casadas.map(c => `<tr><td><input type="checkbox" data-casada="${esc(c.transacao.id)}" checked></td><td>${dataBR(c.transacao.data)}</td><td>${esc(c.transacao.descricao)}</td><td class="num">${moeda(c.transacao.valor)}</td>
        <td>${c.lancamentos.map(l => `${esc(l.descricao)} ${l.status === 'pendente' ? etiqueta('vai dar baixa', 'alerta') : etiqueta('já pago', 'ok')}`).join('<br>')}</td></tr>`).join('')}</tbody></table>` : ''}
    ${r.sem_par.length ? `<p class="suave" style="margin-top:10px">As movimentações sem par (tarifas, transferências, Pix fora do sistema) aparecem para você lançar depois de aplicar.</p>` : ''}
    <div class="linha-acoes" style="margin-top:12px"><span class="espaco"></span><button class="btn pri" data-click="aplicar">Aplicar a conciliação</button></div></div>`;
  ligar(el, { aplicar: () => aplicar([...el.querySelectorAll('[data-casada]')].filter(c => !c.checked).map(c => c.dataset.casada)) });
}

function mostrarCartoes(el, r, aplicar, remapear) {
  const nomes = { data: 'Data da venda', bruto: 'Valor bruto', liquido: 'Valor líquido', taxa: 'Taxa', parcelas: 'Parcelas', previsao: 'Previsão de pagamento', forma: 'Débito/crédito', bandeira: 'Bandeira', nsu: 'NSU / autorização', status: 'Situação' };
  const sel = campo => `<label class="campo w3"><span>${nomes[campo]}</span><select data-mapa="${campo}"><option value="">—</option>${r.cabecalho.map((c, i) => `<option value="${i}" ${r.mapa[campo] === i ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select></label>`;
  el.innerHTML = `<div class="card"><h3>Resultado</h3>
    <div class="kpis">${kpi('Vendas no relatório', r.linhas)}${kpi('Casaram com o sistema', r.casadas)}${kpi('Taxa cobrada de verdade', moeda(r.taxa_relatorio), `o sistema estimava ${moeda(r.taxa_sistema)}`)}
      ${kpi('Só no relatório', r.so_no_relatorio.length, 'venda na maquininha sem registro no sistema')}${kpi('Só no sistema', r.so_no_sistema.length, 'cartão registrado que não está no relatório')}</div>
    <details style="margin-top:10px"><summary>Colunas reconhecidas (mude se alguma estiver errada)</summary><div class="grade-form">${Object.keys(nomes).map(sel).join('')}</div>
      <button class="btn" data-click="remapear" style="margin-top:8px">Conferir de novo com estas colunas</button></details>
    ${r.so_no_relatorio.length ? `<h3 style="margin-top:12px">Só no relatório da maquininha</h3><table class="tab"><tbody>${r.so_no_relatorio.slice(0, 50).map(v => `<tr><td>${dataBR(v.data)}</td><td>${esc(v.forma || '')} ${v.parcelas > 1 ? v.parcelas + 'x' : ''}</td><td class="num">${moeda(v.bruto)}</td><td>${esc(v.nsu || '')}</td></tr>`).join('')}</tbody></table>` : ''}
    ${r.so_no_sistema.length ? `<h3 style="margin-top:12px">Só no sistema</h3><table class="tab"><tbody>${r.so_no_sistema.slice(0, 50).map(f => `<tr><td>${esc(f.descricao)}</td><td>${dataBR(f.vencimento)}</td><td class="num">${moeda(f.valor)}</td></tr>`).join('')}</tbody></table>` : ''}
    ${aplicar ? `<div class="linha-acoes" style="margin-top:12px"><span class="espaco"></span><button class="btn pri" data-click="aplicar">Aplicar taxas e datas reais</button></div>` : ''}</div>`;
  const mapa = () => { const m = {}; el.querySelectorAll('[data-mapa]').forEach(s => { if (s.value !== '') m[s.dataset.mapa] = +s.value; }); return m; };
  ligar(el, { aplicar: () => aplicar && aplicar(mapa()), remapear: () => remapear(mapa()) });
}

function pendenciasExtrato(c) {
  const sem = c.transacoes.filter(t => !t.ids.length && !t.lancado);
  if (!sem.length) { recarregarPagina(); return; }
  const receitas = opcoes(App.d.plano_contas.filter(p => p.tipo === 'receita' && p.id !== 'pc_vendas'));
  const despesas = opcoes(App.d.plano_contas.filter(p => p.tipo === 'despesa'));
  const m = modal({ titulo: 'Movimentações sem par no sistema', largura: 'largo', corpo: `<p class="suave">Lance o que for da loja (tarifa do banco, aluguel pago por transferência...). O que não for da loja, deixe em branco.</p>
    <table class="tab"><tbody>${sem.map((t, k) => `<tr><td>${dataBR(t.data)}</td><td>${esc(t.descricao)}</td><td class="num ${t.valor < 0 ? 'negativo' : 'positivo'}">${moeda(t.valor)}</td>
      <td><select data-k="${k}"><option value="">não lançar</option>${(t.valor > 0 ? receitas : despesas).map(([i, nome]) => `<option value="${i}">${esc(nome)}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table>`,
    botoes: [{ texto: 'Fechar' }, { texto: 'Lançar os escolhidos', classe: 'pri', acao: async mm => {
      let feitos = 0;
      for (const s of mm.querySelectorAll('[data-k]')) {
        if (!s.value) continue;
        await api('conciliacao/lancar', { conciliacao_id: c.id, transacao_id: sem[+s.dataset.k].id, categoria_id: s.value }); feitos++;
      }
      await carregar(['financeiro', 'conciliacoes']); toast(`${feitos} lançamento(s) criado(s).`, 'ok'); recarregarPagina();
    } }] });
  return m;
}

/* ------------------------------------------------------------ pacote do contador */
async function gerarPacoteContador(mes, linhasDre) {
  const r = await api('contador/pacote', { mes, dre: linhasDre });
  const bytes = Uint8Array.from(atob(r.arquivo), ch => ch.charCodeAt(0));
  baixarArquivo(r.nome, new Blob([bytes], { type: 'application/zip' }));
  toast('Pacote do contador gerado. Envie o arquivo .zip para o contador.', 'ok');
}
