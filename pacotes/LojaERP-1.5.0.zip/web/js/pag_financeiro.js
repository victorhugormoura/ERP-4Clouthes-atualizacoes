/* Loja ERP — contas a pagar/receber, fluxo de caixa, DRE, metas, despesas fixas e bens.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

function opcoesPlano(tipo) {
  return App.d.plano_contas.filter(c => c.ativo !== false && (!tipo || c.tipo === tipo) && c.id !== 'pc_vendas')
    .sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')).map(c => [c.id, `${c.nome} — ${GRUPOS_DRE[c.grupo] ? GRUPOS_DRE[c.grupo].split(' (')[0] : c.grupo}`]);
}

/* ------------------------------------------------------------------ contas */
App.paginas.contas = async (el, id, params) => {
  const aba = params.aba || 'pagar';
  const st = { situacao: params.sit || 'abertas', de: '', ate: '' };
  el.innerHTML = `${abas([['pagar', 'Contas a pagar'], ['receber', 'Contas a receber']], aba)}
    <div class="linha-acoes"><div class="chips">${[['abertas', 'Em aberto'], ['vencidas', 'Vencidas'], ['semana', 'Próximos 7 dias'], ['mes', 'Este mês'], ['pagas', aba === 'pagar' ? 'Pagas' : 'Recebidas'], ['todas', 'Todas']].map(([k, t]) => `<button class="chip ${k === st.situacao ? 'ativo' : ''}" data-click="sit" data-k="${k}">${t}</button>`).join('')}</div>
      <span class="espaco"></span>${aba === 'pagar' ? '<button class="btn" data-click="ler" title="Lê o código de barras do boleto, a conta de consumo ou o QR Code Pix">Ler boleto ou Pix</button>' : ''}<button class="btn pri" data-click="novo">Novo lançamento</button></div>
    <div id="resumo-contas" class="kpis"></div><div class="card" id="tab-contas"></div>`;
  const dia = hojeISO(), mes = dia.slice(0, 7);
  const filtrar = () => App.d.financeiro.filter(f => f.tipo === aba && f.status !== 'cancelado').filter(f => {
    switch (st.situacao) {
      case 'abertas': return f.status === 'pendente';
      case 'vencidas': return f.status === 'pendente' && f.vencimento < dia;
      case 'semana': return f.status === 'pendente' && f.vencimento <= somarDias(dia, 7);
      case 'mes': return f.vencimento.slice(0, 7) === mes;
      case 'pagas': return f.status === 'pago';
      default: return true;
    }
  }).sort((a, b) => st.situacao === 'pagas' ? (b.pago_em || '').localeCompare(a.pago_em || '') : a.vencimento.localeCompare(b.vencimento));
  function resumo() {
    const abertas = App.d.financeiro.filter(f => f.tipo === aba && f.status === 'pendente');
    const venc = abertas.filter(f => f.vencimento < dia);
    const v = f => aba === 'receber' ? f.liquido : f.valor;
    el.querySelector('#resumo-contas').innerHTML = kpi('Em aberto', moeda(soma(abertas, v)), `${abertas.length} lançamento(s)`) + kpi('Vencidas', `<span class="${venc.length ? 'negativo' : ''}">${moeda(soma(venc, v))}</span>`, `${venc.length} lançamento(s)`) +
      kpi('Próximos 7 dias', moeda(soma(abertas.filter(f => f.vencimento >= dia && f.vencimento <= somarDias(dia, 7)), v))) + kpi('Próximos 30 dias', moeda(soma(abertas.filter(f => f.vencimento >= dia && f.vencimento <= somarDias(dia, 30)), v)));
  }
  const t = tabela(el.querySelector('#tab-contas'), {
    linhas: filtrar(), exportar: 'contas-' + aba, placeholder: 'Descrição, categoria, cliente, fornecedor...',
    textoBusca: f => `${(App.idx.pc[f.categoria_id] || {}).nome} ${(App.idx.cli[f.cliente_id] || {}).nome} ${(App.idx.forn[f.fornecedor_id] || {}).nome}`,
    colunas: [{ t: 'Vencimento', v: f => f.vencimento, h: f => dataBR(f.vencimento) }, { t: 'Descrição', v: f => f.descricao, h: f => `${esc(f.descricao)}${f.obs ? `<br><small class="suave">${esc(f.obs)}</small>` : ''}` },
      { t: 'Categoria', v: f => (App.idx.pc[f.categoria_id] || {}).nome || '' },
      { t: aba === 'pagar' ? 'Fornecedor' : 'Cliente', v: f => aba === 'pagar' ? (App.idx.forn[f.fornecedor_id] || {}).nome || '' : (App.idx.cli[f.cliente_id] || {}).nome || '' },
      { t: 'Forma', v: f => FORMAS_PAG[f.forma] || f.forma || '' },
      { t: 'Valor', v: f => f.valor, h: f => `${moeda(f.valor)}${f.taxa ? `<br><small class="suave">líq. ${moeda(f.liquido)}</small>` : ''}`, cls: 'num', total: true },
      { t: 'Situação', v: f => statusFin(f)[0], h: f => etiqueta(...statusFin(f)) + (f.pago_em ? `<br><small class="suave">${dataBR(f.pago_em)}</small>` : '') },
      { t: '', semOrdem: true, h: f => f.status === 'pendente' ? `<button class="btn pequeno ok" data-acao="baixar">${aba === 'pagar' ? 'Pagar' : 'Receber'}</button>${f.forma === 'crediario' ? ' <button class="btn pequeno" data-acao="cobrar">Cobrar</button>' : ''}` : '<button class="btn pequeno" data-acao="estornar">Estornar</button>' }],
    acoes: {
      baixar: f => modal({ titulo: `${aba === 'pagar' ? 'Pagamento' : 'Recebimento'}: ${f.descricao}`, corpo: formHTML([
        { n: 'data', r: 'Data', t: 'date', w: 4, padrao: dia }, { n: 'valor_pago', r: 'Valor efetivo', t: 'money', w: 4, padrao: aba === 'receber' ? f.liquido : f.valor, aj: 'Diferença vira juros/desconto no DRE.' },
        { n: 'forma', r: 'Forma', t: 'select', w: 4, vazio: false, padrao: f.forma || 'pix', op: [['pix', 'Pix'], ['dinheiro', 'Dinheiro'], ['boleto', 'Boleto'], ['transferencia', 'Transferência'], ['debito', 'Débito'], ['credito', 'Crédito'], ['cartao', 'Cartão']] },
        { n: 'usar_caixa', r: 'Dinheiro entra/sai da gaveta do caixa aberto', t: 'check', w: 12, padrao: true }]),
        botoes: [{ texto: 'Cancelar' }, { texto: 'Confirmar', classe: 'ok', acao: async m => { const d = lerForm(m, [{ n: 'data' }, { n: 'valor_pago', t: 'money' }, { n: 'forma' }, { n: 'usar_caixa', t: 'check' }]); await api('financeiro/baixar', { id: f.id, ...d }); toast('Baixa registrada.', 'ok'); recarregarPagina(); } }] }),
      estornar: async f => { if (!await confirmar('Desfazer a baixa deste lançamento?', 'Estornar', 'perigo')) return; await api('financeiro/estornar', { id: f.id }); recarregarPagina(); },
      cobrar: async f => { const c = App.idx.cli[f.cliente_id]; if (c && await confirmarCobranca()) abrirWhatsApp(c.telefone, textoModelo('cobranca', { nome: c.apelido || c.nome.split(' ')[0], valor: moeda(f.valor), vencimento: dataBR(f.vencimento) })); }
    },
    aoClicar: f => editarLancamento(f)
  });
  resumo();
  ligar(el, {
    aba: b => ir('#/contas?aba=' + b.dataset.k),
    sit: b => { st.situacao = b.dataset.k; el.querySelectorAll('[data-click=sit]').forEach(x => x.classList.toggle('ativo', x === b)); t.atualizar(filtrar()); },
    novo: () => novoLancamento(aba),
    ler: () => contaPorCodigo()
  });
};

function novoLancamento(tipo, inicial = {}) {
  const campos = [{ n: 'descricao', r: 'Descrição', w: 8, obr: 1 }, { n: 'valor', r: 'Valor total (R$)', t: 'money', w: 4, obr: 1 },
    { n: 'categoria_id', r: 'Categoria (plano de contas)', t: 'select', w: 8, op: () => opcoesPlano(tipo === 'pagar' ? 'despesa' : 'receita'), obr: 1 },
    { n: 'vencimento', r: 'Vencimento', t: 'date', w: 4, padrao: hojeISO(), obr: 1 },
    { n: 'parcelas', r: 'Parcelas / repetições', t: 'number', w: 3, min: 1, padrao: 1 },
    { n: 'modo_parcelas', r: 'Se mais de 1', t: 'select', w: 5, vazio: false, op: [['dividir', 'Dividir o valor nas parcelas'], ['repetir', 'Repetir o valor todo mês']] },
    { n: 'competencia', r: 'Mês de competência (DRE)', t: 'month', w: 4, aj: 'Vazio = mês do vencimento' },
    tipo === 'pagar' ? { n: 'fornecedor_id', r: 'Fornecedor', t: 'select', w: 6, op: () => opcoes(App.d.fornecedores) } : { n: 'cliente_id', r: 'Cliente', t: 'select', w: 6, op: () => opcoes(App.d.clientes.filter(c => !c.anonimizada)) },
    { n: 'pago', r: tipo === 'pagar' ? 'Já está pago' : 'Já foi recebido', t: 'check', w: 6 },
    { n: 'forma', r: 'Forma', t: 'select', w: 6, op: [['pix', 'Pix'], ['dinheiro', 'Dinheiro'], ['boleto', 'Boleto'], ['transferencia', 'Transferência'], ['cartao', 'Cartão']] },
    { n: 'usar_caixa', r: 'Se em dinheiro, movimentar a gaveta do caixa', t: 'check', w: 6 },
    { n: 'obs', r: 'Observação', w: 12 }];
  modal({ titulo: tipo === 'pagar' ? 'Nova conta a pagar' : 'Nova conta a receber', largura: 'largo', corpo: formHTML(campos, inicial),
    botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => { const d = lerForm(m, campos); await api('financeiro/lancar', { tipo, ...d }); toast('Lançamento criado.', 'ok'); recarregarPagina(); } }] });
}

function editarLancamento(f) {
  const editavel = f.status === 'pendente' && ['manual', 'recorrente', 'compra'].includes(f.origem);
  const campos = [{ n: 'descricao', r: 'Descrição', w: 8 }, { n: 'valor', r: 'Valor', t: 'money', w: 4 },
    { n: 'categoria_id', r: 'Categoria', t: 'select', w: 6, op: () => opcoesPlano(f.tipo === 'pagar' ? 'despesa' : 'receita').concat(f.categoria_id === 'pc_vendas' ? [['pc_vendas', 'Vendas']] : []) },
    { n: 'vencimento', r: 'Vencimento', t: 'date', w: 3 }, { n: 'competencia', r: 'Competência', t: 'month', w: 3 },
    ...(f.tipo === 'pagar' ? [{ n: 'fornecedor_id', r: 'Fornecedor', t: 'select', w: 6, op: () => opcoes(App.d.fornecedores) }] : []), { n: 'obs', r: 'Observação', w: 12 }];
  modal({ titulo: f.descricao, largura: 'largo', corpo: `${editavel ? '' : `<div class="caixa-aviso">Origem: ${esc(f.origem)} · ${esc(statusFin(f)[0])}. ${f.status === 'pago' ? 'Estorne a baixa para editar.' : 'Lançamentos de vendas, crediário e trocas são alterados pela origem.'}</div>`}
    ${formHTML(campos.map(c => ({ ...c, ro: !editavel })), f)}${f.taxa ? `<p class="suave" style="margin-top:8px">Taxa: ${moeda(f.taxa)} · líquido ${moeda(f.liquido)}</p>` : ''}`,
    botoes: [...(['manual', 'recorrente'].includes(f.origem) ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { if (!await confirmar('Excluir este lançamento?', 'Excluir', 'perigo')) return false; await api('financeiro/excluir', { id: f.id }); recarregarPagina(); } }] : []),
      { texto: 'Fechar' }, ...(editavel ? [{ texto: 'Salvar', classe: 'pri', acao: async m => { await api('financeiro/editar', { obj: { id: f.id, ...lerForm(m, campos) } }); toast('Lançamento atualizado.', 'ok'); recarregarPagina(); } }] : [])] });
}

/* ----------------------------------------------------------- fluxo de caixa */
App.paginas.fluxo = async (el, id, params) => {
  const dia = hojeISO();
  const comPrevisao = params.previsao === '1';
  const base60 = vendasPeriodo(somarDias(dia, -60), somarDias(dia, -1));
  const mediaDiaria = soma(base60, v => v.total - soma(v.pagamentos, p => n(p.taxa))) / 60;
  const saldo = saldoAtual();
  const pend = App.d.financeiro.filter(f => f.status === 'pendente');
  const semanas = [];
  let acumulado = saldo;
  const vencidosR = soma(pend.filter(f => f.tipo === 'receber' && f.vencimento < dia), f => f.liquido);
  const vencidosP = soma(pend.filter(f => f.tipo === 'pagar' && f.vencimento < dia), f => f.valor);
  acumulado += vencidosR - vencidosP;
  for (let k = 0; k < 13; k++) {
    const ini = somarDias(dia, k * 7), fim = somarDias(dia, k * 7 + 6);
    const prev = comPrevisao ? mediaDiaria * 7 : 0;
    const ent = soma(pend.filter(f => f.tipo === 'receber' && f.vencimento >= ini && f.vencimento <= fim), f => f.liquido) + prev;
    const sai = soma(pend.filter(f => f.tipo === 'pagar' && f.vencimento >= ini && f.vencimento <= fim), f => f.valor);
    acumulado += ent - sai;
    semanas.push({ ini, fim, ent, sai, prev, saldo: acumulado });
  }
  const negativa = semanas.find(s => s.saldo < 0);
  const f = App.cfg.financeiro || {};
  el.innerHTML = `<div class="kpis">${kpi('Saldo atual estimado', moeda(saldo), `Saldo inicial de ${moeda(f.saldo_inicial)} em ${dataBR(f.data_saldo_inicial)} + entradas − saídas`)}
      ${kpi('Atrasados a receber', moeda(vencidosR))}${kpi('Atrasados a pagar', `<span class="${vencidosP ? 'negativo' : ''}">${moeda(vencidosP)}</span>`)}
      ${kpi('Saldo projetado em 90 dias', `<span class="${semanas[12].saldo < 0 ? 'negativo' : ''}">${moeda(semanas[12].saldo)}</span>`, 'Considera só o que já está lançado')}</div>
    ${negativa ? `<div class="caixa-aviso erro">Atenção: o saldo projetado fica negativo na semana de ${dataBR(negativa.ini)}. Antecipe recebíveis, renegocie prazos ou segure compras.</div>` : ''}
    <div class="card"><div class="card-cab"><h3>Saldo projetado por semana</h3><div class="linha-acoes" style="margin:0">
      <label class="check"><input type="checkbox" data-change="previsao" ${comPrevisao ? 'checked' : ''}><span>Incluir previsão de vendas (média líquida de ${moeda(mediaDiaria)}/dia nos últimos 60 dias)</span></label>
      <button class="btn pequeno" data-click="saldo">Ajustar saldo inicial</button></div></div>
      ${graficoBarras(semanas.map(s => ({ rotulo: `${dataBR(s.ini)} a ${dataBR(s.fim)}`, curto: s.ini.slice(8) + '/' + s.ini.slice(5, 7), valor: s.saldo })))}</div>
    <div class="card"><div id="tab-fluxo"></div><p class="suave">A previsão usa os lançamentos pendentes (cartões a receber, crediário, contas a pagar, despesas fixas já geradas)${comPrevisao ? ' e a média recente de vendas, já descontadas as taxas' : '. Marque a opção acima para incluir as vendas previstas'}.</p></div>`;
  tabela(el.querySelector('#tab-fluxo'), { linhas: semanas, busca: false, exportar: 'fluxo-de-caixa', porPagina: 20,
    colunas: [{ t: 'Semana', v: s => `${dataBR(s.ini)} a ${dataBR(s.fim)}` }, { t: 'Entradas', v: s => r2(s.ent), h: s => `<span class="positivo">${moeda(s.ent)}</span>`, cls: 'num', total: true },
      ...(comPrevisao ? [{ t: 'Vendas previstas', v: s => r2(s.prev), h: s => `<small class="suave">${moeda(s.prev)}</small>`, cls: 'num' }] : []),
      { t: 'Saídas', v: s => r2(s.sai), h: s => `<span class="negativo">${moeda(s.sai)}</span>`, cls: 'num', total: true }, { t: 'Resultado', v: s => r2(s.ent - s.sai), h: s => moeda(s.ent - s.sai), cls: 'num' },
      { t: 'Saldo projetado', v: s => r2(s.saldo), h: s => `<b class="${s.saldo < 0 ? 'negativo' : ''}">${moeda(s.saldo)}</b>`, cls: 'num' }] });
  ligar(el, { previsao: c => ir('#/fluxo' + (c.checked ? '?previsao=1' : '')), saldo: () => {
    const campos = [{ n: 'saldo_inicial', r: 'Saldo em caixa + banco nesta data', t: 'money', min: -9999999, w: 6 }, { n: 'data_saldo_inicial', r: 'Data', t: 'date', w: 6 }];
    modal({ titulo: 'Saldo inicial', corpo: `<p class="suave">Informe quanto havia (gaveta + conta bancária) numa data. O sistema soma tudo o que foi recebido e pago a partir dela.</p>${formHTML(campos, f)}`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => { await api('config', { config: { financeiro: lerForm(m, campos) } }); await carregar([]); recarregarPagina(); } }] });
  } });
};

/* -------------------------------------------------------------------- DRE */
App.paginas.dre = async (el, id, params) => {
  const ano = params.ano || hojeISO().slice(0, 4);
  const mesSel = params.mes || (ano === hojeISO().slice(0, 4) ? mesAtual() : `${ano}-12`);
  const meses = Array.from({ length: 12 }, (_, k) => `${ano}-${pad(k + 1)}`);
  const dres = meses.map(m => dre(m));
  const tot = {};
  for (const k of Object.keys(dres[0])) if (typeof dres[0][k] === 'number') tot[k] = soma(dres, d => d[k]);
  tot.margemEbitda = tot.liquida ? tot.ebitda / tot.liquida * 100 : 0;
  tot.margemLiquida = tot.liquida ? tot.liquido / tot.liquida * 100 : 0;
  tot.margemBruta = tot.liquida ? tot.lucroBruto / tot.liquida * 100 : 0;
  const d = dre(mesSel);
  const ind = indicadoresEstoque();
  const linhas = [
    ['Receita bruta de vendas', 'bruta', ''], ['(−) Descontos e cashback', 'desc', 'sub', -1], ['(−) Devoluções', 'devolucoes', 'sub', -1], ['(−) Impostos sobre vendas', 'impostos', 'sub', -1],
    ['= Receita líquida', 'liquida', 'total'], ['(−) Custo das mercadorias vendidas (CMV)', 'cmv', 'sub', -1], ['(−) Perdas e ajustes de estoque', 'perdas', 'sub', -1],
    ['= Lucro bruto', 'lucroBruto', 'total'], ['(−) Taxas de cartão', 'taxas', 'sub', -1], ['(−) Outras despesas com vendas', 'despVendasManual', 'sub', -1],
    ['(−) Despesas administrativas', 'despAdm', 'sub', -1], ['(−) Despesas com pessoal / pró-labore', 'despPessoal', 'sub', -1], ['(+) Outras receitas operacionais', 'outras', 'sub'],
    ['= EBITDA (geração de caixa operacional)', 'ebitda', 'destaque'], ['(−) Depreciação', 'deprec', 'sub', -1], ['= EBIT (lucro operacional)', 'ebit', 'total'],
    ['(+) Receitas financeiras', 'recFin', 'sub'], ['(−) Despesas financeiras', 'despFin', 'sub', -1], ['= Lucro antes do IR', 'lair', 'total'],
    ['(−) IR/CSLL (incluídos no Simples/MEI)', 'ir', 'sub', -1], ['= LUCRO LÍQUIDO', 'liquido', 'destaque'],
    ['Margem EBITDA', 'margemEbitda', 'pct'], ['Margem líquida', 'margemLiquida', 'pct']
  ];
  const cel = (x, l, cls = '') => {
    const v = x[l[1]];
    if (l[2] === 'pct') return `<td class="num ${cls}">${pct(v)}</td>`;
    if (!v || Math.abs(v) < 0.005) return `<td class="num ${cls} suave">—</td>`;
    const s = l[3] === -1 ? -v : v;
    return `<td class="num ${cls} ${s < 0 && l[3] !== -1 ? 'negativo' : ''}">${s < 0 ? '−' : ''}${numBR(Math.abs(v), 2)}</td>`;
  };
  el.innerHTML = `<div class="linha-acoes"><label class="campo"><span>Ano</span><select data-change="ano">${[0, 1, 2, 3].map(k => { const a = +hojeISO().slice(0, 4) - k; return `<option ${String(a) === ano ? 'selected' : ''}>${a}</option>`; }).join('')}</select></label>
      <label class="campo"><span>Mês em destaque</span><select data-change="mes">${meses.map(m => `<option value="${m}" ${m === mesSel ? 'selected' : ''}>${mesLongo(m)}</option>`).join('')}</select></label>
      <span class="espaco"></span><button class="btn" data-click="csv">Exportar CSV</button><button class="btn" data-click="imprimir">Imprimir</button>
      <button class="btn pri" data-click="contador" title="Arquivo .zip do mês em destaque com DRE, vendas, notas, financeiro, vales e extrato">Pacote do contador</button></div>
    <div class="kpis">${kpi('Receita líquida', moeda(d.liquida), mesLongo(mesSel))}${kpi('Lucro bruto', moeda(d.lucroBruto), 'Margem ' + pct(d.margemBruta))}
      ${kpi('EBITDA', `<span class="${d.ebitda < 0 ? 'negativo' : ''}">${moeda(d.ebitda)}</span>`, 'Margem ' + pct(d.margemEbitda))}${kpi('Lucro líquido', `<span class="${d.liquido < 0 ? 'negativo' : 'positivo'}">${moeda(d.liquido)}</span>`, 'Margem ' + pct(d.margemLiquida))}
      ${kpi('Ponto de equilíbrio', moeda(d.pontoEquilibrio), `Margem de contribuição ${pct(d.mc)} · custos fixos ${moeda(d.fixos)}`, d.pontoEquilibrio ? `<div class="barra-prog"><div style="width:${Math.min(100, d.faturamento / d.pontoEquilibrio * 100)}%"></div></div><div class="det">${pct(d.pontoEquilibrio ? d.faturamento / d.pontoEquilibrio * 100 : 0, 0)} atingido</div>` : '')}
      ${kpi('Ticket médio', moeda(d.ticket), `${d.nVendas} vendas · ${numBR(d.pa, 1)} peças/venda`)}${kpi('Giro de estoque', ind.giro ? numBR(ind.giro, 1) + 'x/ano' : '—', `Cobertura ${ind.cobertura ? numBR(ind.cobertura) + ' dias' : '—'}`)}
      ${kpi('Retiradas / compras', moeda(d.retiradas), `Compras de estoque no mês: ${moeda(d.compras)}`)}</div>
    <div class="card" id="dre-tab"><div class="card-cab"><h3>DRE — ${ano} (regime de competência)</h3><small class="suave">Valores em R$</small></div>
      <div class="tabela-wrap"><table class="tab dre"><thead><tr><th></th>${meses.map(m => `<th class="th-num">${MESES[+m.slice(5) - 1]}</th>`).join('')}<th class="th-num">Total</th><th class="th-num">% rec.</th></tr></thead><tbody>
      ${linhas.map(l => `<tr class="${l[2]}"><td>${esc(l[0])}</td>${dres.map(x => cel(x, l, x.mes === mesSel ? 'mes-atual' : '')).join('')}${cel(tot, l)}<td class="num suave">${l[2] === 'pct' ? '' : tot.bruta ? pct(tot[l[1]] / tot.bruta * 100 * (l[3] || 1)) : ''}</td></tr>`).join('')}
      </tbody></table></div></div>
    <div class="grade g2"><div class="card"><h3>Receita líquida × lucro líquido</h3>${graficoBarras(dres.map(x => ({ rotulo: mesNome(x.mes), curto: MESES[+x.mes.slice(5) - 1], valor: x.liquida, linha: x.liquido })), { linha: 'var(--ok)' })}
      <small class="suave">Barras: receita líquida · linha verde: lucro líquido</small></div>
      <div class="card"><h3>Como ler</h3><p class="suave"><b>EBITDA</b> mostra quanto a operação da loja gera antes de depreciação, juros e impostos sobre o lucro — é o melhor termômetro da saúde do negócio.
      <b>Ponto de equilíbrio</b> é o faturamento mínimo do mês para cobrir custos fixos. <b>Compras de mercadoria</b> não são despesa: viram estoque e só entram no resultado como CMV quando a peça é vendida.
      Regime: ${d.regime === 'mei' ? 'MEI — o DAS fixo entra em "Impostos" pela despesa recorrente.' : `Simples Nacional — imposto calculado automaticamente a ${pct(impostoVendaPct())} sobre a receita.`}</p></div></div>`;
  ligar(el, {
    ano: s => ir(`#/dre?ano=${s.value}`), mes: s => ir(`#/dre?ano=${ano}&mes=${s.value}`),
    contador: () => gerarPacoteContador(mesSel, linhas.map(l => [l[0], l[2] === 'pct' ? r2(d[l[1]]) : r2(d[l[1]] * (l[3] || 1))])),
    imprimir: () => imprimir(`<div class="documento" style="max-width:none"><h3>${esc(App.cfg.loja.nome)} — DRE ${ano}</h3>${el.querySelector('#dre-tab .tabela-wrap').innerHTML}</div>`, 'size: A4 landscape; margin: 8mm;'),
    csv: () => baixarCSV('dre-' + ano, [['Linha', ...meses.map(mesNome), 'Total'], ...linhas.map(l => [l[0], ...dres.map(x => l[2] === 'pct' ? r2(x[l[1]]) : r2(x[l[1]] * (l[3] || 1))), l[2] === 'pct' ? r2(tot[l[1]]) : r2(tot[l[1]] * (l[3] || 1))])])
  });
};

/* ------------------------------------------------------------------ metas */
App.paginas.metas = async el => {
  const ano = +hojeISO().slice(0, 4);
  const meses = [...Array.from({ length: 12 }, (_, k) => `${ano}-${pad(k + 1)}`), `${ano + 1}-01`, `${ano + 1}-02`, `${ano + 1}-03`];
  const metas = App.cfg.metas || {};
  el.innerHTML = `<div class="caixa-aviso">Defina a meta de faturamento de cada mês. Uma boa referência: faturamento do mesmo mês do ano anterior + 10% a 20%, e nunca abaixo do ponto de equilíbrio.</div>
    <div class="card"><table class="tab"><thead><tr><th>Mês</th><th class="th-num">Meta</th><th class="th-num">Realizado</th><th class="th-num">%</th><th class="th-num">Ponto de equilíbrio</th><th class="th-num">Mesmo mês ano anterior</th></tr></thead><tbody>
    ${meses.map(m => { const real = soma(vendasPeriodo(m + '-01', ultimoDiaMes(m)), v => v.total); const ant = soma(vendasPeriodo(`${+m.slice(0, 4) - 1}${m.slice(4)}-01`, ultimoDiaMes(`${+m.slice(0, 4) - 1}${m.slice(4)}`)), v => v.total);
      const meta = n(metas[m]); const pe = dre(m).pontoEquilibrio;
      return `<tr><td>${mesLongo(m)}</td><td class="num"><input type="number" step="100" min="0" class="input-num" data-m="${m}" value="${meta || ''}"></td><td class="num">${moeda(real)}</td>
        <td class="num">${meta ? `<span class="${real >= meta ? 'positivo forte' : ''}">${pct(real / meta * 100, 0)}</span>` : '—'}</td><td class="num">${pe ? moeda(pe) : '—'}</td><td class="num">${ant ? moeda(ant) : '—'}</td></tr>`; }).join('')}
    </tbody></table><div class="linha-acoes" style="margin-top:12px"><span class="espaco"></span><button class="btn pri" data-click="salvar">Salvar metas</button></div></div>`;
  ligar(el, { salvar: async () => {
    const novas = { ...metas };
    el.querySelectorAll('[data-m]').forEach(i => { if (n(i.value) > 0) novas[i.dataset.m] = n(i.value); else delete novas[i.dataset.m]; });
    await api('config', { config: { metas: novas } }); await carregar([]); toast('Metas salvas.', 'ok'); recarregarPagina();
  } });
};

/* ------------------------------------------------------------ recorrentes */
App.paginas.recorrentes = async el => {
  const campos = [{ n: 'descricao', r: 'Descrição', w: 8, obr: 1 }, { n: 'valor', r: 'Valor mensal (R$)', t: 'money', w: 4, obr: 1 },
    { n: 'categoria_id', r: 'Categoria', t: 'select', w: 6, op: () => opcoesPlano(), obr: 1 }, { n: 'dia', r: 'Dia do vencimento', t: 'number', w: 3, min: 1, padrao: 5 },
    { n: 'tipo', r: 'Tipo', t: 'select', w: 3, vazio: false, op: [['pagar', 'A pagar'], ['receber', 'A receber']] },
    { n: 'fornecedor_id', r: 'Fornecedor (opcional)', t: 'select', w: 6, op: () => opcoes(App.d.fornecedores) }, { n: 'ativo', r: 'Ativa (gera lançamento todo mês)', t: 'check', w: 6, padrao: true }];
  el.innerHTML = `<div class="caixa-aviso">Despesas que se repetem todo mês. O sistema cria automaticamente as contas a pagar do mês atual e do próximo. Se o valor variar (ex.: energia), ajuste o lançamento em Contas a pagar.</div>
    <div class="linha-acoes"><button class="btn" data-click="gerar">Gerar lançamentos de um mês</button><span class="espaco"></span><button class="btn pri" data-click="nova">Nova despesa fixa</button></div>
    <div class="card" id="tab-rec"></div>`;
  const form = r => modal({ titulo: r ? r.descricao : 'Nova despesa fixa', largura: 'largo', corpo: formHTML(campos, r || {}), botoes: [
    ...(r ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { await api('excluir/recorrentes', { id: r.id }); recarregarPagina(); } }] : []),
    { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => { const o = lerForm(m, campos); const ob = { ...(r || {}), ...o }; delete ob.exemplo; await api('salvar/recorrentes', { obj: ob }); toast('Salvo. Os lançamentos serão gerados ao recarregar os dados.', 'ok'); recarregarPagina(); } }] });
  tabela(el.querySelector('#tab-rec'), { linhas: App.d.recorrentes, busca: false,
    colunas: [{ t: 'Descrição', v: r => r.descricao }, { t: 'Categoria', v: r => (App.idx.pc[r.categoria_id] || {}).nome || '' }, { t: 'Dia', v: r => +r.dia, cls: 'num' },
      { t: 'Valor', v: r => n(r.valor), h: r => moeda(r.valor), cls: 'num', total: l => moeda(soma(l.filter(r => r.ativo), r => n(r.valor))) },
      { t: 'Situação', v: r => r.ativo ? 'Ativa' : 'Inativa', h: r => r.ativo && n(r.valor) > 0 ? etiqueta('Ativa', 'ok') : etiqueta(n(r.valor) ? 'Inativa' : 'Preencher valor', n(r.valor) ? '' : 'alerta') }],
    aoClicar: r => form(r) });
  ligar(el, {
    nova: () => form(null),
    gerar: () => modal({ titulo: 'Gerar lançamentos', corpo: formHTML([{ n: 'mes', r: 'Mês', t: 'month', w: 6, padrao: somarMeses(mesAtual(), 1) }]),
      botoes: [{ texto: 'Cancelar' }, { texto: 'Gerar', classe: 'pri', acao: async m => { const r = await api('recorrentes/gerar', { mes: m.querySelector('[name=mes]').value }); toast(`${r.criados} lançamento(s) criado(s).`, 'ok'); } }] })
  });
};

/* ---------------------------------------------------------------- ativos */
App.paginas.ativos = async el => {
  const campos = [{ n: 'nome', r: 'Bem', w: 8, obr: 1, ph: 'ex.: araras, balcão, computador' }, { n: 'valor', r: 'Valor pago (R$)', t: 'money', w: 4, obr: 1 },
    { n: 'aquisicao', r: 'Data da compra', t: 'date', w: 4, padrao: hojeISO() }, { n: 'vida_util_meses', r: 'Vida útil (meses)', t: 'number', w: 4, padrao: 60, aj: 'Móveis 120 · equipamentos 60 · computador 36' },
    { n: 'ativo', r: 'Em uso', t: 'check', w: 4, padrao: true }];
  el.innerHTML = `<div class="caixa-aviso">Bens da loja (móveis, araras, manequins, computador, reforma). A depreciação mensal entra no DRE entre o EBITDA e o lucro operacional — mostra o desgaste do que você investiu.</div>
    <div class="linha-acoes"><span class="espaco"></span><button class="btn pri" data-click="novo">Novo bem</button></div><div class="card" id="tab-at"></div>`;
  const mes = mesAtual();
  const deprecAcum = a => { if (!a.aquisicao) return 0; const meses = Math.max(0, Math.min(n(a.vida_util_meses), (+mes.slice(0, 4) - +a.aquisicao.slice(0, 4)) * 12 + (+mes.slice(5) - +a.aquisicao.slice(5, 7)) + 1)); return n(a.valor) / Math.max(1, n(a.vida_util_meses)) * meses; };
  const form = a => modal({ titulo: a ? a.nome : 'Novo bem', corpo: formHTML(campos, a || {}) + (a ? '' : formHTML([{ n: 'lancar', r: 'Lançar também em contas a pagar (pago hoje)', t: 'check', w: 12 }])), botoes: [
    ...(a ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { await api('excluir/ativos', { id: a.id }); recarregarPagina(); } }] : []),
    { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => {
      const o = lerForm(m, campos);
      await api('salvar/ativos', { obj: { ...(a || {}), ...o } });
      const l = m.querySelector('[name=lancar]');
      if (l && l.checked) await api('financeiro/lancar', { tipo: 'pagar', descricao: 'Compra: ' + o.nome, valor: o.valor, categoria_id: 'pc_equipamentos', vencimento: o.aquisicao || hojeISO(), pago: true, forma: 'pix' });
      recarregarPagina();
    } }] });
  tabela(el.querySelector('#tab-at'), { linhas: App.d.ativos, busca: false,
    colunas: [{ t: 'Bem', v: a => a.nome }, { t: 'Compra', v: a => a.aquisicao, h: a => dataBR(a.aquisicao) }, { t: 'Valor', v: a => n(a.valor), h: a => moeda(a.valor), cls: 'num', total: true },
      { t: 'Vida útil', v: a => +a.vida_util_meses, h: a => `${a.vida_util_meses} meses`, cls: 'num' }, { t: 'Depreciação/mês', v: a => r2(n(a.valor) / Math.max(1, n(a.vida_util_meses))), h: a => moeda(n(a.valor) / Math.max(1, n(a.vida_util_meses))), cls: 'num', total: true },
      { t: 'Depreciado', v: a => r2(deprecAcum(a)), h: a => moeda(deprecAcum(a)), cls: 'num' }, { t: 'Valor contábil', v: a => r2(n(a.valor) - deprecAcum(a)), h: a => moeda(n(a.valor) - deprecAcum(a)), cls: 'num', total: true }],
    aoClicar: a => form(a) });
  ligar(el, { novo: () => form(null) });
};
