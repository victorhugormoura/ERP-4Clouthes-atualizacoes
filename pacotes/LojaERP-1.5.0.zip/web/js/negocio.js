/* Loja ERP — regras de negócio do lado da tela: preços, promoções, indicadores, DRE e documentos.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const FORMAS_PAG = { dinheiro: 'Dinheiro', pix: 'Pix', debito: 'Débito', credito: 'Crédito', crediario: 'Fiado (crediário)', vale: 'Vale (troca ou presente)', cashback: 'Cashback' };
const GRUPOS_DRE = {
  receita_vendas: 'Receita de vendas (automática)', outras_receitas: 'Outras receitas operacionais',
  receitas_financeiras: 'Receitas financeiras', estoque: 'Compra de estoque (não entra no DRE)',
  administrativas: 'Despesas administrativas', vendas: 'Despesas com vendas', pessoal: 'Despesas com pessoal',
  impostos: 'Impostos sobre vendas', financeiras: 'Despesas financeiras', investimento: 'Investimentos (não entra no DRE)',
  retirada: 'Retirada de lucro (não entra no DRE)', fora_dre: 'Fora do DRE (movimento de caixa)'
};
const TIPOS_MOV = {
  estoque_inicial: 'Estoque inicial', entrada: 'Entrada (compra)', venda: 'Venda', cancelamento: 'Cancelamento de venda',
  devolucao: 'Devolução/troca', condicional_saida: 'Saída condicional', condicional_retorno: 'Retorno condicional',
  ajuste_entrada: 'Ajuste (entrada)', ajuste_saida: 'Ajuste (saída)', perda: 'Perda', defeito: 'Defeito', furto: 'Furto',
  uso_interno: 'Uso interno', brinde: 'Brinde', devolucao_fornecedor: 'Devolução ao fornecedor', inventario: 'Inventário',
  estorno_entrada: 'Estorno de entrada'
};
const MOV_PERDAS = ['perda', 'defeito', 'furto', 'uso_interno', 'brinde', 'ajuste_saida', 'ajuste_entrada', 'inventario'];

/* ----------------------------------------------------------- precificação */
function impostoVendaPct() {
  const f = App.cfg.fiscal || {};
  return f.regime === 'simples' || f.regime === 'outro' ? n(f.aliquota_simples) : 0;
}
function arredondarPreco(v) {
  const modo = (App.cfg.precificacao || {}).arredondamento || '90';
  if (!(v > 0)) return 0;
  if (modo === 'nenhum') return r2(v);
  if (modo === '00') return Math.ceil(v);
  const fr = modo === '99' ? 0.99 : 0.90;
  let c = Math.floor(v) + fr;
  if (c < v - 1e-9) c += 1;
  return r2(c);
}
function sugestaoPreco(custo, categoriaId) {
  const p = App.cfg.precificacao || {};
  const cat = App.idx.cat[categoriaId] || {};
  const margem = cat.margem !== undefined && cat.margem !== '' ? n(cat.margem) : n(p.margem_padrao);
  const markup = n(cat.markup) || n(p.markup_padrao) || 2;
  const custosPct = impostoVendaPct() + n(p.taxa_cartao_media) + n(p.comissao) + n(p.despesas_fixas_pct);
  const divisor = 1 - (custosPct + margem) / 100;
  const porMargem = custo > 0 && divisor > 0.05 ? arredondarPreco(custo / divisor) : 0;
  const porMarkup = custo > 0 ? arredondarPreco(custo * markup) : 0;
  return { margem, markup, custosPct, porMargem, porMarkup, sugerido: p.metodo === 'markup' ? porMarkup : porMargem };
}
function analisePreco(custo, preco) {
  const p = App.cfg.precificacao || {};
  const variaveis = preco * (impostoVendaPct() + n(p.taxa_cartao_media) + n(p.comissao)) / 100;
  const contribuicao = preco - custo - variaveis;
  const liquido = contribuicao - preco * n(p.despesas_fixas_pct) / 100;
  return {
    markup: custo > 0 ? preco / custo : 0, margemBruta: preco > 0 ? (preco - custo) / preco * 100 : 0,
    contribuicao, margemContribuicao: preco > 0 ? contribuicao / preco * 100 : 0,
    lucroLiquido: liquido, margemLiquida: preco > 0 ? liquido / preco * 100 : 0
  };
}

/* ----------------------------------------------------------- promoções */
const TIPOS_PROMO = {
  percentual: 'Desconto % em produtos', leve_pague: 'Leve X, pague Y', progressivo: 'Progressivo por quantidade',
  valor_minimo: 'Desconto acima de um valor', aniversariante: 'Aniversariante do mês', primeira_compra: 'Primeira compra',
  pagamento: 'Desconto à vista (Pix/dinheiro)', cupom: 'Cupom de desconto'
};
const PROMO_ITEM = ['percentual', 'leve_pague', 'progressivo'];

function statusPromo(p, dia = hojeISO()) {
  if (!p.ativo) return ['Desativada', ''];
  if (p.inicio && dia < p.inicio) return ['Agendada', 'info'];
  if (p.fim && dia > p.fim) return ['Encerrada', 'erro'];
  if (p.dias_semana && p.dias_semana.length && !p.dias_semana.includes(new Date(dia + 'T12:00:00').getDay())) return ['Ativa (outro dia da semana)', 'alerta'];
  if (p.tipo === 'cupom' && n(p.max_usos) > 0 && n(p.usos) >= n(p.max_usos)) return ['Esgotado', 'erro'];
  return ['Valendo hoje', 'ok'];
}
function promoValida(p, dia) { return statusPromo(p, dia)[0] === 'Valendo hoje'; }
function noEscopo(p, linha) {
  const e = p.escopo || { tipo: 'todos', ids: [] };
  if (linha.servico_id) return false;
  if (e.tipo === 'todos') return true;
  const prod = App.idx.prod[linha.produto_id] || {};
  const campo = { categoria: 'categoria_id', colecao: 'colecao_id', marca: 'marca_id', produto: 'id' }[e.tipo];
  return (e.ids || []).includes(prod[campo]);
}
function aniversarianteMes(cliente, dia = hojeISO()) {
  return !!(cliente && cliente.nascimento && cliente.nascimento.slice(5, 7) === dia.slice(5, 7));
}

/* Calcula o carrinho aplicando as promoções vigentes.
   Por item: vale o maior desconto não cumulativo + os cumulativos. No total: idem. */
function calcularCarrinho(car) {
  const dia = hojeISO();
  const promos = (App.d.promocoes || []).filter(p => promoValida(p, dia));
  const linhas = car.itens.map(it => ({ ...it, bruto: r2(it.preco_unit * it.qtd), cands: [] }));
  for (const p of promos.filter(p => PROMO_ITEM.includes(p.tipo))) {
    const eleg = linhas.filter(l => noEscopo(p, l));
    if (!eleg.length) continue;
    if (p.tipo === 'percentual') {
      eleg.forEach(l => l.cands.push({ p, d: l.bruto * n(p.percentual) / 100 }));
    } else if (p.tipo === 'progressivo') {
      const qtd = soma(eleg, l => l.qtd);
      const faixa = (p.faixas || []).filter(f => qtd >= n(f.qtd)).sort((a, b) => n(b.qtd) - n(a.qtd))[0];
      if (faixa) eleg.forEach(l => l.cands.push({ p, d: l.bruto * n(faixa.percentual) / 100 }));
    } else if (p.tipo === 'leve_pague') {
      const leve = Math.max(2, n(p.leve)), pague = Math.max(0, Math.min(leve - 1, n(p.pague)));
      const unidades = [];
      eleg.forEach(l => { for (let k = 0; k < l.qtd; k++) unidades.push({ l, preco: l.preco_unit }); });
      unidades.sort((a, b) => a.preco - b.preco);
      const gratis = Math.floor(unidades.length / leve) * (leve - pague);
      const desc = new Map();
      unidades.slice(0, gratis).forEach(u => desc.set(u.l, (desc.get(u.l) || 0) + u.preco));
      desc.forEach((d, l) => l.cands.push({ p, d }));
    }
  }
  const aplicadas = new Set();
  for (const l of linhas) {
    const naoCum = l.cands.filter(c => !c.p.cumulativa).sort((a, b) => b.d - a.d)[0];
    const cum = l.cands.filter(c => c.p.cumulativa);
    let d = (naoCum ? naoCum.d : 0) + soma(cum, c => c.d) + n(l.desc_manual);
    l.desconto = r2(Math.min(l.bruto, d));
    l.promocoes = [naoCum, ...cum].filter(Boolean).map(c => c.p.nome);
    l.promocoes.forEach(x => aplicadas.add(x));
    l.total = r2(l.bruto - l.desconto);
  }
  const subtotal = r2(soma(linhas, l => l.bruto));
  const descItens = r2(soma(linhas, l => l.desconto));
  const base = r2(subtotal - descItens);
  const cliente = App.idx.cli[car.cliente_id];
  const stats = cliente ? App.idx.cliStats[cliente.id] : null;
  const cands = [];
  let cupom = null, erroCupom = '';
  for (const p of promos) {
    let d = 0;
    if (p.tipo === 'valor_minimo' && base >= n(p.minimo)) d = base * n(p.percentual) / 100;
    if (p.tipo === 'aniversariante' && aniversarianteMes(cliente, dia)) d = base * n(p.percentual) / 100;
    if (p.tipo === 'primeira_compra' && cliente && !(stats && stats.compras)) d = base * n(p.percentual) / 100;
    if (p.tipo === 'pagamento' && car.avista) d = base * n(p.percentual) / 100;
    if (d > 0) cands.push({ p, d });
  }
  if (car.cupom) {
    const codigo = car.cupom.trim().toUpperCase();
    const p = (App.d.promocoes || []).find(x => x.tipo === 'cupom' && x.codigo === codigo);
    if (!p) erroCupom = 'Cupom não encontrado.';
    else if (!promoValida(p, dia)) erroCupom = `Cupom ${statusPromo(p, dia)[0].toLowerCase()}.`;
    else if (base < n(p.minimo)) erroCupom = `Cupom válido para compras a partir de ${moeda(p.minimo)}.`;
    else { cupom = p; cands.push({ p, d: n(p.valor_fixo) > 0 ? n(p.valor_fixo) : base * n(p.percentual) / 100 }); }
  }
  const naoCum = cands.filter(c => !c.p.cumulativa).sort((a, b) => b.d - a.d)[0];
  const usadas = [naoCum, ...cands.filter(c => c.p.cumulativa)].filter(Boolean);
  let descCarrinho = Math.min(base, soma(usadas, c => c.d));
  usadas.forEach(c => aplicadas.add(c.p.nome));
  let descManual = car.desc_manual_tipo === 'pct' ? (base - descCarrinho) * n(car.desc_manual) / 100 : n(car.desc_manual);
  descManual = Math.max(0, Math.min(base - descCarrinho, descManual));
  descCarrinho = r2(descCarrinho + descManual);
  const pagamentoPromo = promos.find(p => p.tipo === 'pagamento');
  return {
    linhas, subtotal, descItens, descPromoCarrinho: r2(descCarrinho - descManual), descManual: r2(descManual),
    descCarrinho, total: r2(base - descCarrinho), aplicadas: [...aplicadas], cupom, erroCupom,
    avistaFormas: car.avista && pagamentoPromo ? (pagamentoPromo.formas || ['pix', 'dinheiro']) : null,
    temPromoPagamento: !!pagamentoPromo, pagamentoPromo
  };
}

/* ----------------------------------------------------------- clientes */
function cashbackDisponivel(c) {
  if (!c) return 0;
  if (c.cashback_validade && c.cashback_validade < hojeISO()) return 0;
  return n(c.cashback_saldo);
}
function segmentoCliente(c) {
  const s = App.idx.cliStats[c.id];
  if (!s) return ['Sem compras', ''];
  const dias = diasEntre(s.ultima, hojeISO());
  if (dias > 120) return ['Inativa', 'erro'];
  if (dias > 60) return ['Em risco', 'alerta'];
  if (s.total >= App.idx.corteVip && s.compras >= 2) return ['VIP', 'pri'];
  if (s.compras === 1 && dias <= 30) return ['Nova', 'info'];
  return ['Ativa', 'ok'];
}
function crediarioAberto(clienteId) {
  return (App.d.financeiro || []).filter(f => f.cliente_id === clienteId && f.tipo === 'receber' && f.status === 'pendente' && f.forma === 'crediario');
}
function linkWhatsApp(telefone, texto) {
  let d = String(telefone || '').replace(/\D/g, '');
  if (!d) return '';
  if (d.length <= 11) d = '55' + d;
  return `https://wa.me/${d}?text=${encodeURIComponent(texto)}`;
}
function textoModelo(chave, vars) {
  const modelo = (App.cfg.whatsapp || {})[chave] || '';
  return modelo.replace(/\{(\w+)\}/g, (m, k) => vars[k] ?? (k === 'loja' ? App.cfg.loja.nome : m));
}
function abrirWhatsApp(telefone, texto) {
  const url = linkWhatsApp(telefone, texto);
  if (!url) { toast('Cliente sem telefone cadastrado.', 'erro'); return; }
  window.open(url, '_blank', 'noopener');
}

/* ----------------------------------------------------------- estoque */
function estoqueProduto(p) { return soma(p.variacoes || [], v => v.estoque); }
function valorEstoque() {
  let pecas = 0, custo = 0, venda = 0;
  for (const p of App.d.produtos) {
    if (p.ativo === false) continue;
    const q = soma(p.variacoes, v => Math.max(0, v.estoque));
    pecas += q; custo += q * n(p.custo); venda += q * n(p.preco);
  }
  return { pecas, custo, venda };
}
function ultimaVendaPorProduto() {
  const m = {};
  for (const v of App.d.vendas) if (v.status === 'concluida') for (const i of v.itens) if (i.produto_id && (!m[i.produto_id] || v.data > m[i.produto_id])) m[i.produto_id] = v.data;
  return m;
}

/* ----------------------------------------------------------- vendas */
function vendasPeriodo(de, ate) {
  return App.d.vendas.filter(v => v.status === 'concluida' && v.data.slice(0, 10) >= de && v.data.slice(0, 10) <= ate);
}
function faturamentoDia(dia) { return App.idx.fatDia[dia] || 0; }
function resumoVendas(vendas) {
  const fat = soma(vendas, v => v.total);
  const pecas = soma(vendas, v => soma(v.itens.filter(i => i.produto_id), i => i.qtd));
  const cmv = soma(vendas, v => soma(v.itens, i => i.custo_unit * i.qtd));
  const desc = soma(vendas, v => v.desconto_itens + v.desconto_carrinho);
  return { fat, n: vendas.length, pecas, cmv, desc, ticket: vendas.length ? fat / vendas.length : 0,
    pa: vendas.length ? pecas / vendas.length : 0, lucroBruto: fat - cmv, margem: fat ? (fat - cmv) / fat * 100 : 0 };
}

/* ----------------------------------------------------------- DRE */
function depreciacaoMes(mes) {
  let t = 0;
  for (const a of App.d.ativos || []) {
    if (a.ativo === false || !a.aquisicao || !(n(a.vida_util_meses) > 0)) continue;
    const ini = a.aquisicao.slice(0, 7);
    const fim = somarMeses(ini, n(a.vida_util_meses) - 1);
    if (mes >= ini && mes <= fim) t += n(a.valor) / n(a.vida_util_meses);
  }
  return t;
}
function dre(mes) {
  const pc = App.idx.pc;
  const grupo = f => (pc[f.categoria_id] || {}).grupo || (f.tipo === 'pagar' ? 'administrativas' : 'outras_receitas');
  const vendas = App.d.vendas.filter(v => v.status === 'concluida' && v.data.slice(0, 7) === mes);
  const trocas = App.d.trocas.filter(t => t.data.slice(0, 7) === mes);
  let bruta = 0, desc = 0, cmv = 0, taxas = 0, cashback = 0, pecas = 0, servicos = 0;
  for (const v of vendas) {
    bruta += v.subtotal; desc += v.desconto_itens + v.desconto_carrinho;
    for (const i of v.itens) { cmv += i.custo_unit * i.qtd; if (i.produto_id) pecas += i.qtd; else servicos += i.total; }
    for (const p of v.pagamentos) { taxas += n(p.taxa); if (p.forma === 'cashback') cashback += p.valor; }
  }
  desc += cashback;
  // Taxa da maquininha na venda de vale-presente: é despesa do mês em que o vale foi vendido.
  taxas += soma(App.d.financeiro.filter(f => f.origem === 'vale_presente' && f.status !== 'cancelado' && f.competencia === mes), f => n(f.taxa));
  const devolucoes = soma(trocas, t => t.total), cmvDevol = soma(trocas, t => t.custo_total);
  const receitaAposDeducoes = bruta - desc - devolucoes;
  const fin = App.d.financeiro.filter(f => f.status !== 'cancelado' && f.competencia === mes);
  const porGrupo = g => soma(fin.filter(f => grupo(f) === g && f.tipo === 'pagar'), f => f.valor) - soma(fin.filter(f => grupo(f) === g && f.tipo === 'receber'), f => f.valor);
  const impostoAuto = Math.max(0, receitaAposDeducoes) * impostoVendaPct() / 100;
  const impostos = impostoAuto + porGrupo('impostos');
  const liquida = receitaAposDeducoes - impostos;
  const perdas = -soma(App.d.movimentos.filter(m => MOV_PERDAS.includes(m.tipo) && m.data.slice(0, 7) === mes), m => m.qtd * m.custo_unit);
  const cmvLiq = cmv - cmvDevol;
  const lucroBruto = liquida - cmvLiq - perdas;
  const despVendasManual = porGrupo('vendas');
  const despVendas = taxas + despVendasManual;
  const despAdm = porGrupo('administrativas'), despPessoal = porGrupo('pessoal');
  const outras = soma(fin.filter(f => f.tipo === 'receber' && grupo(f) === 'outras_receitas'), f => f.valor);
  const ebitda = lucroBruto - despVendas - despAdm - despPessoal + outras;
  const deprec = depreciacaoMes(mes);
  const ebit = ebitda - deprec;
  let jurosPagos = 0, jurosRecebidos = 0;
  for (const f of App.d.financeiro) {
    if (f.status !== 'pago' || !f.pago_em || f.pago_em.slice(0, 7) !== mes || f.valor_pago === null) continue;
    const dif = f.tipo === 'pagar' ? f.valor_pago - f.valor : f.valor_pago - f.liquido;
    if (Math.abs(dif) < 0.01 || f.origem === 'venda') continue;
    if (f.tipo === 'pagar') { if (dif > 0) jurosPagos += dif; else jurosRecebidos += -dif; }
    else { if (dif > 0) jurosRecebidos += dif; else jurosPagos += -dif; }
  }
  const recFin = soma(fin.filter(f => f.tipo === 'receber' && grupo(f) === 'receitas_financeiras'), f => f.valor) + jurosRecebidos;
  const despFin = porGrupo('financeiras') + jurosPagos;
  const lair = ebit + recFin - despFin;
  const regime = (App.cfg.fiscal || {}).regime;
  // No MEI e no Simples Nacional, IRPJ e CSLL já estão dentro do DAS/alíquota.
  const ir = 0;
  const liquido = lair - ir;
  const fixos = despAdm + despPessoal + despVendasManual + deprec;
  const variaveisPct = receitaAposDeducoes > 0 ? (impostos + cmvLiq + perdas + taxas) / receitaAposDeducoes : 0;
  const mc = 1 - variaveisPct;
  return {
    mes, bruta, desc, devolucoes, impostos, impostoAuto, liquida, cmv: cmvLiq, perdas, lucroBruto, taxas, despVendasManual,
    despVendas, despAdm, despPessoal, outras, ebitda, deprec, ebit, recFin, despFin, lair, ir, liquido, regime,
    nVendas: vendas.length, pecas, servicos,
    ticket: vendas.length ? soma(vendas, v => v.total) / vendas.length : 0, pa: vendas.length ? pecas / vendas.length : 0,
    margemBruta: liquida ? lucroBruto / liquida * 100 : 0, margemEbitda: liquida ? ebitda / liquida * 100 : 0,
    margemLiquida: liquida ? liquido / liquida * 100 : 0, mc: mc * 100, pontoEquilibrio: mc > 0 ? fixos / mc : 0, fixos,
    retiradas: porGrupo('retirada'), compras: porGrupo('estoque'), investimentos: porGrupo('investimento'),
    faturamento: soma(vendas, v => v.total)
  };
}
function indicadoresEstoque() {
  const est = valorEstoque();
  const dia = hojeISO(), ini90 = somarDias(dia, -90), ini365 = somarDias(dia, -365);
  const cmv90 = soma(vendasPeriodo(ini90, dia), v => soma(v.itens, i => i.custo_unit * i.qtd));
  const cmv365 = soma(vendasPeriodo(ini365, dia), v => soma(v.itens, i => i.custo_unit * i.qtd));
  const cmvDia = cmv90 / 90;
  return { ...est, cobertura: cmvDia > 0 ? est.custo / cmvDia : 0, giro: est.custo > 0 ? (cmv365 || cmv90 * 365 / 90) / est.custo : 0 };
}

/* ----------------------------------------------------------- financeiro */
function saldoAtual() {
  const f = App.cfg.financeiro || {};
  const ini = f.data_saldo_inicial || '0000-00-00';
  let s = n(f.saldo_inicial);
  for (const x of App.d.financeiro) {
    if (x.status !== 'pago' || !x.pago_em || x.pago_em < ini) continue;
    s += x.tipo === 'receber' ? n(x.valor_pago) : -n(x.valor_pago);
  }
  return s;
}
function statusFin(f) {
  if (f.status === 'pago') return [f.tipo === 'receber' ? 'Recebido' : 'Pago', 'ok'];
  if (f.status === 'cancelado') return ['Cancelado', ''];
  if (f.vencimento < hojeISO()) return ['Vencido', 'erro'];
  if (f.vencimento === hojeISO()) return ['Vence hoje', 'alerta'];
  return ['Pendente', 'info'];
}

/* ----------------------------------------------------------- tarefas */
function tarefaDoDia(t, dia) {
  if (t.ativo === false) return false;
  const d = new Date(dia + 'T12:00:00');
  switch (t.recorrencia) {
    case 'diaria': return true;
    case 'semanal': return d.getDay() === +t.dia_semana;
    case 'mensal': { const ult = +ultimoDiaMes(dia.slice(0, 7)).slice(8); return d.getDate() === Math.min(+t.dia_mes || 1, ult); }
    case 'anual': return dia.slice(5) === t.data;
    case 'unica': return dia === t.data;
  }
  return false;
}
function tarefasPendentes(dia = hojeISO()) {
  const hoje = [], atrasadas = [];
  for (const t of App.d.tarefas || []) {
    if (tarefaDoDia(t, dia) && !(t.feitas || {})[dia]) hoje.push({ t, dia });
    if (t.recorrencia !== 'diaria') for (let k = 1; k <= 7; k++) {
      const d = somarDias(dia, -k);
      if (tarefaDoDia(t, d) && !(t.feitas || {})[d]) atrasadas.push({ t, dia: d });
    }
  }
  return { hoje, atrasadas };
}

/* ----------------------------------------------------------- alertas */
function alertas() {
  const lista = [], dia = hojeISO();
  const fin = App.d.financeiro.filter(f => f.status === 'pendente');
  const vencidasPagar = fin.filter(f => f.tipo === 'pagar' && f.vencimento < dia);
  if (vencidasPagar.length) lista.push(['erro', `${vencidasPagar.length} conta(s) a pagar vencida(s): ${moeda(soma(vencidasPagar, f => f.valor))}`, '#/contas?aba=pagar']);
  const prox = fin.filter(f => f.tipo === 'pagar' && f.vencimento >= dia && f.vencimento <= somarDias(dia, 7));
  if (prox.length) lista.push(['alerta', `${prox.length} conta(s) a pagar nos próximos 7 dias: ${moeda(soma(prox, f => f.valor))}`, '#/contas?aba=pagar']);
  const cred = fin.filter(f => f.forma === 'crediario' && f.vencimento < dia);
  if (cred.length) lista.push(['erro', `${cred.length} parcela(s) de crediário atrasada(s): ${moeda(soma(cred, f => f.valor))}`, '#/contas?aba=receber']);
  const conds = App.d.condicionais.filter(c => c.status === 'aberto' && c.prazo < dia);
  if (conds.length) lista.push(['alerta', `${conds.length} condicional(is) com prazo vencido`, '#/condicional']);
  let baixo = 0, zerado = 0;
  for (const p of App.d.produtos) if (p.ativo !== false) for (const v of p.variacoes) { if (v.estoque <= 0) zerado++; else if (v.estoque <= n(v.estoque_min)) baixo++; }
  if (baixo) lista.push(['alerta', `${baixo} variação(ões) com estoque baixo`, '#/estoque?filtro=baixo']);
  if (zerado) lista.push(['info', `${zerado} variação(ões) com estoque zerado`, '#/estoque?filtro=zerado']);
  const ult = ultimaVendaPorProduto(), limite = somarDias(dia, -n((App.cfg.estoque || {}).dias_parado || 90));
  const parados = App.d.produtos.filter(p => p.ativo !== false && estoqueProduto(p) > 0 && (ult[p.id] || p.criado_em || '') < limite);
  if (parados.length) lista.push(['info', `${parados.length} produto(s) parado(s) há mais de ${App.cfg.estoque.dias_parado} dias — considere uma promoção`, '#/relatorios?sec=parados']);
  const aniv = App.d.clientes.filter(c => c.ativo !== false && c.nascimento && c.nascimento.slice(5) === dia.slice(5));
  if (aniv.length) lista.push(['ok', `Aniversariante(s) hoje: ${aniv.map(c => c.nome).join(', ')}`, '#/clientes?filtro=aniversario']);
  if (!App.d.caixa.some(c => c.status === 'aberto')) lista.push(['info', 'O caixa de hoje ainda não foi aberto.', '#/caixa']);
  const caixaAntigo = App.d.caixa.find(c => c.status === 'aberto' && c.aberto_em.slice(0, 10) < dia);
  if (caixaAntigo) lista.push(['alerta', `Há um caixa aberto desde ${dataBR(caixaAntigo.aberto_em)}. Feche-o e abra o de hoje.`, '#/caixa']);
  if (!App.d.recorrentes.some(r => r.ativo && n(r.valor) > 0)) lista.push(['info', 'Cadastre suas despesas fixas (aluguel, luz, pró-labore...) para o DRE ficar completo.', '#/recorrentes']);
  const meta = n((App.cfg.metas || {})[dia.slice(0, 7)]);
  if (!meta) lista.push(['info', 'Defina a meta de faturamento deste mês.', '#/metas']);
  if (ehMei()) {
    const s = situacaoMei();
    if (s.nivel !== 'ok') lista.push([s.nivel, `MEI: ${s.texto}`, '#/mei']);
    const notas = App.d.vendas.filter(v => v.status === 'concluida' && v.nota && v.nota.pedida && !v.nota.numero).length;
    if (notas) lista.push(['alerta', `${notas} nota(s) fiscal(is) pedida(s) aguardando registro`, '#/mei']);
  }
  if (App.papel === 'dona' || App.papel === 'gerente') {
    const rev = (App.cfg.conformidade || {}).revisado_em;
    if (!rev || rev < somarDias(dia, -180)) lista.push(['info', rev ? 'Faz mais de 6 meses que a lista de conformidade (Procon e LGPD) foi revisada.' : 'Revise a lista de conformidade da loja (Procon e LGPD).', '#/config?aba=consumidor']);
  }
  const vales = App.d.vales.filter(v => v.status === 'ativo' && v.validade && v.validade >= dia && v.validade <= somarDias(dia, 7));
  if (vales.length) lista.push(['info', `${vales.length} vale(s) vencem nesta semana`, '#/trocas?aba=vales']);
  return lista;
}

/* ----------------------------------------------------------- documentos */
function cabecalhoLoja() {
  const l = App.cfg.loja;
  return `<h2>${esc(l.nome)}</h2>${l.razao_social ? `<div class="c">${esc(l.razao_social)}</div>` : ''}
    ${l.cnpj ? `<div class="c">CNPJ ${esc(l.cnpj)}</div>` : ''}${l.endereco ? `<div class="c">${esc(l.endereco)}${l.cidade ? ' — ' + esc(l.cidade) : ''}</div>` : ''}
    ${l.whatsapp || l.telefone ? `<div class="c">${esc(fone(l.whatsapp || l.telefone))}</div>` : ''}${l.instagram ? `<div class="c">${esc(l.instagram)}</div>` : ''}`;
}
function reciboHTML(v) {
  const cli = App.idx.cli[v.cliente_id];
  return `<div class="recibo">${cabecalhoLoja()}<hr>
    <div class="c"><b>COMPROVANTE DE VENDA Nº ${v.numero}</b></div><div class="c">${dataHoraBR(v.data)}</div>
    ${v.cliente_nome ? `<div>Cliente: ${esc(v.cliente_nome)}</div>` : ''}<hr>
    <table>${v.itens.map(i => `<tr><td colspan="2">${esc(i.nome)}${i.tamanho ? ` ${esc(i.tamanho)}/${esc(i.cor)}` : ''}</td></tr>
      <tr><td>${i.qtd} x ${moeda(i.preco_unit)}${i.desconto ? ` (-${moeda(i.desconto)})` : ''}</td><td class="r">${moeda(i.total)}</td></tr>`).join('')}</table><hr>
    <table><tr><td>Subtotal</td><td class="r">${moeda(v.subtotal)}</td></tr>
    ${v.desconto_itens + v.desconto_carrinho > 0 ? `<tr><td>Descontos</td><td class="r">-${moeda(v.desconto_itens + v.desconto_carrinho)}</td></tr>` : ''}
    <tr><td><b>TOTAL</b></td><td class="r"><b>${moeda(v.total)}</b></td></tr>
    ${v.pagamentos.map(p => `<tr><td>${p.forma === 'vale' ? nomeVale(App.d.vales.find(x => x.codigo === p.codigo) || {}) : FORMAS_PAG[p.forma]}${p.parcelas > 1 ? ` ${p.parcelas}x` : ''}${p.codigo ? ' ' + esc(p.codigo) : ''}</td><td class="r">${moeda(p.valor)}</td></tr>`).join('')}
    ${v.troco > 0 ? `<tr><td>Troco</td><td class="r">${moeda(v.troco)}</td></tr>` : ''}</table>
    ${(v.promocoes || []).length ? `<hr><div>Promoções: ${esc(v.promocoes.join(', '))}</div>` : ''}
    ${v.cashback_gerado > 0 ? `<hr><div>Cashback ganho: ${moeda(v.cashback_gerado)}${cli && cli.cashback_validade ? ` (válido até ${dataBR(cli.cashback_validade)})` : ''}</div><div>Saldo de cashback: ${moeda(cli ? cli.cashback_saldo : 0)}</div>` : ''}
    ${parcelasCrediarioHTML(v)}
    ${avisosConsumidorHTML(v)}
    <hr><div class="c">${esc(App.cfg.loja.mensagem_recibo || '')}</div>${notaFiscalReciboHTML(v)}</div>`;
}
/* Informações ao consumidor no comprovante (CDC): política de troca, garantia legal e compra fora da loja. */
function avisosConsumidorHTML(v) {
  const c = App.cfg.consumidor || {};
  const partes = [];
  if (v.distancia) partes.push(`<b>Compra fora da loja</b> (internet, WhatsApp, telefone ou entrega): você pode desistir em até 7 dias do recebimento e receber de volta tudo o que pagou (CDC, art. 49).`);
  if (c.imprimir_politica !== false && c.politica_troca) partes.push(`<b>Política de troca:</b> ${esc(c.politica_troca)}`);
  if (c.imprimir_garantia !== false) partes.push('<b>Garantia legal:</b> defeitos podem ser reclamados em até 90 dias (CDC, art. 26).');
  return partes.length ? `<hr><div style="font-size:11px">${partes.map(p => `<div style="margin-bottom:4px">${p}</div>`).join('')}</div>` : '';
}
function notaFiscalReciboHTML(v) {
  const nf = v.nfe || {};
  if (nf.status === 'autorizado') return `<div class="c" style="margin-top:6px">NFC-e nº ${esc(String(nf.numero || ''))} série ${esc(String(nf.serie || ''))}${nf.ambiente === 'homologacao' ? ' — HOMOLOGAÇÃO, SEM VALOR FISCAL' : ''}<br><small>Chave ${esc(nf.chave || '')}</small><br><small>Este comprovante não substitui o DANFE da NFC-e.</small></div>`;
  return '<div class="c" style="margin-top:6px">Documento sem valor fiscal</div>';
}
function parcelasCrediarioHTML(v) {
  const parc = App.d.financeiro.filter(f => f.ref === v.id && f.forma === 'crediario');
  if (!parc.length) return '';
  const cr = App.cfg.crediario || {};
  const total = soma(parc, f => f.valor), multa = n(cr.multa_atraso_pct), juros = n(cr.juros_mes_pct);
  // CDC, art. 52: preço à vista, número e valor das parcelas, juros e total a prazo informados por escrito.
  return `<hr><div><b>Parcelas do crediário</b></div><table>${parc.map(f => `<tr><td>${esc(f.parcela)} — ${dataBR(f.vencimento)}</td><td class="r">${moeda(f.valor)}</td></tr>`).join('')}</table>
    <div style="font-size:11px;margin-top:6px">Preço à vista ${moeda(total)} · ${parc.length} parcela(s) sem juros · total a prazo ${moeda(total)}.
      ${multa || juros ? `Em caso de atraso: ${multa ? `multa de ${pct(multa)}` : ''}${multa && juros ? ' e ' : ''}${juros ? `juros de ${pct(juros)} ao mês` : ''}.` : 'Sem multa nem juros por atraso.'}
      Pode pagar antes do vencimento a qualquer momento.</div>
    <div style="margin-top:14px">Assinatura: ______________________</div>`;
}
function termoCondicionalHTML(c) {
  const cli = App.idx.cli[c.cliente_id] || {};
  const total = soma(c.itens, i => i.qtd * i.preco_unit);
  return `<div class="documento">${cabecalhoLoja().replace(/<h2>/, '<h2 style="margin:0">')}<hr>
    <h3>Termo de condicional nº ${c.numero}</h3>
    <p>Cliente: <b>${esc(cli.nome || c.cliente_nome)}</b>${cli.cpf ? ` — CPF ${esc(cpfFmt(cli.cpf))}` : ''}${cli.telefone ? ` — ${esc(fone(cli.telefone))}` : ''}<br>
    Retirada: ${dataHoraBR(c.data)} — <b>Devolução até: ${dataBR(c.prazo)}</b></p>
    <table><thead><tr><th>Peça</th><th>Tam./Cor</th><th>Qtd</th><th>Valor</th></tr></thead><tbody>
    ${c.itens.map(i => `<tr><td>${esc(i.nome)}</td><td>${esc(i.tamanho)} / ${esc(i.cor)}</td><td>${i.qtd}</td><td>${moeda(i.preco_unit * i.qtd)}</td></tr>`).join('')}
    <tr><td colspan="3"><b>Total</b></td><td><b>${moeda(total)}</b></td></tr></tbody></table>
    <p>Declaro ter recebido as peças acima para prova, comprometendo-me a devolvê-las em perfeito estado, com etiquetas,
    até a data indicada, ou a pagar pelas peças que ficarem comigo.</p>
    <p style="margin-top:40px">______________________________________<br>${esc(cli.nome || c.cliente_nome)}</p></div>`;
}
const MODELOS_PROMOCIONAIS = ['aniversario', 'novidades', 'reativacao', 'cashback'];
/* Cobrança sem constranger (CDC, arts. 42 e 71): fora do horário comercial pede confirmação. */
async function confirmarCobranca() {
  const agora = new Date(), h = agora.getHours(), domingo = agora.getDay() === 0;
  if (!domingo && h >= 8 && h < 20) return true;
  return confirmar('Agora está fora do horário comercial. Cobrança à noite, de madrugada ou no domingo pode ser vista como constrangimento (Código de Defesa do Consumidor, arts. 42 e 71). Prefira enviar entre 8h e 20h, de segunda a sábado. Enviar mesmo assim?', 'Enviar mesmo assim');
}

const NOME_VALE = { troca: 'Vale-troca', presente: 'Vale-presente' };
function nomeVale(v) { return NOME_VALE[v.tipo] || 'Vale-troca'; }
function situacaoVale(v) {
  if (v.status === 'cancelado') return ['Cancelado', ''];
  if (v.status === 'usado') return ['Usado', ''];
  if (v.validade && v.validade < hojeISO()) return ['Vencido', 'erro'];
  return ['Ativo', 'ok'];
}
function valeHTML(vale, troca) {
  const presente = vale.tipo === 'presente';
  const parcial = vale.status === 'ativo' && vale.saldo < vale.valor - 0.009;
  return `<div class="recibo">${cabecalhoLoja()}<hr><div class="c"><b>${presente ? 'VALE-PRESENTE' : 'VALE-TROCA'}</b></div>
    ${presente && vale.para ? `<div class="c" style="margin-top:6px">Para: <b>${esc(vale.para)}</b></div>` : ''}
    ${presente && vale.mensagem ? `<div class="c" style="margin:6px 0;font-style:italic">${esc(vale.mensagem)}</div>` : ''}
    <div class="c" style="font-size:20px;margin:8px 0"><b>${esc(vale.codigo)}</b></div>
    <div class="c">${code128SVG(vale.codigo)}</div>
    <table><tr><td>Valor</td><td class="r"><b>${moeda(vale.valor)}</b></td></tr>
    ${parcial ? `<tr><td>Saldo</td><td class="r"><b>${moeda(vale.saldo)}</b></td></tr>` : ''}
    <tr><td>Válido até</td><td class="r"><b>${vale.validade ? dataBR(vale.validade) : 'sem prazo'}</b></td></tr>
    <tr><td>Emitido em</td><td class="r">${dataBR(vale.criado_em)}</td></tr>
    ${troca ? `<tr><td>Troca nº</td><td class="r">${troca.numero}</td></tr>` : ''}</table>
    <hr><div class="c">Apresente este código no caixa.${presente ? ' Pode ser usado em mais de uma compra até acabar o saldo.' : ''}</div></div>`;
}
function imprimirVale(vale, troca) { imprimir(valeHTML(vale, troca), 'size: 80mm auto; margin: 3mm;'); }

/* Campo "Válido até" dos vales: data com atalhos ou sem prazo de validade. */
function campoValidadeHTML(diasPadrao, atual) {
  const dias = n(diasPadrao);
  const data = atual !== undefined ? (atual || '') : (dias > 0 ? somarDias(hojeISO(), dias) : '');
  return `<div class="grade-form campo-validade">
    <label class="campo w4"><span>Válido até</span><input type="date" name="validade" min="${hojeISO()}" value="${data}" ${data ? '' : 'disabled'}></label>
    <div class="w5" style="align-self:end;display:flex;gap:6px;flex-wrap:wrap">${[[30, '30 dias'], [90, '90 dias'], [180, '6 meses'], [365, '1 ano']]
      .map(([d, t]) => `<button type="button" class="btn pequeno" data-prazo="${d}">${t}</button>`).join('')}</div>
    <label class="check w3" style="align-self:end"><input type="checkbox" name="sem_validade" ${data ? '' : 'checked'}><span>Sem prazo de validade</span></label></div>`;
}
function ligarValidade(raiz) {
  const sem = raiz.querySelector('[name=sem_validade]'), data = raiz.querySelector('[name=validade]');
  sem.onchange = () => { data.disabled = sem.checked; if (!sem.checked && !data.value) data.value = somarDias(hojeISO(), 90); };
  raiz.querySelectorAll('[data-prazo]').forEach(b => b.onclick = () => { sem.checked = false; data.disabled = false; data.value = somarDias(hojeISO(), +b.dataset.prazo); });
}
function lerValidade(raiz) {
  if (raiz.querySelector('[name=sem_validade]').checked) return '';
  const v = raiz.querySelector('[name=validade]').value;
  if (!v) throw new Error('Informe a data de validade do vale ou marque "Sem prazo de validade".');
  if (v < hojeISO()) throw new Error('A validade do vale não pode ser uma data que já passou.');
  return v;
}
