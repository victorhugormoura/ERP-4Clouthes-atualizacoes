"""Loja ERP — leitura de extratos (OFX) e de relatórios das maquininhas (CSV) e conciliação com o financeiro.

Funções puras, sem rede: recebem o conteúdo do arquivo e a lista de lançamentos e devolvem o que casou.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import csv
import datetime as dt
import io
import re
import unicodedata

TOLERANCIA = 0.011          # diferença aceita entre valores (centavos de arredondamento)


class ErroArquivo(ValueError):
    pass


def _texto(conteudo):
    if isinstance(conteudo, str):
        return conteudo
    for codificacao in ('utf-8-sig', 'cp1252', 'latin-1'):
        try:
            return conteudo.decode(codificacao)
        except UnicodeDecodeError:
            continue
    raise ErroArquivo('Não foi possível ler o arquivo (codificação desconhecida).')


def _sem_acento(texto):
    return ''.join(c for c in unicodedata.normalize('NFD', str(texto)) if unicodedata.category(c) != 'Mn').lower().strip()


def numero(texto):
    """'1.234,56', '1234.56', 'R$ -12,30', '(12,30)' -> float."""
    t = str(texto or '').strip().replace('R$', '').replace('\xa0', '').replace(' ', '')
    negativo = t.startswith('(') and t.endswith(')') or t.startswith('-') or t.endswith('-')
    t = t.strip('()-+')
    if not t:
        return 0.0
    if ',' in t and '.' in t:
        t = t.replace('.', '').replace(',', '.') if t.rfind(',') > t.rfind('.') else t.replace(',', '')
    elif ',' in t:
        t = t.replace(',', '.')
    elif t.count('.') > 1:
        t = t.replace('.', '')
    try:
        v = float(t)
    except ValueError:
        raise ErroArquivo(f'Valor inválido: {texto!r}')
    return -v if negativo else v


def data(texto):
    """'31/10/2026', '31/10/26', '2026-10-31', '2026-10-31T10:00', '20261031...' -> 'AAAA-MM-DD'."""
    t = str(texto or '').strip()
    m = re.match(r'^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})', t)
    if m:
        d, mes, a = int(m.group(1)), int(m.group(2)), int(m.group(3))
        a += 2000 if a < 100 else 0
    else:
        m = re.match(r'^(\d{4})-?(\d{2})-?(\d{2})', t)
        if not m:
            raise ErroArquivo(f'Data inválida: {texto!r}')
        a, mes, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        return dt.date(a, mes, d).isoformat()
    except ValueError:
        raise ErroArquivo(f'Data inválida: {texto!r}')


# --------------------------------------------------------------------------- OFX

def ler_ofx(conteudo):
    """Lê extrato OFX (versão 1, SGML, ou 2, XML). Devolve {'banco', 'conta', 'inicio', 'fim', 'transacoes': [...]}.

    Cada transação: {'id', 'data', 'valor' (positivo = entrada), 'tipo', 'descricao'}."""
    texto = _texto(conteudo)
    if '<OFX' not in texto.upper():
        raise ErroArquivo('O arquivo não parece um extrato OFX. No site ou app do banco, exporte o extrato em "OFX" ou "Money".')

    def campo(bloco, nome):
        m = re.search(r'<' + nome + r'>\s*([^<\r\n]*)', bloco, re.I)
        return m.group(1).strip() if m else ''

    transacoes = []
    for bloco in re.findall(r'<STMTTRN>(.*?)(?=</STMTTRN>|<STMTTRN>|</BANKTRANLIST>)', texto, re.I | re.S):
        valor = campo(bloco, 'TRNAMT')
        quando = campo(bloco, 'DTPOSTED')
        if not valor or not quando:
            continue
        descricao = ' '.join(x for x in (campo(bloco, 'NAME'), campo(bloco, 'MEMO')) if x)
        transacoes.append({
            'id': campo(bloco, 'FITID') or f'{quando[:8]}-{valor}-{len(transacoes)}',
            'data': data(quando[:8]), 'valor': round(numero(valor.replace(',', '.')), 2),
            'tipo': campo(bloco, 'TRNTYPE').upper(), 'descricao': descricao[:200],
        })
    if not transacoes:
        raise ErroArquivo('Nenhuma movimentação encontrada no extrato OFX.')
    datas = sorted(t['data'] for t in transacoes)
    return {'banco': campo(texto, 'ORG') or campo(texto, 'BANKID'), 'conta': campo(texto, 'ACCTID')[-4:],
            'inicio': datas[0], 'fim': datas[-1], 'transacoes': transacoes}


# ------------------------------------------------------------- CSV das maquininhas

# Nomes de coluna usados pelos portais (comparados sem acento e em minúsculas).
SINONIMOS = {
    'data': ('data da venda', 'data venda', 'data da transacao', 'data transacao', 'data/hora da venda',
             'data e hora', 'data/hora', 'data da compra', 'data de venda', 'data'),
    'bruto': ('valor bruto', 'valor da venda', 'valor venda', 'valor bruto da parcela', 'valor original',
              'valor total', 'valor da transacao', 'valor'),
    'liquido': ('valor liquido', 'liquido', 'valor liquido da parcela', 'valor a receber', 'valor recebido'),
    'taxa': ('taxa', 'valor da taxa', 'tarifa', 'desconto', 'valor mdr', 'mdr', 'taxas'),
    'parcelas': ('parcelas', 'qtd parcelas', 'quantidade de parcelas', 'n de parcelas', 'plano', 'parcela'),
    'previsao': ('data prevista de pagamento', 'previsao de pagamento', 'data prevista', 'data de pagamento',
                 'data do pagamento', 'data de recebimento', 'data do recebimento', 'previsao', 'pagamento'),
    'forma': ('forma de pagamento', 'meio de pagamento', 'modalidade', 'tipo de transacao', 'produto', 'tipo'),
    'bandeira': ('bandeira',),
    'nsu': ('nsu', 'codigo de autorizacao', 'autorizacao', 'cod autorizacao', 'cv', 'id da transacao', 'codigo da venda'),
    'status': ('status', 'situacao'),
}
OBRIGATORIAS = ('data', 'bruto')


def ler_csv(conteudo):
    """Lê o CSV exportado do portal. Devolve (cabeçalho, linhas como listas)."""
    texto = _texto(conteudo).strip()
    if not texto:
        raise ErroArquivo('Arquivo vazio.')
    if texto[:2] == 'PK':
        raise ErroArquivo('Este arquivo é uma planilha do Excel (.xlsx). Abra no Excel e salve como "CSV", ou exporte em CSV no portal.')
    amostra = texto[:5000]
    delim = max((';', ',', '\t', '|'), key=lambda d: amostra.splitlines()[0].count(d))
    linhas = [l for l in csv.reader(io.StringIO(texto), delimiter=delim) if any(c.strip() for c in l)]
    # Alguns portais põem linhas de título antes do cabeçalho: usa a primeira linha com coluna de data e de valor.
    for i, linha in enumerate(linhas[:15]):
        nomes = [_sem_acento(c) for c in linha]
        if any('data' in n for n in nomes) and any('valor' in n or 'bruto' in n for n in nomes):
            return linha, linhas[i + 1:]
    return linhas[0], linhas[1:]


def mapear_colunas(cabecalho):
    """Descobre qual coluna é cada campo, pelos nomes usados nos portais. Devolve {campo: índice}."""
    nomes = [_sem_acento(c) for c in cabecalho]
    mapa = {}
    for campo, sinonimos in SINONIMOS.items():
        for s in sinonimos:                       # primeiro o nome exato, depois "começa com"
            if s in nomes and nomes.index(s) not in mapa.values():
                mapa[campo] = nomes.index(s)
                break
        else:
            for s in sinonimos:
                achou = next((i for i, n in enumerate(nomes) if n.startswith(s) and i not in mapa.values()), None)
                if achou is not None:
                    mapa[campo] = achou
                    break
    return mapa


def _forma(texto):
    t = _sem_acento(texto)
    if 'debito' in t:
        return 'debito'
    if 'credito' in t:
        return 'credito'
    if 'pix' in t:
        return 'pix'
    return ''


def _parcelas(texto):
    t = _sem_acento(texto)
    m = re.search(r'(\d+)\s*/\s*(\d+)', t)            # "2/3" -> parcela 2 de 3
    if m:
        return int(m.group(2)), int(m.group(1))
    m = re.search(r'(\d+)', t)
    if m:
        return max(1, int(m.group(1))), 0
    return 1, 0


def vendas_maquininha(conteudo, mapa=None):
    """Lê o CSV e devolve as vendas/recebíveis normalizados e o mapa usado."""
    cab, linhas = ler_csv(conteudo)
    mapa = mapa or mapear_colunas(cab)
    faltam = [c for c in OBRIGATORIAS if c not in mapa]
    if faltam:
        raise ErroArquivo('Não achei as colunas de ' + ' e '.join({'data': 'data da venda', 'bruto': 'valor bruto'}[c] for c in faltam)
                          + '. Escolha as colunas manualmente.')
    saida = []
    for n, linha in enumerate(linhas, 1):
        def col(campo):
            i = mapa.get(campo)
            return linha[i] if i is not None and i < len(linha) else ''
        status = _sem_acento(col('status'))
        if any(x in status for x in ('cancelad', 'estornad', 'negad', 'recusad')):
            continue
        try:
            bruto = abs(numero(col('bruto')))
            quando = data(col('data'))
        except ErroArquivo:
            continue                                  # linhas de total ou subtítulo
        if bruto <= 0:
            continue
        liquido = abs(numero(col('liquido'))) if col('liquido') else None
        taxa = abs(numero(col('taxa'))) if col('taxa') else None
        if liquido is None and taxa is not None:
            liquido = round(bruto - taxa, 2)
        if taxa is None and liquido is not None:
            taxa = round(bruto - liquido, 2)
        parcelas, parcela = _parcelas(col('parcelas')) if col('parcelas') else (1, 0)
        try:
            previsao = data(col('previsao')) if col('previsao') else ''
        except ErroArquivo:
            previsao = ''
        saida.append({'linha': n, 'data': quando, 'bruto': round(bruto, 2), 'liquido': liquido, 'taxa': taxa,
                      'parcelas': parcelas, 'parcela': parcela, 'previsao': previsao, 'forma': _forma(col('forma')),
                      'bandeira': col('bandeira').strip()[:30], 'nsu': col('nsu').strip()[:40]})
    if not saida:
        raise ErroArquivo('Nenhuma venda encontrada no arquivo.')
    return {'cabecalho': cab, 'mapa': mapa, 'vendas': saida}


# ------------------------------------------------------------------- conciliação

def _perto(a, b):
    return abs(a - b) <= TOLERANCIA


def _dias(a, b):
    return abs((dt.date.fromisoformat(a[:10]) - dt.date.fromisoformat(b[:10])).days)


def conciliar_cartoes(vendas, financeiro):
    """Casa as vendas do relatório da maquininha com os recebíveis de cartão do financeiro.

    Aceita relatório por parcela (cada linha é uma parcela) ou por venda (uma linha com o total e o nº de
    parcelas). Devolve {'casadas': [{'linha', 'ids', 'taxa', 'liquido', 'previsao'}], 'so_no_relatorio': [...],
    'so_no_sistema': [ids]}."""
    candidatos = [f for f in financeiro if f.get('tipo') == 'receber' and f.get('forma') in ('debito', 'credito')
                  and f.get('status') != 'cancelado' and f.get('origem') == 'venda']
    usados = set()
    casadas, sobra = [], []
    por_pagamento = {}
    for f in candidatos:
        por_pagamento.setdefault((f.get('ref'), f.get('forma')), []).append(f)
    for v in sorted(vendas, key=lambda x: (x['data'], -x['bruto'])):
        dia = v['data']
        livres = [f for f in candidatos if f['id'] not in usados and (f.get('criado_em') or '')[:10] == dia
                  and (not v['forma'] or v['forma'] == f['forma'])]
        ids_livres = {f['id'] for f in livres}
        # 1) uma parcela (ou venda à vista) com o mesmo valor
        alvo = next((f for f in livres if _perto(f['valor'], v['bruto'])
                     and (not v['parcela'] or f.get('parcela', '').startswith(f"{v['parcela']}/"))), None)
        if alvo:
            grupo = [alvo]
        else:
            # 2) a venda inteira parcelada: soma das parcelas do mesmo pagamento
            grupo = None
            for chave, fs in por_pagamento.items():
                fs_livres = [f for f in fs if f['id'] in ids_livres]
                if len(fs_livres) > 1 and _perto(sum(f['valor'] for f in fs_livres), v['bruto']) \
                        and (v['parcelas'] <= 1 or v['parcelas'] == len(fs_livres)):
                    grupo = sorted(fs_livres, key=lambda f: f.get('parcela', ''))
                    break
        if not grupo:
            sobra.append(v)
            continue
        usados.update(f['id'] for f in grupo)
        casadas.append({'linha': v['linha'], 'ids': [f['id'] for f in grupo], 'taxa': v['taxa'], 'liquido': v['liquido'],
                        'previsao': v['previsao'] if len(grupo) == 1 else '', 'nsu': v['nsu'], 'bruto': v['bruto']})
    datas = [v['data'] for v in vendas]
    periodo = (min(datas), max(datas)) if datas else ('', '')
    so_sistema = [f['id'] for f in candidatos if f['id'] not in usados and f.get('status') == 'pendente'
                  and periodo[0] <= (f.get('criado_em') or '')[:10] <= periodo[1]]
    return {'casadas': casadas, 'so_no_relatorio': sobra, 'so_no_sistema': so_sistema}


def conciliar_extrato(transacoes, financeiro, ja_conciliadas=()):
    """Casa cada movimentação do extrato com lançamentos do financeiro.

    - Entrada: recebível de cartão ou conta a receber pendente com o mesmo valor líquido e vencimento próximo,
      ou a soma dos recebíveis de cartão que vencem no mesmo dia (a maquininha deposita tudo junto);
      ou recebimento já baixado (Pix) no mesmo dia, com o mesmo valor.
    - Saída: conta a pagar com o mesmo valor e vencimento ou pagamento próximo.
    Devolve {'casadas': [{'transacao', 'ids', 'baixar'}], 'sem_par': [transacao]}."""
    usados = set()
    casadas, sem_par = [], []
    # Já conferido em outro extrato não casa de novo. Crediário fica de fora: um Pix de terceiro com o mesmo
    # valor daria baixa na parcela de outra cliente.
    ativos = [f for f in financeiro if f.get('status') in ('pendente', 'pago') and not f.get('conferido_extrato')
              and f.get('forma') != 'crediario']
    for t in sorted(transacoes, key=lambda x: x['data']):
        if t['id'] in ja_conciliadas:
            continue
        valor = abs(t['valor'])
        tipo = 'receber' if t['valor'] > 0 else 'pagar'
        mesmos = [f for f in ativos if f['id'] not in usados and f['tipo'] == tipo]

        def liquido(f):
            return f.get('valor_pago') if f['status'] == 'pago' and f.get('valor_pago') is not None else (
                f.get('liquido', f['valor']) if tipo == 'receber' else f['valor'])

        def referencia(f):
            return f.get('pago_em') if f['status'] == 'pago' else f.get('vencimento')

        perto = [f for f in mesmos if referencia(f) and _dias(referencia(f), t['data']) <= (1 if tipo == 'receber' else 3)
                 and _perto(liquido(f), valor)]
        perto.sort(key=lambda f: (_dias(referencia(f), t['data']), f['status'] != 'pendente'))
        # Dois lançamentos igualmente bons (mesmo valor, mesma data): não escolhe sozinho, manda para revisão.
        empate = len(perto) > 1 and _dias(referencia(perto[0]), t['data']) == _dias(referencia(perto[1]), t['data']) \
            and perto[0]['status'] == perto[1]['status']
        grupo = [] if empate else perto[:1]
        if not grupo and not empate and tipo == 'receber':
            # depósito da maquininha: soma dos recebíveis de cartão do dia (ou do dia útil anterior)
            for folga in (0, 1, 2, 3):
                dia = (dt.date.fromisoformat(t['data']) - dt.timedelta(days=folga)).isoformat()
                cartoes = [f for f in mesmos if f.get('forma') in ('debito', 'credito') and f['status'] == 'pendente'
                           and f.get('vencimento') == dia]
                if len(cartoes) > 1 and _perto(sum(liquido(f) for f in cartoes), valor):
                    grupo = cartoes
                    break
        if not grupo:
            sem_par.append(t)
            continue
        usados.update(f['id'] for f in grupo)
        casadas.append({'transacao': t, 'ids': [f['id'] for f in grupo],
                        'baixar': [f['id'] for f in grupo if f['status'] == 'pendente']})
    return {'casadas': casadas, 'sem_par': sem_par}
