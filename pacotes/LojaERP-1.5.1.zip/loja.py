#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Loja ERP — gestão completa para loja de roupas de pequeno porte.

Servidor local que usa apenas a biblioteca padrão do Python (3.8 ou superior).
Os dados ficam em arquivos JSON na pasta "dados", ao lado deste programa, e
podem ser sincronizados com Google Drive, Dropbox ou OneDrive.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""

import argparse
import base64
import calendar
import contextlib
import copy
import csv
import datetime as dt
import hashlib
import hmac
import io
import math
import json
import os
import platform
import random
import re
import secrets
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import urllib.request
import webbrowser
import zipfile
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

VERSAO = '1.5.1'
CREDITO = 'Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com'

if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
    WEB_DIR = os.path.join(getattr(sys, '_MEIPASS', BASE_DIR), 'web')
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    WEB_DIR = os.path.join(BASE_DIR, 'web')

ARQ_PASTA_LOJA = os.path.join(BASE_DIR, 'pasta_loja.txt')
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)   # o Python embutido não inclui a pasta do programa sozinho

import atualizacao  # noqa: E402
import celular  # noqa: E402
import conciliacao  # noqa: E402
import integracoes  # noqa: E402
import licenca  # noqa: E402


def ler_pasta_configurada():
    """Lê a pasta da loja gravada pelo instalador (UTF-16 com BOM ou UTF-8)."""
    try:
        with open(ARQ_PASTA_LOJA, 'rb') as f:
            bruto = f.read()
    except OSError:
        return None
    texto = bruto.decode('utf-16') if bruto[:2] in (b'\xff\xfe', b'\xfe\xff') else bruto.decode('utf-8-sig', 'replace')
    pasta = texto.strip().rstrip('\\/')
    return pasta + os.sep if re.fullmatch(r'[A-Za-z]:', pasta) else (pasta or None)


def definir_pastas(pasta=None):
    """Define onde ficam dados e backups: argumento --pasta, arquivo do instalador ou a pasta do programa."""
    global PASTA_LOJA, DADOS_DIR, FOTOS_DIR, BACKUP_DIR, ARQ_AUDITORIA, ARQ_EM_USO
    PASTA_LOJA = os.path.abspath(os.path.expanduser(pasta or ler_pasta_configurada() or BASE_DIR))
    DADOS_DIR = os.path.join(PASTA_LOJA, 'dados')
    FOTOS_DIR = os.path.join(DADOS_DIR, 'fotos')
    BACKUP_DIR = os.path.join(PASTA_LOJA, 'backups')
    ARQ_AUDITORIA = os.path.join(DADOS_DIR, 'auditoria.log')
    ARQ_EM_USO = os.path.join(DADOS_DIR, '.em_uso.json')


definir_pastas()

COLECOES = (
    'categorias', 'marcas', 'fornecedores', 'colecoes', 'servicos', 'produtos', 'clientes',
    'vendas', 'entradas', 'movimentos', 'financeiro', 'recorrentes', 'caixa',
    'condicionais', 'trocas', 'vales', 'promocoes', 'tarefas', 'ativos', 'plano_contas',
    'cobrancas', 'conciliacoes',
)
GENERICAS = ('categorias', 'marcas', 'fornecedores', 'colecoes', 'servicos', 'promocoes',
             'recorrentes', 'tarefas', 'ativos', 'plano_contas')
CAMPOS_CIFRADOS = ('cpf', 'telefone', 'email', 'endereco', 'nascimento', 'observacoes')
AVISO_USUARIOS_PERDIDOS = ('O arquivo de usuários (usuarios.json) está faltando ou vazio, mas a loja tem dados gravados. '
                           'Restaure o backup mais recente. Se quiser mesmo começar do zero, mova a pasta "dados" '
                           'para outro lugar e abra o sistema de novo.')
ROTAS_PUBLICAS = {'estado', 'setup', 'login', 'recuperar', 'restaurar', 'backup/enviar'}
ITERACOES_PBKDF2 = 600000
MAGICO_BACKUP = b'LOJAERP-BKP2\n'
LIMITE_UPLOAD_BACKUP = 1024 * 1024 * 1024
LIMITE_DESCOMPACTADO = 4 * 1024 * 1024 * 1024
FORMAS = ('dinheiro', 'pix', 'debito', 'credito', 'crediario', 'vale', 'cashback')
TIPOS_AJUSTE = {
    'ajuste_entrada': 1, 'ajuste_saida': -1, 'perda': -1, 'defeito': -1, 'furto': -1,
    'uso_interno': -1, 'brinde': -1, 'devolucao_fornecedor': -1,
}
PAPEIS = {
    'dona': 'Proprietária — acesso total',
    'gerente': 'Gerente — tudo, exceto usuários, segurança e limpeza de dados',
    'vendedora': 'Vendedora — caixa, condicional, trocas, clientes e consultas (sem custos e financeiro)',
}
NEGADO_GERENTE = {'licenca/ativar', 'integracoes/salvar', 'integracoes/testar', 'usuario/adicionar', 'usuario/remover', 'usuario/papel', 'usuario/senha', 'limpar_exemplo', 'nova_recuperacao',
                  'atualizacao/instalar', 'atualizacao/config'}
# Pelo celular não se faz o que mexe no sistema inteiro: isso fica no computador da loja.
BLOQUEADAS_NO_CELULAR = {'setup', 'recuperar', 'restaurar', 'backup', 'backup/enviar', 'encerrar', 'limpar_exemplo',
                         'nova_recuperacao', 'usuario/adicionar', 'usuario/remover', 'usuario/papel', 'usuario/senha',
                         'licenca/ativar', 'integracoes/salvar', 'integracoes/testar',
                         'conflito/mover'}
PORTA_CELULAR = 8780
PACOTE_JS = ('core.js', 'negocio.js', 'pag_vendas.js', 'pag_estoque.js', 'pag_clientes.js', 'pag_financeiro.js',
             'pag_admin.js', 'pix.js', 'extras.js', 'backup.js', 'mei.js', 'leitor.js', 'celular.js', 'integracoes.js', 'main.js')
VALIDADE_PAREAMENTO = 120
PERMITIDO_VENDEDORA = {
    'logout', 'senha', 'venda', 'venda/nota', 'nfe/emitir', 'nfe/consultar', 'nfe/danfe', 'pix/cobrar', 'pix/status', 'pix/cancelar',
    'condicional/abrir', 'condicional/fechar', 'troca', 'vale/presente', 'caixa/abrir',
    'caixa/movimento', 'caixa/fechar', 'cliente/salvar', 'foto', 'salvar/tarefas', 'financeiro/baixar', 'config',
}
SENHA_MINIMA = 8
SENHA_MINIMA_GESTAO = 10   # dona e gerente: qualquer senha abre a chave da loja inteira
SENHAS_COMUNS = {'12345678', '123456789', '1234567890', '87654321', '11111111', '00000000', 'password', 'senha123',
                 'senha1234', 'senha12345', 'mudar123', 'admin123', 'qwerty123', 'abc12345', 'abcd1234', 'loja1234',
                 'iloveyou', 'brasil123', 'q1w2e3r4', '1q2w3e4r', 'q1w2e3r4t5', '1q2w3e4r5t'}
SESSAO_MAX_INATIVA = 10 * 3600
OCIOSO_MAX = 4 * 3600
LIMITE_CORPO = 20 * 1024 * 1024
MIME = {
    '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
    '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
}

PLANO_CONTAS = [
    ('pc_vendas', 'Vendas (lançamento automático)', 'receita', 'receita_vendas'),
    ('pc_outras_receitas', 'Outras receitas', 'receita', 'outras_receitas'),
    ('pc_rendimentos', 'Rendimentos e juros recebidos', 'receita', 'receitas_financeiras'),
    ('pc_aporte', 'Aporte da sócia / capital', 'receita', 'fora_dre'),
    ('pc_emprestimo_recebido', 'Empréstimo recebido', 'receita', 'fora_dre'),
    ('pc_compra_mercadorias', 'Compra de mercadorias', 'despesa', 'estoque'),
    ('pc_aluguel', 'Aluguel', 'despesa', 'administrativas'),
    ('pc_condominio', 'Condomínio / IPTU', 'despesa', 'administrativas'),
    ('pc_energia', 'Energia elétrica', 'despesa', 'administrativas'),
    ('pc_agua', 'Água', 'despesa', 'administrativas'),
    ('pc_internet', 'Internet e telefone', 'despesa', 'administrativas'),
    ('pc_contabilidade', 'Contabilidade', 'despesa', 'administrativas'),
    ('pc_sistemas', 'Sistemas e aplicativos', 'despesa', 'administrativas'),
    ('pc_material', 'Material de escritório e limpeza', 'despesa', 'administrativas'),
    ('pc_manutencao', 'Manutenção e reparos', 'despesa', 'administrativas'),
    ('pc_seguro', 'Seguro', 'despesa', 'administrativas'),
    ('pc_taxas_diversas', 'Taxas e licenças (alvará, bombeiros etc.)', 'despesa', 'administrativas'),
    ('pc_servicos_terceiros', 'Serviços de terceiros (costureira etc.)', 'despesa', 'administrativas'),
    ('pc_marketing', 'Marketing e anúncios', 'despesa', 'vendas'),
    ('pc_embalagens', 'Embalagens, sacolas e etiquetas', 'despesa', 'vendas'),
    ('pc_comissoes', 'Comissões', 'despesa', 'vendas'),
    ('pc_frete_entrega', 'Fretes de entrega / motoboy', 'despesa', 'vendas'),
    ('pc_maquininha', 'Aluguel da maquininha', 'despesa', 'vendas'),
    ('pc_prolabore', 'Pró-labore', 'despesa', 'pessoal'),
    ('pc_salarios', 'Salários', 'despesa', 'pessoal'),
    ('pc_encargos', 'Encargos (INSS, FGTS)', 'despesa', 'pessoal'),
    ('pc_beneficios', 'Vale-transporte / alimentação', 'despesa', 'pessoal'),
    ('pc_das_mei', 'DAS MEI', 'despesa', 'impostos'),
    ('pc_das_simples', 'Pagamento do DAS Simples (imposto já calculado nas vendas)', 'despesa', 'fora_dre'),
    ('pc_tarifas', 'Tarifas bancárias', 'despesa', 'financeiras'),
    ('pc_juros', 'Juros, multas e IOF', 'despesa', 'financeiras'),
    ('pc_equipamentos', 'Compra de equipamentos e móveis', 'despesa', 'investimento'),
    ('pc_reforma', 'Reforma / obras na loja', 'despesa', 'investimento'),
    ('pc_retirada', 'Retirada de lucro', 'despesa', 'retirada'),
    ('pc_emprestimo_pago', 'Pagamento de empréstimo (principal)', 'despesa', 'fora_dre'),
    ('pc_devolucao_cliente', 'Devolução de dinheiro a cliente', 'despesa', 'fora_dre'),
    ('pc_vale_presente', 'Venda de vale-presente (vira receita quando é usado)', 'receita', 'fora_dre'),
]
PLANO_SISTEMA = {'pc_vendas', 'pc_compra_mercadorias', 'pc_devolucao_cliente', 'pc_vale_presente'}
NOME_VALE = {'troca': 'Vale-troca', 'presente': 'Vale-presente'}
FORMAS_LEGIVEIS = {'dinheiro': 'Dinheiro', 'pix': 'Pix', 'debito': 'Débito', 'credito': 'Crédito', 'crediario': 'Crediário',
                   'vale': 'Vale', 'cashback': 'Cashback'}
# Credenciais das integrações: guardadas cifradas e nunca enviadas para a tela.
SEGREDOS_INTEGRACAO = {'nfe': ('token',), 'pix': ('token', 'client_secret', 'certificado', 'chave_certificado')}
CAMPOS_INTEGRACAO = {
    'nfe': ('ativo', 'provedor', 'ambiente', 'emitir', 'ncm_padrao', 'cfop', 'csosn', 'origem', 'pis_cst', 'cofins_cst',
            'informacoes_adicionais'),
    'pix': ('ativo', 'provedor', 'email_pagador', 'banco', 'url_api', 'url_token', 'client_id', 'chave_pix', 'escopo',
            'parametro_url', 'cabecalhos', 'minutos', 'modo_token'),
}
# Código de Defesa do Consumidor (Lei 8.078/1990): limites usados no crediário da loja.
MULTA_MAXIMA_PCT = 2.0      # art. 52, § 1º
JUROS_MAXIMO_MES_PCT = 1.0  # limite adotado pelo sistema para juros de mora
POLITICA_TROCA_PADRAO = ('Trocas em até 30 dias, com a etiqueta e este comprovante. '
                         'Peças com defeito: você pode reclamar em até 90 dias e escolher conserto, troca, '
                         'devolução do valor ou abatimento no preço (Código de Defesa do Consumidor, arts. 18 e 26).')
FORMAS_VALE_PRESENTE = ('dinheiro', 'pix', 'debito', 'credito')
VALOR_MAX_VALE = 20000.0


class ErroNegocio(Exception):
    """Erro de regra de negócio, exibido diretamente para a usuária."""


# ---------------------------------------------------------------- utilidades

def agora():
    return dt.datetime.now().replace(microsecond=0).isoformat()


def agora_menos(minutos):
    return (dt.datetime.now() - dt.timedelta(minutes=minutos)).replace(microsecond=0).isoformat()


def hoje():
    return dt.date.today().isoformat()


def novo_id():
    return f'{int(time.time() * 1000):x}{secrets.token_hex(3)}'


def num(valor, padrao=0.0):
    if valor is None or valor == '':
        return padrao
    try:
        return float(str(valor).replace(',', '.'))
    except ValueError:
        return padrao


def inteiro(valor, padrao=0):
    return int(round(num(valor, padrao)))


def r2(valor):
    return round(float(valor) + (1e-9 if valor >= 0 else -1e-9), 2)


def b64e(dados):
    return base64.urlsafe_b64encode(dados).decode()


def b64d(texto):
    return base64.urlsafe_b64decode(texto.encode())


def slug(texto):
    t = unicodedata.normalize('NFKD', texto).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', '_', t).strip('_')


def somar_dias(data_iso, dias):
    return (dt.date.fromisoformat(data_iso[:10]) + dt.timedelta(days=dias)).isoformat()


def data_br(data_iso):
    return dt.date.fromisoformat(str(data_iso)[:10]).strftime('%d/%m/%Y')


def somar_meses(data_iso, meses):
    d = dt.date.fromisoformat(data_iso[:10])
    total = d.month - 1 + meses
    ano, mes = d.year + total // 12, total % 12 + 1
    return dt.date(ano, mes, min(d.day, calendar.monthrange(ano, mes)[1])).isoformat()


def data_no_mes(mes_iso, dia):
    ano, mes = (int(x) for x in mes_iso.split('-'))
    dia = min(max(1, int(dia or 1)), calendar.monthrange(ano, mes)[1])
    return dt.date(ano, mes, dia).isoformat()


def achar(lista, ident):
    if not ident:
        return None
    return next((x for x in lista if x.get('id') == ident), None)


def so_digitos(texto):
    return re.sub(r'\D', '', str(texto or ''))


def cpf_valido(cpf):
    c = so_digitos(cpf)
    if len(c) != 11 or c == c[0] * 11:
        return False
    for n in (9, 10):
        soma = sum(int(c[i]) * (n + 1 - i) for i in range(n))
        dig = (soma * 10) % 11 % 10
        if dig != int(c[n]):
            return False
    return True


def ean13(base12):
    soma = sum(int(d) * (3 if i % 2 else 1) for i, d in enumerate(base12))
    return base12 + str((10 - soma % 10) % 10)


def black_friday(ano):
    d = dt.date(ano, 11, 1)
    primeira_quinta = d + dt.timedelta(days=(3 - d.weekday()) % 7)
    return primeira_quinta + dt.timedelta(days=22)


def dia_das_maes(ano):
    d = dt.date(ano, 5, 1)
    primeiro_domingo = d + dt.timedelta(days=(6 - d.weekday()) % 7)
    return primeiro_domingo + dt.timedelta(days=7)


def sanear(valor, nivel=0):
    """Limita tamanho e profundidade de dados recebidos da tela."""
    if nivel > 6:
        raise ErroNegocio('Dados inválidos.')
    if isinstance(valor, str):
        return valor[:5000]
    if isinstance(valor, dict):
        if len(valor) > 400:
            raise ErroNegocio('Dados inválidos.')
        return {str(k)[:80]: sanear(v, nivel + 1) for k, v in valor.items()}
    if isinstance(valor, list):
        if len(valor) > 5000:
            raise ErroNegocio('Dados inválidos.')
        return [sanear(v, nivel + 1) for v in valor]
    if isinstance(valor, (int, float, bool)) or valor is None:
        return valor
    raise ErroNegocio('Dados inválidos.')


def mesclar_padrao(padrao, atual):
    saida = dict(atual)
    for k, v in padrao.items():
        if k not in saida:
            saida[k] = copy.deepcopy(v)
        elif isinstance(v, dict) and isinstance(saida[k], dict) and k not in ('metas', 'grades', 'aparencia', 'painel'):
            saida[k] = mesclar_padrao(v, saida[k])
    return saida


# --------------------------------------------------------------- criptografia

class Cofre:
    """Cifra autenticada com primitivas da biblioteca padrão.

    Formato atual (v2): 0x02 | nonce (16) | dados XOR SHAKE256(chave, nonce) | HMAC-SHA256 (32).
    O formato v1 (HMAC-SHA256 em modo contador, etiqueta de 16 bytes) continua legível.
    A chave mestra é aleatória e fica guardada apenas "envelopada" pela senha (PBKDF2)
    e pelo código de recuperação.
    """
    PREFIXO = 'enc2:'
    PREFIXOS_LEGIVEIS = ('enc2:', 'enc1:')

    def __init__(self, chave):
        self.k_enc = hmac.new(chave, b'loja-erp/cifra', hashlib.sha256).digest()
        self.k_mac = hmac.new(chave, b'loja-erp/integridade', hashlib.sha256).digest()

    @staticmethod
    def _xor(a, b):
        return (int.from_bytes(a, 'big') ^ int.from_bytes(b, 'big')).to_bytes(len(a), 'big')

    def _fluxo(self, nonce, tamanho):
        return hashlib.shake_256(b'loja-erp/v2' + self.k_enc + nonce).digest(tamanho)

    def _fluxo_v1(self, nonce, tamanho):
        saida = bytearray()
        for contador in range((tamanho + 31) // 32):
            saida += hmac.new(self.k_enc, nonce + contador.to_bytes(8, 'big'), hashlib.sha256).digest()
        return bytes(saida[:tamanho])

    def cifrar_bytes(self, dados):
        nonce = secrets.token_bytes(16)
        cifrado = self._xor(dados, self._fluxo(nonce, len(dados))) if dados else b''
        tag = hmac.new(self.k_mac, b'v2' + nonce + cifrado, hashlib.sha256).digest()
        return b'\x02' + nonce + cifrado + tag

    def decifrar_bytes(self, blob):
        if blob[:1] == b'\x02' and len(blob) >= 49:
            nonce, cifrado, tag = blob[1:17], blob[17:-32], blob[-32:]
            if hmac.compare_digest(tag, hmac.new(self.k_mac, b'v2' + nonce + cifrado, hashlib.sha256).digest()):
                return self._xor(cifrado, self._fluxo(nonce, len(cifrado))) if cifrado else b''
        if len(blob) < 32:
            raise ValueError('dado cifrado inválido')
        nonce, cifrado, tag = blob[:16], blob[16:-16], blob[-16:]
        if not hmac.compare_digest(tag, hmac.new(self.k_mac, nonce + cifrado, hashlib.sha256).digest()[:16]):
            raise ValueError('falha de integridade')
        return self._xor(cifrado, self._fluxo_v1(nonce, len(cifrado))) if cifrado else b''

    def cifrar(self, texto):
        if texto is None or texto == '':
            return ''
        return self.PREFIXO + b64e(self.cifrar_bytes(str(texto).encode('utf-8')))

    def decifrar(self, valor):
        if not isinstance(valor, str) or not valor.startswith(self.PREFIXOS_LEGIVEIS):
            return valor
        try:
            return self.decifrar_bytes(b64d(valor[5:])).decode('utf-8')
        except (ValueError, UnicodeDecodeError):
            return '[ilegível]'


def envelopar(chave, segredo, iteracoes=ITERACOES_PBKDF2):
    salt = secrets.token_bytes(16)
    kek = hashlib.pbkdf2_hmac('sha256', segredo.encode('utf-8'), salt, iteracoes, 32)
    return {'salt': b64e(salt), 'iter': iteracoes, 'blob': b64e(Cofre(kek).cifrar_bytes(chave))}


ITERACOES_MAXIMAS = 5_000_000   # teto para cabeçalhos de backup adulterados não travarem o sistema


def desenvelopar(envelope, segredo):
    iteracoes = int(envelope['iter'])
    if not 1000 <= iteracoes <= ITERACOES_MAXIMAS:
        raise ValueError('envelope inválido')
    kek = hashlib.pbkdf2_hmac('sha256', segredo.encode('utf-8'), b64d(envelope['salt']), iteracoes, 32)
    return Cofre(kek).decifrar_bytes(b64d(envelope['blob']))


def verificador_chave(chave):
    return b64e(hmac.new(chave, b'verificador', hashlib.sha256).digest())


def id_login(sal, login):
    """Identifica o usuário no cabeçalho do backup sem expor o nome de login."""
    return hmac.new(sal, login.encode('utf-8'), hashlib.sha256).hexdigest()[:24]


def chave_por_segredo(usuarios, login, segredo):
    """Abre a chave mestra com a senha de um usuário ou com o código de recuperação."""
    candidatos = []
    u = None
    if login:
        sal = bytes.fromhex(usuarios.get('sal', '')) if usuarios.get('sal') else b''
        ident = id_login(sal, login) if sal else None
        u = next((x for x in usuarios.get('lista', []) if x.get('login') == login or (ident and x.get('id') == ident)), None)
    if u:
        candidatos.append((u['envelope'], str(segredo or '')))
    if usuarios.get('recuperacao'):
        candidatos.append((usuarios['recuperacao'], normalizar_codigo(segredo)))
    for envelope, valor in candidatos:
        try:
            chave = desenvelopar(envelope, valor)
        except (ValueError, KeyError):
            continue
        if not usuarios.get('verificador') or hmac.compare_digest(verificador_chave(chave), usuarios['verificador']):
            return chave
    return None


def normalizar_codigo(codigo):
    return re.sub(r'[^A-Z0-9]', '', str(codigo or '').upper())


def gerar_codigo_recuperacao():
    alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    bruto = ''.join(secrets.choice(alfabeto) for _ in range(20))
    return '-'.join(bruto[i:i + 4] for i in range(0, 20, 4))


# ---------------------------------------------------------------- persistência

def validar_senha(senha, papel, login=''):
    """Recusa senhas curtas, óbvias ou iguais ao usuário. Dona e gerente precisam de senha mais longa."""
    minimo = SENHA_MINIMA_GESTAO if papel in ('dona', 'gerente') else SENHA_MINIMA
    quem = f' de {login}' if login else ''
    if len(senha) < minimo:
        raise ErroNegocio(f'A senha{quem} deve ter pelo menos {minimo} caracteres'
                          + (' (proprietária e gerente).' if minimo > SENHA_MINIMA else '.'))
    baixa = senha.lower()
    if baixa in SENHAS_COMUNS or len(set(senha)) < 4 or (login and login.lower() in baixa):
        raise ErroNegocio(f'A senha{quem} é fácil de adivinhar. Misture palavras, números e símbolos.')


def sem_custos(valor):
    """Cópia sem custo, lucro e margem, para o perfil vendedora."""
    if isinstance(valor, list):
        return [sem_custos(x) for x in valor]
    if isinstance(valor, dict):
        return {k: sem_custos(v) for k, v in valor.items()
                if 'custo' not in k and k not in ('lucro', 'margem', 'markup', 'cmv')}
    return valor


class Banco:
    def __init__(self):
        self.trava = threading.RLock()
        self.c = {}
        self.mtimes = {}
        self.config = {}
        self.usuarios = {}
        for pasta in (DADOS_DIR, FOTOS_DIR, BACKUP_DIR):
            os.makedirs(pasta, exist_ok=True)
        self.carregar_tudo()

    @staticmethod
    def _arq(nome):
        return os.path.join(DADOS_DIR, nome + '.json')

    def tem_dados(self):
        """Há cadastros ou movimento gravados (sem contar os padrões criados na instalação)."""
        return any(self.c.get(n) for n in COLECOES if n not in ('plano_contas', 'categorias'))

    def _ler(self, nome, padrao):
        caminho = self._arq(nome)
        if not os.path.exists(caminho):
            return copy.deepcopy(padrao), None
        ultimo_erro = None
        for _ in range(6):
            try:
                with open(caminho, 'r', encoding='utf-8') as f:
                    conteudo = json.load(f)
                return conteudo, os.path.getmtime(caminho)
            except (json.JSONDecodeError, PermissionError, OSError) as e:
                ultimo_erro = e
                time.sleep(0.4)
        copia = f'{caminho}.corrompido-{int(time.time())}'
        atualizacao.copiar_arquivo(caminho, copia)
        raise RuntimeError(f'Não foi possível ler {nome}.json ({ultimo_erro}). Uma cópia foi salva em '
                           f'{copia}. Restaure o último backup da pasta "backups".')

    def _gravar(self, nome, conteudo):
        caminho = self._arq(nome)
        temporario = caminho + '.tmp'
        texto = json.dumps(conteudo, ensure_ascii=False, indent=1)
        with open(temporario, 'w', encoding='utf-8') as f:
            f.write(texto)
            f.flush()
            os.fsync(f.fileno())
        for tentativa in range(15):
            try:
                os.replace(temporario, caminho)
                break
            except PermissionError:
                if tentativa == 14:
                    raise
                time.sleep(0.2)
        self.mtimes[nome] = os.path.getmtime(caminho)

    def carregar_tudo(self):
        with self.trava:
            for nome in COLECOES:
                self.c[nome], self.mtimes[nome] = self._ler(nome, [])
            self.config, self.mtimes['config'] = self._ler('config', {})
            self.usuarios, self.mtimes['usuarios'] = self._ler('usuarios', {})
            if self.config:
                self.config = mesclar_padrao(config_padrao(), self.config)

    def sincronizar(self):
        """Recarrega arquivos alterados por fora (ex.: sincronização do Google Drive)."""
        alterados = []
        for nome in COLECOES + ('config', 'usuarios'):
            try:
                mt = os.path.getmtime(self._arq(nome))
            except OSError:
                continue
            if mt != self.mtimes.get(nome):
                conteudo, mt = self._ler(nome, {} if nome in ('config', 'usuarios') else [])
                if nome == 'config':
                    self.config = mesclar_padrao(config_padrao(), conteudo)
                elif nome == 'usuarios':
                    self.usuarios = conteudo
                else:
                    self.c[nome] = conteudo
                self.mtimes[nome] = mt
                alterados.append(nome)
        return alterados

    def salvar(self, *nomes):
        with self.trava:
            for nome in dict.fromkeys(nomes):
                if nome == 'config':
                    self._gravar('config', self.config)
                elif nome == 'usuarios':
                    self._gravar('usuarios', self.usuarios)
                else:
                    self._gravar(nome, self.c[nome])

    def recarregar(self, nome):
        if nome == 'config':
            conteudo, self.mtimes[nome] = self._ler('config', {})
            self.config = mesclar_padrao(config_padrao(), conteudo) if conteudo else conteudo
        elif nome == 'usuarios':
            self.usuarios, self.mtimes[nome] = self._ler('usuarios', {})
        else:
            self.c[nome], self.mtimes[nome] = self._ler(nome, [])

    @contextlib.contextmanager
    def transacao(self, *nomes):
        """Executa uma operação e grava as coleções envolvidas.

        A memória sempre espelha o disco entre operações; se algo falhar no meio,
        as coleções afetadas são relidas do disco e nada fica pela metade.
        """
        with self.trava:
            try:
                yield
            except Exception:
                for n in dict.fromkeys(nomes):
                    self.recarregar(n)
                raise
            self.salvar(*nomes)


def config_padrao():
    return {
        'loja': {
            'nome': 'Minha Loja', 'razao_social': '', 'cnpj': '', 'telefone': '', 'whatsapp': '',
            'instagram': '', 'email': '', 'endereco': '', 'cidade': '',
            'mensagem_recibo': 'Obrigada pela preferência!',
        },
        'fiscal': {'regime': 'simples', 'aliquota_simples': 4.0},
        'taxas': {'dinheiro': 0, 'pix': 0, 'debito': 1.5, 'credito_1': 3.2, 'credito_2_6': 4.3,
                  'credito_7_12': 5.5, 'crediario': 0, 'vale': 0, 'cashback': 0},
        'prazos': {'debito': 1, 'credito': 30, 'pix': 0},
        'antecipacao_credito': False,
        'baixa_automatica_cartao': True,
        'precificacao': {'metodo': 'margem', 'margem_padrao': 20, 'markup_padrao': 2.2,
                         'taxa_cartao_media': 3.0, 'comissao': 0, 'despesas_fixas_pct': 18,
                         'arredondamento': '90'},
        'fidelidade': {'ativo': True, 'cashback_pct': 5, 'validade_dias': 90,
                       'uso_minimo_compra': 50, 'uso_max_pct': 30},
        'vales': {'validade_dias': 90, 'presente_validade_dias': 365},
        'condicional': {'prazo_dias': 3, 'max_pecas': 10},
        'crediario': {'max_parcelas': 4, 'multa_atraso_pct': 0, 'juros_mes_pct': 0},
        'consumidor': {
            'politica_troca': POLITICA_TROCA_PADRAO, 'prazo_troca_dias': 30,
            'imprimir_politica': True, 'imprimir_garantia': True,
        },
        'conformidade': {'itens': {}, 'revisado_em': ''},
        'integracoes': {
            'nfe': {'ativo': False, 'provedor': 'focusnfe', 'ambiente': 'homologacao', 'emitir': 'perguntar',
                    'ncm_padrao': '', 'cfop': '5102', 'csosn': '102', 'origem': '0', 'pis_cst': '49', 'cofins_cst': '49',
                    'informacoes_adicionais': ''},
            'pix': {'ativo': False, 'provedor': 'mercadopago', 'email_pagador': '', 'banco': '', 'url_api': '',
                    'url_token': '', 'client_id': '', 'chave_pix': '', 'escopo': '', 'parametro_url': '', 'cabecalhos': {},
                    'minutos': 30, 'modo_token': 'basic_form'},
            'cartoes': {'mapas': {}},
        },
        'estoque': {'permitir_negativo': False, 'dias_parado': 90},
        'grades': {
            'Letras': 'PP,P,M,G,GG', 'Numeração feminina': '34,36,38,40,42,44,46',
            'Numeração masculina': '38,40,42,44,46,48', 'Plus size': 'G1,G2,G3,G4',
            'Calçados': '33,34,35,36,37,38,39,40', 'Infantil': '2,4,6,8,10,12,14,16',
            'Tamanho único': 'U',
        },
        'cores': ('Preto,Branco,Off-white,Bege,Caramelo,Marrom,Cinza,Azul-marinho,Azul,Jeans claro,'
                  'Jeans escuro,Verde,Verde-militar,Vermelho,Vinho,Rosa,Lilás,Amarelo,Laranja,'
                  'Dourado,Prata,Estampado,Animal print'),
        'financeiro': {'saldo_inicial': 0, 'data_saldo_inicial': hoje()},
        'metas': {},
        'pix': {'chave': '', 'tipo_chave': 'cpf', 'nome': '', 'cidade': ''},
        'mei': {'abertura': '', 'limite_anual': 81000, 'cnpj_avisar': True},
        'seguranca': {'bloqueio_min': 30},
        'licenca': {'chave': '', 'inicio_teste': ''},
        'aparencia': {},
        'painel': {},
        'whatsapp': {
            'aniversario': 'Oi, {nome}! A equipe da {loja} deseja um feliz aniversário! Neste mês você tem um desconto especial esperando por você aqui na loja.',
            'novidades': 'Oi, {nome}! Chegaram novidades na {loja} e lembrei de você. Quer que eu te mande fotos das peças?',
            'cobranca': 'Oi, {nome}, tudo bem? Passando para lembrar da parcela de {valor} com vencimento em {vencimento}. Qualquer dúvida, estou à disposição!',
            'condicional': 'Oi, {nome}! As peças do seu condicional vencem em {prazo}. Me avisa quando puder trazer ou se quiser ficar com alguma!',
            'recibo': 'Obrigada pela compra, {nome}! Venda nº {numero} no valor de {valor}. Volte sempre à {loja}!',
            'reativacao': 'Oi, {nome}! Faz tempo que você não aparece na {loja}. Separei algumas novidades com a sua cara. Vem ver!',
            'cashback': 'Oi, {nome}! Você tem {valor} de cashback na {loja}, válido até {validade}. Aproveite!',
        },
        'seq': {'venda': 0, 'produto': 0, 'codigo': 0, 'condicional': 0, 'entrada': 0, 'troca': 0},
        'versao': VERSAO,
    }


def verificar_dependencias(somente_programa=False):
    """Confere o que o programa precisa para rodar e devolve uma lista de itens verificados."""
    itens = []

    def item(nome, ok, detalhe, critico=False):
        itens.append({'item': nome, 'ok': bool(ok), 'detalhe': detalhe, 'critico': critico})

    v = sys.version_info
    item('Python 3.8 ou superior', v >= (3, 8), f'Instalado: {platform.python_version()}', True)
    item('Criptografia (hashlib/PBKDF2)', hasattr(hashlib, 'pbkdf2_hmac'), 'Biblioteca padrão do Python', True)
    faltando = [a for a in ('index.html', 'css/app.css', 'js/core.js', 'js/main.js')
                if not os.path.isfile(os.path.join(WEB_DIR, a))]
    item('Arquivos da interface', not faltando, 'Completos' if not faltando else 'Faltando: ' + ', '.join(faltando), True)
    item('Conexão segura (TLS)', hasattr(ssl, 'PROTOCOL_TLS_SERVER'), 'Para o acesso pelo celular', True)
    if somente_programa:
        return itens
    try:
        os.makedirs(DADOS_DIR, exist_ok=True)
        teste = os.path.join(DADOS_DIR, '.teste_escrita')
        with open(teste, 'w', encoding='utf-8') as f:
            f.write('ok')
        os.remove(teste)
        escrita = True
    except OSError:
        escrita = False
    item('Permissão de gravação na pasta de dados', escrita, DADOS_DIR, True)
    try:
        livre = shutil.disk_usage(PASTA_LOJA).free / 1024 ** 3
        item('Espaço livre em disco', livre > 0.2, f'{livre:.1f} GB livres')
    except OSError:
        pass
    nuvem = detectar_nuvem(PASTA_LOJA)
    item('Pasta sincronizada na nuvem', bool(nuvem),
         f'Detectado: {nuvem} — cópia automática dos dados' if nuvem else
         'Recomendado: coloque a pasta do sistema dentro do Google Drive, Dropbox ou OneDrive')
    item('Sistema operacional', True, f'{platform.system()} {platform.release()}')
    return itens


# ------------------------------------------------------------------ backups

PADRAO_BACKUP = re.compile(r'backup-(\d{8})-(\d{6})\.(lojabkp|zip)')


def chave_backup(chave):
    return hmac.new(chave, b'loja-erp/backup', hashlib.sha256).digest()


def compactar_dados():
    """Compacta a pasta de dados em memória (zip) e devolve (bytes, quantidade de arquivos)."""
    memoria = io.BytesIO()
    total = 0
    with zipfile.ZipFile(memoria, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for raiz, pastas, arquivos in os.walk(DADOS_DIR):
            pastas[:] = [p for p in pastas if not p.startswith('_')]
            for a in sorted(arquivos):
                if a.endswith('.tmp') or a.startswith('.') or '.corrompido-' in a:
                    continue
                completo = os.path.join(raiz, a)
                z.write(completo, os.path.relpath(completo, PASTA_LOJA).replace(os.sep, '/'))
                total += 1
    return memoria.getvalue(), total


def ler_cabecalho_backup(caminho):
    """Lê o cabeçalho público de um backup (sem a chave). Devolve (cabeçalho, deslocamento do conteúdo)."""
    with open(caminho, 'rb') as f:
        if f.read(len(MAGICO_BACKUP)) != MAGICO_BACKUP:
            raise ValueError('arquivo não é um backup do Loja ERP')
        tamanho = int.from_bytes(f.read(4), 'big')
        if not 0 < tamanho < 1024 * 1024:
            raise ValueError('cabeçalho de backup inválido')
        cab = json.loads(f.read(tamanho).decode('utf-8'))
    return cab, len(MAGICO_BACKUP) + 4 + tamanho


def abrir_backup(caminho, login, segredo):
    """Decifra um backup e devolve o zip em bytes. Aceita backups antigos em .zip simples."""
    if caminho.endswith('.zip'):
        with open(caminho, 'rb') as f:
            return f.read()
    cab, inicio = ler_cabecalho_backup(caminho)
    chave = chave_por_segredo(cab.get('acesso') or {}, login, segredo)
    if not chave:
        raise ErroNegocio('Usuário, senha ou código de recuperação não conferem com este backup.')
    with open(caminho, 'rb') as f:
        f.seek(inicio)
        blob = f.read()
    try:
        conteudo = Cofre(chave_backup(chave)).decifrar_bytes(blob)
    except ValueError:
        raise ErroNegocio('O arquivo de backup está danificado (falha na verificação de integridade).')
    if hashlib.sha256(conteudo).hexdigest() != cab.get('sha256'):
        raise ErroNegocio('O arquivo de backup está danificado (conteúdo diferente do registrado).')
    return conteudo


def validar_zip_dados(conteudo):
    """Confere o zip do backup e impede caminhos fora da pasta de dados."""
    with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
        infos = z.infolist()
        if len(infos) > 200_000 or sum(i.file_size for i in infos) > LIMITE_DESCOMPACTADO:
            raise ErroNegocio('O backup é grande demais para ser restaurado por aqui.')
        if z.testzip() is not None:
            raise ErroNegocio('O backup contém arquivos danificados.')
        nomes = z.namelist()
    for nome in nomes:
        partes = nome.replace('\\', '/').split('/')
        if partes[0] != 'dados' or '..' in partes or nome.startswith('/') or ':' in nome:
            raise ErroNegocio('O backup contém caminhos inválidos e não foi restaurado.')
    if 'dados/usuarios.json' not in nomes:
        raise ErroNegocio('O backup não contém os usuários da loja.')
    return len(nomes)


def selecionar_retencao(nomes, hoje_d=None):
    """Mantém: todos dos últimos 14 dias, 1 por semana por 12 semanas e 1 por mês por 24 meses."""
    hoje_d = hoje_d or dt.date.today()
    manter, semanas, meses = set(), set(), set()
    for nome in sorted(nomes):
        m = PADRAO_BACKUP.fullmatch(nome)
        if not m:
            continue
        dia = dt.datetime.strptime(m.group(1), '%Y%m%d').date()
        idade = (hoje_d - dia).days
        semana, mes = dia.isocalendar()[:2], (dia.year, dia.month)
        if idade <= 14:
            manter.add(nome)
        elif idade <= 84 and semana not in semanas:
            manter.add(nome)
        elif idade <= 730 and mes not in meses:
            manter.add(nome)
        semanas.add(semana)
        meses.add(mes)
    return manter


def detectar_nuvem(caminho):
    c = caminho.lower()
    for chave, nome in (('meu drive', 'Google Drive'), ('my drive', 'Google Drive'), ('google drive', 'Google Drive'),
                        ('googledrive', 'Google Drive'), ('dropbox', 'Dropbox'), ('onedrive', 'OneDrive')):
        if chave in c:
            return nome
    return None


_cache_processos = {'quando': 0.0, 'nomes': None}


def app_de_sincronizacao_ativo(nuvem):
    """No Windows, confere se o aplicativo de sincronização está em execução (None = não foi possível saber)."""
    if sys.platform != 'win32' or not nuvem:
        return None
    if time.time() - _cache_processos['quando'] > 60:
        try:
            r = subprocess.run(['tasklist', '/FO', 'CSV', '/NH'], capture_output=True, text=True, timeout=10,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            _cache_processos['nomes'] = r.stdout.lower()
        except (OSError, subprocess.SubprocessError):
            _cache_processos['nomes'] = None
        _cache_processos['quando'] = time.time()
    nomes = _cache_processos['nomes']
    if nomes is None:
        return None
    esperado = {'Google Drive': ('googledrivefs.exe',), 'OneDrive': ('onedrive.exe',), 'Dropbox': ('dropbox.exe',)}[nuvem]
    return any(e in nomes for e in esperado)


def arquivos_de_conflito():
    """Arquivos criados pelo Drive/OneDrive/Dropbox quando há edição simultânea (ex.: "vendas (1).json")."""
    esperados = {n + '.json' for n in COLECOES} | {'config.json', 'usuarios.json', 'auditoria.log'}
    conflitos = []
    try:
        for nome in os.listdir(DADOS_DIR):
            completo = os.path.join(DADOS_DIR, nome)
            if os.path.isdir(completo) or nome.startswith('.') or nome in esperados or nome.endswith('.tmp'):
                continue
            if nome.endswith(('.json', '.log')) or re.search(r'conflit|\(\d+\)', nome, re.I):
                conflitos.append(nome)
    except OSError:
        pass
    return sorted(conflitos)


def ler_auditoria(limite=400):
    if not os.path.exists(ARQ_AUDITORIA):
        return []
    with open(ARQ_AUDITORIA, 'r', encoding='utf-8', errors='replace') as f:
        linhas = f.readlines()
    return [x.rstrip('\n') for x in reversed(linhas[-limite:])]


def ultimo_hash_auditoria():
    linhas = ler_auditoria(1)
    if linhas and ' | #' in linhas[0]:
        return linhas[0].rsplit(' | #', 1)[1].strip()
    return ''


def verificar_auditoria():
    """Confere o encadeamento do registro de auditoria. Devolve (íntegro, número da primeira linha alterada)."""
    if not os.path.exists(ARQ_AUDITORIA):
        return True, None
    anterior = ''
    with open(ARQ_AUDITORIA, 'r', encoding='utf-8', errors='replace') as f:
        for numero, linha in enumerate(f, 1):
            linha = linha.rstrip('\n')
            if ' | #' not in linha:
                continue
            base, elo = linha.rsplit(' | #', 1)
            if hashlib.sha256((anterior + base).encode('utf-8')).hexdigest()[:16] != elo:
                return False, numero
            anterior = elo
    return True, None


# ------------------------------------------------------------ pacote do contador

def _csv(cabecalho, linhas):
    """CSV no jeito do Excel brasileiro: ponto e vírgula, vírgula decimal e BOM."""
    saida = io.StringIO()
    escritor = csv.writer(saida, delimiter=';', lineterminator='\r\n')
    escritor.writerow(cabecalho)
    def celula(v):
        if isinstance(v, float):
            return f'{v:.2f}'.replace('.', ',')
        texto = str(v)
        # Texto que começa com = + - @ vira fórmula no Excel (ex.: mensagem do Pix no extrato): neutraliza.
        return "'" + texto if texto[:1] in ('=', '+', '-', '@', '\t', '\r') else texto
    for linha in linhas:
        escritor.writerow([celula(v) for v in linha])
    return ('﻿' + saida.getvalue()).encode('utf-8')


def pacote_contador(app, mes, dre):
    """Monta o ZIP do mês para o contador: DRE, vendas, notas (XML), financeiro, vales, trocas, caixa e extrato."""
    b = app.banco
    no_mes = lambda texto: str(texto or '')[:7] == mes  # noqa: E731
    vendas = [v for v in b.c['vendas'] if no_mes(v.get('data'))]
    forma = lambda v: ' + '.join(f'{FORMAS_LEGIVEIS.get(p["forma"], p["forma"])} {p["valor"]:.2f}'.replace('.', ',') for p in v['pagamentos'])  # noqa: E731
    arquivos = {}
    loja = b.config.get('loja') or {}
    arquivos['LEIA-ME.txt'] = (
        f'Pacote do mês {mes[5:]}/{mes[:4]} — {loja.get("nome", "")} {("CNPJ " + loja["cnpj"]) if loja.get("cnpj") else ""}\r\n'
        f'Gerado pelo Loja ERP {VERSAO} em {dt.datetime.now():%d/%m/%Y %H:%M}.\r\n\r\n'
        'dre.csv                Resultado do mês (o mesmo da tela DRE do sistema; valores gerenciais).\r\n'
        'vendas.csv             Vendas do mês, com formas de pagamento e nota fiscal.\r\n'
        'itens-vendidos.csv     Peças vendidas, com custo.\r\n'
        'notas-fiscais.csv      NFC-e emitidas pela integração (e notas registradas à mão).\r\n'
        'nfe/                   XML das NFC-e autorizadas (guarde por 5 anos).\r\n'
        'financeiro.csv         Contas a pagar e a receber com vencimento ou pagamento no mês.\r\n'
        'vales.csv              Vales-troca e vales-presente: emitidos, usados e saldo em aberto.\r\n'
        'trocas.csv             Trocas e devoluções do mês.\r\n'
        'caixa.csv              Fechamentos de caixa do mês.\r\n'
        'extrato-conciliado.csv Movimentações dos extratos importados e com o que casaram.\r\n\r\n'
        'Os valores do DRE são gerenciais e não substituem a escrituração contábil.\r\n').encode('utf-8')
    arquivos['dre.csv'] = _csv(['Linha', 'Valor (R$)'], [[str(l[0])[:80], float(num(l[1]))] for l in dre if isinstance(l, (list, tuple)) and len(l) == 2])
    arquivos['vendas.csv'] = _csv(
        ['Número', 'Data', 'Situação', 'Subtotal', 'Descontos', 'Total', 'Pagamentos', 'Troco', 'Venda fora da loja', 'Nota pedida', 'Nota fiscal', 'Chave NFC-e'],
        [[v['numero'], v['data'][:16].replace('T', ' '), v['status'], float(v['subtotal']), float(v['desconto_itens'] + v['desconto_carrinho']),
          float(v['total']), forma(v), float(v.get('troco') or 0), 'sim' if v.get('distancia') else 'não',
          'sim' if (v.get('nota') or {}).get('pedida') else 'não', (v.get('nota') or {}).get('numero', ''),
          (v.get('nfe') or {}).get('chave', '') if (v.get('nfe') or {}).get('status') == 'autorizado' else ''] for v in vendas])
    arquivos['itens-vendidos.csv'] = _csv(
        ['Venda', 'Data', 'Produto', 'Tamanho', 'Cor', 'Quantidade', 'Preço unitário', 'Desconto', 'Total', 'Custo unitário'],
        [[v['numero'], v['data'][:10], i['nome'], i.get('tamanho', ''), i.get('cor', ''), i['qtd'], float(i['preco_unit']),
          float(i.get('desconto') or 0), float(i['total']), float(i.get('custo_unit') or 0)]
         for v in vendas if v['status'] == 'concluida' for i in v['itens']])
    linhas_nf = []
    for v in vendas:
        nfe = v.get('nfe') or {}
        if nfe.get('status') or (v.get('nota') or {}).get('numero'):
            linhas_nf.append([v['numero'], v['data'][:10], nfe.get('status') or 'registrada à mão', nfe.get('numero', ''), nfe.get('serie', ''),
                              nfe.get('chave', ''), nfe.get('ambiente', ''), float(v['total']), (v.get('nota') or {}).get('numero', '')])
            if nfe.get('xml_local') and app.cofre:
                try:
                    with open(os.path.join(DADOS_DIR, nfe['xml_local']), 'rb') as f:
                        arquivos[f'nfe/{os.path.basename(nfe["xml_local"])[:-4]}'] = app.cofre.decifrar_bytes(f.read())
                except (OSError, ValueError):
                    pass
    arquivos['notas-fiscais.csv'] = _csv(['Venda', 'Data', 'Situação', 'Número', 'Série', 'Chave', 'Ambiente', 'Valor', 'Registro'], linhas_nf)
    contas = {c['id']: c['nome'] for c in b.c['plano_contas']}
    fin = [f for f in b.c['financeiro'] if f['status'] != 'cancelado' and (no_mes(f.get('vencimento')) or no_mes(f.get('pago_em')))]
    arquivos['financeiro.csv'] = _csv(
        ['Tipo', 'Descrição', 'Categoria', 'Forma', 'Vencimento', 'Situação', 'Pago em', 'Valor', 'Taxa', 'Líquido', 'Valor pago', 'Conferido no extrato'],
        [['a receber' if f['tipo'] == 'receber' else 'a pagar', f['descricao'], contas.get(f.get('categoria_id'), ''), f.get('forma', ''),
          f.get('vencimento', ''), f['status'], f.get('pago_em') or '', float(f['valor']), float(f.get('taxa') or 0),
          float(f.get('liquido') if f.get('liquido') is not None else f['valor']), float(f['valor_pago']) if f.get('valor_pago') is not None else '',
          'sim' if f.get('conferido_extrato') else ''] for f in fin])
    vales = [x for x in b.c['vales'] if no_mes(x.get('criado_em')) or any(no_mes(u.get('data')) for u in x.get('usos', []))
             or (x['status'] == 'ativo' and str(x.get('criado_em') or '')[:7] <= mes)]
    arquivos['vales.csv'] = _csv(
        ['Código', 'Tipo', 'Emitido em', 'Validade', 'Valor', 'Usado no mês', 'Saldo atual', 'Situação'],
        [[x['codigo'], NOME_VALE.get(x.get('tipo'), 'Vale-troca'), str(x.get('criado_em') or '')[:10], x.get('validade') or 'sem prazo',
          float(x['valor']), float(sum(u['valor'] for u in x.get('usos', []) if no_mes(u.get('data')))), float(x['saldo']), x['status']]
         for x in vales])
    arquivos['trocas.csv'] = _csv(
        ['Número', 'Data', 'Venda', 'Valor', 'Destino', 'Motivo', 'Peças'],
        [[t['numero'], t['data'][:10], t.get('venda_numero') or '', float(t['total']), t['destino'], t.get('motivo', ''),
          '; '.join(f'{i["qtd"]}x {i["nome"]} {i["tamanho"]}/{i["cor"]}' for i in t['itens'])]
         for t in b.c['trocas'] if no_mes(t.get('data'))])
    arquivos['caixa.csv'] = _csv(
        ['Aberto em', 'Fechado em', 'Valor inicial', 'Esperado', 'Contado', 'Diferença'],
        [[c.get('aberto_em', '')[:16].replace('T', ' '), str(c.get('fechado_em') or '')[:16].replace('T', ' '), float(c.get('valor_inicial') or 0),
          float(c.get('esperado') or 0), float(c.get('contado') or 0), float(c.get('diferenca') or 0)]
         for c in b.c['caixa'] if no_mes(c.get('aberto_em'))])
    arquivos['extrato-conciliado.csv'] = _csv(
        ['Data', 'Descrição', 'Valor', 'Banco', 'Conta (final)', 'Situação'],
        [[t['data'], t.get('descricao', ''), float(t['valor']), c.get('banco', ''), c.get('conta', ''),
          'conciliada' if t.get('ids') else 'lançada' if t.get('lancado') else 'sem par']
         for c in b.c['conciliacoes'] if c.get('tipo') == 'extrato' for t in c.get('transacoes', []) if no_mes(t.get('data'))])
    memoria = io.BytesIO()
    with zipfile.ZipFile(memoria, 'w', zipfile.ZIP_DEFLATED) as z:
        for nome, dados in arquivos.items():
            z.writestr(nome, dados)
    return memoria.getvalue()


# --------------------------------------------------------------------- núcleo

class Aplicacao:
    def __init__(self, banco, porta):
        self.banco = banco
        self.porta = porta
        self.token = secrets.token_urlsafe(24)
        self.sessoes = {}
        self.chave = None
        self.cofre = None
        self.falhas = {}          # origem -> [tentativas erradas, bloqueado até]
        self.origem = 'local'     # quem fez a requisição em andamento (sempre sob app.trava)
        self.dia_rotina = None
        self.id_instancia = secrets.token_hex(8)
        self.ultimo_acesso = time.time()
        self.marcar_exemplo = False
        self.aviso_uso = ''
        self.recuperacao = ''
        self.trava = threading.RLock()
        self.trava_auditoria = threading.Lock()
        self.hash_auditoria = None
        self.servidor_celular = None
        self.impressao_celular = ''
        self.pareamentos = {}
        self.trava_celular = threading.RLock()
        self.celular = self._ler_celular()
        self.atualizador = atualizacao.Atualizador(BASE_DIR, pasta_estado_local(), VERSAO, log=print)
        self.pedido_reinicio = False

    # ------------------------------------------------------------ celular (rede local)
    @staticmethod
    def _arq_celular():
        return arquivo_instancia().replace('instancia-', 'celular-')

    def _ler_celular(self):
        try:
            with open(self._arq_celular(), 'r', encoding='utf-8') as f:
                e = json.load(f)
        except (OSError, ValueError):
            e = {}
        e.setdefault('ativo', False)
        e.setdefault('porta', PORTA_CELULAR)
        e.setdefault('aparelhos', [])
        return e

    def _salvar_celular(self):
        """Grava o estado do celular (chame com trava_celular). Arquivo temporário único por gravação."""
        temporario = f'{self._arq_celular()}.{secrets.token_hex(4)}.tmp'
        with open(temporario, 'w', encoding='utf-8') as f:
            json.dump(self.celular, f, ensure_ascii=False, indent=1)
        os.replace(temporario, self._arq_celular())

    def ligar_celular(self):
        if self.servidor_celular:
            return
        ips = celular.ips_locais()
        if not ips:
            raise ErroNegocio('Este computador não está ligado a uma rede local (Wi-Fi ou cabo). Conecte e tente de novo.')
        contexto, self.impressao_celular = celular.preparar_certificado(pasta_estado_local(), ips)
        try:
            srv = ServidorCelular(('0.0.0.0', int(self.celular['porta'])), ManipuladorCelular, contexto)
        except OSError:
            srv = ServidorCelular(('0.0.0.0', porta_livre(PORTA_CELULAR, '0.0.0.0')), ManipuladorCelular, contexto)
        srv.app = self
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        self.servidor_celular = srv
        with self.trava_celular:
            self.celular.update(ativo=True, porta=srv.server_address[1])
            self._salvar_celular()
        print(f'{agora()} acesso pelo celular ligado: https://{ips[0]}:{srv.server_address[1]}')

    def desligar_celular(self, lembrar=True):
        srv, self.servidor_celular = self.servidor_celular, None
        if srv:
            srv.shutdown()
            srv.server_close()
        with self.trava_celular:
            self.pareamentos.clear()
            if lembrar:
                self.celular['ativo'] = False
                self._salvar_celular()

    def aparelho_valido(self, tok):
        """Devolve o aparelho dono da chave (pode estar aguardando permissão) ou None."""
        if not tok or len(tok) > 100:
            return None
        h = hashlib.sha256(tok.encode()).hexdigest()
        with self.trava_celular:
            agora_ts = time.time()
            antes = len(self.celular['aparelhos'])
            self.celular['aparelhos'] = [a for a in self.celular['aparelhos']
                                         if not a.get('pendente') or a.get('expira', 0) > agora_ts]
            mudou = len(self.celular['aparelhos']) != antes
            achado = None
            for a in self.celular['aparelhos']:
                if hmac.compare_digest(a['hash'], h):
                    achado = a
                    if not a.get('pendente') and agora_ts - a.get('visto', 0) > 300:
                        a['visto'] = agora_ts
                        a['ultimo_uso'] = agora()
                        mudou = True
            if mudou:
                try:
                    self._salvar_celular()
                except OSError:
                    pass
            return achado

    def parear(self, codigo, agente):
        """Troca um código de QR (uso único) por uma chave de aparelho, que fica aguardando
        alguém clicar em "Permitir" no computador, conferindo o código curto mostrado nos dois."""
        with self.trava_celular:
            agora_ts = time.time()
            for c in [c for c, t in self.pareamentos.items() if t <= agora_ts]:
                self.pareamentos.pop(c, None)
            achado = next((c for c in self.pareamentos if hmac.compare_digest(c.encode(), str(codigo).encode())), None)
            if not achado or self.pareamentos.pop(achado, None) is None:
                return None
            tok = secrets.token_urlsafe(32)
            nome = celular.nome_aparelho(agente)
            self.celular['aparelhos'].append({
                'id': novo_id(), 'nome': nome, 'hash': hashlib.sha256(tok.encode()).hexdigest(),
                'pendente': True, 'conferencia': f'{secrets.randbelow(10000):04d}', 'expira': agora_ts + 300,
                'criado_em': agora(), 'ultimo_uso': agora(), 'visto': agora_ts})
            self._salvar_celular()
        return tok

    def resumo_celular(self):
        ips = celular.ips_locais() if self.servidor_celular else []
        porta = self.servidor_celular.server_address[1] if self.servidor_celular else self.celular['porta']
        with self.trava_celular:
            aparelhos = [{k: a.get(k) for k in ('id', 'nome', 'criado_em', 'ultimo_uso')}
                         for a in self.celular['aparelhos'] if not a.get('pendente')]
            pendentes = [{k: a.get(k) for k in ('id', 'nome', 'conferencia')}
                         for a in self.celular['aparelhos'] if a.get('pendente') and a.get('expira', 0) > time.time()]
        contatos = dict(self.servidor_celular.contatos) if self.servidor_celular else {}
        # Testes feitos no próprio computador (o IP dele ou 127.0.0.1) não contam como celular.
        externos = {ip: t for ip, t in contatos.items() if ip not in ips and not ip.startswith('127.')}
        ultimo = max(externos.items(), key=lambda x: x[1]) if externos else None
        return {'ativo': bool(self.servidor_celular), 'porta': porta, 'ips': ips, 'impressao': self.impressao_celular,
                'ultimo_contato': {'ip': ultimo[0], 'segundos': int(time.time() - ultimo[1])} if ultimo else None,
                'windows': sys.platform == 'win32', 'aparelhos': aparelhos, 'pendentes': pendentes}

    def op_celular_ativar(self, d, usuario):
        if d.get('ativo'):
            self.ligar_celular()
            self.auditar(usuario, 'celular_ligado')
        else:
            self.desligar_celular()
            self.auditar(usuario, 'celular_desligado')
        return dict(self.resumo_celular(), ok=True)

    def op_celular_parear(self, d, usuario):
        if not self.servidor_celular:
            raise ErroNegocio('Ligue o acesso pelo celular primeiro.')
        codigo = secrets.token_urlsafe(18)
        with self.trava_celular:
            self.pareamentos[codigo] = time.time() + VALIDADE_PAREAMENTO
        porta = self.servidor_celular.server_address[1]
        return {'ok': True, 'validade': VALIDADE_PAREAMENTO,
                'enderecos': [f'https://{ip}:{porta}/parear?c={codigo}' for ip in celular.ips_locais()]}

    def op_celular_permitir(self, d, usuario):
        with self.trava_celular:
            a = next((x for x in self.celular['aparelhos'] if x['id'] == d.get('id') and x.get('pendente')), None)
            if not a:
                raise ErroNegocio('Este pedido de conexão não existe mais. Gere um QR Code novo.')
            if d.get('permitir'):
                for k in ('pendente', 'conferencia', 'expira'):
                    a.pop(k, None)
            else:
                self.celular['aparelhos'].remove(a)
            self._salvar_celular()
        self.auditar(usuario, 'celular_conectado' if d.get('permitir') else 'celular_recusado', a['nome'])
        return dict(self.resumo_celular(), ok=True)

    def op_celular_remover(self, d, usuario):
        with self.trava_celular:
            antes = len(self.celular['aparelhos'])
            if d.get('todos'):
                self.celular['aparelhos'] = []
            else:
                self.celular['aparelhos'] = [a for a in self.celular['aparelhos'] if a['id'] != d.get('id')]
            self._salvar_celular()
            removidos = antes - len(self.celular['aparelhos'])
        self.auditar(usuario, 'celular_removido', str(removidos))
        return dict(self.resumo_celular(), ok=True)

    # ---------------------------------------------------------------------- licença
    def _arq_licenca_local(self):
        return arquivo_instancia().replace('instancia-', 'licenca-')

    def situacao_licenca(self):
        if self.banco is None or not self.banco.config:
            return licenca.situacao({})
        reg = dict(self.banco.config.get('licenca') or {})
        if not reg.get('inicio_teste'):
            # Loja que já usava o sistema antes das licenças: o teste grátis começa agora.
            reg['inicio_teste'] = hoje()
            with self.banco.transacao('config'):
                self.banco.config.setdefault('licenca', {})['inicio_teste'] = reg['inicio_teste']
        # Cópia local do início do teste: editar a data na pasta da nuvem não estende o período.
        try:
            with open(self._arq_licenca_local(), 'r', encoding='utf-8') as f:
                local = json.load(f).get('inicio_teste', '')
        except (OSError, ValueError):
            local = ''
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', local or '') and local < reg['inicio_teste']:
            reg['inicio_teste'] = local
        elif local != reg['inicio_teste']:
            try:
                with open(self._arq_licenca_local(), 'w', encoding='utf-8') as f:
                    json.dump({'inicio_teste': reg['inicio_teste']}, f)
            except OSError:
                pass
        return licenca.situacao(reg)

    def resumo_licenca(self):
        s = self.situacao_licenca()
        return {k: s[k] for k in ('plano', 'nome_plano', 'estado', 'mensagem', 'valida_ate', 'dias_restantes')}

    def op_licenca_ativar(self, d, usuario):
        try:
            dados = licenca.ler_chave(d.get('chave'))
        except ValueError as e:
            raise ErroNegocio(str(e))
        if dados['valida_ate'] < hoje():
            raise ErroNegocio(f'Esta chave venceu em {dados["valida_ate"][8:10]}/{dados["valida_ate"][5:7]}/{dados["valida_ate"][:4]}. '
                              'Peça uma chave nova.')
        with self.banco.transacao('config'):
            self.banco.config.setdefault('licenca', {})['chave'] = re.sub(r'\s+', '', str(d.get('chave')))
            self.banco.config['licenca']['ativada_em'] = agora()
        self.auditar(usuario, 'licenca_ativada', f'{dados["plano"]} até {dados["valida_ate"]} ({dados.get("id", "")})')
        return dict(self.situacao_licenca(), ok=True)

    # ------------------------------------------------------------------ atualização
    def op_atualizacao_verificar(self, d, usuario):
        return dict(self.atualizador.verificar(baixar=True), ok=True)

    def op_atualizacao_config(self, d, usuario):
        self.atualizador.estado['automatica'] = bool(d.get('automatica'))
        self.atualizador.salvar()
        self.auditar(usuario, 'atualizacao_automatica', 'ligada' if d.get('automatica') else 'desligada')
        return dict(self.atualizador.resumo(), ok=True)

    def op_atualizacao_instalar(self, d, usuario):
        if not self.atualizador.pode_aplicar():
            raise ErroNegocio('Não há atualização pronta para instalar.')
        self.auditar(usuario, 'atualizacao_instalada', self.atualizador.estado['pronta']['versao'])
        self.pedido_reinicio = True
        return {'ok': True, 'reiniciando': True, '_encerrar': True}

    # ---------------------------------------------------------- sessão / auditoria
    def criar_sessao(self, login):
        tok = secrets.token_urlsafe(32)
        self.sessoes[tok] = {'login': login, 'visto': time.time(), 'token': tok}
        return tok

    def sessao_valida(self, tok):
        if not tok:
            return None
        s = self.sessoes.get(tok)
        if not s:
            return None
        if time.time() - s['visto'] > SESSAO_MAX_INATIVA or (self.banco and not self._usuario(s['login'])):
            self.sessoes.pop(tok, None)
            return None
        s['visto'] = time.time()
        return s

    def encerrar_sessoes(self, login, exceto=None):
        for tok, sess in list(self.sessoes.items()):
            if sess['login'] == login and tok != exceto:
                self.sessoes.pop(tok, None)

    def auditar(self, usuario, acao, detalhe=''):
        """Registra a ação. Cada linha leva um resumo da anterior: apagar ou editar linhas é detectável."""
        linha = f'{agora()} | {usuario or "-"} | {acao} | {detalhe}'.replace('\n', ' ').replace('\r', ' ')
        with self.trava_auditoria:
            if self.hash_auditoria is None:
                self.hash_auditoria = ultimo_hash_auditoria()
            elo = hashlib.sha256((self.hash_auditoria + linha).encode('utf-8')).hexdigest()[:16]
            try:
                with open(ARQ_AUDITORIA, 'a', encoding='utf-8') as f:
                    f.write(f'{linha} | #{elo}\n')
                self.hash_auditoria = elo
            except OSError:
                pass

    def precisa_setup(self):
        return self.banco is not None and not self.banco.usuarios.get('lista') and not self.banco.tem_dados()

    def usuarios_perdidos(self):
        """A lista de usuários sumiu (conflito de sincronização, arquivo apagado), mas há dados gravados."""
        return self.banco is not None and not self.banco.usuarios.get('lista') and self.banco.tem_dados()

    # --------------------------------------------------------------- despacho
    def papel(self, login):
        u = self._usuario(login) if login else None
        return (u or {}).get('papel', 'vendedora')

    def checar_permissao(self, rota, login, d):
        papel = self.papel(login)
        if papel == 'dona':
            return
        if papel == 'gerente':
            if rota in NEGADO_GERENTE:
                raise ErroNegocio('Seu perfil (gerente) não tem permissão para esta ação.')
            return
        if rota not in PERMITIDO_VENDEDORA:
            raise ErroNegocio('Seu perfil (vendedora) não tem permissão para esta ação. Peça à proprietária.')
        if rota == 'config' and set((d.get('config') or {}).keys()) - {'aparencia', 'painel'}:
            raise ErroNegocio('Seu perfil só pode alterar a aparência e o painel.')
        if rota == 'financeiro/baixar':
            f = achar(self.banco.c['financeiro'], d.get('id'))
            if not f or f['tipo'] != 'receber' or f.get('forma') != 'crediario':
                raise ErroNegocio('Seu perfil só pode receber parcelas de crediário.')
            if d.get('forma') not in ('dinheiro', 'pix', 'debito', 'credito'):
                raise ErroNegocio('Escolha como a cliente pagou: dinheiro, Pix ou cartão.')
            # Valor e data vêm do próprio lançamento: a vendedora não altera quanto nem quando foi pago.
            d.pop('valor_pago', None)
            d['data'] = hoje()
            d['usar_caixa'] = True

    def executar(self, metodo, rota, d, sessao, qs):
        usuario = sessao['login'] if sessao else ''
        if metodo == 'GET':
            if rota == 'estado':
                return self.estado(sessao)
            if rota == 'dados':
                self.rotinas()
                return self.dados(qs, usuario)
            if rota in ('auditoria', 'backups') and self.papel(usuario) == 'vendedora':
                raise ErroNegocio('Seu perfil de acesso não permite esta consulta.')
            if rota == 'auditoria':
                integro, linha = verificar_auditoria()
                return {'linhas': ler_auditoria(), 'integro': integro, 'linha_alterada': linha}
            if rota == 'backups':
                return {'arquivos': self.listar_backups()}
            if rota == 'saude':
                return self.saude()
            if rota == 'licenca':
                s = self.situacao_licenca()
                if self.papel(usuario) == 'vendedora':
                    s = {k: s[k] for k in ('plano', 'nome_plano', 'estado', 'mensagem', 'valida_ate', 'dias_restantes', 'contato', 'ofertas', 'pagamento', 'dias_carencia')}
                return s
            if rota in ('celular', 'atualizacao'):
                if self.papel(usuario) == 'vendedora':
                    raise ErroNegocio('Seu perfil de acesso não permite esta consulta.')
                if rota == 'celular':
                    return self.resumo_celular()
                return dict(self.atualizador.resumo(), programa_na_nuvem=detectar_nuvem(BASE_DIR) or '', pasta_programa=BASE_DIR)
            if rota == 'caixa/resumo':
                c = self.caixa_aberto()
                return {'caixa': c, 'resumo': self.caixa_esperado(c) if c else None}
            raise ErroNegocio('Rota não encontrada.')

        if rota not in ROTAS_PUBLICAS:
            self.checar_permissao(rota, usuario, d)
            if not self.recuperacao and not licenca.operacao_permitida(rota, self.situacao_licenca()['estado']):
                raise ErroNegocio('A licença do Loja ERP venceu e o sistema está em modo de consulta. Seus dados continuam '
                                  'disponíveis para ver, exportar e fazer backup. Renove em Configurações › Licença e plano.')
        if rota.startswith('salvar/'):
            return self.op_salvar_generico(rota[7:], d.get('obj') or {}, usuario)
        if rota.startswith('excluir/'):
            return self.op_excluir_generico(rota[8:], d.get('id'), usuario)

        tabela = {
            'setup': self.op_setup, 'login': self.op_login, 'logout': self.op_logout,
            'recuperar': self.op_recuperar, 'senha': self.op_senha,
            'nova_recuperacao': self.op_nova_recuperacao, 'usuario/adicionar': self.op_usuario_adicionar,
            'usuario/remover': self.op_usuario_remover, 'usuario/papel': self.op_usuario_papel,
            'usuario/senha': self.op_usuario_senha,
            'config': self.op_config,
            'produto/salvar': self.op_produto_salvar, 'produto/excluir': self.op_produto_excluir,
            'cliente/salvar': self.op_cliente_salvar, 'cliente/excluir': self.op_cliente_excluir,
            'venda': self.op_venda_api, 'venda/cancelar': self.op_venda_cancelar, 'venda/nota': self.op_venda_nota,
            'entrada': self.op_entrada, 'entrada/cancelar': self.op_entrada_cancelar,
            'ajuste': self.op_ajuste, 'inventario': self.op_inventario,
            'condicional/abrir': self.op_condicional_abrir, 'condicional/fechar': self.op_condicional_fechar,
            'troca': self.op_troca, 'vale/presente': self.op_vale_presente, 'vale/validade': self.op_vale_validade,
            'vale/cancelar': self.op_vale_cancelar, 'caixa/abrir': self.op_caixa_abrir,
            'integracoes/salvar': self.op_integracoes_salvar, 'integracoes/testar': self.op_integracoes_testar,
            'nfe/emitir': self.op_nfe_emitir, 'nfe/consultar': self.op_nfe_consultar, 'nfe/cancelar': self.op_nfe_cancelar,
            'nfe/danfe': self.op_nfe_danfe, 'pix/cobrar': self.op_pix_cobrar, 'pix/status': self.op_pix_status,
            'pix/cancelar': self.op_pix_cancelar, 'conciliacao/cartoes': self.op_conciliacao_cartoes,
            'conciliacao/extrato': self.op_conciliacao_extrato, 'conciliacao/lancar': self.op_conciliacao_lancar,
            'contador/pacote': self.op_contador_pacote,
            'caixa/movimento': self.op_caixa_movimento, 'caixa/fechar': self.op_caixa_fechar,
            'financeiro/lancar': self.op_fin_lancar, 'financeiro/baixar': self.op_fin_baixar,
            'financeiro/estornar': self.op_fin_estornar, 'financeiro/editar': self.op_fin_editar,
            'financeiro/excluir': self.op_fin_excluir, 'recorrentes/gerar': self.op_recorrentes_gerar,
            'foto': self.op_foto, 'backup': self.op_backup, 'limpar_exemplo': self.op_limpar_exemplo,
            'encerrar': self.op_encerrar, 'restaurar': self.op_restaurar, 'conflito/mover': self.op_conflito_mover,
            'celular/ativar': self.op_celular_ativar, 'celular/parear': self.op_celular_parear,
            'celular/remover': self.op_celular_remover, 'celular/permitir': self.op_celular_permitir,
            'licenca/ativar': self.op_licenca_ativar,
            'atualizacao/verificar': self.op_atualizacao_verificar,
            'atualizacao/config': self.op_atualizacao_config, 'atualizacao/instalar': self.op_atualizacao_instalar,
        }
        funcao = tabela.get(rota)
        if not funcao:
            raise ErroNegocio('Operação desconhecida.')
        if rota in ('setup', 'login', 'recuperar'):
            return funcao(d)
        if rota in ('logout', 'restaurar'):
            return funcao(d, sessao)
        if rota == 'senha':
            d['_token_atual'] = sessao['token']
        return funcao(d, usuario)

    def estado(self, sessao):
        if self.recuperacao:
            return {'recuperacao': self.recuperacao, 'backups': self.resumo_backups_publico(), 'pasta_loja': PASTA_LOJA,
                    'versao': VERSAO, 'credito': CREDITO, 'precisa_setup': False, 'logado': False, 'papeis': PAPEIS}
        logado = bool(sessao and self.cofre)
        return {
            'precisa_setup': self.precisa_setup(),
            'logado': logado,
            'usuario': sessao['login'] if sessao else None,
            'papel': self.papel(sessao['login']) if logado else None,
            'loja': self.banco.config.get('loja', {}).get('nome', '') if self.banco.config else '',
            'versao': VERSAO, 'credito': CREDITO, 'aviso_uso': self.aviso_uso,
            'verificacoes': verificar_dependencias() if self.precisa_setup() else [],
            'backups': self.resumo_backups_publico() if self.precisa_setup() else [],
            'pasta_loja': PASTA_LOJA if logado else '',
            'papeis': PAPEIS,
            'licenca': self.resumo_licenca() if logado else None,
        }

    def dados(self, qs, usuario=''):
        pedido = [x for x in (qs.get('c', [''])[0] or '').split(',') if x]
        nomes = [n for n in pedido if n in COLECOES] if pedido else list(COLECOES)
        papel = self.papel(usuario)
        restrito = papel == 'vendedora'
        saida = {}
        for nome in nomes:
            if nome == 'clientes':
                saida[nome] = [self.cliente_publico(c) for c in self.banco.c['clientes']]
            elif restrito and nome in ('entradas', 'ativos', 'recorrentes', 'conciliacoes'):
                saida[nome] = []
            elif restrito and nome == 'financeiro':
                saida[nome] = [f for f in self.banco.c['financeiro'] if f.get('forma') == 'crediario']
            elif restrito:
                saida[nome] = sem_custos(self.banco.c[nome])
            else:
                saida[nome] = self.banco.c[nome]
        usuarios = [{'login': u['login'], 'nome': u['nome'], 'papel': u.get('papel', '')}
                    for u in self.banco.usuarios.get('lista', [])]
        cfg = dict(self.banco.config)
        cfg['aparencia'] = (self.banco.config.get('aparencia') or {}).get(usuario, {})
        cfg['painel'] = (self.banco.config.get('painel') or {}).get(usuario, {})
        cfg.pop('licenca', None)   # a chave não vai para a tela; a situação vem em 'licenca'
        cfg['integracoes'] = self.integracoes_publicas(papel)
        return {'licenca': self.resumo_licenca(), 'dados': saida, 'config': cfg, 'hoje': hoje(), 'agora': agora(), 'papel': papel, 'pasta_loja': PASTA_LOJA,
                'usuarios': usuarios, 'aviso_uso': self.aviso_uso, 'papeis': PAPEIS}

    # ------------------------------------------------------------------- rotinas
    def rotinas(self):
        """Executa tarefas automáticas uma vez por dia (recorrentes, cartões, backup)."""
        dia = hoje()
        if self.dia_rotina == dia or self.precisa_setup():
            return
        self.dia_rotina = dia
        b = self.banco
        with b.transacao('financeiro'):
            mes = dia[:7]
            self.gerar_recorrentes(mes)
            self.gerar_recorrentes(somar_meses(mes + '-01', 1)[:7])
            if b.config.get('baixa_automatica_cartao'):
                for f in b.c['financeiro']:
                    if (f['tipo'] == 'receber' and f['status'] == 'pendente' and f.get('origem') == 'venda'
                            and f.get('forma') in ('debito', 'credito') and f['vencimento'] <= dia):
                        f.update(status='pago', pago_em=f['vencimento'], valor_pago=f['liquido'])
        if not any(b['nome'].startswith(f'backup-{dia.replace("-", "")}') and b['formato'] == 'cifrado'
                   for b in self.listar_backups()):
            try:
                self.fazer_backup()
            except OSError as e:
                self.auditar('sistema', 'backup_falhou', str(e))

    def gerar_recorrentes(self, mes):
        criados = 0
        for r in self.banco.c['recorrentes']:
            if not r.get('ativo') or num(r.get('valor')) <= 0:
                continue
            existe = any(f.get('recorrente_id') == r['id'] and f.get('competencia') == mes
                         for f in self.banco.c['financeiro'])
            if existe:
                continue
            anterior = self.marcar_exemplo
            self.marcar_exemplo = bool(r.get('exemplo'))
            self.lancar(tipo=r.get('tipo') or 'pagar', descricao=r['descricao'], categoria_id=r.get('categoria_id'),
                        valor=num(r['valor']), vencimento=data_no_mes(mes, r.get('dia', 5)), competencia=mes,
                        origem='recorrente', recorrente_id=r['id'], fornecedor_id=r.get('fornecedor_id'))
            self.marcar_exemplo = anterior
            criados += 1
        return criados

    # -------------------------------------------------------------- auxiliares
    def lancar(self, **kw):
        valor = r2(num(kw.get('valor')))
        taxa = r2(num(kw.get('taxa')))
        reg = {
            'id': novo_id(), 'tipo': 'pagar', 'descricao': '', 'categoria_id': None, 'valor': valor,
            'taxa': taxa, 'liquido': r2(valor - taxa), 'vencimento': hoje(), 'competencia': None,
            'status': 'pendente', 'pago_em': None, 'valor_pago': None, 'forma': '', 'origem': 'manual',
            'ref': None, 'cliente_id': None, 'fornecedor_id': None, 'parcela': '', 'obs': '',
            'caixa_id': None, 'criado_em': agora(),
        }
        kw.pop('valor', None)
        kw.pop('taxa', None)
        reg.update(kw)
        reg['competencia'] = reg['competencia'] or reg['vencimento'][:7]
        if reg['status'] == 'pago':
            reg['pago_em'] = reg['pago_em'] or reg['vencimento']
            if reg['valor_pago'] is None:
                reg['valor_pago'] = reg['liquido'] if reg['tipo'] == 'receber' else reg['valor']
        if self.marcar_exemplo:
            reg['exemplo'] = True
        self.banco.c['financeiro'].append(reg)
        return reg

    def movimento(self, tipo, p, v, qtd, custo, ref=None, doc='', obs='', data=None, usuario=''):
        reg = {
            'id': novo_id(), 'data': data or agora(), 'tipo': tipo, 'produto_id': p['id'],
            'variacao_id': v['id'], 'produto_nome': p['nome'],
            'variacao': f"{v.get('tamanho', '')} / {v.get('cor', '')}", 'qtd': qtd,
            'custo_unit': r2(num(custo)), 'saldo': v['estoque'], 'ref': ref, 'doc': doc, 'obs': obs,
            'usuario': usuario,
        }
        if self.marcar_exemplo:
            reg['exemplo'] = True
        self.banco.c['movimentos'].append(reg)

    def proximo(self, chave):
        seq = self.banco.config.setdefault('seq', {})
        seq[chave] = int(seq.get(chave, 0)) + 1
        return seq[chave]

    def novo_codigo_barras(self):
        usados = {v.get('codigo_barras') for p in self.banco.c['produtos'] for v in p.get('variacoes', [])}
        while True:
            codigo = ean13('2' + f'{self.proximo("codigo"):011d}')
            if codigo not in usados:
                return codigo

    def produto_variacao(self, produto_id, variacao_id):
        p = achar(self.banco.c['produtos'], produto_id)
        if not p:
            raise ErroNegocio('Produto não encontrado.')
        v = achar(p.get('variacoes', []), variacao_id)
        if not v:
            raise ErroNegocio(f'Variação não encontrada em {p["nome"]}.')
        return p, v

    def cliente_publico(self, c):
        saida = dict(c)
        if self.cofre:
            for campo in CAMPOS_CIFRADOS:
                if campo in saida:
                    saida[campo] = self.cofre.decifrar(saida[campo])
        else:
            for campo in CAMPOS_CIFRADOS:
                saida.pop(campo, None)
        return saida

    def caixa_aberto(self):
        return next((c for c in self.banco.c['caixa'] if c.get('status') == 'aberto'), None)

    def lancar_recebimento(self, pg, valor, doc, dia, comum):
        """Lança no financeiro um recebimento em dinheiro, Pix, débito ou crédito (à vista ou parcelado)."""
        cfg = self.banco.config
        forma = pg['forma']
        if forma == 'dinheiro':
            if valor > 0:
                self.lancar(descricao=doc + ' — dinheiro', valor=valor, vencimento=dia, status='pago',
                            pago_em=dia, forma='dinheiro', **comum)
        elif forma == 'pix':
            self.lancar(descricao=doc + ' — Pix', valor=valor, taxa=pg['taxa'], vencimento=dia,
                        status='pago', pago_em=dia, forma='pix', **comum)
        elif forma == 'debito':
            venc = somar_dias(dia, inteiro(cfg['prazos'].get('debito', 1)))
            self.lancar(descricao=doc + ' — débito', valor=valor, taxa=pg['taxa'], vencimento=venc,
                        forma='debito', **comum)
        elif forma == 'credito':
            if cfg.get('antecipacao_credito') or pg['parcelas'] == 1:
                prazo = 1 if cfg.get('antecipacao_credito') else inteiro(cfg['prazos'].get('credito', 30))
                self.lancar(descricao=f'{doc} — crédito {pg["parcelas"]}x', valor=valor, taxa=pg['taxa'],
                            vencimento=somar_dias(dia, prazo), forma='credito', **comum)
            else:
                n = pg['parcelas']
                parte, parte_taxa = r2(valor / n), r2(pg['taxa'] / n)
                for k in range(1, n + 1):
                    v = parte if k < n else r2(valor - parte * (n - 1))
                    taxa = parte_taxa if k < n else r2(pg['taxa'] - parte_taxa * (n - 1))
                    self.lancar(descricao=f'{doc} — crédito parcela {k}/{n}', valor=v, taxa=taxa,
                                vencimento=somar_dias(dia, inteiro(cfg['prazos'].get('credito', 30)) * k),
                                forma='credito', parcela=f'{k}/{n}', **comum)

    def caixa_esperado(self, c):
        b = self.banco
        vendas_dinheiro = 0.0
        for v in b.c['vendas']:
            if v.get('caixa_id') == c['id'] and v['status'] == 'concluida':
                dinheiro = sum(p['valor'] for p in v['pagamentos'] if p['forma'] == 'dinheiro')
                vendas_dinheiro += dinheiro - v.get('troco', 0)
        recebimentos = sum(num(f.get('valor_pago')) for f in b.c['financeiro']
                           if f.get('caixa_id') == c['id'] and f['tipo'] == 'receber'
                           and f['status'] == 'pago' and f.get('origem') != 'venda')
        pagamentos = sum(num(f.get('valor_pago')) for f in b.c['financeiro']
                         if f.get('caixa_id') == c['id'] and f['tipo'] == 'pagar' and f['status'] == 'pago')
        supr = sum(m['valor'] for m in c.get('movimentos', []) if m['tipo'] == 'suprimento')
        sang = sum(m['valor'] for m in c.get('movimentos', []) if m['tipo'] == 'sangria')
        esperado = c['valor_inicial'] + vendas_dinheiro + recebimentos - pagamentos + supr - sang
        return {'inicial': c['valor_inicial'], 'vendas_dinheiro': r2(vendas_dinheiro),
                'recebimentos': r2(recebimentos), 'pagamentos': r2(pagamentos),
                'suprimentos': r2(supr), 'sangrias': r2(sang), 'esperado': r2(esperado)}

    def cashback_disponivel(self, cliente, dia):
        if not cliente:
            return 0.0
        validade = cliente.get('cashback_validade')
        if validade and validade < dia:
            return 0.0
        return r2(num(cliente.get('cashback_saldo')))

    def taxa_pct(self, forma, parcelas):
        t = self.banco.config.get('taxas', {})
        if forma == 'credito':
            if parcelas <= 1:
                return num(t.get('credito_1'))
            return num(t.get('credito_2_6')) if parcelas <= 6 else num(t.get('credito_7_12'))
        return num(t.get(forma, 0))

    # ------------------------------------------------------------ autenticação
    def op_setup(self, d):
        if not self.precisa_setup():
            raise ErroNegocio('O sistema já foi configurado.')
        login = str(d.get('login', '')).strip().lower()
        senha = str(d.get('senha', ''))
        nome = str(d.get('nome', '')).strip()
        if not re.fullmatch(r'[a-z0-9._-]{3,30}', login):
            raise ErroNegocio('Usuário deve ter de 3 a 30 letras minúsculas, números, ponto ou traço.')
        validar_senha(senha, 'dona', login)
        chave = secrets.token_bytes(32)
        codigo = gerar_codigo_recuperacao()
        b = self.banco
        b.usuarios = {
            'lista': [{'login': login, 'nome': nome or login, 'papel': 'dona',
                       'envelope': envelopar(chave, senha), 'criado_em': agora()}],
            'recuperacao': envelopar(chave, normalizar_codigo(codigo)),
            'verificador': verificador_chave(chave),
        }
        self.chave, self.cofre = chave, Cofre(chave)
        b.config = config_padrao()
        b.config['licenca']['inicio_teste'] = hoje()
        loja = d.get('loja') if isinstance(d.get('loja'), dict) else {'nome': d.get('loja')}
        for k in b.config['loja']:
            if loja.get(k):
                b.config['loja'][k] = str(loja[k]).strip()
        b.config['loja']['nome'] = str(loja.get('nome') or 'Minha Loja').strip()
        regime = d.get('regime') if d.get('regime') in ('mei', 'simples', 'outro') else 'simples'
        b.config['fiscal']['regime'] = regime
        b.config['fiscal']['aliquota_simples'] = 0 if regime == 'mei' else num(d.get('aliquota'), 4.0)
        if isinstance(d.get('pix'), dict):
            b.config['pix'].update({k: str(v).strip() for k, v in d['pix'].items() if k in b.config['pix']})
        if isinstance(d.get('aparencia'), dict):
            b.config['aparencia'] = {login: d['aparencia']}
        extras = []
        for u in d.get('usuarios') or []:
            ul = str(u.get('login', '')).strip().lower()
            if not ul:
                continue
            if not re.fullmatch(r'[a-z0-9._-]{3,30}', ul) or ul == login or any(x['login'] == ul for x in extras):
                raise ErroNegocio(f'Usuário adicional inválido ou repetido: {ul}')
            validar_senha(str(u.get('senha', '')), u.get('papel') if u.get('papel') in PAPEIS else 'vendedora', ul)
            extras.append({'login': ul, 'nome': str(u.get('nome') or ul).strip(),
                           'papel': u.get('papel') if u.get('papel') in PAPEIS else 'vendedora',
                           'envelope': envelopar(chave, str(u['senha'])), 'criado_em': agora()})
        b.usuarios['lista'].extend(extras)
        for nome_col in COLECOES:
            b.c[nome_col] = []
        self.semear(bool(d.get('exemplo')), regime)
        b.salvar('usuarios', 'config', *COLECOES)
        self.dia_rotina = None
        self.rotinas()
        self.auditar(login, 'setup', f'loja configurada (exemplo={bool(d.get("exemplo"))})')
        return {'ok': True, 'recuperacao': codigo, '_sessao': self.criar_sessao(login)}

    def _abrir_chave(self, chave):
        verificador = self.banco.usuarios.get('verificador')
        if verificador:
            if not hmac.compare_digest(verificador_chave(chave), verificador):
                raise ErroNegocio('Chave inconsistente.')
        self.chave, self.cofre = chave, Cofre(chave)

    def _usuario(self, login):
        return next((u for u in self.banco.usuarios.get('lista', []) if u['login'] == login), None)

    def _checar_bloqueio(self):
        # Cada celular tem o próprio contador: errar senha no celular não bloqueia o computador da loja.
        restante = self.falhas.get(self.origem, [0, 0.0])[1] - time.time()
        if restante > 0:
            raise ErroNegocio(f'Muitas tentativas incorretas. Aguarde {int(restante) + 1} segundos.')

    def _registrar_falha(self):
        f = self.falhas.setdefault(self.origem, [0, 0.0])
        f[0] += 1
        if f[0] >= 3:
            limite = 300 if self.origem == 'local' else 3600
            f[1] = time.time() + min(2 ** (f[0] - 2), limite)

    def _zerar_falhas(self):
        self.falhas.pop(self.origem, None)

    def op_login(self, d):
        self._checar_bloqueio()
        login = str(d.get('login', '')).strip().lower()
        u = self._usuario(login)
        try:
            if not u:
                raise ValueError
            chave = desenvelopar(u['envelope'], str(d.get('senha', '')))
        except (ValueError, KeyError):
            self._registrar_falha()
            self.auditar(login, 'login_falhou')
            raise ErroNegocio('Usuário ou senha incorretos.')
        self._abrir_chave(chave)
        if int(u['envelope'].get('iter', 0)) < ITERACOES_PBKDF2:
            u['envelope'] = envelopar(chave, str(d.get('senha', '')))
            self.banco.salvar('usuarios')
        self._zerar_falhas()
        self.auditar(login, 'login')
        self.dia_rotina = None
        return {'ok': True, '_sessao': self.criar_sessao(login)}

    def op_logout(self, d, sessao):
        if sessao:
            self.sessoes.pop(sessao['token'], None)
            self.auditar(sessao['login'], 'logout')
        if not self.sessoes:
            self.chave = self.cofre = None
        return {'ok': True, '_sessao': ''}

    def op_recuperar(self, d):
        self._checar_bloqueio()
        login = str(d.get('login', '')).strip().lower()
        u = self._usuario(login)
        nova = str(d.get('nova_senha', ''))
        try:
            if not u:
                raise ValueError
            chave = desenvelopar(self.banco.usuarios['recuperacao'], normalizar_codigo(d.get('codigo')))
        except (ValueError, KeyError):
            self._registrar_falha()
            raise ErroNegocio('Usuário ou código de recuperação incorretos.')
        validar_senha(nova, u.get('papel', 'vendedora'), login)
        self._abrir_chave(chave)
        u['envelope'] = envelopar(chave, nova)
        self.banco.salvar('usuarios')
        self._zerar_falhas()
        self.encerrar_sessoes(login)
        self.auditar(login, 'senha_recuperada')
        return {'ok': True, '_sessao': self.criar_sessao(login)}

    def op_senha(self, d, usuario):
        u = self._usuario(usuario)
        try:
            desenvelopar(u['envelope'], str(d.get('atual', '')))
        except ValueError:
            raise ErroNegocio('Senha atual incorreta.')
        validar_senha(str(d.get('nova', '')), u.get('papel', 'vendedora'), usuario)
        u['envelope'] = envelopar(self.chave, str(d['nova']))
        self.banco.salvar('usuarios')
        self.encerrar_sessoes(usuario, exceto=d.get('_token_atual'))
        self.auditar(usuario, 'senha_alterada')
        return {'ok': True}

    def op_nova_recuperacao(self, d, usuario):
        u = self._usuario(usuario)
        try:
            desenvelopar(u['envelope'], str(d.get('senha', '')))
        except ValueError:
            raise ErroNegocio('Senha incorreta.')
        codigo = gerar_codigo_recuperacao()
        self.banco.usuarios['recuperacao'] = envelopar(self.chave, normalizar_codigo(codigo))
        self.banco.salvar('usuarios')
        self.auditar(usuario, 'codigo_recuperacao_gerado')
        return {'ok': True, 'recuperacao': codigo}

    def op_usuario_adicionar(self, d, usuario):
        login = str(d.get('login', '')).strip().lower()
        if not re.fullmatch(r'[a-z0-9._-]{3,30}', login):
            raise ErroNegocio('Usuário inválido.')
        if self._usuario(login):
            raise ErroNegocio('Esse usuário já existe.')
        validar_senha(str(d.get('senha', '')), d.get('papel') if d.get('papel') in PAPEIS else 'vendedora', login)
        self.banco.usuarios['lista'].append({
            'login': login, 'nome': str(d.get('nome') or login).strip(),
            'papel': d.get('papel') if d.get('papel') in PAPEIS else 'vendedora',
            'envelope': envelopar(self.chave, str(d['senha'])), 'criado_em': agora()})
        self.banco.salvar('usuarios')
        self.auditar(usuario, 'usuario_adicionado', login)
        return {'ok': True}

    def op_usuario_papel(self, d, usuario):
        u = self._usuario(str(d.get('login', '')).strip().lower())
        if not u:
            raise ErroNegocio('Usuário não encontrado.')
        if d.get('papel') not in PAPEIS:
            raise ErroNegocio('Perfil inválido.')
        if u['login'] == usuario and d['papel'] != 'dona':
            raise ErroNegocio('Você não pode reduzir o próprio acesso.')
        u['papel'] = d['papel']
        self.banco.salvar('usuarios')
        self.encerrar_sessoes(u['login'])
        self.auditar(usuario, 'perfil_alterado', f'{u["login"]} -> {u["papel"]}')
        return {'ok': True}

    def op_usuario_senha(self, d, usuario):
        """A proprietária define uma senha nova para alguém da equipe que esqueceu a dela."""
        login = str(d.get('login', '')).strip().lower()
        u = self._usuario(login)
        if not u or login == usuario:
            raise ErroNegocio('Escolha outra pessoa da equipe. Para a sua senha, use "Trocar minha senha".')
        try:
            desenvelopar(self._usuario(usuario)['envelope'], str(d.get('minha_senha', '')))
        except (ValueError, KeyError, TypeError):
            self._registrar_falha()
            raise ErroNegocio('Sua senha (proprietária) não confere.')
        validar_senha(str(d.get('senha', '')), u.get('papel', 'vendedora'), login)
        u['envelope'] = envelopar(self.chave, str(d['senha']))
        self.banco.salvar('usuarios')
        self.encerrar_sessoes(login)
        self.auditar(usuario, 'senha_redefinida', login)
        return {'ok': True}

    def op_usuario_remover(self, d, usuario):
        login = str(d.get('login', '')).strip().lower()
        if login == usuario:
            raise ErroNegocio('Você não pode remover o próprio usuário.')
        lista = self.banco.usuarios['lista']
        self.banco.usuarios['lista'] = [u for u in lista if u['login'] != login]
        self.banco.salvar('usuarios')
        self.encerrar_sessoes(login)
        self.auditar(usuario, 'usuario_removido', login)
        return {'ok': True}

    # ------------------------------------------------------------ configuração
    def op_config(self, d, usuario):
        permitidas = ('loja', 'fiscal', 'taxas', 'prazos', 'antecipacao_credito', 'baixa_automatica_cartao',
                      'precificacao', 'fidelidade', 'vales', 'condicional', 'crediario', 'consumidor', 'conformidade', 'estoque',
                      'grades', 'cores', 'financeiro', 'metas', 'whatsapp', 'pix', 'mei', 'seguranca')
        cfg = d.get('config') or {}
        cred = cfg.get('crediario')
        if isinstance(cred, dict):
            for campo in ('multa_atraso_pct', 'juros_mes_pct'):
                valor = cred.get(campo, 0)
                try:
                    valor = float(str(valor if valor not in (None, '') else 0).replace(',', '.'))
                except ValueError:
                    raise ErroNegocio('Multa e juros precisam ser números (ex.: 2 ou 1,5).')
                if not math.isfinite(valor):
                    raise ErroNegocio('Multa e juros precisam ser números (ex.: 2 ou 1,5).')
                cred[campo] = round(valor, 2)
            if num(cred.get('multa_atraso_pct')) > MULTA_MAXIMA_PCT:
                raise ErroNegocio(f'A multa por atraso pode ser no máximo {MULTA_MAXIMA_PCT:.0f}% '
                                  '(Código de Defesa do Consumidor, art. 52, § 1º).')
            if num(cred.get('juros_mes_pct')) > JUROS_MAXIMO_MES_PCT:
                raise ErroNegocio(f'Os juros de atraso podem ser no máximo {JUROS_MAXIMO_MES_PCT:.0f}% ao mês no sistema.')
            if num(cred.get('multa_atraso_pct')) < 0 or num(cred.get('juros_mes_pct')) < 0:
                raise ErroNegocio('Multa e juros não podem ser negativos.')
        cons = cfg.get('consumidor')
        if isinstance(cons, dict) and len(str(cons.get('politica_troca') or '')) > 1500:
            raise ErroNegocio('A política de troca pode ter no máximo 1.500 caracteres.')
        with self.banco.transacao('config'):
            for k in permitidas:
                if k in cfg:
                    self.banco.config[k] = cfg[k]
            for k in ('aparencia', 'painel'):
                if k in cfg and isinstance(cfg[k], dict):
                    self.banco.config.setdefault(k, {})[usuario] = cfg[k]
        self.auditar(usuario, 'config', ','.join(k for k in permitidas if k in cfg))
        return {'ok': True, 'alterados': []}

    # ------------------------------------------------------ cadastros genéricos
    def op_salvar_generico(self, colecao, obj, usuario):
        if colecao not in GENERICAS:
            raise ErroNegocio('Cadastro inválido.')
        if not isinstance(obj, dict):
            raise ErroNegocio('Dados inválidos.')
        obj = sanear({k: v for k, v in obj.items() if not str(k).startswith('_')})
        campo_nome = 'descricao' if colecao == 'recorrentes' else ('titulo' if colecao == 'tarefas' else 'nome')
        if not str(obj.get(campo_nome, '')).strip():
            raise ErroNegocio('Preencha o nome/descrição.')
        lista = self.banco.c[colecao]
        with self.banco.transacao(colecao):
            existente = achar(lista, obj.get('id'))
            if existente:
                if colecao == 'promocoes':
                    obj['usos'] = existente.get('usos', 0)
                if colecao == 'plano_contas' and existente.get('sistema'):
                    obj['sistema'] = True
                    obj['grupo'] = existente['grupo']
                    obj['tipo'] = existente['tipo']
                existente.clear()
                existente.update(obj)
                existente['atualizado_em'] = agora()
            else:
                obj['id'] = obj.get('id') or novo_id()
                obj['criado_em'] = agora()
                if colecao == 'promocoes':
                    obj['usos'] = 0
                if colecao == 'promocoes' and obj.get('tipo') == 'cupom':
                    obj['codigo'] = str(obj.get('codigo', '')).strip().upper()
                lista.append(obj)
            if colecao == 'promocoes' and obj.get('tipo') == 'cupom':
                codigo = str(obj.get('codigo', '')).strip().upper()
                if not codigo:
                    raise ErroNegocio('Informe o código do cupom.')
                if any(p is not obj and p.get('tipo') == 'cupom' and p.get('codigo') == codigo
                       and p.get('id') != obj.get('id') for p in lista):
                    raise ErroNegocio('Já existe um cupom com esse código.')
                (existente or obj)['codigo'] = codigo
        self.auditar(usuario, f'salvar_{colecao}', str(obj.get(campo_nome))[:60])
        alterados = [colecao]
        if colecao == 'recorrentes':
            self.dia_rotina = None
            alterados.append('financeiro')
        return {'ok': True, 'id': (existente or obj)['id'], 'alterados': alterados}

    def op_excluir_generico(self, colecao, ident, usuario):
        if colecao not in GENERICAS:
            raise ErroNegocio('Cadastro inválido.')
        refs = {
            'categorias': [('produtos', 'categoria_id')], 'marcas': [('produtos', 'marca_id')],
            'fornecedores': [('produtos', 'fornecedor_id'), ('entradas', 'fornecedor_id'),
                             ('financeiro', 'fornecedor_id')],
            'colecoes': [('produtos', 'colecao_id')],
            'plano_contas': [('financeiro', 'categoria_id'), ('recorrentes', 'categoria_id')],
        }
        alvo = achar(self.banco.c[colecao], ident)
        if not alvo:
            raise ErroNegocio('Registro não encontrado.')
        if colecao == 'plano_contas' and alvo.get('sistema'):
            raise ErroNegocio('Esta conta é usada pelo sistema e não pode ser excluída.')
        for col, campo in refs.get(colecao, []):
            if any(x.get(campo) == ident for x in self.banco.c[col]):
                raise ErroNegocio('Este cadastro está em uso e não pode ser excluído. Você pode desativá-lo.')
        if colecao == 'servicos' and any(i.get('servico_id') == ident for v in self.banco.c['vendas']
                                         for i in v['itens']):
            raise ErroNegocio('Serviço já usado em vendas. Desative-o em vez de excluir.')
        with self.banco.transacao(colecao):
            self.banco.c[colecao] = [x for x in self.banco.c[colecao] if x.get('id') != ident]
        self.auditar(usuario, f'excluir_{colecao}', ident)
        return {'ok': True, 'alterados': [colecao]}

    # ---------------------------------------------------------------- produtos
    def op_produto_salvar(self, d, usuario):
        o = d.get('obj') or {}
        b = self.banco
        nome = str(o.get('nome', '')).strip()
        if not nome:
            raise ErroNegocio('Informe o nome do produto.')
        vars_in = o.get('variacoes') or []
        if not vars_in:
            raise ErroNegocio('Cadastre pelo menos uma variação (tamanho/cor).')
        with b.transacao('produtos', 'movimentos', 'config'):
            existente = achar(b.c['produtos'], o.get('id'))
            pid = existente['id'] if existente else novo_id()
            sku = str(o.get('sku', '')).strip().upper() or f'P{self.proximo("produto"):05d}'
            if any(p['id'] != pid and p.get('sku', '').upper() == sku for p in b.c['produtos']):
                raise ErroNegocio(f'O código (SKU) {sku} já está em uso.')
            codigos_outros = {v.get('codigo_barras') for p in b.c['produtos'] if p['id'] != pid
                              for v in p.get('variacoes', [])}
            antigas = {v['id']: v for v in (existente or {}).get('variacoes', [])}
            novas, combos, codigos, iniciais = [], set(), set(), []
            for vi in vars_in:
                tam = str(vi.get('tamanho', '')).strip() or 'U'
                cor = str(vi.get('cor', '')).strip() or 'Única'
                combo = (tam.upper(), cor.upper())
                if combo in combos:
                    raise ErroNegocio(f'Variação repetida: {tam} / {cor}.')
                combos.add(combo)
                codigo = str(vi.get('codigo_barras', '')).strip().upper()
                ve = antigas.get(vi.get('id'))
                if not codigo:
                    codigo = (ve or {}).get('codigo_barras') or self.novo_codigo_barras()
                if codigo in codigos_outros or codigo in codigos:
                    raise ErroNegocio(f'Código de barras {codigo} já está em uso.')
                codigos.add(codigo)
                nv = {'id': ve['id'] if ve else novo_id(), 'tamanho': tam, 'cor': cor, 'codigo_barras': codigo,
                      'estoque': ve['estoque'] if ve else 0, 'estoque_min': max(0, inteiro(vi.get('estoque_min')))}
                if not ve and inteiro(vi.get('estoque_inicial')) > 0:
                    iniciais.append((nv, inteiro(vi['estoque_inicial'])))
                novas.append(nv)
            ids_novos = {v['id'] for v in novas}
            for vid, v in antigas.items():
                if vid not in ids_novos and v['estoque'] != 0:
                    raise ErroNegocio(f'A variação {v["tamanho"]} / {v["cor"]} ainda tem estoque '
                                      f'({v["estoque"]}). Zere com um ajuste antes de removê-la.')
            campos = ('descricao', 'categoria_id', 'marca_id', 'fornecedor_id', 'colecao_id', 'genero',
                      'referencia', 'ncm', 'localizacao', 'tags', 'foto')
            reg = existente if existente else {'id': pid, 'criado_em': agora()}
            for c in campos:
                reg[c] = o.get(c) or ''
            reg.update(nome=nome, sku=sku, custo=r2(num(o.get('custo'))), preco=r2(num(o.get('preco'))),
                       ativo=bool(o.get('ativo', True)), variacoes=novas, atualizado_em=agora())
            if reg['preco'] <= 0:
                raise ErroNegocio('Informe o preço de venda.')
            if not existente:
                b.c['produtos'].append(reg)
                if o.get('exemplo') or self.marcar_exemplo:
                    reg['exemplo'] = True
            for v, qtd in iniciais:
                v['estoque'] += qtd
                self.movimento('estoque_inicial', reg, v, qtd, reg['custo'], doc='Cadastro', usuario=usuario)
        self.auditar(usuario, 'produto_salvo', f'{sku} {nome}')
        return {'ok': True, 'id': reg['id'], 'alterados': ['produtos', 'movimentos']}

    def op_produto_excluir(self, d, usuario):
        b = self.banco
        p = achar(b.c['produtos'], d.get('id'))
        if not p:
            raise ErroNegocio('Produto não encontrado.')
        usado = (any(i.get('produto_id') == p['id'] for v in b.c['vendas'] for i in v['itens'])
                 or any(i.get('produto_id') == p['id'] for e in b.c['entradas'] for i in e['itens'])
                 or any(i.get('produto_id') == p['id'] for c in b.c['condicionais'] for i in c['itens']))
        with b.transacao('produtos', 'movimentos'):
            if usado:
                p['ativo'] = False
                msg = 'Produto com histórico: foi apenas desativado.'
            else:
                b.c['produtos'] = [x for x in b.c['produtos'] if x['id'] != p['id']]
                b.c['movimentos'] = [m for m in b.c['movimentos'] if m['produto_id'] != p['id']]
                msg = 'Produto excluído.'
        self.auditar(usuario, 'produto_excluido', p['sku'])
        return {'ok': True, 'mensagem': msg, 'alterados': ['produtos', 'movimentos']}

    # ---------------------------------------------------------------- clientes
    def op_cliente_salvar(self, d, usuario):
        o = d.get('obj') or {}
        b = self.banco
        nome = str(o.get('nome', '')).strip()
        if not nome:
            raise ErroNegocio('Informe o nome da cliente.')
        cpf = so_digitos(o.get('cpf'))
        if cpf and not cpf_valido(cpf):
            raise ErroNegocio('CPF inválido.')
        with b.transacao('clientes'):
            existente = achar(b.c['clientes'], o.get('id'))
            if cpf:
                for c in b.c['clientes']:
                    if c is not existente and so_digitos(self.cofre.decifrar(c.get('cpf', ''))) == cpf:
                        raise ErroNegocio(f'CPF já cadastrado para {c["nome"]}.')
            reg = existente if existente else {'id': novo_id(), 'criado_em': agora(), 'cashback_saldo': 0,
                                               'cashback_validade': ''}
            simples = ('apelido', 'instagram', 'genero', 'tam_superior', 'tam_inferior', 'tam_calcado', 'estilo',
                       'preferencias', 'tags', 'como_conheceu')
            for c in simples:
                reg[c] = str(o.get(c) or '').strip()
            reg['nome'] = nome
            reg['aceita_mensagens'] = bool(o.get('aceita_mensagens'))
            reg['limite_crediario'] = r2(max(0, num(o.get('limite_crediario'))))
            reg['ativo'] = bool(o.get('ativo', True))
            reg['cpf'] = self.cofre.cifrar(cpf)
            reg['telefone'] = self.cofre.cifrar(so_digitos(o.get('telefone')))
            for c in ('email', 'endereco', 'nascimento', 'observacoes'):
                reg[c] = self.cofre.cifrar(str(o.get(c) or '').strip())
            reg['atualizado_em'] = agora()
            if not existente:
                if self.marcar_exemplo:
                    reg['exemplo'] = True
                b.c['clientes'].append(reg)
        self.auditar(usuario, 'cliente_salvo', reg['id'])
        return {'ok': True, 'id': reg['id'], 'alterados': ['clientes']}

    def op_cliente_excluir(self, d, usuario):
        """Atende pedido de exclusão (LGPD): anonimiza dados pessoais e mantém o histórico de vendas."""
        b = self.banco
        c = achar(b.c['clientes'], d.get('id'))
        if not c:
            raise ErroNegocio('Cliente não encontrada.')
        pendente = any(f.get('cliente_id') == c['id'] and f['status'] == 'pendente' and f['tipo'] == 'receber'
                       for f in b.c['financeiro'])
        if pendente:
            raise ErroNegocio('A cliente possui crediário em aberto. Quite antes de excluir.')
        with b.transacao('clientes'):
            for campo in CAMPOS_CIFRADOS + ('apelido', 'instagram', 'preferencias', 'tags', 'estilo'):
                c[campo] = ''
            c.update(nome='Cliente removida (LGPD)', anonimizada=True, ativo=False, aceita_mensagens=False,
                     cashback_saldo=0, anonimizada_em=agora())
        self.auditar(usuario, 'cliente_anonimizada', c['id'])
        return {'ok': True, 'alterados': ['clientes']}

    # ------------------------------------------------------------------ vendas
    def op_venda_api(self, d, usuario):
        with self.banco.transacao('produtos', 'vendas', 'movimentos', 'financeiro', 'clientes', 'vales',
                                  'promocoes', 'config', 'condicionais', 'cobrancas'):
            venda = self.registrar_venda(d, usuario)
        self.auditar(usuario, 'venda', f'nº {venda["numero"]} total {venda["total"]:.2f}')
        return {'ok': True, 'venda': venda,
                'alterados': ['produtos', 'vendas', 'movimentos', 'financeiro', 'clientes', 'vales', 'promocoes']}

    def registrar_venda(self, d, usuario, data=None):
        b = self.banco
        cfg = b.config
        data = data or agora()
        dia = data[:10]
        itens_in = d.get('itens') or []
        if not itens_in:
            raise ErroNegocio('O carrinho está vazio.')
        cliente = None
        if d.get('cliente_id'):
            cliente = achar(b.c['clientes'], d['cliente_id'])
            if not cliente:
                raise ErroNegocio('Cliente não encontrada.')
        itens, consumo, pares = [], {}, []
        for it in itens_in:
            q = inteiro(it.get('qtd'))
            if q <= 0:
                raise ErroNegocio('Quantidade inválida.')
            preco = r2(num(it.get('preco_unit')))
            if preco < 0:
                raise ErroNegocio('Preço inválido.')
            desconto = r2(min(max(num(it.get('desconto')), 0), preco * q))
            if it.get('servico_id'):
                s = achar(b.c['servicos'], it['servico_id'])
                if not s:
                    raise ErroNegocio('Serviço não encontrado.')
                itens.append({'servico_id': s['id'], 'produto_id': None, 'variacao_id': None, 'sku': 'SERV',
                              'nome': s['nome'], 'tamanho': '', 'cor': '', 'categoria_id': 'servicos', 'qtd': q,
                              'preco_unit': preco, 'desconto': desconto, 'total': r2(preco * q - desconto),
                              'custo_unit': r2(num(s.get('custo'))), 'promocoes': it.get('promocoes') or []})
                continue
            p, v = self.produto_variacao(it.get('produto_id'), it.get('variacao_id'))
            consumo[v['id']] = consumo.get(v['id'], 0) + q
            if not cfg['estoque'].get('permitir_negativo') and consumo[v['id']] > v['estoque']:
                raise ErroNegocio(f'Estoque insuficiente: {p["nome"]} {v["tamanho"]}/{v["cor"]} '
                                  f'(disponível: {v["estoque"]}).')
            pares.append((p, v, q))
            itens.append({'produto_id': p['id'], 'variacao_id': v['id'], 'sku': p['sku'], 'nome': p['nome'],
                          'tamanho': v['tamanho'], 'cor': v['cor'], 'categoria_id': p.get('categoria_id'),
                          'colecao_id': p.get('colecao_id'), 'marca_id': p.get('marca_id'), 'qtd': q,
                          'preco_unit': preco, 'desconto': desconto, 'total': r2(preco * q - desconto),
                          'custo_unit': r2(num(p.get('custo'))), 'promocoes': it.get('promocoes') or []})
        subtotal = r2(sum(i['preco_unit'] * i['qtd'] for i in itens))
        desc_itens = r2(sum(i['desconto'] for i in itens))
        desc_carrinho = r2(max(0, num(d.get('desconto_carrinho'))))
        total = r2(subtotal - desc_itens - desc_carrinho)
        if total < 0:
            raise ErroNegocio('Os descontos são maiores que o valor da venda.')

        pags = []
        for pg in d.get('pagamentos') or []:
            forma = pg.get('forma')
            if forma not in FORMAS:
                raise ErroNegocio('Forma de pagamento inválida.')
            valor = r2(num(pg.get('valor')))
            if valor <= 0:
                continue
            parcelas = max(1, inteiro(pg.get('parcelas'), 1))
            if forma == 'credito' and parcelas > 12:
                raise ErroNegocio('Máximo de 12 parcelas no cartão.')
            if forma == 'crediario' and parcelas > inteiro(cfg['crediario'].get('max_parcelas', 4)):
                raise ErroNegocio('Número de parcelas do crediário acima do permitido.')
            item = {'forma': forma, 'valor': valor,
                    'parcelas': parcelas if forma in ('credito', 'crediario') else 1,
                    'codigo': str(pg.get('codigo') or '').strip().upper(),
                    'primeiro_vencimento': pg.get('primeiro_vencimento') or ''}
            if forma == 'pix' and pg.get('cobranca_id'):
                cob = achar(b.c['cobrancas'], pg['cobranca_id'])
                if not cob or cob['status'] != 'paga':
                    raise ErroNegocio('O Pix ainda não foi confirmado pelo banco. Aguarde a confirmação na tela do QR Code.')
                if cob.get('venda_id'):
                    raise ErroNegocio('Este Pix já foi usado em outra venda.')
                if abs(cob['valor'] - valor) > 0.009:
                    raise ErroNegocio('O valor do Pix confirmado é diferente do valor nesta forma de pagamento.')
                item['cobranca_id'] = cob['id']
            pags.append(item)
        soma = r2(sum(p['valor'] for p in pags))
        if soma + 0.009 < total:
            raise ErroNegocio(f'Pagamento insuficiente: faltam R$ {total - soma:.2f}.')
        troco = r2(soma - total)
        dinheiro = sum(p['valor'] for p in pags if p['forma'] == 'dinheiro')
        if troco > 0.009 and troco > dinheiro + 0.009:
            raise ErroNegocio('Só é possível dar troco quando há pagamento em dinheiro. Ajuste os valores.')
        if any(p['forma'] in ('crediario', 'cashback') for p in pags) and not cliente:
            raise ErroNegocio('Selecione a cliente para usar crediário ou cashback.')

        cb_uso = r2(sum(p['valor'] for p in pags if p['forma'] == 'cashback'))
        if cb_uso:
            fid = cfg['fidelidade']
            if cb_uso > self.cashback_disponivel(cliente, dia) + 0.009:
                raise ErroNegocio('Saldo de cashback insuficiente ou vencido.')
            if total < num(fid.get('uso_minimo_compra')):
                raise ErroNegocio(f'Cashback só pode ser usado em compras a partir de R$ {num(fid["uso_minimo_compra"]):.2f}.')
            if cb_uso > total * num(fid.get('uso_max_pct', 100)) / 100 + 0.009:
                raise ErroNegocio(f'Cashback limitado a {num(fid["uso_max_pct"]):.0f}% do valor da compra.')
        uso_vales = {}
        for p in pags:
            if p['forma'] == 'vale':
                uso_vales[p['codigo']] = uso_vales.get(p['codigo'], 0) + p['valor']
        for codigo, valor in uso_vales.items():
            vale = next((x for x in b.c['vales'] if x['codigo'] == codigo), None)
            if not vale or vale['status'] != 'ativo':
                raise ErroNegocio(f'Vale {codigo or "(sem código)"} não encontrado, já usado ou cancelado.')
            nome = NOME_VALE.get(vale.get('tipo'), 'Vale-troca')
            if vale.get('validade') and vale['validade'] < dia:
                raise ErroNegocio(f'{nome} {codigo} vencido em {data_br(vale["validade"])}.')
            if valor > vale['saldo'] + 0.009:
                raise ErroNegocio(f'{nome} {codigo} tem saldo de R$ {vale["saldo"]:.2f}.')
        cred = r2(sum(p['valor'] for p in pags if p['forma'] == 'crediario'))
        if cred and num(cliente.get('limite_crediario')) > 0:
            aberto = sum(f['valor'] for f in b.c['financeiro'] if f.get('cliente_id') == cliente['id']
                         and f['tipo'] == 'receber' and f['status'] == 'pendente' and f.get('forma') == 'crediario')
            if aberto + cred > num(cliente['limite_crediario']) + 0.009:
                raise ErroNegocio(f'Limite de crediário excedido (em aberto: R$ {aberto:.2f}, '
                                  f'limite: R$ {num(cliente["limite_crediario"]):.2f}).')

        # aplicação
        numero = self.proximo('venda')
        caixa = self.caixa_aberto()
        for p in pags:
            p['taxa_pct'] = self.taxa_pct(p['forma'], p['parcelas'])
            base = p['valor'] - (troco if p['forma'] == 'dinheiro' else 0)
            p['taxa'] = r2(base * p['taxa_pct'] / 100)
        venda = {
            'id': novo_id(), 'numero': numero, 'data': data, 'cliente_id': cliente['id'] if cliente else None,
            'cliente_nome': cliente['nome'] if cliente else '', 'itens': itens, 'subtotal': subtotal,
            'desconto_itens': desc_itens, 'desconto_carrinho': desc_carrinho, 'total': total,
            'pagamentos': pags, 'troco': troco, 'promocoes': d.get('promocoes') or [],
            'cupom': str(d.get('cupom') or '').upper(), 'status': 'concluida', 'usuario': usuario,
            'caixa_id': caixa['id'] if caixa else None, 'condicional_id': d.get('condicional_id'),
            'obs': str(d.get('obs') or '')[:500], 'cashback_gerado': 0, 'cashback_usado': cb_uso,
            'distancia': bool(d.get('distancia')),
            'nota': {'pedida': bool((d.get('nota') or {}).get('pedida')),
                     'documento': so_digitos((d.get('nota') or {}).get('documento'))[:14], 'numero': ''},
        }
        if self.marcar_exemplo:
            venda['exemplo'] = True
        doc = f'Venda {numero}'
        for p, v, q in pares:
            v['estoque'] -= q
            self.movimento('venda', p, v, -q, p.get('custo'), ref=venda['id'], doc=doc, data=data, usuario=usuario)
        comum = {'tipo': 'receber', 'categoria_id': 'pc_vendas', 'origem': 'venda', 'ref': venda['id'],
                 'cliente_id': venda['cliente_id'], 'competencia': dia[:7]}
        for pg in pags:
            forma = pg['forma']
            if forma in FORMAS_VALE_PRESENTE:
                self.lancar_recebimento(pg, r2(pg['valor'] - troco) if forma == 'dinheiro' else pg['valor'],
                                        doc, dia, comum)
                if pg.get('cobranca_id'):
                    achar(b.c['cobrancas'], pg['cobranca_id'])['venda_id'] = venda['id']
            elif forma == 'crediario':
                n = pg['parcelas']
                primeiro = pg['primeiro_vencimento'] or somar_meses(dia, 1)
                parte = r2(pg['valor'] / n)
                c2 = dict(comum, origem='crediario')
                for k in range(n):
                    valor = parte if k < n - 1 else r2(pg['valor'] - parte * (n - 1))
                    self.lancar(descricao=f'{doc} — crediário {k + 1}/{n} — {cliente["nome"]}', valor=valor,
                                vencimento=somar_meses(primeiro, k), forma='crediario', parcela=f'{k + 1}/{n}', **c2)
            elif forma == 'vale':
                vale = next(x for x in b.c['vales'] if x['codigo'] == pg['codigo'])
                vale['saldo'] = r2(vale['saldo'] - pg['valor'])
                vale.setdefault('usos', []).append({'venda_id': venda['id'], 'valor': pg['valor'], 'data': data})
                if vale['saldo'] <= 0.009:
                    vale['saldo'] = 0
                    vale['status'] = 'usado'
        fid = cfg['fidelidade']
        if cliente:
            saldo = self.cashback_disponivel(cliente, dia) - cb_uso
            gerado = 0.0
            if fid.get('ativo') and total > 0:
                gerado = r2(max(0, total - cb_uso) * num(fid.get('cashback_pct')) / 100)
            cliente['cashback_saldo'] = r2(max(0, saldo + gerado))
            if gerado:
                cliente['cashback_validade'] = somar_dias(dia, inteiro(fid.get('validade_dias', 90)))
            venda['cashback_gerado'] = gerado
        if d.get('cupom_id'):
            promo = achar(b.c['promocoes'], d['cupom_id'])
            if promo:
                promo['usos'] = int(promo.get('usos', 0)) + 1
        if d.get('condicional_id'):
            cond = achar(b.c['condicionais'], d['condicional_id'])
            if cond:
                cond['venda_id'] = venda['id']
        b.c['vendas'].append(venda)
        return venda

    def op_venda_nota(self, d, usuario):
        """Registra o número da nota fiscal emitida fora do sistema (ex.: emissor gratuito do MEI)."""
        venda = achar(self.banco.c['vendas'], d.get('id'))
        if not venda:
            raise ErroNegocio('Venda não encontrada.')
        with self.banco.transacao('vendas'):
            nota = venda.setdefault('nota', {'pedida': True, 'documento': ''})
            nota.update(numero=str(d.get('numero') or '').strip()[:60], registrada_em=agora(), pedida=True)
        self.auditar(usuario, 'nota_registrada', f'venda {venda["numero"]}: {nota["numero"]}')
        return {'ok': True, 'alterados': ['vendas']}

    def op_venda_cancelar(self, d, usuario):
        b = self.banco
        venda = achar(b.c['vendas'], d.get('id'))
        if not venda or venda['status'] != 'concluida':
            raise ErroNegocio('Venda não encontrada ou já cancelada.')
        if any(t.get('venda_id') == venda['id'] for t in b.c['trocas']):
            raise ErroNegocio('Esta venda tem troca/devolução registrada e não pode ser cancelada.')
        nfe = venda.get('nfe') or {}
        if nfe.get('ref') and nfe.get('status') not in ('cancelado', 'erro_autorizacao', 'denegado', 'nao_encontrada') \
                and not d.get('sem_cancelar_nota'):
            raise ErroNegocio('Esta venda tem nota fiscal. Cancele a nota primeiro (botão "Cancelar nota" na venda). '
                              'Se o prazo de cancelamento da nota já passou, fale com o contador sobre a nota de devolução.')
        with b.transacao('produtos', 'vendas', 'movimentos', 'financeiro', 'clientes', 'vales'):
            for it in venda['itens']:
                if not it.get('produto_id'):
                    continue
                p = achar(b.c['produtos'], it['produto_id'])
                v = achar(p.get('variacoes', []), it['variacao_id']) if p else None
                if p and v:
                    v['estoque'] += it['qtd']
                    self.movimento('cancelamento', p, v, it['qtd'], it['custo_unit'], ref=venda['id'],
                                   doc=f'Cancelamento venda {venda["numero"]}', usuario=usuario)
            for f in b.c['financeiro']:
                if f.get('ref') == venda['id'] and f['status'] != 'cancelado':
                    f['status'] = 'cancelado'
            for pg in venda['pagamentos']:
                if pg['forma'] == 'vale':
                    vale = next((x for x in b.c['vales'] if x['codigo'] == pg['codigo']), None)
                    if vale:
                        vale['saldo'] = r2(vale['saldo'] + pg['valor'])
                        vale['status'] = 'ativo'
                        vale['usos'] = [u for u in vale.get('usos', []) if u.get('venda_id') != venda['id']]
            cliente = achar(b.c['clientes'], venda.get('cliente_id'))
            if cliente:
                cliente['cashback_saldo'] = r2(max(0, num(cliente.get('cashback_saldo')) + venda.get('cashback_usado', 0)
                                                   - venda.get('cashback_gerado', 0)))
            venda.update(status='cancelada', cancelada_em=agora(), motivo_cancelamento=str(d.get('motivo') or ''))
        self.auditar(usuario, 'venda_cancelada', f'nº {venda["numero"]}'
                     + (' (nota fiscal não cancelada)' if nfe.get('status') == 'autorizado' else ''))
        return {'ok': True, 'alterados': ['produtos', 'vendas', 'movimentos', 'financeiro', 'clientes', 'vales']}

    # ----------------------------------------------------------------- estoque
    def op_entrada(self, d, usuario):
        b = self.banco
        itens_in = d.get('itens') or []
        if not itens_in:
            raise ErroNegocio('Adicione os itens da compra.')
        dia = str(d.get('data') or hoje())[:10]
        itens, total_prod = [], 0.0
        for it in itens_in:
            q = inteiro(it.get('qtd'))
            if q <= 0:
                continue
            custo = r2(num(it.get('custo_unit')))
            if custo < 0:
                raise ErroNegocio('Custo inválido.')
            p, v = self.produto_variacao(it.get('produto_id'), it.get('variacao_id'))
            itens.append([p, v, q, custo])
            total_prod += q * custo
        if not itens:
            raise ErroNegocio('Informe a quantidade de pelo menos um item.')
        frete, outras, desconto = (r2(max(0, num(d.get(k)))) for k in ('frete', 'outras', 'desconto'))
        extra = frete + outras - desconto
        fator = extra / total_prod if total_prod > 0 else 0
        total_nota = r2(total_prod + extra)
        pg = d.get('pagamento') or {}
        modo = pg.get('modo', 'avista')
        with b.transacao('produtos', 'entradas', 'movimentos', 'financeiro', 'config'):
            numero = self.proximo('entrada')
            entrada_id = novo_id()
            por_produto = {}
            for p, v, q, custo in itens:
                ef = r2(custo * (1 + fator))
                acc = por_produto.setdefault(p['id'], [p, 0, 0.0])
                acc[1] += q
                acc[2] += q * ef
            for p, q, valor in por_produto.values():
                atual = sum(max(0, x['estoque']) for x in p['variacoes'])
                p['custo_anterior'] = p.get('custo', 0)
                p['ultimo_custo_compra'] = r2(valor / q)
                p['custo'] = r2((atual * num(p.get('custo')) + valor) / (atual + q)) if atual + q else r2(valor / q)
            novos_precos = d.get('novos_precos') or {}
            for pid, preco in novos_precos.items():
                p = achar(b.c['produtos'], pid)
                if p and num(preco) > 0:
                    p['preco'] = r2(num(preco))
            registro_itens = []
            for p, v, q, custo in itens:
                ef = r2(custo * (1 + fator))
                v['estoque'] += q
                self.movimento('entrada', p, v, q, ef, ref=entrada_id, doc=f'Entrada {numero} NF {d.get("nota", "")}',
                               data=dia + agora()[10:], usuario=usuario)
                registro_itens.append({'produto_id': p['id'], 'variacao_id': v['id'], 'nome': p['nome'],
                                       'tamanho': v['tamanho'], 'cor': v['cor'], 'qtd': q, 'custo_unit': custo,
                                       'custo_efetivo': ef})
            fornecedor = achar(b.c['fornecedores'], d.get('fornecedor_id'))
            desc = f'Compra NF {d.get("nota") or "s/n"}' + (f' — {fornecedor["nome"]}' if fornecedor else '')
            comum = {'tipo': 'pagar', 'categoria_id': 'pc_compra_mercadorias', 'origem': 'compra', 'ref': entrada_id,
                     'fornecedor_id': d.get('fornecedor_id'), 'competencia': dia[:7]}
            if modo == 'avista':
                self.lancar(descricao=desc, valor=total_nota, vencimento=dia, status='pago', pago_em=dia,
                            forma=pg.get('forma') or 'pix', **comum)
            elif modo == 'parcelado':
                n = max(1, min(24, inteiro(pg.get('parcelas'), 1)))
                primeiro = pg.get('primeiro_vencimento') or somar_dias(dia, 30)
                intervalo = max(1, inteiro(pg.get('intervalo_dias'), 30))
                parte = r2(total_nota / n)
                for k in range(n):
                    valor = parte if k < n - 1 else r2(total_nota - parte * (n - 1))
                    self.lancar(descricao=f'{desc} — parcela {k + 1}/{n}', valor=valor,
                                vencimento=somar_dias(primeiro, intervalo * k), parcela=f'{k + 1}/{n}',
                                forma=pg.get('forma') or 'boleto', **comum)
            b.c['entradas'].append({
                'id': entrada_id, 'numero': numero, 'data': dia, 'fornecedor_id': d.get('fornecedor_id'),
                'nota': str(d.get('nota') or ''), 'itens': registro_itens, 'frete': frete, 'outras': outras,
                'desconto': desconto, 'total_produtos': r2(total_prod), 'total': total_nota, 'pagamento': pg,
                'status': 'ativa', 'obs': str(d.get('obs') or ''), 'usuario': usuario, 'criado_em': agora()})
        self.auditar(usuario, 'entrada', f'nº {numero} total {total_nota:.2f}')
        return {'ok': True, 'numero': numero,
                'alterados': ['produtos', 'entradas', 'movimentos', 'financeiro']}

    def op_entrada_cancelar(self, d, usuario):
        b = self.banco
        e = achar(b.c['entradas'], d.get('id'))
        if not e or e['status'] != 'ativa':
            raise ErroNegocio('Entrada não encontrada ou já cancelada.')
        with b.transacao('produtos', 'entradas', 'movimentos', 'financeiro'):
            for it in e['itens']:
                p, v = self.produto_variacao(it['produto_id'], it['variacao_id'])
                if v['estoque'] < it['qtd'] and not b.config['estoque'].get('permitir_negativo'):
                    raise ErroNegocio(f'{p["nome"]} {v["tamanho"]}/{v["cor"]} não tem estoque suficiente '
                                      f'para estornar (já foi vendido).')
                v['estoque'] -= it['qtd']
                self.movimento('estorno_entrada', p, v, -it['qtd'], it['custo_efetivo'], ref=e['id'],
                               doc=f'Estorno entrada {e["numero"]}', usuario=usuario)
            for f in b.c['financeiro']:
                if f.get('ref') == e['id'] and f['status'] == 'pendente':
                    f['status'] = 'cancelado'
            e.update(status='cancelada', cancelada_em=agora())
        self.auditar(usuario, 'entrada_cancelada', f'nº {e["numero"]}')
        return {'ok': True, 'alterados': ['produtos', 'entradas', 'movimentos', 'financeiro']}

    def op_ajuste(self, d, usuario):
        tipo = d.get('tipo')
        if tipo not in TIPOS_AJUSTE:
            raise ErroNegocio('Tipo de ajuste inválido.')
        q = abs(inteiro(d.get('qtd')))
        if q <= 0:
            raise ErroNegocio('Informe a quantidade.')
        b = self.banco
        with b.transacao('produtos', 'movimentos'):
            p, v = self.produto_variacao(d.get('produto_id'), d.get('variacao_id'))
            delta = q * TIPOS_AJUSTE[tipo]
            if v['estoque'] + delta < 0 and not b.config['estoque'].get('permitir_negativo'):
                raise ErroNegocio(f'Estoque atual é {v["estoque"]}; não é possível retirar {q}.')
            v['estoque'] += delta
            self.movimento(tipo, p, v, delta, p.get('custo'), doc='Ajuste', obs=str(d.get('obs') or ''), usuario=usuario)
        self.auditar(usuario, 'ajuste', f'{tipo} {p["sku"]} {delta:+d}')
        return {'ok': True, 'alterados': ['produtos', 'movimentos']}

    def op_inventario(self, d, usuario):
        b = self.banco
        alterados = 0
        with b.transacao('produtos', 'movimentos'):
            for c in d.get('contagens') or []:
                if c.get('contado') in (None, ''):
                    continue
                p, v = self.produto_variacao(c.get('produto_id'), c.get('variacao_id'))
                contado = max(0, inteiro(c['contado']))
                delta = contado - v['estoque']
                if delta:
                    v['estoque'] = contado
                    self.movimento('inventario', p, v, delta, p.get('custo'), doc='Inventário',
                                   obs=str(d.get('obs') or ''), usuario=usuario)
                    alterados += 1
        self.auditar(usuario, 'inventario', f'{alterados} itens ajustados')
        return {'ok': True, 'ajustados': alterados, 'alterados': ['produtos', 'movimentos']}

    # ------------------------------------------------------------ condicional
    def op_condicional_abrir(self, d, usuario):
        b = self.banco
        cliente = achar(b.c['clientes'], d.get('cliente_id'))
        if not cliente:
            raise ErroNegocio('Selecione a cliente do condicional.')
        itens_in = [i for i in (d.get('itens') or []) if not i.get('servico_id')]
        if not itens_in:
            raise ErroNegocio('Adicione as peças do condicional.')
        total_pecas = sum(inteiro(i.get('qtd')) for i in itens_in)
        maximo = inteiro(b.config['condicional'].get('max_pecas', 10))
        if maximo and total_pecas > maximo:
            raise ErroNegocio(f'Máximo de {maximo} peças por condicional.')
        with b.transacao('produtos', 'movimentos', 'condicionais', 'config'):
            numero = self.proximo('condicional')
            cid = novo_id()
            itens, consumo = [], {}
            for it in itens_in:
                q = inteiro(it.get('qtd'))
                p, v = self.produto_variacao(it.get('produto_id'), it.get('variacao_id'))
                consumo[v['id']] = consumo.get(v['id'], 0) + q
                if q <= 0 or consumo[v['id']] > v['estoque']:
                    raise ErroNegocio(f'Estoque insuficiente: {p["nome"]} {v["tamanho"]}/{v["cor"]}.')
                v['estoque'] -= q
                self.movimento('condicional_saida', p, v, -q, p.get('custo'), ref=cid, doc=f'Condicional {numero}',
                               usuario=usuario)
                itens.append({'produto_id': p['id'], 'variacao_id': v['id'], 'nome': p['nome'], 'sku': p['sku'],
                              'tamanho': v['tamanho'], 'cor': v['cor'], 'qtd': q,
                              'preco_unit': r2(num(it.get('preco_unit')) or p['preco'])})
            prazo = d.get('prazo') or somar_dias(hoje(), inteiro(b.config['condicional'].get('prazo_dias', 3)))
            reg = {'id': cid, 'numero': numero, 'data': agora(), 'cliente_id': cliente['id'],
                   'cliente_nome': cliente['nome'], 'itens': itens, 'prazo': prazo, 'status': 'aberto',
                   'obs': str(d.get('obs') or ''), 'usuario': usuario}
            if self.marcar_exemplo:
                reg['exemplo'] = True
            b.c['condicionais'].append(reg)
        self.auditar(usuario, 'condicional_aberto', f'nº {numero}')
        return {'ok': True, 'condicional': reg, 'alterados': ['produtos', 'movimentos', 'condicionais']}

    def op_condicional_fechar(self, d, usuario):
        """Devolve todas as peças ao estoque; as que a cliente ficou seguem para o PDV."""
        b = self.banco
        cond = achar(b.c['condicionais'], d.get('id'))
        if not cond or cond['status'] != 'aberto':
            raise ErroNegocio('Condicional não encontrado ou já fechado.')
        ficou = set(int(i) for i in (d.get('ficou') or []))
        with b.transacao('produtos', 'movimentos', 'condicionais'):
            for idx, it in enumerate(cond['itens']):
                p, v = self.produto_variacao(it['produto_id'], it['variacao_id'])
                v['estoque'] += it['qtd']
                self.movimento('condicional_retorno', p, v, it['qtd'], p.get('custo'), ref=cond['id'],
                               doc=f'Retorno condicional {cond["numero"]}', usuario=usuario)
                it['ficou'] = idx in ficou
            cond.update(status='fechado', fechado_em=agora(), pecas_compradas=len(ficou))
        self.auditar(usuario, 'condicional_fechado', f'nº {cond["numero"]}')
        return {'ok': True, 'condicional': cond, 'alterados': ['produtos', 'movimentos', 'condicionais']}

    # --------------------------------------------------------- troca / vale
    def novo_codigo_vale(self, prefixo='VT'):
        alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
        usados = {v['codigo'] for v in self.banco.c['vales']}
        while True:
            codigo = prefixo + ''.join(secrets.choice(alfabeto) for _ in range(6))
            if codigo not in usados:
                return codigo

    def validade_vale(self, d, chave_padrao):
        """Validade escolhida para o vale: 'AAAA-MM-DD', '' (sem validade) ou, sem o campo, o padrão da configuração."""
        if 'validade' not in d:
            dias = inteiro(self.banco.config.get('vales', {}).get(chave_padrao, 0))
            return somar_dias(hoje(), dias) if dias > 0 else None
        texto = str(d.get('validade') or '').strip()
        if not texto:
            return None
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', texto):
            raise ErroNegocio('Data de validade inválida.')
        try:
            dt.date.fromisoformat(texto)
        except ValueError:
            raise ErroNegocio('Data de validade inválida.')
        if texto < hoje():
            raise ErroNegocio('A validade do vale não pode ser uma data que já passou.')
        return texto

    def garantir_conta(self, conta_id):
        """Inclui no plano de contas uma conta do sistema criada em versão mais nova (lojas já configuradas)."""
        if achar(self.banco.c['plano_contas'], conta_id):
            return
        for i, n, t, g in PLANO_CONTAS:
            if i == conta_id:
                self.banco.c['plano_contas'].append({'id': i, 'nome': n, 'tipo': t, 'grupo': g, 'sistema': True,
                                                     'ativo': True})

    def op_vale_presente(self, d, usuario):
        """Venda de vale-presente: o dinheiro entra agora, mas só vira receita (e faturamento do MEI) quando o
        vale é usado numa venda. Até lá é um valor que a loja deve à cliente."""
        b = self.banco
        valor = r2(num(d.get('valor')))
        if valor <= 0:
            raise ErroNegocio('Informe o valor do vale-presente.')
        if valor > VALOR_MAX_VALE:
            raise ErroNegocio(f'O valor máximo de um vale-presente é R$ {VALOR_MAX_VALE:.2f}.')
        forma = d.get('forma')
        if forma not in FORMAS_VALE_PRESENTE:
            raise ErroNegocio('Escolha como o vale foi pago: dinheiro, Pix, débito ou crédito.')
        parcelas = max(1, min(12, inteiro(d.get('parcelas') or 1))) if forma == 'credito' else 1
        cliente = achar(b.c['clientes'], d.get('cliente_id')) if d.get('cliente_id') else None
        if d.get('cliente_id') and not cliente:
            raise ErroNegocio('Cliente não encontrada.')
        validade = self.validade_vale(d, 'presente_validade_dias')
        para = str(d.get('para') or '').strip()[:80]
        mensagem = str(d.get('mensagem') or '').strip()[:200]
        dia = hoje()
        with b.transacao('vales', 'financeiro', 'plano_contas'):
            self.garantir_conta('pc_vale_presente')
            caixa = self.caixa_aberto() if forma == 'dinheiro' else None
            vale = {'id': novo_id(), 'tipo': 'presente', 'codigo': self.novo_codigo_vale('VP'),
                    'cliente_id': cliente['id'] if cliente else None, 'para': para, 'mensagem': mensagem,
                    'valor': valor, 'saldo': valor, 'status': 'ativo', 'criado_em': agora(), 'validade': validade,
                    'forma': forma, 'parcelas': parcelas, 'usuario': usuario, 'usos': []}
            pg = {'forma': forma, 'parcelas': parcelas}
            pg['taxa'] = r2(valor * self.taxa_pct(forma, parcelas) / 100)
            comum = {'tipo': 'receber', 'categoria_id': 'pc_vale_presente', 'origem': 'vale_presente',
                     'ref': vale['id'], 'cliente_id': vale['cliente_id'], 'competencia': dia[:7],
                     'caixa_id': caixa['id'] if caixa else None}
            self.lancar_recebimento(pg, valor, f'Vale-presente {vale["codigo"]}', dia, comum)
            b.c['vales'].append(vale)
        self.auditar(usuario, 'vale_presente', f'{vale["codigo"]} {valor:.2f} {forma}')
        return {'ok': True, 'vale': vale, 'alterados': ['vales', 'financeiro', 'plano_contas']}

    def op_vale_validade(self, d, usuario):
        """Muda a validade de um vale (prorrogar, tirar o prazo ou encurtar antes de usar)."""
        b = self.banco
        vale = achar(b.c['vales'], d.get('id'))
        if not vale or vale['status'] != 'ativo':
            raise ErroNegocio('Vale não encontrado, já usado ou cancelado.')
        if 'validade' not in d:
            raise ErroNegocio('Informe a nova validade ou marque "sem validade".')
        nova = self.validade_vale(d, 'validade_dias')
        with b.transacao('vales'):
            antiga = vale.get('validade')
            vale['validade'] = nova
            vale.setdefault('historico', []).append({'data': agora(), 'usuario': usuario, 'de': antiga, 'para': nova})
        self.auditar(usuario, 'vale_validade', f'{vale["codigo"]}: {antiga or "sem"} -> {nova or "sem"}')
        return {'ok': True, 'vale': vale, 'alterados': ['vales']}

    def op_vale_cancelar(self, d, usuario):
        """Cancela um vale-presente que ainda não foi usado (devolução do valor a quem comprou)."""
        b = self.banco
        vale = achar(b.c['vales'], d.get('id'))
        if not vale or vale.get('tipo') != 'presente':
            raise ErroNegocio('Só o vale-presente pode ser cancelado. O vale-troca vem de uma troca já registrada.')
        if vale['status'] != 'ativo' or vale.get('usos') or abs(vale['saldo'] - vale['valor']) > 0.009:
            raise ErroNegocio('Este vale-presente já foi usado (todo ou em parte) e não pode mais ser cancelado.')
        with b.transacao('vales', 'financeiro'):
            for f in b.c['financeiro']:
                if f.get('ref') == vale['id'] and f['status'] != 'cancelado':
                    f['status'] = 'cancelado'
            vale.update(status='cancelado', saldo=0, cancelado_em=agora(),
                        motivo_cancelamento=str(d.get('motivo') or '')[:200])
        self.auditar(usuario, 'vale_cancelado', f'{vale["codigo"]} {vale["valor"]:.2f}')
        return {'ok': True, 'alterados': ['vales', 'financeiro']}

    # ------------------------------------------------------------- integrações
    # Todas opcionais. A chamada de rede acontece fora da trava do sistema: a operação devolve '_rede' com
    # a função que fala com o serviço e a que grava o resultado (ver Manipulador._tratar).
    def integracoes_publicas(self, papel='dona'):
        integ = copy.deepcopy(self.banco.config.get('integracoes') or {})
        for secao, campos in SEGREDOS_INTEGRACAO.items():
            bloco = integ.setdefault(secao, {})
            for c in campos:
                bloco['tem_' + c] = bool(bloco.pop(c, ''))
            if papel != 'dona':
                # Gerente e vendedora só precisam saber o que está ligado.
                integ[secao] = {k: bloco.get(k) for k in ('ativo', 'ambiente', 'emitir', 'provedor', 'minutos') if k in bloco}
        if papel != 'dona':
            integ.pop('cartoes', None)
        integ['bancos_pix'] = integracoes.BANCOS_PIX
        return integ

    def config_integracao(self, secao):
        return (self.banco.config.get('integracoes') or {}).get(secao) or {}

    def segredos_integracao(self, secao):
        if not self.cofre:
            raise ErroNegocio('Entre no sistema para usar as integrações.')
        bloco = self.config_integracao(secao)
        return {c: self.cofre.decifrar(bloco.get(c) or '') for c in SEGREDOS_INTEGRACAO[secao]}

    def op_integracoes_salvar(self, d, usuario):
        secao = d.get('secao')
        if secao not in CAMPOS_INTEGRACAO:
            raise ErroNegocio('Integração desconhecida.')
        novo = d.get('dados') if isinstance(d.get('dados'), dict) else {}
        if not self.cofre:
            raise ErroNegocio('Entre no sistema para salvar as credenciais.')
        if 'ambiente' in novo and novo['ambiente'] not in ('homologacao', 'producao'):
            raise ErroNegocio('Ambiente inválido.')
        if secao == 'nfe' and novo.get('emitir') not in (None, 'perguntar', 'sempre'):
            raise ErroNegocio('Opção de emissão inválida.')
        if secao == 'pix' and novo.get('modo_token') not in (None, 'basic_form', 'corpo_form', 'basic_json'):
            raise ErroNegocio('Forma de autenticação inválida.')
        if secao == 'pix' and novo.get('provedor') not in (None, 'mercadopago', 'banco'):
            raise ErroNegocio('Escolha Mercado Pago ou a API Pix do seu banco.')
        for campo in ('url_api', 'url_token'):
            if novo.get(campo):
                try:
                    integracoes.validar_url(novo[campo], integracoes.LOCAL_PERMITIDO)
                except integracoes.ErroIntegracao as e:
                    raise ErroNegocio(str(e))
        cab = novo.get('cabecalhos')
        if cab is not None and (not isinstance(cab, dict) or len(cab) > 5
                                or any(not re.fullmatch(r'[A-Za-z0-9-]{1,40}', str(k)) or len(str(v)) > 200 for k, v in cab.items())):
            raise ErroNegocio('Cabeçalhos extras inválidos.')
        if secao == 'nfe' and novo.get('ncm_padrao') and len(so_digitos(novo['ncm_padrao'])) != 8:
            raise ErroNegocio('O NCM tem 8 números (ex.: 6109.10.00).')
        with self.banco.transacao('config'):
            bloco = self.banco.config.setdefault('integracoes', {}).setdefault(secao, {})
            for c in CAMPOS_INTEGRACAO[secao]:
                if c in novo:
                    v = novo[c]
                    if c == 'ativo':
                        v = bool(v)
                    elif c == 'minutos':
                        v = max(5, min(120, inteiro(v, 30)))
                    elif c != 'cabecalhos':
                        v = str(v or '').strip()[:300]
                    bloco[c] = v
            for c in SEGREDOS_INTEGRACAO[secao]:
                v = novo.get(c)
                if v == '__apagar__':
                    bloco[c] = ''
                elif isinstance(v, str) and v.strip():
                    if len(v) > 20000:
                        raise ErroNegocio('Credencial grande demais.')
                    bloco[c] = self.cofre.cifrar(v.strip())
        self.auditar(usuario, 'integracao_config', f'{secao} ativo={bool(bloco.get("ativo"))} ambiente={bloco.get("ambiente", "")}')
        return {'ok': True, 'integracoes': self.integracoes_publicas(), 'alterados': []}

    def cliente_nfe(self, exigir_ativo=True):
        cfg = self.config_integracao('nfe')
        if exigir_ativo and not cfg.get('ativo'):
            raise ErroNegocio('A emissão de nota pela integração está desligada (Configurações › Integrações).')
        url = os.environ.get('LOJA_ERP_FOCUS_URL') if integracoes.LOCAL_PERMITIDO else None
        try:
            return integracoes.FocusNFe(self.segredos_integracao('nfe')['token'], cfg.get('ambiente') or 'homologacao', url)
        except integracoes.ErroIntegracao as e:
            raise ErroNegocio(str(e))

    def cliente_pix(self, exigir_ativo=True):
        cfg = self.config_integracao('pix')
        if exigir_ativo and not cfg.get('ativo'):
            raise ErroNegocio('O Pix por API está desligado (Configurações › Integrações).')
        seg = self.segredos_integracao('pix')
        try:
            if cfg.get('provedor') == 'banco':
                return integracoes.PixBacen(cfg, seg)
            url = os.environ.get('LOJA_ERP_MP_URL') if integracoes.LOCAL_PERMITIDO else None
            return integracoes.PixMercadoPago(seg['token'], url)
        except integracoes.ErroIntegracao as e:
            raise ErroNegocio(str(e))

    def op_integracoes_testar(self, d, usuario):
        secao = d.get('secao')
        cliente = self.cliente_nfe(False) if secao == 'nfe' else self.cliente_pix(False) if secao == 'pix' else None
        if cliente is None:
            raise ErroNegocio('Integração desconhecida.')

        def concluir(r):
            if isinstance(r, Exception):
                raise ErroNegocio(f'Teste falhou: {r}')
            self.auditar(usuario, 'integracao_teste', f'{secao} ok')
            return {'ok': True, 'resultado': r}
        return {'_rede': {'chamar': cliente.testar, 'concluir': concluir}}

    # ------------------------------------------------------------------ nota fiscal
    @staticmethod
    def ref_nfe(venda, rejeicoes=0):
        base = f'loja-{venda["numero"]}-{venda["id"][:8]}'
        return base if not rejeicoes else f'{base}-{rejeicoes + 1}'

    def arquivo_xml_nfe(self, venda, chave):
        mes = (venda.get('data') or hoje())[:7]
        return os.path.join(DADOS_DIR, 'nfe', mes, f'{re.sub(r"[^0-9A-Za-z]", "", chave) or venda["id"]}.xml.cif')

    def op_nfe_emitir(self, d, usuario):
        b = self.banco
        venda = achar(b.c['vendas'], d.get('venda_id'))
        if not venda or venda['status'] != 'concluida':
            raise ErroNegocio('Venda não encontrada ou cancelada.')
        atual = venda.get('nfe') or {}
        if atual.get('status') in ('autorizado', 'processando_autorizacao'):
            raise ErroNegocio('Esta venda já tem nota emitida ou em processamento. Use "Consultar nota".')
        cfg = self.config_integracao('nfe')
        cliente = self.cliente_nfe()
        documento = so_digitos(d.get('documento') or (venda.get('nota') or {}).get('documento'))
        if documento and len(documento) not in (11, 14):
            raise ErroNegocio('CPF ou CNPJ inválido para a nota.')
        if any(not it.get('produto_id') for it in venda['itens']):
            raise ErroNegocio('Esta venda tem serviço (ajuste, costura, embalagem...). Serviço não entra na NFC-e: ele tem '
                              'nota própria de serviço (ISS). Venda o serviço separado das peças, ou fale com o contador.')
        try:
            dados = integracoes.montar_nfce(venda, {p['id']: p for p in b.c['produtos']},
                                            {c['id']: c for c in b.c['categorias']}, cfg, b.config.get('loja') or {}, documento,
                                            {v['codigo']: v.get('tipo') or 'troca' for v in b.c['vales']})
        except integracoes.ErroIntegracao as e:
            raise ErroNegocio(str(e))
        # Nota rejeitada pela Sefaz: nova referência. Sem resposta (queda, tempo esgotado): mesma referência, e
        # antes de reenviar consulta se a primeira chegou, para nunca emitir duas notas da mesma venda.
        if atual.get('status') == 'enviando' and str(atual.get('enviada_em') or '') > agora_menos(minutos=3):
            raise ErroNegocio('A nota desta venda está sendo enviada. Aguarde um instante e use "Consultar nota".')
        rejeicoes = int(atual.get('rejeicoes') or 0) + (1 if atual.get('status') == 'erro_autorizacao' else 0)
        ref = self.ref_nfe(venda, rejeicoes)
        conferir_antes = atual.get('status') in ('enviando', 'erro_comunicacao') and atual.get('ref') == ref
        with b.transacao('vendas'):
            venda['nfe'] = {'status': 'enviando', 'ref': ref, 'ambiente': cfg.get('ambiente') or 'homologacao',
                            'tentativas': int(atual.get('tentativas') or 0) + 1, 'rejeicoes': rejeicoes, 'enviada_em': agora()}

        def chamar():
            r = cliente.consultar_nfce(ref) if conferir_antes else None
            if not r or r['status'] == 'nao_encontrada':
                r = cliente.emitir_nfce(ref, dados)
            if r['status'] == 'autorizado':
                r['_xml'] = self._baixar_quieto(cliente, r['xml'])
            return r
        tentativa = venda['nfe']['tentativas']
        return {'_rede': {'chamar': chamar, 'concluir': lambda r: self.gravar_nfe(venda['id'], r, usuario, tentativa)}}

    @staticmethod
    def _baixar_quieto(cliente, caminho):
        try:
            return cliente.baixar(caminho)
        except integracoes.ErroIntegracao:
            return b''          # a nota vale mesmo sem o XML local; "Consultar nota" tenta baixar de novo

    def gravar_nfe(self, venda_id, r, usuario, tentativa=None):
        b = self.banco
        venda = achar(b.c['vendas'], venda_id)
        if not venda:
            raise ErroNegocio('Venda não encontrada.')
        nfe = venda.get('nfe') or {}
        if tentativa is not None and nfe.get('tentativas') != tentativa:
            # Outra emissão começou depois desta: a resposta antiga não pode sobrescrever a nova.
            return {'ok': nfe.get('status') == 'autorizado', 'nfe': nfe, 'alterados': []}
        falha = isinstance(r, Exception) or r['status'] in ('erro', 'nao_encontrada', 'erro_comunicacao')
        if falha and nfe.get('status') in ('autorizado', 'cancelado'):
            # Uma consulta que falhou não apaga nota autorizada ou cancelada na Sefaz.
            with b.transacao('vendas'):
                nfe['ultima_consulta'] = {'em': agora(), 'mensagem': str(r) if isinstance(r, Exception) else r['mensagem']}
            raise ErroNegocio('Não foi possível consultar a nota agora. Ela continua como estava; tente de novo mais tarde.')
        with b.transacao('vendas'):
            nfe = venda.setdefault('nfe', {})
            if isinstance(r, Exception):
                nfe.update(status='erro_comunicacao', mensagem=str(r))
            else:
                xml = r.pop('_xml', b'')
                nfe.update({k: v for k, v in r.items() if k != 'http'})
                if r['status'] == 'autorizado':
                    nfe['autorizada_em'] = nfe.get('autorizada_em') or agora()
                    nota = venda.setdefault('nota', {'pedida': True, 'documento': ''})
                    nota.update(pedida=True, numero=f'NFC-e {r["numero"]} série {r["serie"]}', registrada_em=agora())
                    if xml and self.cofre:
                        caminho = self.arquivo_xml_nfe(venda, r['chave'])
                        os.makedirs(os.path.dirname(caminho), exist_ok=True)
                        with open(caminho, 'wb') as f:
                            f.write(self.cofre.cifrar_bytes(xml))
                        nfe['xml_local'] = os.path.relpath(caminho, DADOS_DIR).replace(os.sep, '/')
        if not isinstance(r, Exception):
            self.auditar(usuario, 'nfe_' + (r['status'] or 'resposta'), f'venda {venda["numero"]} {r.get("chave", "")}')
        return {'ok': venda['nfe'].get('status') == 'autorizado', 'nfe': venda['nfe'], 'alterados': ['vendas']}

    def op_nfe_consultar(self, d, usuario):
        venda = achar(self.banco.c['vendas'], d.get('venda_id'))
        if not venda or not venda.get('nfe'):
            raise ErroNegocio('Esta venda não tem nota enviada.')
        cliente = self.cliente_nfe(False)
        ref = venda['nfe']['ref']
        precisa_xml = not venda['nfe'].get('xml_local')

        def chamar():
            r = cliente.consultar_nfce(ref)
            if r['status'] == 'autorizado' and precisa_xml:
                r['_xml'] = self._baixar_quieto(cliente, r['xml'])
            return r
        return {'_rede': {'chamar': chamar, 'concluir': lambda r: self.gravar_nfe(venda['id'], r, usuario)}}

    def op_nfe_cancelar(self, d, usuario):
        venda = achar(self.banco.c['vendas'], d.get('venda_id'))
        if not venda or (venda.get('nfe') or {}).get('status') != 'autorizado':
            raise ErroNegocio('Só dá para cancelar nota autorizada.')
        justificativa = ' '.join(str(d.get('justificativa') or '').split())
        if not 15 <= len(justificativa) <= 255:
            raise ErroNegocio('Escreva o motivo do cancelamento com 15 a 255 letras (exigência da Sefaz).')
        cliente = self.cliente_nfe(False)
        ref = venda['nfe']['ref']

        def concluir(r):
            if isinstance(r, Exception):
                raise ErroNegocio(f'A nota não foi cancelada: {r}')
            if r['status'] != 'cancelado':
                raise ErroNegocio(f'A Sefaz não cancelou a nota: {r["mensagem"] or r["status"]}. Se o prazo de cancelamento '
                                  'já passou, fale com o contador sobre a nota de devolução.')
            atual = achar(self.banco.c['vendas'], venda['id']) or venda
            with self.banco.transacao('vendas'):
                atual['nfe'].update(status='cancelado', cancelada_em=agora(), justificativa=justificativa,
                                    xml_cancelamento=r.get('xml_cancelamento') or '')
            self.auditar(usuario, 'nfe_cancelada', f'venda {atual["numero"]}')
            return {'ok': True, 'nfe': atual['nfe'], 'alterados': ['vendas']}
        return {'_rede': {'chamar': lambda: cliente.cancelar_nfce(ref, justificativa), 'concluir': concluir}}

    def op_nfe_danfe(self, d, usuario):
        """Baixa o DANFE (impressão da nota) do emissor e devolve para a tela imprimir."""
        venda = achar(self.banco.c['vendas'], d.get('venda_id'))
        nfe = (venda or {}).get('nfe') or {}
        if not nfe.get('danfe'):
            raise ErroNegocio('Esta venda não tem DANFE disponível.')
        cliente = self.cliente_nfe(False)

        def concluir(r):
            if isinstance(r, Exception):
                raise ErroNegocio(str(r))
            tipo = 'pdf' if r[:4] == b'%PDF' else 'html'
            return {'ok': True, 'tipo': tipo, 'arquivo': base64.b64encode(r).decode('ascii')}
        return {'_rede': {'chamar': lambda: cliente.baixar(nfe['danfe']), 'concluir': concluir}}

    # ------------------------------------------------------------------ Pix por API
    def op_pix_cobrar(self, d, usuario):
        valor = r2(num(d.get('valor')))
        if not 0 < valor <= 100000:
            raise ErroNegocio('Valor do Pix inválido.')
        cfg = self.config_integracao('pix')
        cliente_pix = self.cliente_pix()
        loja = self.banco.config.get('loja') or {}
        descricao = str(d.get('descricao') or f'Compra na {loja.get("nome") or "loja"}')[:100]
        minutos = max(5, min(120, inteiro(cfg.get('minutos'), 30)))
        if isinstance(cliente_pix, integracoes.PixMercadoPago):
            email = (cfg.get('email_pagador') or loja.get('email') or '').strip()
            if '@' not in email:
                raise ErroNegocio('O Mercado Pago pede um e-mail no Pix. Preencha o e-mail da loja ou o e-mail em Integrações › Pix.')
            chamar = lambda: cliente_pix.criar(valor, descricao, email, minutos)  # noqa: E731
        else:
            chamar = lambda: cliente_pix.criar(valor, descricao, minutos)  # noqa: E731

        def concluir(r):
            if isinstance(r, Exception):
                raise ErroNegocio(str(r))
            cob = {'id': novo_id(), 'provedor': cfg.get('provedor') or 'mercadopago', 'externo_id': r['externo_id'],
                   'valor': valor, 'descricao': descricao, 'status': r['status'], 'copia_cola': r['copia_cola'],
                   'criado_em': agora(), 'usuario': usuario, 'venda_id': None, 'pago_em': '', 'e2e': ''}
            with self.banco.transacao('cobrancas'):
                self.banco.c['cobrancas'].append(cob)
            return {'ok': True, 'cobranca': cob, 'qr_base64': r.get('qr_base64') or '', 'alterados': ['cobrancas']}
        return {'_rede': {'chamar': chamar, 'concluir': concluir}}

    def op_pix_status(self, d, usuario):
        cob = achar(self.banco.c['cobrancas'], d.get('id'))
        if not cob:
            raise ErroNegocio('Cobrança Pix não encontrada.')
        if cob['status'] != 'aguardando':
            return {'ok': True, 'cobranca': cob}
        cliente_pix = self.cliente_pix(False)

        def concluir(r):
            atual = achar(self.banco.c['cobrancas'], cob['id']) or cob
            if isinstance(r, Exception):
                return {'ok': False, 'cobranca': atual, 'erro': str(r)}   # a tela tenta de novo em seguida
            if atual['status'] != 'aguardando':
                return {'ok': True, 'cobranca': atual}
            with self.banco.transacao('cobrancas'):
                atual['status'] = r['status']
                if r['status'] == 'paga':
                    atual.update(pago_em=r.get('pago_em') or agora(), e2e=r.get('e2e') or '',
                                 valor_pago=r.get('valor_pago') or atual['valor'])
            if r['status'] == 'paga':
                self.auditar(usuario, 'pix_recebido', f'{atual["valor"]:.2f} {atual["provedor"]}')
            return {'ok': True, 'cobranca': atual, 'alterados': ['cobrancas']}
        return {'_rede': {'chamar': lambda: cliente_pix.consultar(cob['externo_id']), 'concluir': concluir}}

    def op_pix_cancelar(self, d, usuario):
        cob = achar(self.banco.c['cobrancas'], d.get('id'))
        if not cob or cob['status'] != 'aguardando':
            return {'ok': True}
        cliente_pix = self.cliente_pix(False)

        def chamar():
            # A cliente pode ter pago no último instante: cancela e depois confere o status real no serviço.
            try:
                cliente_pix.cancelar(cob['externo_id'])
            except integracoes.ErroIntegracao:
                pass
            return cliente_pix.consultar(cob['externo_id'])

        def concluir(r):
            if isinstance(r, Exception):
                return {'ok': False, 'erro': str(r)}     # continua aguardando; a consulta seguinte mostra se foi pago
            atual = achar(self.banco.c['cobrancas'], cob['id'])
            if atual and atual['status'] == 'aguardando':
                with self.banco.transacao('cobrancas'):
                    atual['status'] = r['status'] if r['status'] != 'aguardando' else 'cancelada'
                    if r['status'] == 'paga':
                        atual.update(pago_em=r.get('pago_em') or agora(), e2e=r.get('e2e') or '',
                                     valor_pago=r.get('valor_pago') or atual['valor'])
            return {'ok': True, 'cobranca': atual, 'alterados': ['cobrancas']}
        return {'_rede': {'chamar': chamar, 'concluir': concluir}}

    # ------------------------------------------------------------------ conciliação
    @staticmethod
    def _arquivo_enviado(d):
        try:
            conteudo = base64.b64decode(str(d.get('arquivo') or ''), validate=True)
        except ValueError:
            raise ErroNegocio('Arquivo inválido.')
        if not conteudo:
            raise ErroNegocio('Escolha o arquivo.')
        if len(conteudo) > 10 * 1024 * 1024:
            raise ErroNegocio('Arquivo grande demais (máximo 10 MB). Exporte um período menor.')
        return conteudo

    def descrever_lancamento(self, f):
        return {'id': f['id'], 'descricao': f['descricao'], 'valor': f['valor'], 'liquido': f.get('liquido'),
                'vencimento': f.get('vencimento'), 'status': f['status'], 'forma': f.get('forma'), 'tipo': f['tipo']}

    def op_conciliacao_cartoes(self, d, usuario):
        b = self.banco
        provedor = str(d.get('provedor') or 'maquininha')[:30]
        mapa = d.get('mapa') if isinstance(d.get('mapa'), dict) else None
        if mapa:
            mapa = {k: inteiro(v) for k, v in mapa.items() if k in conciliacao.SINONIMOS and str(v) != ''}
        try:
            lido = conciliacao.vendas_maquininha(self._arquivo_enviado(d), mapa)
        except conciliacao.ErroArquivo as e:
            raise ErroNegocio(str(e))
        r = conciliacao.conciliar_cartoes(lido['vendas'], b.c['financeiro'])
        idx = {f['id']: f for f in b.c['financeiro']}
        taxa_relatorio = r2(sum(c['taxa'] or 0 for c in r['casadas']))
        taxa_sistema = r2(sum(idx[i].get('taxa') or 0 for c in r['casadas'] for i in c['ids']))
        resposta = {'cabecalho': lido['cabecalho'], 'mapa': lido['mapa'], 'linhas': len(lido['vendas']),
                    'casadas': len(r['casadas']), 'taxa_relatorio': taxa_relatorio, 'taxa_sistema': taxa_sistema,
                    'so_no_relatorio': r['so_no_relatorio'][:200],
                    'so_no_sistema': [self.descrever_lancamento(idx[i]) for i in r['so_no_sistema']][:200]}
        if not d.get('aplicar'):
            return resposta
        with b.transacao('financeiro', 'conciliacoes', 'config'):
            for c in r['casadas']:
                fs = [idx[i] for i in c['ids']]
                total = sum(f['valor'] for f in fs) or 1
                for f in fs:
                    if f['status'] == 'pendente' and c['taxa'] is not None:
                        f['taxa'] = r2(c['taxa'] * f['valor'] / total)
                        f['liquido'] = r2(f['valor'] - f['taxa'])
                        if c['previsao']:
                            f['vencimento'] = c['previsao']
                    f['conciliado'] = {'fonte': provedor, 'nsu': c['nsu'], 'em': hoje()}
            b.c['conciliacoes'].append({'id': novo_id(), 'tipo': 'cartoes', 'provedor': provedor,
                                        'arquivo': str(d.get('nome') or '')[:120], 'em': agora(), 'usuario': usuario,
                                        'casadas': len(r['casadas']), 'so_no_relatorio': r['so_no_relatorio'][:500],
                                        'so_no_sistema': r['so_no_sistema'][:500]})
            b.config.setdefault('integracoes', {}).setdefault('cartoes', {}).setdefault('mapas', {})[provedor] = lido['mapa']
        self.auditar(usuario, 'conciliacao_cartoes', f'{provedor}: {len(r["casadas"])} casadas')
        resposta.update(ok=True, aplicado=True, alterados=['financeiro', 'conciliacoes'])
        return resposta

    def op_conciliacao_extrato(self, d, usuario):
        b = self.banco
        try:
            extrato = conciliacao.ler_ofx(self._arquivo_enviado(d))
        except conciliacao.ErroArquivo as e:
            raise ErroNegocio(str(e))
        ja = {t['id'] for c in b.c['conciliacoes'] if c.get('tipo') == 'extrato' for t in c.get('transacoes', [])}
        r = conciliacao.conciliar_extrato(extrato['transacoes'], b.c['financeiro'], ja)
        ignorar = set(d.get('ignorar') or []) if isinstance(d.get('ignorar'), list) else set()
        if ignorar:
            r['sem_par'] += [c['transacao'] for c in r['casadas'] if c['transacao']['id'] in ignorar]
            r['casadas'] = [c for c in r['casadas'] if c['transacao']['id'] not in ignorar]
        idx = {f['id']: f for f in b.c['financeiro']}
        resposta = {'banco': extrato['banco'], 'conta': extrato['conta'], 'inicio': extrato['inicio'], 'fim': extrato['fim'],
                    'total': len(extrato['transacoes']), 'repetidas': sum(1 for t in extrato['transacoes'] if t['id'] in ja),
                    'casadas': [{'transacao': c['transacao'], 'lancamentos': [self.descrever_lancamento(idx[i]) for i in c['ids']],
                                 'baixar': len(c['baixar'])} for c in r['casadas']][:300],
                    'sem_par': r['sem_par'][:300]}
        if not d.get('aplicar'):
            return resposta
        with b.transacao('financeiro', 'conciliacoes'):
            for c in r['casadas']:
                t = c['transacao']
                fs = [idx[i] for i in c['ids']]
                for f in fs:
                    if f['status'] == 'pendente':
                        valor_pago = abs(t['valor']) if len(fs) == 1 else (f.get('liquido') if f['tipo'] == 'receber' else f['valor'])
                        f.update(status='pago', pago_em=t['data'], valor_pago=r2(valor_pago))
                    f['conferido_extrato'] = {'transacao': t['id'], 'data': t['data']}
            registro = {'id': novo_id(), 'tipo': 'extrato', 'banco': extrato['banco'], 'conta': extrato['conta'],
                        'inicio': extrato['inicio'], 'fim': extrato['fim'], 'arquivo': str(d.get('nome') or '')[:120],
                        'em': agora(), 'usuario': usuario,
                        'transacoes': [dict(c['transacao'], ids=c['ids']) for c in r['casadas']]
                        + [dict(t, ids=[]) for t in r['sem_par']]}
            b.c['conciliacoes'].append(registro)
        self.auditar(usuario, 'conciliacao_extrato', f'{len(r["casadas"])} casadas, {len(r["sem_par"])} sem par')
        resposta.update(ok=True, aplicado=True, conciliacao_id=registro['id'], alterados=['financeiro', 'conciliacoes'])
        return resposta

    def op_conciliacao_lancar(self, d, usuario):
        """Lança no financeiro uma movimentação do extrato que não tinha par (ex.: tarifa do banco)."""
        b = self.banco
        reg = achar(b.c['conciliacoes'], d.get('conciliacao_id'))
        t = next((x for x in (reg or {}).get('transacoes', []) if x['id'] == d.get('transacao_id')), None)
        if not t or t.get('ids') or t.get('lancado') or any(
                x.get('lancado') or x.get('ids') for c in b.c['conciliacoes'] if c.get('tipo') == 'extrato'
                for x in c.get('transacoes', []) if x['id'] == t['id']):
            raise ErroNegocio('Movimentação não encontrada ou já conciliada.')
        conta = achar(b.c['plano_contas'], d.get('categoria_id'))
        tipo = 'receber' if t['valor'] > 0 else 'pagar'
        if not conta or conta.get('tipo') != ('receita' if tipo == 'receber' else 'despesa'):
            raise ErroNegocio('Escolha uma categoria de ' + ('receita' if tipo == 'receber' else 'despesa') + '.')
        with b.transacao('financeiro', 'conciliacoes'):
            f = self.lancar(tipo=tipo, descricao=str(d.get('descricao') or t['descricao'] or 'Movimentação do extrato')[:120],
                            categoria_id=conta['id'], valor=abs(t['valor']), vencimento=t['data'], status='pago',
                            pago_em=t['data'], forma='banco', origem='extrato')
            f['conferido_extrato'] = {'transacao': t['id'], 'data': t['data']}
            t['lancado'] = f['id']
        self.auditar(usuario, 'conciliacao_lancamento', f'{tipo} {abs(t["valor"]):.2f}')
        return {'ok': True, 'alterados': ['financeiro', 'conciliacoes']}

    # ------------------------------------------------------------- pacote do contador
    def op_contador_pacote(self, d, usuario):
        mes = str(d.get('mes') or '')
        if not re.fullmatch(r'\d{4}-\d{2}', mes):
            raise ErroNegocio('Escolha o mês.')
        conteudo = pacote_contador(self, mes, d.get('dre') if isinstance(d.get('dre'), list) else [])
        self.auditar(usuario, 'pacote_contador', mes)
        loja = slug((self.banco.config.get('loja') or {}).get('nome') or 'loja').replace('_', '-') or 'loja'
        return {'ok': True, 'nome': f'contador-{loja}-{mes}.zip', 'arquivo': base64.b64encode(conteudo).decode('ascii')}

    def op_troca(self, d, usuario):
        b = self.banco
        venda = achar(b.c['vendas'], d.get('venda_id'))
        if d.get('venda_id') and (not venda or venda['status'] != 'concluida'):
            raise ErroNegocio('Venda não encontrada ou cancelada.')
        destino = d.get('destino')
        if destino not in ('vale', 'dinheiro', 'pix', 'estorno_cartao'):
            raise ErroNegocio('Escolha o destino do valor (vale-troca ou devolução).')
        cliente_id = d.get('cliente_id') or (venda or {}).get('cliente_id')
        itens_in = [i for i in (d.get('itens') or []) if inteiro(i.get('qtd')) > 0]
        if not itens_in:
            raise ErroNegocio('Selecione as peças devolvidas.')
        validade = self.validade_vale(d, 'validade_dias') if destino == 'vale' else None
        with b.transacao('produtos', 'movimentos', 'trocas', 'vales', 'financeiro', 'config'):
            numero = self.proximo('troca')
            tid = novo_id()
            itens, total, custo_total = [], 0.0, 0.0
            for it in itens_in:
                q = inteiro(it['qtd'])
                p, v = self.produto_variacao(it.get('produto_id'), it.get('variacao_id'))
                custo = num(p.get('custo'))
                valor_unit = r2(num(it.get('valor_unit')) or p['preco'])
                if venda:
                    vend = [i for i in venda['itens'] if i.get('variacao_id') == v['id']]
                    if not vend:
                        raise ErroNegocio(f'{p["nome"]} {v["tamanho"]}/{v["cor"]} não consta nesta venda.')
                    qtd_vendida = sum(i['qtd'] for i in vend)
                    ja = sum(x['qtd'] for t in b.c['trocas'] if t.get('venda_id') == venda['id']
                             for x in t['itens'] if x['variacao_id'] == v['id'])
                    if q > qtd_vendida - ja:
                        raise ErroNegocio(f'Quantidade devolvida maior que a vendida para {p["nome"]}.')
                    custo = vend[0]['custo_unit']
                    valor_unit = r2(sum(i['total'] for i in vend) / qtd_vendida)
                v['estoque'] += q
                self.movimento('devolucao', p, v, q, custo, ref=tid, doc=f'Troca {numero}', usuario=usuario)
                itens.append({'produto_id': p['id'], 'variacao_id': v['id'], 'nome': p['nome'], 'tamanho': v['tamanho'],
                              'cor': v['cor'], 'qtd': q, 'valor_unit': valor_unit, 'custo_unit': r2(custo)})
                total += q * valor_unit
                custo_total += q * custo
            total = r2(total)
            reg = {'id': tid, 'numero': numero, 'data': agora(), 'venda_id': venda['id'] if venda else None,
                   'venda_numero': venda['numero'] if venda else None, 'cliente_id': cliente_id, 'itens': itens,
                   'total': total, 'custo_total': r2(custo_total), 'destino': destino,
                   'motivo': str(d.get('motivo') or ''), 'usuario': usuario, 'vale_codigo': None}
            if destino == 'vale':
                codigo = self.novo_codigo_vale()
                b.c['vales'].append({'id': novo_id(), 'tipo': 'troca', 'codigo': codigo, 'cliente_id': cliente_id,
                                     'valor': total, 'saldo': total, 'status': 'ativo', 'criado_em': agora(),
                                     'validade': validade, 'troca_id': tid, 'usos': []})
                reg['vale_codigo'] = codigo
            else:
                caixa = self.caixa_aberto() if destino == 'dinheiro' else None
                self.lancar(tipo='pagar', descricao=f'Devolução troca {numero}', categoria_id='pc_devolucao_cliente',
                            valor=total, vencimento=hoje(), status='pago', pago_em=hoje(), forma=destino,
                            origem='troca', ref=tid, cliente_id=cliente_id,
                            caixa_id=caixa['id'] if caixa else None)
            b.c['trocas'].append(reg)
        self.auditar(usuario, 'troca', f'nº {numero} {destino} {total:.2f}')
        return {'ok': True, 'troca': reg,
                'alterados': ['produtos', 'movimentos', 'trocas', 'vales', 'financeiro']}

    # -------------------------------------------------------------------- caixa
    def op_caixa_abrir(self, d, usuario):
        if self.caixa_aberto():
            raise ErroNegocio('Já existe um caixa aberto.')
        with self.banco.transacao('caixa'):
            self.banco.c['caixa'].append({'id': novo_id(), 'aberto_em': agora(), 'valor_inicial': r2(max(0, num(d.get('valor')))),
                                          'movimentos': [], 'status': 'aberto', 'usuario': usuario})
        self.auditar(usuario, 'caixa_aberto', f'{num(d.get("valor")):.2f}')
        return {'ok': True, 'alterados': ['caixa']}

    def op_caixa_movimento(self, d, usuario):
        c = self.caixa_aberto()
        if not c:
            raise ErroNegocio('Abra o caixa primeiro.')
        tipo = d.get('tipo')
        valor = r2(num(d.get('valor')))
        if tipo not in ('sangria', 'suprimento') or valor <= 0:
            raise ErroNegocio('Movimento inválido.')
        with self.banco.transacao('caixa'):
            c['movimentos'].append({'data': agora(), 'tipo': tipo, 'valor': valor, 'obs': str(d.get('obs') or ''),
                                    'usuario': usuario})
        self.auditar(usuario, f'caixa_{tipo}', f'{valor:.2f}')
        return {'ok': True, 'alterados': ['caixa']}

    def op_caixa_fechar(self, d, usuario):
        c = self.caixa_aberto()
        if not c:
            raise ErroNegocio('Não há caixa aberto.')
        contado = r2(num(d.get('contado')))
        with self.banco.transacao('caixa'):
            resumo = self.caixa_esperado(c)
            c.update(status='fechado', fechado_em=agora(), contado=contado, resumo=resumo,
                     esperado=resumo['esperado'], diferenca=r2(contado - resumo['esperado']),
                     obs=str(d.get('obs') or ''))
        self.auditar(usuario, 'caixa_fechado', f'contado {contado:.2f} diferença {c["diferenca"]:.2f}')
        return {'ok': True, 'caixa': c, 'alterados': ['caixa']}

    # --------------------------------------------------------------- financeiro
    def op_fin_lancar(self, d, usuario):
        tipo = d.get('tipo')
        if tipo not in ('pagar', 'receber'):
            raise ErroNegocio('Tipo inválido.')
        descricao = str(d.get('descricao') or '').strip()
        valor = r2(num(d.get('valor')))
        if not descricao or valor <= 0:
            raise ErroNegocio('Informe descrição e valor.')
        venc = str(d.get('vencimento') or hoje())[:10]
        n = max(1, min(60, inteiro(d.get('parcelas'), 1)))
        repetir = d.get('modo_parcelas') == 'repetir'
        parte = valor if repetir else r2(valor / n)
        with self.banco.transacao('financeiro'):
            for k in range(n):
                v = parte if (repetir or k < n - 1) else r2(valor - parte * (n - 1))
                vk = somar_meses(venc, k)
                comp = d.get('competencia') if n == 1 and d.get('competencia') else vk[:7]
                pago = bool(d.get('pago')) and k == 0
                caixa = self.caixa_aberto() if pago and d.get('forma') == 'dinheiro' and d.get('usar_caixa') else None
                self.lancar(tipo=tipo, descricao=descricao + (f' ({k + 1}/{n})' if n > 1 else ''),
                            categoria_id=d.get('categoria_id'), valor=v, vencimento=vk, competencia=comp,
                            status='pago' if pago else 'pendente', pago_em=hoje() if pago else None,
                            forma=d.get('forma') or '', fornecedor_id=d.get('fornecedor_id') or None,
                            cliente_id=d.get('cliente_id') or None, obs=str(d.get('obs') or ''),
                            parcela=f'{k + 1}/{n}' if n > 1 else '', caixa_id=caixa['id'] if caixa else None)
        self.auditar(usuario, 'lancamento', f'{tipo} {descricao} {valor:.2f}')
        return {'ok': True, 'alterados': ['financeiro']}

    def op_fin_baixar(self, d, usuario):
        f = achar(self.banco.c['financeiro'], d.get('id'))
        if not f or f['status'] != 'pendente':
            raise ErroNegocio('Lançamento não encontrado ou já baixado.')
        forma = d.get('forma') or f.get('forma') or ''
        with self.banco.transacao('financeiro'):
            caixa = self.caixa_aberto() if forma == 'dinheiro' and d.get('usar_caixa', True) else None
            padrao = f['liquido'] if f['tipo'] == 'receber' else f['valor']
            f.update(status='pago', pago_em=str(d.get('data') or hoje())[:10], forma=forma,
                     valor_pago=r2(num(d.get('valor_pago'), padrao)), caixa_id=caixa['id'] if caixa else None)
        self.auditar(usuario, 'baixa', f'{f["descricao"]} {f["valor_pago"]:.2f}')
        return {'ok': True, 'alterados': ['financeiro']}

    def op_fin_estornar(self, d, usuario):
        f = achar(self.banco.c['financeiro'], d.get('id'))
        if not f or f['status'] != 'pago':
            raise ErroNegocio('Lançamento não está pago.')
        with self.banco.transacao('financeiro'):
            f.update(status='pendente', pago_em=None, valor_pago=None, caixa_id=None)
        self.auditar(usuario, 'estorno_baixa', f['descricao'])
        return {'ok': True, 'alterados': ['financeiro']}

    def op_fin_editar(self, d, usuario):
        o = d.get('obj') or {}
        f = achar(self.banco.c['financeiro'], o.get('id'))
        if not f:
            raise ErroNegocio('Lançamento não encontrado.')
        if f['status'] != 'pendente' or f.get('origem') in ('venda', 'crediario', 'troca'):
            raise ErroNegocio('Somente lançamentos pendentes criados manualmente, recorrentes ou de compras podem ser editados.')
        valor = r2(num(o.get('valor')))
        if valor <= 0:
            raise ErroNegocio('Valor inválido.')
        with self.banco.transacao('financeiro'):
            f.update(descricao=str(o.get('descricao') or f['descricao']), categoria_id=o.get('categoria_id') or f['categoria_id'],
                     valor=valor, liquido=r2(valor - f.get('taxa', 0)), vencimento=str(o.get('vencimento') or f['vencimento'])[:10],
                     competencia=str(o.get('competencia') or f['competencia'])[:7], obs=str(o.get('obs') or ''),
                     fornecedor_id=o.get('fornecedor_id') or f.get('fornecedor_id'))
        self.auditar(usuario, 'lancamento_editado', f['descricao'])
        return {'ok': True, 'alterados': ['financeiro']}

    def op_fin_excluir(self, d, usuario):
        f = achar(self.banco.c['financeiro'], d.get('id'))
        if not f:
            raise ErroNegocio('Lançamento não encontrado.')
        if f.get('origem') not in ('manual', 'recorrente'):
            raise ErroNegocio('Este lançamento veio de uma venda, compra ou troca. Cancele pela origem.')
        with self.banco.transacao('financeiro'):
            if f.get('origem') == 'recorrente':
                f['status'] = 'cancelado'
            else:
                self.banco.c['financeiro'] = [x for x in self.banco.c['financeiro'] if x['id'] != f['id']]
        self.auditar(usuario, 'lancamento_excluido', f['descricao'])
        return {'ok': True, 'alterados': ['financeiro']}

    def op_recorrentes_gerar(self, d, usuario):
        mes = str(d.get('mes') or hoje()[:7])[:7]
        if not re.fullmatch(r'\d{4}-\d{2}', mes):
            raise ErroNegocio('Mês inválido.')
        with self.banco.transacao('financeiro'):
            n = self.gerar_recorrentes(mes)
        self.auditar(usuario, 'recorrentes_gerados', f'{mes}: {n}')
        return {'ok': True, 'criados': n, 'alterados': ['financeiro']}

    # ------------------------------------------------------- arquivos e backup
    def op_foto(self, d, usuario):
        m = re.match(r'data:image/(jpeg|png|webp);base64,(.+)$', str(d.get('imagem') or ''), re.S)
        if not m:
            raise ErroNegocio('Imagem inválida.')
        dados = base64.b64decode(m.group(2))
        if len(dados) > 4 * 1024 * 1024:
            raise ErroNegocio('Imagem muito grande (máx. 4 MB).')
        assinaturas = {'jpeg': b'\xff\xd8', 'png': b'\x89PNG', 'webp': b'RIFF'}
        if not dados.startswith(assinaturas[m.group(1)]):
            raise ErroNegocio('Arquivo de imagem inválido.')
        nome = f'{novo_id()}.{"jpg" if m.group(1) == "jpeg" else m.group(1)}'
        with open(os.path.join(FOTOS_DIR, nome), 'wb') as f:
            f.write(dados)
        return {'ok': True, 'arquivo': nome}

    def _indice_backups(self):
        try:
            with open(os.path.join(BACKUP_DIR, 'indice.json'), 'r', encoding='utf-8') as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def _gravar_indice_backups(self, indice):
        caminho = os.path.join(BACKUP_DIR, 'indice.json')
        with open(caminho + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(indice, f, ensure_ascii=False, indent=1)
        os.replace(caminho + '.tmp', caminho)

    def listar_backups(self):
        indice = self._indice_backups()
        lista = []
        try:
            nomes = os.listdir(BACKUP_DIR)
        except OSError:
            return []
        for nome in nomes:
            m = PADRAO_BACKUP.fullmatch(nome) or re.fullmatch(r'enviado-[0-9a-f]+\.lojabkp', nome)
            if not m:
                continue
            caminho = os.path.join(BACKUP_DIR, nome)
            item = {'nome': nome, 'tamanho': os.path.getsize(caminho), 'formato': 'antigo (zip)' if nome.endswith('.zip') else 'cifrado'}
            item.update(indice.get(nome, {}))
            if 'criado_em' not in item:
                if m.re is PADRAO_BACKUP:
                    item['criado_em'] = dt.datetime.strptime(m.group(1) + m.group(2), '%Y%m%d%H%M%S').isoformat()
                else:
                    item['criado_em'] = dt.datetime.fromtimestamp(os.path.getmtime(caminho)).replace(microsecond=0).isoformat()
            lista.append(item)
        return sorted(lista, key=lambda x: x['criado_em'], reverse=True)

    def resumo_backups_publico(self):
        """Lista backups sem precisar da chave (para a tela de recuperação)."""
        saida = []
        for item in self.listar_backups():
            info = {k: item.get(k) for k in ('nome', 'criado_em', 'tamanho', 'formato')}
            if item['formato'] == 'cifrado':
                try:
                    cab, _ = ler_cabecalho_backup(os.path.join(BACKUP_DIR, item['nome']))
                    info['loja'] = cab.get('loja', '')
                except (OSError, ValueError):
                    info['danificado'] = True
            saida.append(info)
        return saida

    def fazer_backup(self, motivo='automático'):
        """Gera backup compactado e criptografado, confere a gravação e aplica a retenção."""
        if not self.chave:
            raise ErroNegocio('Entre no sistema para fazer o backup.')
        os.makedirs(BACKUP_DIR, exist_ok=True)
        conteudo, quantidade = compactar_dados()
        criado = dt.datetime.now().replace(microsecond=0)
        while os.path.exists(os.path.join(BACKUP_DIR, f'backup-{criado:%Y%m%d-%H%M%S}.lojabkp')):
            criado += dt.timedelta(seconds=1)
        nome = f'backup-{criado:%Y%m%d-%H%M%S}.lojabkp'
        caminho = os.path.join(BACKUP_DIR, nome)
        u = self.banco.usuarios
        sal = secrets.token_bytes(16)
        # Só proprietária e gerente abrem o backup; a lista não expõe logins nem nomes.
        gestao = [{'id': id_login(sal, x['login']), 'envelope': x['envelope']}
                  for x in u.get('lista', []) if x.get('papel') in ('dona', 'gerente')]
        cab = {
            'formato': 2, 'app': VERSAO, 'criado_em': criado.isoformat(),
            'loja': self.banco.config.get('loja', {}).get('nome', ''), 'arquivos': quantidade,
            'tamanho': len(conteudo), 'sha256': hashlib.sha256(conteudo).hexdigest(), 'motivo': motivo,
            'acesso': {'sal': sal.hex(), 'lista': gestao,
                       'recuperacao': u.get('recuperacao'), 'verificador': u.get('verificador')},
        }
        cab_bytes = json.dumps(cab, ensure_ascii=False).encode('utf-8')
        cofre = Cofre(chave_backup(self.chave))
        with open(caminho + '.tmp', 'wb') as f:
            f.write(MAGICO_BACKUP + len(cab_bytes).to_bytes(4, 'big') + cab_bytes)
            f.write(cofre.cifrar_bytes(conteudo))
            f.flush()
            os.fsync(f.fileno())
        os.replace(caminho + '.tmp', caminho)
        try:
            cab_lido, inicio = ler_cabecalho_backup(caminho)
            with open(caminho, 'rb') as f:
                f.seek(inicio)
                relido = cofre.decifrar_bytes(f.read())
            verificado = hashlib.sha256(relido).hexdigest() == cab_lido['sha256']
            validar_zip_dados(relido)
        except (OSError, ValueError, ErroNegocio):
            verificado = False
        indice = self._indice_backups()
        indice[nome] = {'criado_em': cab['criado_em'], 'arquivos': quantidade, 'verificado': verificado, 'motivo': motivo}
        manter = selecionar_retencao([b['nome'] for b in self.listar_backups()] + [nome])
        for antigo in list(indice) + [x for x in os.listdir(BACKUP_DIR)]:
            if PADRAO_BACKUP.fullmatch(antigo) and antigo not in manter:
                try:
                    os.remove(os.path.join(BACKUP_DIR, antigo))
                except OSError:
                    pass
                indice.pop(antigo, None)
        self._gravar_indice_backups(indice)
        if not verificado:
            self.auditar('sistema', 'backup_falhou_verificacao', nome)
        return nome, verificado

    def op_backup(self, d, usuario):
        nome, verificado = self.fazer_backup('manual')
        self.auditar(usuario, 'backup', nome)
        if not verificado:
            raise ErroNegocio('O backup foi gravado mas falhou na conferência. Verifique o espaço em disco e tente de novo.')
        return {'ok': True, 'arquivo': nome}

    @staticmethod
    def receber_backup(entrada, tamanho):
        """Grava em disco, aos poucos, um backup .lojabkp enviado pela tela (restauração em outro computador).
        Só aceita o formato criptografado: um .zip antigo é restaurado apenas se já estiver na pasta backups."""
        inicio = entrada.read(min(tamanho, len(MAGICO_BACKUP)))
        if inicio != MAGICO_BACKUP:
            raise ErroNegocio('Este arquivo não é um backup criptografado do Loja ERP (.lojabkp).')
        os.makedirs(BACKUP_DIR, exist_ok=True)
        nome = f'enviado-{secrets.token_hex(6)}.lojabkp'
        caminho = os.path.join(BACKUP_DIR, nome)
        restante = tamanho - len(inicio)
        try:
            with open(caminho + '.tmp', 'wb') as f:
                f.write(inicio)
                while restante > 0:
                    bloco = entrada.read(min(restante, 1024 * 1024))
                    if not bloco:
                        raise ErroNegocio('O envio do arquivo foi interrompido. Tente de novo.')
                    f.write(bloco)
                    restante -= len(bloco)
            ler_cabecalho_backup(caminho + '.tmp')
            os.replace(caminho + '.tmp', caminho)
        except (OSError, ValueError) as e:
            raise ErroNegocio(f'Não foi possível receber o backup: {e}')
        finally:
            if os.path.exists(caminho + '.tmp'):
                os.remove(caminho + '.tmp')
        return {'ok': True, 'nome': nome}

    def op_restaurar(self, d, sessao):
        """Restaura um backup. A pasta de dados atual é preservada ao lado, nunca apagada."""
        nome = os.path.basename(str(d.get('nome') or ''))
        caminho = os.path.join(BACKUP_DIR, nome)
        if not (PADRAO_BACKUP.fullmatch(nome) or re.fullmatch(r'enviado-[0-9a-f]+\.lojabkp', nome)) or not os.path.isfile(caminho):
            raise ErroNegocio('Backup não encontrado.')
        livre = self.recuperacao or self.precisa_setup()
        if not livre and not (sessao and self.papel(sessao['login']) == 'dona'):
            raise ErroNegocio('Somente a proprietária pode restaurar um backup.')
        self._checar_bloqueio()
        login = str(d.get('login') or (sessao or {}).get('login') or '').strip().lower()
        try:
            conteudo = abrir_backup(caminho, login, d.get('segredo'))
        except ErroNegocio:
            self._registrar_falha()
            raise
        validar_zip_dados(conteudo)
        carimbo = f'{dt.datetime.now():%Y%m%d-%H%M%S}'
        if self.chave and not self.recuperacao:
            try:
                self.fazer_backup('antes de restaurar')
            except (OSError, ErroNegocio):
                pass
        if os.path.isdir(DADOS_DIR) and os.listdir(DADOS_DIR):
            destino = os.path.join(PASTA_LOJA, f'dados-antes-da-restauracao-{carimbo}')
            for tentativa in range(10):
                try:
                    os.replace(DADOS_DIR, destino)
                    break
                except OSError:
                    if tentativa == 9:
                        raise ErroNegocio('Não foi possível substituir a pasta de dados (algum programa está usando os arquivos). '
                                          'Pause a sincronização da nuvem por um instante e tente de novo.')
                    time.sleep(0.5)
        temporaria = os.path.join(PASTA_LOJA, f'.restaurando-{carimbo}')
        with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
            z.extractall(temporaria)
        os.replace(os.path.join(temporaria, 'dados'), DADOS_DIR)
        shutil.rmtree(temporaria, ignore_errors=True)
        os.makedirs(FOTOS_DIR, exist_ok=True)
        self.banco = Banco()
        self.recuperacao = ''
        self.sessoes.clear()
        self.chave = self.cofre = None
        self.dia_rotina = None
        self._zerar_falhas()
        self.auditar(login or '-', 'backup_restaurado', nome)
        return {'ok': True, '_sessao': '',
                'mensagem': 'Backup restaurado. Entre novamente com seu usuário e senha da época do backup.'}

    def saude(self):
        """Situação do backup e da sincronização com a nuvem, para o indicador da tela."""
        nuvem = detectar_nuvem(PASTA_LOJA)
        app_ativo = app_de_sincronizacao_ativo(nuvem)
        conflitos = arquivos_de_conflito()
        backups = [b for b in self.listar_backups() if b['formato'] == 'cifrado' and b['nome'].startswith('backup-')]
        ultimo = backups[0] if backups else None
        horas = (dt.datetime.now() - dt.datetime.fromisoformat(ultimo['criado_em'])).total_seconds() / 3600 if ultimo else None
        msgs = []
        if conflitos:
            msgs.append(('erro', f'{len(conflitos)} arquivo(s) de conflito de sincronização na pasta de dados. '
                                 'Isso acontece quando o sistema é usado em dois computadores ao mesmo tempo.'))
        if not ultimo:
            msgs.append(('alerta', 'Ainda não há backup. Ele é feito automaticamente uma vez por dia.'))
        elif ultimo.get('verificado') is False:
            msgs.append(('erro', 'O último backup falhou na conferência. Faça um backup manual.'))
        elif horas > 72:
            msgs.append(('erro', f'O último backup tem {int(horas // 24)} dias.'))
        elif horas > 26:
            msgs.append(('alerta', 'O backup de hoje ainda não foi feito.'))
        if not nuvem:
            msgs.append(('alerta', 'A pasta da loja não está no Google Drive, OneDrive ou Dropbox: os dados não têm cópia na nuvem.'))
        elif app_ativo is False:
            msgs.append(('alerta', f'O aplicativo do {nuvem} não está aberto neste computador: os dados não estão sendo enviados para a nuvem.'))
        nivel = 'erro' if any(t == 'erro' for t, _ in msgs) else 'alerta' if msgs else 'ok'
        return {'nivel': nivel, 'mensagens': [m for _, m in msgs], 'nuvem': nuvem, 'app_nuvem_ativo': app_ativo,
                'conflitos': conflitos, 'ultimo_backup': ultimo, 'pasta_loja': PASTA_LOJA,
                'restauracoes_anteriores': sorted(n for n in os.listdir(PASTA_LOJA) if n.startswith('dados-antes-da-restauracao-'))
                if os.path.isdir(PASTA_LOJA) else []}

    def op_conflito_mover(self, d, usuario):
        nome = os.path.basename(str(d.get('nome') or ''))
        if nome not in arquivos_de_conflito():
            raise ErroNegocio('Arquivo não encontrado.')
        quarentena = os.path.join(DADOS_DIR, '_conflitos')
        os.makedirs(quarentena, exist_ok=True)
        os.replace(os.path.join(DADOS_DIR, nome), os.path.join(quarentena, nome))
        self.auditar(usuario, 'conflito_movido', nome)
        return {'ok': True}

    def op_limpar_exemplo(self, d, usuario):
        u = self._usuario(usuario)
        try:
            desenvelopar(u['envelope'], str(d.get('senha', '')))
        except ValueError:
            raise ErroNegocio('Senha incorreta.')
        b = self.banco
        self.fazer_backup('antes de remover exemplos')
        with b.transacao(*COLECOES, 'config'):
            for nome in COLECOES:
                if nome == 'recorrentes':
                    for r in b.c[nome]:
                        if r.pop('exemplo', None):
                            r.update(valor=0, ativo=False)
                    continue
                b.c[nome] = [x for x in b.c[nome] if not x.get('exemplo')]
            seq = b.config['seq']
            seq['venda'] = max([v['numero'] for v in b.c['vendas']] or [0])
            seq['condicional'] = max([c['numero'] for c in b.c['condicionais']] or [0])
            seq['troca'] = max([t['numero'] for t in b.c['trocas']] or [0])
            seq['entrada'] = max([e['numero'] for e in b.c['entradas']] or [0])
            b.config['metas'] = {}
        self.auditar(usuario, 'dados_exemplo_removidos')
        return {'ok': True, 'alterados': list(COLECOES)}

    def op_encerrar(self, d, usuario):
        self.auditar(usuario, 'sistema_encerrado')
        return {'ok': True, '_encerrar': True}

    # --------------------------------------------------- dados pré-programados
    def semear(self, exemplo, regime):
        b = self.banco
        ano = dt.date.today().year
        b.c['plano_contas'] = [{'id': i, 'nome': n, 'tipo': t, 'grupo': g, 'sistema': i in PLANO_SISTEMA, 'ativo': True}
                               for i, n, t, g in PLANO_CONTAS]
        categorias = [
            ('Blusas', 22, 2.3), ('Camisetas', 20, 2.2), ('Regatas', 20, 2.2), ('Camisas', 22, 2.3),
            ('Vestidos', 22, 2.4), ('Saias', 22, 2.3), ('Shorts', 20, 2.2), ('Calças', 20, 2.2),
            ('Jeans', 18, 2.1), ('Macacões', 22, 2.3), ('Conjuntos', 22, 2.3), ('Moda praia', 25, 2.4),
            ('Moda íntima', 25, 2.5), ('Fitness', 22, 2.3), ('Casacos e jaquetas', 20, 2.2), ('Tricô', 20, 2.2),
            ('Acessórios', 30, 2.8), ('Bolsas', 25, 2.5), ('Bijuterias', 35, 3.0), ('Calçados', 18, 2.0),
        ]
        b.c['categorias'] = [{'id': 'cat_' + slug(n), 'nome': n, 'margem': m, 'markup': mk, 'ativo': True}
                             for n, m, mk in categorias]
        b.c['colecoes'] = [
            {'id': 'col_basicos', 'nome': 'Básicos (permanente)', 'inicio': '', 'fim': '', 'ativo': True},
            {'id': 'col_oi', 'nome': f'Outono-Inverno {ano}', 'inicio': f'{ano}-03-01', 'fim': f'{ano}-08-31', 'ativo': True},
            {'id': 'col_pv', 'nome': f'Primavera-Verão {ano}/{str(ano + 1)[2:]}', 'inicio': f'{ano}-08-01',
             'fim': f'{ano + 1}-02-28', 'ativo': True},
        ]
        b.c['servicos'] = [
            {'id': 'srv_barra', 'nome': 'Ajuste de barra', 'preco': 15.0, 'custo': 8.0, 'ativo': True,
             'descricao': 'Feito pela costureira parceira'},
            {'id': 'srv_ajuste', 'nome': 'Ajuste de cintura / alça', 'preco': 25.0, 'custo': 12.0, 'ativo': True,
             'descricao': ''},
            {'id': 'srv_presente', 'nome': 'Embalagem para presente', 'preco': 5.0, 'custo': 2.0, 'ativo': True,
             'descricao': ''},
            {'id': 'srv_entrega', 'nome': 'Entrega (motoboy)', 'preco': 10.0, 'custo': 8.0, 'ativo': True,
             'descricao': ''},
        ]
        b.c['tarefas'] = [self._tarefa(*t) for t in [
            ('Abrir o caixa e conferir o troco', 'diaria'),
            ('Postar novidades nos stories', 'diaria'),
            ('Fechar o caixa e conferir os valores', 'diaria'),
            ('Conferir estoque baixo e fazer pedidos', 'semanal', {'dia_semana': 1}),
            ('Cobrar condicionais vencidos', 'semanal', {'dia_semana': 1}),
            ('Revisar contas a pagar da semana', 'semanal', {'dia_semana': 1}),
            ('Trocar a vitrine e os manequins', 'semanal', {'dia_semana': 5}),
            ('Analisar o DRE e as metas do mês anterior', 'mensal', {'dia_mes': 3}),
            ('Mandar mensagem para as aniversariantes do mês', 'mensal', {'dia_mes': 1}),
            ('Inventário rotativo de uma categoria', 'mensal', {'dia_mes': 10}),
            ('Contatar clientes inativas (reativação)', 'mensal', {'dia_mes': 12}),
            ('Revisar peças paradas há mais de 90 dias', 'mensal', {'dia_mes': 15}),
            ('Pagar o DAS (vence dia 20)', 'mensal', {'dia_mes': 18}),
            ('Copiar o backup para um pendrive ou outro local', 'mensal', {'dia_mes': 28}),
            ('Liquidação de verão — preparar etiquetas e vitrine', 'anual', {'data': '01-08'}),
            ('Dia das Mães — kits, vitrine e divulgação', 'anual', {'data': '04-20'}),
            ('Dia dos Namorados — vitrine e sugestões de presente', 'anual', {'data': '05-25'}),
            ('Planejar compras da coleção Primavera-Verão', 'anual', {'data': '06-15'}),
            ('Liquidação de inverno — preparar etiquetas e vitrine', 'anual', {'data': '07-08'}),
            ('Semana do Cliente (15/09) — preparar ação', 'anual', {'data': '09-05'}),
            ('Black Friday — separar peças, preços e divulgação', 'anual', {'data': '11-01'}),
            ('Natal — vitrine, embalagens e horário estendido', 'anual', {'data': '11-25'}),
        ]]
        b.c['promocoes'] = self._promocoes_padrao()
        recorrentes = [
            ('Aluguel', 'pc_aluguel', 5, 2200), ('Energia elétrica', 'pc_energia', 10, 260),
            ('Água', 'pc_agua', 10, 60), ('Internet e telefone', 'pc_internet', 15, 130),
            ('Contabilidade', 'pc_contabilidade', 10, 300), ('Pró-labore', 'pc_prolabore', 5, 2500),
            ('Marketing (anúncios em redes sociais)', 'pc_marketing', 1, 200),
            ('Embalagens e sacolas', 'pc_embalagens', 20, 120), ('Aluguel da maquininha', 'pc_maquininha', 5, 0),
        ]
        if regime == 'mei':
            recorrentes.append(('DAS MEI', 'pc_das_mei', 20, 80))
        b.c['recorrentes'] = [{'id': novo_id(), 'descricao': n, 'categoria_id': c, 'dia': dia, 'tipo': 'pagar',
                               'valor': v if exemplo else 0, 'ativo': bool(exemplo and v), 'fornecedor_id': '',
                               **({'exemplo': True} if exemplo and v else {})}
                              for n, c, dia, v in recorrentes]
        if exemplo:
            self.semear_exemplo()

    @staticmethod
    def _tarefa(titulo, recorrencia, extra=None):
        t = {'id': novo_id(), 'titulo': titulo, 'recorrencia': recorrencia, 'dia_semana': None, 'dia_mes': None,
             'data': '', 'ativo': True, 'feitas': {}}
        t.update(extra or {})
        return t

    def _promocoes_padrao(self):
        hoje_d = dt.date.today()

        def janela(m1, d1, m2, d2):
            for ano in (hoje_d.year, hoje_d.year + 1):
                ini, fim = dt.date(ano, m1, d1), dt.date(ano + (1 if m2 < m1 else 0), m2, d2)
                if fim >= hoje_d:
                    return ini.isoformat(), fim.isoformat()
            return '', ''

        def evento(func, antes, depois):
            for ano in (hoje_d.year, hoje_d.year + 1):
                base = func(ano)
                if base + dt.timedelta(days=depois) >= hoje_d:
                    return (base - dt.timedelta(days=antes)).isoformat(), (base + dt.timedelta(days=depois)).isoformat()
            return '', ''

        def p(nome, tipo, **kw):
            base = {'id': novo_id(), 'nome': nome, 'tipo': tipo, 'ativo': True, 'inicio': '', 'fim': '',
                    'dias_semana': [], 'cumulativa': False, 'escopo': {'tipo': 'todos', 'ids': []},
                    'percentual': 0, 'descricao': '', 'usos': 0}
            base.update(kw)
            return base

        bf = evento(black_friday, 0, 3)
        maes = evento(dia_das_maes, 7, 0)
        return [
            p('Aniversariante do mês', 'aniversariante', percentual=10,
              descricao='10% de desconto para a cliente no mês do aniversário.'),
            p('Primeira compra', 'primeira_compra', percentual=5, descricao='5% na primeira compra da cliente cadastrada.'),
            p('Pagamento à vista no Pix ou dinheiro', 'pagamento', percentual=5, formas=['pix', 'dinheiro'],
              descricao='Marque "à vista" no caixa; o pagamento precisa ser todo em Pix ou dinheiro.'),
            p('Compras acima de R$ 300', 'valor_minimo', minimo=300, percentual=10),
            p('Leve 3, pague 2 — Camisetas e Regatas', 'leve_pague', ativo=False, leve=3, pague=2,
              escopo={'tipo': 'categoria', 'ids': ['cat_camisetas', 'cat_regatas']},
              descricao='A peça de menor valor sai de graça a cada 3.'),
            p('Leve mais, pague menos', 'progressivo', ativo=False,
              faixas=[{'qtd': 2, 'percentual': 5}, {'qtd': 3, 'percentual': 10}, {'qtd': 5, 'percentual': 15}],
              descricao='2 peças: 5% · 3 peças: 10% · 5 ou mais: 15%.'),
            p('Queima de estoque — coleção Outono-Inverno', 'percentual', ativo=False, percentual=30,
              escopo={'tipo': 'colecao', 'ids': ['col_oi']}),
            p('Terça das Amigas', 'percentual', ativo=False, percentual=10, dias_semana=[2],
              descricao='10% em tudo às terças-feiras.'),
            p('Black Friday', 'percentual', percentual=20, inicio=bf[0], fim=bf[1],
              descricao='Sexta a segunda-feira (Cyber Monday).'),
            p('Esquenta de Natal — Acessórios, Bolsas e Bijuterias', 'percentual', percentual=15,
              escopo={'tipo': 'categoria', 'ids': ['cat_acessorios', 'cat_bolsas', 'cat_bijuterias']},
              inicio=janela(12, 10, 12, 24)[0], fim=janela(12, 10, 12, 24)[1]),
            p('Liquidação de Verão', 'percentual', percentual=30, escopo={'tipo': 'colecao', 'ids': ['col_pv']},
              inicio=janela(1, 8, 1, 31)[0], fim=janela(1, 8, 1, 31)[1]),
            p('Dia das Mães', 'valor_minimo', minimo=200, percentual=10, inicio=maes[0], fim=maes[1]),
            p('Dia dos Namorados — Moda íntima e Acessórios', 'percentual', percentual=10,
              escopo={'tipo': 'categoria', 'ids': ['cat_moda_intima', 'cat_acessorios']},
              inicio=janela(6, 5, 6, 12)[0], fim=janela(6, 5, 6, 12)[1]),
            p('Semana do Cliente', 'percentual', percentual=10, inicio=janela(9, 12, 9, 18)[0], fim=janela(9, 12, 9, 18)[1]),
            p('Cupom de boas-vindas', 'cupom', codigo='BEMVINDA10', percentual=10, minimo=100, max_usos=0,
              descricao='Divulgue no Instagram: 10% em compras a partir de R$ 100.'),
            p('Cupom Instagram', 'cupom', codigo='INSTA5', percentual=5, minimo=0, max_usos=0),
        ]

    def semear_exemplo(self):
        b = self.banco
        rnd = random.Random(2026)
        self.marcar_exemplo = True
        try:
            b.c['marcas'] = [{'id': 'mar_propria', 'nome': 'Marca Própria', 'ativo': True, 'exemplo': True},
                             {'id': 'mar_flor', 'nome': 'Atelier Flor (exemplo)', 'ativo': True, 'exemplo': True},
                             {'id': 'mar_urbana', 'nome': 'Urbana Jeans (exemplo)', 'ativo': True, 'exemplo': True}]
            b.c['fornecedores'] = [
                {'id': 'for_1', 'nome': 'Confecções Exemplo Ltda', 'fantasia': 'Confecções Exemplo', 'cnpj': '',
                 'contato': 'Representante', 'telefone': '', 'whatsapp': '', 'email': '', 'cidade': 'São Paulo/SP',
                 'prazo_pagamento': '30/60/90', 'pedido_minimo': 800, 'fornece': 'Blusas, vestidos, saias',
                 'ativo': True, 'exemplo': True},
                {'id': 'for_2', 'nome': 'Jeans Atacado Exemplo', 'fantasia': 'Jeans Exemplo', 'cnpj': '',
                 'contato': '', 'telefone': '', 'whatsapp': '', 'email': '', 'cidade': 'Goiânia/GO',
                 'prazo_pagamento': '28 dias', 'pedido_minimo': 1000, 'fornece': 'Jeans', 'ativo': True,
                 'exemplo': True},
                {'id': 'for_3', 'nome': 'Acessórios Exemplo', 'fantasia': '', 'cnpj': '', 'contato': '',
                 'telefone': '', 'whatsapp': '', 'email': '', 'cidade': 'Limeira/SP', 'prazo_pagamento': 'À vista',
                 'pedido_minimo': 300, 'fornece': 'Bijuterias e bolsas', 'ativo': True, 'exemplo': True},
            ]
            letras, nums = ['P', 'M', 'G'], ['36', '38', '40', '42']
            catalogo = [
                ('Blusa Viscose Manga Bufante', 'cat_blusas', 'mar_flor', 'for_1', 'col_pv', 38, letras, ['Off-white', 'Rosa']),
                ('Camiseta Básica Algodão', 'cat_camisetas', 'mar_propria', 'for_1', 'col_basicos', 18, ['P', 'M', 'G', 'GG'], ['Preto', 'Branco']),
                ('Regata Canelada', 'cat_regatas', 'mar_propria', 'for_1', 'col_basicos', 15, letras, ['Branco', 'Preto', 'Vinho']),
                ('Calça Jeans Mom Cintura Alta', 'cat_jeans', 'mar_urbana', 'for_2', 'col_basicos', 62, nums, ['Jeans claro']),
                ('Short Jeans Destroyed', 'cat_shorts', 'mar_urbana', 'for_2', 'col_pv', 42, nums, ['Jeans claro']),
                ('Vestido Midi Floral', 'cat_vestidos', 'mar_flor', 'for_1', 'col_pv', 72, letras, ['Estampado']),
                ('Saia Midi Plissada', 'cat_saias', 'mar_flor', 'for_1', 'col_pv', 45, letras, ['Preto', 'Verde-militar']),
                ('Macacão Linho Pantalona', 'cat_macacoes', 'mar_flor', 'for_1', 'col_pv', 95, letras, ['Caramelo']),
                ('Cardigã Tricô Tranças', 'cat_trico', 'mar_propria', 'for_1', 'col_oi', 58, ['U'], ['Off-white', 'Cinza']),
                ('Jaqueta Jeans Oversized', 'cat_casacos_e_jaquetas', 'mar_urbana', 'for_2', 'col_oi', 88, letras, ['Jeans escuro']),
                ('Conjunto Fitness Top e Legging', 'cat_fitness', 'mar_propria', 'for_1', 'col_basicos', 49, letras, ['Preto', 'Lilás']),
                ('Biquíni Cortininha', 'cat_moda_praia', 'mar_propria', 'for_1', 'col_pv', 32, letras, ['Estampado', 'Preto']),
                ('Bolsa Tiracolo Matelassê', 'cat_bolsas', 'mar_propria', 'for_3', 'col_basicos', 55, ['U'], ['Preto', 'Caramelo']),
                ('Brinco Argola Dourada', 'cat_bijuterias', 'mar_propria', 'for_3', 'col_basicos', 9, ['U'], ['Dourado']),
            ]
            cats = {c['id']: c for c in b.c['categorias']}
            for nome, cat, marca, forn, col, custo, tams, cores, in catalogo:
                markup = cats[cat]['markup']
                bruto = custo * markup
                preco = float(int(bruto)) + 0.90 if int(bruto) + 0.90 >= bruto else float(int(bruto)) + 1.90
                variacoes = [{'tamanho': t, 'cor': c, 'estoque_inicial': rnd.randint(3, 8),
                              'estoque_min': 1} for c in cores for t in tams]
                self.op_produto_salvar({'obj': {'nome': nome, 'categoria_id': cat, 'marca_id': marca,
                                                'fornecedor_id': forn, 'colecao_id': col, 'custo': custo,
                                                'preco': preco, 'genero': 'Feminino', 'variacoes': variacoes,
                                                'ativo': True}}, 'sistema')
            clientes = [
                ('Mariana Exemplo', '11900000001', '1990-%02d-12' % dt.date.today().month, 'M', '38', '36'),
                ('Juliana Exemplo', '11900000002', '1985-03-22', 'G', '42', '38'),
                ('Patrícia Exemplo', '11900000003', '1978-07-05', 'P', '36', '35'),
                ('Camila Exemplo', '11900000004', '1995-11-30', 'M', '40', '37'),
                ('Fernanda Exemplo', '11900000005', '2000-01-18', 'GG', '44', '39'),
                ('Renata Exemplo', '11900000006', '1988-09-09', 'M', '38', '36'),
            ]
            ids_clientes = []
            for nome, tel, nasc, sup, inf, calc in clientes:
                r = self.op_cliente_salvar({'obj': {'nome': nome, 'telefone': tel, 'nascimento': nasc,
                                                    'tam_superior': sup, 'tam_inferior': inf, 'tam_calcado': calc,
                                                    'aceita_mensagens': True, 'limite_crediario': 600,
                                                    'observacoes': 'Cliente fictícia de demonstração.'}}, 'sistema')
                ids_clientes.append(r['id'])
            hoje_d = dt.date.today()
            formas = ['pix', 'pix', 'dinheiro', 'debito', 'credito', 'credito']
            for dias_atras in range(55, 0, -1):
                for _ in range(rnd.choice([0, 1, 1, 2, 2, 3])):
                    disponiveis = [(p, v) for p in b.c['produtos'] for v in p['variacoes'] if v['estoque'] > 0]
                    if not disponiveis:
                        break
                    escolhidos = rnd.sample(disponiveis, k=min(len(disponiveis), rnd.choice([1, 1, 2, 2, 3])))
                    itens = [{'produto_id': p['id'], 'variacao_id': v['id'], 'qtd': 1, 'preco_unit': p['preco'],
                              'desconto': 0} for p, v in escolhidos]
                    total = r2(sum(i['preco_unit'] for i in itens))
                    forma = rnd.choice(formas)
                    pag = {'forma': forma, 'valor': total, 'parcelas': rnd.choice([1, 2, 3]) if forma == 'credito' else 1}
                    cliente = rnd.choice(ids_clientes + [None, None])
                    hora = f'{rnd.randint(9, 18):02d}:{rnd.randint(0, 59):02d}:00'
                    data = f'{(hoje_d - dt.timedelta(days=dias_atras)).isoformat()}T{hora}'
                    self.registrar_venda({'itens': itens, 'pagamentos': [pag], 'cliente_id': cliente}, 'sistema', data=data)
            p = b.c['produtos'][5]
            self.registrar_venda({'itens': [{'produto_id': p['id'], 'variacao_id': p['variacoes'][0]['id'], 'qtd': 1,
                                             'preco_unit': p['preco']}],
                                  'pagamentos': [{'forma': 'crediario', 'valor': p['preco'], 'parcelas': 3}],
                                  'cliente_id': ids_clientes[1]}, 'sistema',
                                 data=f'{(hoje_d - dt.timedelta(days=40)).isoformat()}T15:10:00')
            p1, p2 = b.c['produtos'][0], b.c['produtos'][6]
            self.op_condicional_abrir({'cliente_id': ids_clientes[2], 'prazo': somar_dias(hoje(), -1),
                                       'itens': [{'produto_id': p1['id'], 'variacao_id': p1['variacoes'][1]['id'], 'qtd': 1},
                                                 {'produto_id': p2['id'], 'variacao_id': p2['variacoes'][1]['id'], 'qtd': 1}]},
                                      'sistema')
            b.c['ativos'] = [
                {'id': novo_id(), 'nome': 'Araras, manequins e espelhos', 'valor': 1800, 'aquisicao': f'{hoje_d.year - 1}-02-01',
                 'vida_util_meses': 60, 'ativo': True, 'exemplo': True},
                {'id': novo_id(), 'nome': 'Computador e impressora térmica', 'valor': 3200, 'aquisicao': f'{hoje_d.year - 1}-02-01',
                 'vida_util_meses': 36, 'ativo': True, 'exemplo': True},
            ]
            mes_ant = somar_meses(hoje()[:7] + '-01', -1)[:7]
            self.gerar_recorrentes(mes_ant)
            self.gerar_recorrentes(hoje()[:7])
            for f in b.c['financeiro']:
                if f.get('origem') == 'recorrente' and f['vencimento'] < hoje():
                    f.update(status='pago', pago_em=f['vencimento'], valor_pago=f['valor'])
            for f in b.c['financeiro']:
                if f.get('forma') in ('debito', 'credito') and f['status'] == 'pendente' and f['vencimento'] <= hoje():
                    f.update(status='pago', pago_em=f['vencimento'], valor_pago=f['liquido'])
            b.config['metas'] = {hoje()[:7]: 12000}
            b.config['financeiro']['saldo_inicial'] = 5000
            b.config['financeiro']['data_saldo_inicial'] = (hoje_d - dt.timedelta(days=60)).isoformat()
        finally:
            self.marcar_exemplo = False


# --------------------------------------------------------------- servidor HTTP

PAGINA_SEM_ACESSO = '''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Loja ERP</title>
<style>body{font-family:system-ui,sans-serif;background:#f4f1ee;color:#2b2b2b;display:grid;place-items:center;
height:100vh;margin:0}div{background:#fff;padding:32px 40px;border-radius:14px;max-width:460px;
box-shadow:0 6px 24px #0001}h1{font-size:20px;margin:0 0 12px}</style></head><body><div>
<h1>Acesso protegido</h1><p>Abra o sistema pelo atalho <b>Loja ERP</b>. Ele gera um endereço novo e
seguro a cada vez que é executado.</p><p>Se o sistema já estiver aberto, clicar no atalho de novo leva você
direto a ele.</p></div></body></html>'''


PAGINA_CELULAR = '''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Loja ERP</title>
<style>body{font-family:system-ui,sans-serif;background:#f4f1ee;color:#2b2b2b;margin:0;padding:24px}
div{background:#fff;padding:24px;border-radius:14px;max-width:460px;margin:30px auto;box-shadow:0 6px 24px #0001}
h1{font-size:20px;margin:0 0 12px}li{margin:6px 0}</style></head><body><div><h1>%s</h1>%s</div></body></html>'''
CELULAR_SEM_ACESSO = PAGINA_CELULAR % ('Celular não conectado', '''<p>Para usar o Loja ERP neste celular:</p><ol>
<li>No computador da loja, abra <b>Configurações › Usar no celular</b>.</li>
<li>Toque em <b>Conectar um celular</b>.</li><li>Aponte a câmera deste celular para o QR Code que aparecer.</li></ol>''')
CELULAR_AGUARDANDO = '''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="3">
<title>Loja ERP</title><style>body{font-family:system-ui,sans-serif;background:#f4f1ee;color:#2b2b2b;margin:0;padding:24px}
div{background:#fff;padding:24px;border-radius:14px;max-width:460px;margin:30px auto;box-shadow:0 6px 24px #0001;text-align:center}
h1{font-size:20px;margin:0 0 12px}b.c{display:block;font-size:44px;letter-spacing:8px;margin:14px 0;color:#7a3557}</style></head>
<body><div><h1>Falta só permitir no computador</h1><p>No computador da loja, confira se aparece este código e clique em
<b>Permitir</b>:</p><b class="c">{CODIGO}</b><p>Esta tela muda sozinha quando for permitido.</p></div></body></html>'''
CELULAR_CODIGO_VENCIDO = PAGINA_CELULAR % ('QR Code vencido', '''<p>Cada QR Code vale por 2 minutos e só uma vez.</p>
<p>No computador, toque em <b>Conectar um celular</b> de novo e leia o novo QR Code.</p>''')


class Manipulador(BaseHTTPRequestHandler):
    server_version = 'LojaERP'
    sys_version = ''
    timeout = 60

    def log_message(self, *args):
        pass

    @property
    def app(self):
        return self.server.app

    def _cookies(self):
        c = cookies.SimpleCookie()
        try:
            c.load(self.headers.get('Cookie', ''))
        except cookies.CookieError:
            pass
        return {k: v.value for k, v in c.items()}

    @property
    def lan(self):
        return getattr(self.server, 'lan', False)

    def _host_ok(self):
        host = (self.headers.get('Host') or '').lower()
        if self.lan:
            # Só endereço IP da rede local: nomes de domínio ficam de fora (impede "DNS rebinding").
            m = re.fullmatch(r'(\d{1,3}(?:\.\d{1,3}){3}):(\d+)', host)
            return bool(m) and int(m.group(2)) == self.server.server_address[1] and celular.ip_privado(m.group(1))
        return host in (f'127.0.0.1:{self.app.porta}', f'localhost:{self.app.porta}')

    def _enviar(self, status, corpo, tipo='application/json; charset=utf-8', extras=None):
        self._descartar_corpo()
        if isinstance(corpo, (dict, list)):
            corpo = json.dumps(corpo, ensure_ascii=False).encode('utf-8')
        elif isinstance(corpo, str):
            corpo = corpo.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', tipo)
        self.send_header('Content-Length', str(len(corpo)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Permissions-Policy', 'camera=(self), microphone=(), geolocation=(), payment=(), usb=()')
        self.send_header('X-Permitted-Cross-Domain-Policies', 'none')
        self.send_header('Content-Security-Policy',
                         "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                         "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'")
        for k, v in extras or []:
            self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(corpo)

    def do_GET(self):
        self._tratar('GET')

    def do_POST(self):
        self._tratar('POST')

    def _tratar(self, metodo):
        try:
            if not self._host_ok():
                return self._enviar(403, 'Endereço não permitido.', 'text/plain; charset=utf-8')
            url = urlparse(self.path)
            caminho = url.path
            self.origem = 'local'
            self.corpo_lido = False   # a mesma conexão (HTTP/1.1) atende vários pedidos
            if self.lan and (caminho.startswith('/sistema/') or caminho == '/entrar'):
                return self._enviar(404, 'Não encontrado', 'text/plain')
            if caminho == '/sistema/ping':
                desafio = parse_qs(url.query).get('c', [''])[0]
                resposta = {'app': 'LojaERP'}
                if re.fullmatch(r'[0-9a-f]{32}', desafio):
                    resposta['prova'] = prova_instancia(self.app.token, desafio)
                return self._enviar(200, resposta)
            if self.lan and caminho == '/parear' and self.app.aparelho_valido(self._cookies().get('aparelho')):
                return self._enviar(302, '', 'text/plain', [('Location', '/')])   # este celular já está conectado
            if self.lan and caminho == '/parear':
                tok = self.app.parear(parse_qs(url.query).get('c', [''])[0], self.headers.get('User-Agent', ''))
                if not tok:
                    return self._enviar(403, CELULAR_CODIGO_VENCIDO, 'text/html; charset=utf-8')
                return self._enviar(302, '', 'text/plain', [
                    ('Location', '/'),
                    ('Set-Cookie', f'aparelho={tok}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=34560000')])
            if caminho == '/sistema/encerrar':
                t = parse_qs(url.query).get('t', [''])[0]
                if not hmac.compare_digest(t.encode(), self.app.token.encode()):
                    return self._enviar(403, {'erro': 'Token inválido.'})
                self._enviar(200, {'ok': True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if caminho == '/entrar':
                t = parse_qs(url.query).get('t', [''])[0]
                if hmac.compare_digest(t.encode(), self.app.token.encode()):
                    return self._enviar(302, '', 'text/plain', [
                        ('Location', '/'),
                        ('Set-Cookie', f'acesso={self.app.token}; HttpOnly; SameSite=Strict; Path=/')])
                return self._enviar(403, PAGINA_SEM_ACESSO, 'text/html; charset=utf-8')
            ck = self._cookies()
            if self.lan:
                aparelho = self.app.aparelho_valido(ck.get('aparelho'))
                if not aparelho:
                    return self._enviar(403, CELULAR_SEM_ACESSO, 'text/html; charset=utf-8')
                if aparelho.get('pendente'):
                    if caminho.startswith('/api/'):
                        return self._enviar(403, {'erro': 'Aguardando a permissão no computador da loja.'})
                    return self._enviar(200, CELULAR_AGUARDANDO.replace('{CODIGO}', aparelho['conferencia']),
                                        'text/html; charset=utf-8')
                self.origem = 'aparelho:' + aparelho['id']
            elif not hmac.compare_digest(ck.get('acesso', '').encode(), self.app.token.encode()):
                return self._enviar(403, PAGINA_SEM_ACESSO, 'text/html; charset=utf-8')
            self.app.ultimo_acesso = time.time()
            if caminho.startswith('/api/'):
                return self._api(metodo, caminho[5:], url, ck)
            if caminho.startswith('/fotos/'):
                return self._foto(caminho[7:], ck)
            return self._estatico(caminho)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            traceback.print_exc()
            try:
                self._enviar(500, {'erro': 'Erro interno. Detalhes no arquivo loja.log.'})
            except OSError:
                pass

    def _estatico(self, caminho):
        if caminho in ('', '/'):
            caminho = '/index.html'
        if caminho == '/js/pacote.js':
            # Todos os scripts num arquivo só: menos conexões e menos pedidos (bom no celular).
            partes = []
            for nome in PACOTE_JS:
                with open(os.path.join(WEB_DIR, 'js', nome), 'rb') as f:
                    partes.append(b'/* ' + nome.encode() + b' */\n' + f.read().rstrip() + b'\n')
            return self._enviar(200, b'\n'.join(partes), MIME['.js'])
        rel = caminho.lstrip('/')
        if not re.fullmatch(r'[A-Za-z0-9_\-]+(/[A-Za-z0-9_\-]+)*\.[a-z0-9]+', rel):
            return self._enviar(404, 'Não encontrado', 'text/plain')
        raiz = os.path.realpath(WEB_DIR)
        arq = os.path.realpath(os.path.join(raiz, *rel.split('/')))
        if os.path.commonpath([raiz, arq]) != raiz or not os.path.isfile(arq):
            return self._enviar(404, 'Não encontrado', 'text/plain')
        with open(arq, 'rb') as f:
            conteudo = f.read()
        tipo = MIME.get(os.path.splitext(arq)[1].lower(), 'application/octet-stream')
        self._enviar(200, conteudo, tipo)

    def _foto(self, nome, ck):
        if not self.app.sessao_valida(ck.get('sessao')):
            return self._enviar(401, 'Faça login', 'text/plain')
        if not re.fullmatch(r'[0-9a-f]+\.(jpg|png|webp)', nome):
            return self._enviar(404, 'Não encontrado', 'text/plain')
        arq = os.path.join(FOTOS_DIR, nome)
        if not os.path.isfile(arq):
            return self._enviar(404, 'Não encontrado', 'text/plain')
        with open(arq, 'rb') as f:
            self._enviar(200, f.read(), MIME['.' + nome.rsplit('.', 1)[1]])

    def _ler_corpo(self, limite):
        try:
            tamanho = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            tamanho = 0
        if tamanho < 0 or tamanho > limite:
            return None
        self.corpo_lido = True
        return self.rfile.read(tamanho) if tamanho else b''

    def _descartar_corpo(self):
        """Lê o corpo não usado antes de responder um erro: fechar a conexão com dados pendentes
        faz o navegador receber "conexão interrompida" em vez da mensagem."""
        if self.command != 'POST' or getattr(self, 'corpo_lido', False):
            return
        self.corpo_lido = True
        try:
            tamanho = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            return
        if 0 < tamanho <= 1024 * 1024:
            try:
                self.rfile.read(tamanho)
            except OSError:
                pass
        else:
            self.close_connection = True

    def _api(self, metodo, rota, url, ck):
        app = self.app
        if metodo == 'POST' and self.headers.get('X-Loja') != '1':
            return self._enviar(403, {'erro': 'Requisição recusada.'})
        if self.lan and (rota in BLOQUEADAS_NO_CELULAR or rota.startswith(('celular', 'atualizacao', 'backup'))):
            return self._enviar(403, {'erro': 'Isso só pode ser feito no computador da loja.'})
        sessao = app.sessao_valida(ck.get('sessao'))
        if sessao and not app.cofre:
            sessao = None
        if not app.recuperacao and app.usuarios_perdidos():
            app.recuperacao = AVISO_USUARIOS_PERDIDOS
            app.sessoes.clear()
        if app.recuperacao and rota not in ('estado', 'restaurar', 'backup/enviar'):
            return self._enviar(503, {'erro': 'O sistema está em modo de recuperação. Restaure um backup.'})
        if rota not in ROTAS_PUBLICAS and not sessao:
            return self._enviar(401, {'erro': 'Sessão encerrada. Entre novamente.'})

        if metodo == 'POST' and rota == 'atualizacao/verificar':
            # Fora da trava geral: baixar e testar pode levar minutos e o caixa não pode parar.
            if app.papel(sessao['login']) == 'vendedora':
                return self._enviar(403, {'erro': 'Sem permissão.'})
            self._ler_corpo(LIMITE_CORPO)
            return self._enviar(200, dict(app.atualizador.verificar(baixar=True), ok=True))

        if rota == 'celular/diagnostico':
            if app.papel(sessao['login']) == 'vendedora':
                return self._enviar(403, {'erro': 'Sem permissão.'})
            self._ler_corpo(LIMITE_CORPO)
            return self._enviar(200, diagnosticar_celular(app))

        if metodo == 'POST' and rota == 'celular/firewall':
            if app.papel(sessao['login']) == 'vendedora':
                return self._enviar(403, {'erro': 'Sem permissão.'})
            ok, msg = celular.liberar_firewall(app.celular['porta'])
            return self._enviar(200 if ok else 400, {'ok': True, 'mensagem': msg} if ok else {'erro': msg})

        if metodo == 'POST' and rota == 'backup/enviar':
            pode = app.recuperacao or app.precisa_setup() or (sessao and app.papel(sessao['login']) == 'dona')
            if not pode:
                return self._enviar(403, {'erro': 'Somente a proprietária pode enviar um backup.'})
            try:
                tamanho = int(self.headers.get('Content-Length') or 0)
            except ValueError:
                tamanho = 0
            if tamanho < 0 or tamanho > LIMITE_UPLOAD_BACKUP:
                return self._enviar(413, {'erro': 'Arquivo muito grande.'})
            try:
                self.corpo_lido = True
                return self._enviar(200, app.receber_backup(self.rfile, tamanho))
            except ErroNegocio as e:
                return self._enviar(400, {'erro': str(e)})

        if metodo == 'GET' and rota.startswith('backup/') and rota != 'backup/enviar':
            nome = os.path.basename(rota[7:])
            arq = os.path.join(BACKUP_DIR, nome)
            if app.papel(sessao['login']) == 'vendedora':
                return self._enviar(403, {'erro': 'Sem permissão.'})
            if not PADRAO_BACKUP.fullmatch(nome) or not os.path.isfile(arq):
                return self._enviar(404, {'erro': 'Backup não encontrado.'})
            with open(arq, 'rb') as f:
                return self._enviar(200, f.read(), 'application/octet-stream',
                                    [('Content-Disposition', f'attachment; filename="{nome}"')])

        corpo = {}
        if metodo == 'POST':
            bruto = self._ler_corpo(LIMITE_CORPO)
            if bruto is None:
                return self._enviar(413, {'erro': 'Conteúdo muito grande.'})
            try:
                corpo = json.loads(bruto.decode('utf-8')) if bruto else {}
            except (ValueError, UnicodeDecodeError):
                return self._enviar(400, {'erro': 'Dados inválidos.'})
            if not isinstance(corpo, dict):
                return self._enviar(400, {'erro': 'Dados inválidos.'})
        try:
            with app.trava:
                if app.banco is not None:
                    app.banco.sincronizar()
                app.origem = self.origem
                resultado = app.executar(metodo, rota, corpo, sessao, parse_qs(url.query))
            if isinstance(resultado, dict) and '_rede' in resultado:
                # Integrações: a chamada ao serviço externo roda sem segurar o sistema; o resultado é gravado depois.
                etapa = resultado.pop('_rede')
                try:
                    retorno = etapa['chamar']()
                except integracoes.ErroIntegracao as e:
                    retorno = e
                except Exception as e:  # noqa: BLE001 - falha inesperada do serviço vira mensagem, não derruba o sistema
                    traceback.print_exc()
                    retorno = integracoes.ErroIntegracao(f'falha inesperada ({type(e).__name__})')
                with app.trava:
                    if app.banco is not None:
                        app.banco.sincronizar()
                    resultado = etapa['concluir'](retorno)
            if rota == 'estado' and isinstance(resultado, dict):
                resultado['celular'] = self.lan
                if self.lan and not sessao:
                    for k in ('aviso_uso', 'pasta_loja', 'backups', 'verificacoes'):
                        resultado.pop(k, None)
        except ErroNegocio as e:
            return self._enviar(400, {'erro': str(e)})
        extras = []
        encerrar = False
        if isinstance(resultado, dict):
            if '_sessao' in resultado:
                tok = resultado.pop('_sessao')
                valor = f'sessao={tok}; HttpOnly; SameSite=Strict; Path=/' if tok else \
                    'sessao=; Max-Age=0; HttpOnly; SameSite=Strict; Path=/'
                extras.append(('Set-Cookie', valor + ('; Secure' if self.lan else '')))
            encerrar = resultado.pop('_encerrar', False)
        self._enviar(200, resultado, extras=extras)
        if encerrar:
            threading.Thread(target=self.server.shutdown, daemon=True).start()


# ----------------------------------------------------------------------- main

TEM_CONSOLE = sys.stdout is not None and sys.stdin is not None


def pasta_estado_local():
    """Pasta local da usuária (fora da nuvem) para log e controle da instância em execução."""
    base = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), '.local', 'state')
    pasta = os.path.join(base, 'LojaERP')
    os.makedirs(pasta, exist_ok=True)
    return pasta


def preparar_saida():
    """Sem janela de console (pythonw), as mensagens vão para um arquivo de log."""
    if TEM_CONSOLE:
        return
    log = os.path.join(pasta_estado_local(), 'loja.log')
    try:
        if os.path.getsize(log) > 1024 * 1024:
            os.replace(log, log + '.1')
    except OSError:
        pass
    sys.stdout = sys.stderr = open(log, 'a', encoding='utf-8', buffering=1)
    print(f'\n--- {agora()} ---')


def alertar(mensagem, erro=True):
    print(mensagem)
    if TEM_CONSOLE:
        if erro:
            input('\n  Pressione Enter para sair...')
    elif sys.platform == 'win32':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, mensagem, 'Loja ERP', 0x10 if erro else 0x40)


def arquivo_instancia():
    chave = hashlib.sha1(os.path.normcase(DADOS_DIR).encode('utf-8')).hexdigest()[:12]
    return os.path.join(pasta_estado_local(), f'instancia-{chave}.json')


_LOCAL = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # nunca passa por proxy


def prova_instancia(token, desafio):
    return hmac.new(token.encode(), b'loja-erp/ping' + desafio.encode(), hashlib.sha256).hexdigest()


def instancia_ativa():
    """Devolve os dados da instância já aberta para esta pasta, se ela responder e provar que conhece o token.
    Assim um programa estranho que ocupe a porta depois de uma queda não recebe a usuária."""
    try:
        with open(arquivo_instancia(), 'r', encoding='utf-8') as f:
            info = json.load(f)
        desafio = secrets.token_hex(16)
        with _LOCAL.open(f'http://127.0.0.1:{int(info["porta"])}/sistema/ping?c={desafio}', timeout=2) as r:
            resposta = json.load(r)
        if hmac.compare_digest(str(resposta.get('prova', '')), prova_instancia(info['token'], desafio)):
            return info
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        pass
    return None


def encerrar_instancia():
    info = instancia_ativa()
    if not info:
        return False
    try:
        _LOCAL.open(f'http://127.0.0.1:{int(info["porta"])}/sistema/encerrar?t={info["token"]}', timeout=5).close()
    except OSError:
        return False
    for _ in range(20):
        if not instancia_ativa():
            break
        time.sleep(0.25)
    return True


class Servidor(ThreadingHTTPServer):
    """No Windows, a porta fica exclusiva: outro programa não consegue se ligar a ela enquanto o sistema roda."""
    daemon_threads = True
    allow_reuse_address = sys.platform != 'win32'
    lan = False

    def server_bind(self):
        if sys.platform == 'win32' and hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class ManipuladorCelular(Manipulador):
    """Conexões persistentes (HTTP/1.1): o navegador do celular reaproveita a mesma conexão segura em vez de
    abrir uma nova a cada arquivo. Com certificado próprio, cada conexão nova custa ao Chrome uma rodada de
    "erro de certificado + nova tentativa"; muitas seguidas terminam em ERR_TOO_MANY_RETRIES."""
    protocol_version = 'HTTP/1.1'
    timeout = 120

    def _enviar(self, status, corpo, tipo='application/json; charset=utf-8', extras=None):
        if status >= 400 or not self.path.startswith(('/js/', '/css/', '/img/', '/fotos/')):
            registrar_celular(self.client_address[0], f'{self.command} {self.path.split("?")[0]} -> {status}')
        super()._enviar(status, corpo, tipo, extras)


_registro_celular = {}


def diagnosticar_celular(app):
    """Junta o que dá para saber deste lado: servidor no ar, endereços, último aparelho que chegou,
    perfil da rede e regras de firewall do Windows. Devolve itens com nível ok/alerta/erro e o que fazer."""
    itens = []

    def item(nivel, titulo, detalhe=''):
        itens.append({'nivel': nivel, 'titulo': titulo, 'detalhe': detalhe})

    st = app.resumo_celular()
    if not st['ativo']:
        item('erro', 'O acesso pelo celular está desligado', 'Clique em "Ligar acesso pelo celular".')
        return {'itens': itens}
    item('ok', f'Programa esperando celulares na porta {st["porta"]}', 'Endereços deste computador: ' + ', '.join(st['ips']))
    contato = st.get('ultimo_contato')
    if contato:
        item('ok', f'Um aparelho chegou até este computador há {contato["segundos"]} s ({contato["ip"]})',
             'A rede e o firewall deixam passar. Se a página não abre, gere um QR Code novo e feche as abas antigas no celular.')
    else:
        item('alerta', 'Nenhum celular chegou até este computador desde que o acesso foi ligado',
             'Tente abrir o QR Code no celular e clique em "Verificar" de novo. Se continuar assim, o bloqueio está no '
             'firewall ou na rede (Wi-Fi de visitantes ou "isolamento de clientes" no roteador).')
    d = celular.diagnostico_windows()
    if not d.get('disponivel'):
        return {'itens': itens, 'windows': d}
    publicas = [x for x in d['perfis'] if x.get('categoria') == 'Public']
    if publicas:
        item('alerta', 'O Windows marcou a rede como "Pública": ' + ', '.join(x.get('nome') or x.get('interface', '') for x in publicas),
             'Em redes públicas o Windows bloqueia mais. O botão "Liberar no firewall" já cobre esse caso; se for a rede da loja, '
             'você também pode marcá-la como "Privada" em Configurações do Windows › Rede e Internet.')
    bloqueios = [r for r in d['regras'] if r.get('acao') == 'Block' and r.get('ativa') == 'True']
    liberacoes = [r for r in d['regras'] if r.get('acao') == 'Allow' and r.get('ativa') == 'True']
    if bloqueios:
        item('erro', f'O firewall do Windows tem {len(bloqueios)} regra(s) BLOQUEANDO o Loja ERP',
             'Normalmente criadas quando o aviso do firewall foi cancelado. Clique em "Liberar no firewall do Windows": '
             'ele apaga esses bloqueios e cria a liberação certa.')
    elif liberacoes:
        item('ok', 'O firewall do Windows libera o Loja ERP', ', '.join(sorted({r.get('nome', '') for r in liberacoes})))
    else:
        item('alerta', 'O firewall do Windows ainda não tem liberação para o Loja ERP', 'Clique em "Liberar no firewall do Windows".')
    desligado = [f['perfil'] for f in d['firewall'] if f.get('ativo') == 'False']
    outros = [o for o in d['outros'] if o and 'windows' not in o.lower()]
    if outros:
        item('alerta', 'Outro firewall instalado: ' + ', '.join(outros),
             'Ele pode bloquear mesmo com o do Windows liberado. Abra o programa e permita o "Loja ERP" (pythonw.exe) '
             'na rede local, ou desative o firewall dele um instante para testar.')
    if desligado:
        item('ok', 'Firewall do Windows desligado nos perfis: ' + ', '.join(desligado))
    return {'itens': itens}


def registrar_celular(ip, texto, limitar=False):
    """Diagnóstico do acesso pelo celular no loja.log (sem códigos nem chaves: só método, caminho e resultado)."""
    if limitar:
        chave = (ip, texto[:40])
        if time.time() - _registro_celular.get(chave, 0) < 60:
            return
        _registro_celular[chave] = time.time()
    print(f'{agora()} celular {ip}: {texto}')


class ServidorCelular(Servidor):
    """Servidor HTTPS para os celulares pareados. Só aceita aparelhos de endereço de rede local; a negociação
    TLS acontece na linha de cada conexão, para um aparelho lento não travar os outros. Limita conexões
    simultâneas (no total e por aparelho) para um aparelho da rede não esgotar o programa."""
    lan = True
    LIMITE_TOTAL = 96
    LIMITE_POR_IP = 24

    def __init__(self, endereco, manipulador, contexto):
        self.contexto = contexto
        self.trava_conexoes = threading.Lock()
        self.conexoes = {}
        self.contatos = {}
        super().__init__(endereco, manipulador)

    def verify_request(self, request, client_address):
        # Registra que um aparelho chegou até aqui: se nada aparece, o bloqueio está antes (firewall ou rede).
        self.contatos[client_address[0]] = time.time()
        registrar_celular(client_address[0], 'conexão recebida', limitar=True)
        if not celular.ip_privado(client_address[0]):
            return False
        with self.trava_conexoes:
            if sum(self.conexoes.values()) >= self.LIMITE_TOTAL or self.conexoes.get(client_address[0], 0) >= self.LIMITE_POR_IP:
                return False
            self.conexoes[client_address[0]] = self.conexoes.get(client_address[0], 0) + 1
        return True

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            with self.trava_conexoes:
                n = self.conexoes.get(client_address[0], 1) - 1
                if n > 0:
                    self.conexoes[client_address[0]] = n
                else:
                    self.conexoes.pop(client_address[0], None)

    def finish_request(self, request, client_address):
        request.settimeout(10)
        try:
            tls = self.contexto.wrap_socket(request, server_side=True)
        except ssl.SSLError as e:
            # O normal: o navegador recusa o certificado próprio na primeira conexão e tenta de novo aceitando.
            registrar_celular(client_address[0], f'conexão segura recusada pelo navegador ({e.reason or e})', limitar=True)
            return
        except OSError as e:
            registrar_celular(client_address[0], f'conexão interrompida no início ({e})', limitar=True)
            return
        try:
            self.RequestHandlerClass(tls, client_address, self)
        finally:
            try:
                tls.close()
            except OSError:
                pass

    def handle_error(self, request, client_address):
        if not isinstance(sys.exc_info()[1], (ssl.SSLError, ConnectionError, TimeoutError)):
            super().handle_error(request, client_address)


def porta_livre(inicial, host):
    for porta in range(inicial, inicial + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if Servidor.allow_reuse_address:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((host, porta))
                return porta
            except OSError:
                continue
    raise RuntimeError('Nenhuma porta livre encontrada.')


def verificar_uso_concorrente():
    """Avisa se outro computador está usando a mesma pasta de dados (ex.: pasta compartilhada no Drive)."""
    try:
        with open(ARQ_EM_USO, 'r', encoding='utf-8') as f:
            info = json.load(f)
    except (OSError, ValueError):
        return ''
    if info.get('host') != socket.gethostname() and time.time() - num(info.get('batida')) < 120:
        return (f'Atenção: o computador "{info.get("host")}" parece estar usando o sistema agora. '
                'Usar em dois computadores ao mesmo tempo pode causar conflito de sincronização.')
    return ''


def vigiar(servidor, parar):
    """Marca a pasta como em uso e encerra o servidor após longo tempo sem nenhum acesso."""
    while not parar.is_set():
        try:
            with open(ARQ_EM_USO, 'w', encoding='utf-8') as f:
                json.dump({'host': socket.gethostname(), 'pid': os.getpid(), 'batida': time.time()}, f)
        except OSError:
            pass
        if servidor.app.banco is None:
            parar.wait(30)
            continue
        if time.time() - servidor.app.ultimo_acesso > OCIOSO_MAX:
            print(f'{agora()} encerrado por inatividade')
            threading.Thread(target=servidor.shutdown, daemon=True).start()
            return
        parar.wait(30)


def main():
    ap = argparse.ArgumentParser(description='Loja ERP')
    ap.add_argument('--porta', type=int, default=8765)
    ap.add_argument('--pasta', help='pasta da loja (onde ficam "dados" e "backups")')
    ap.add_argument('--sem-navegador', action='store_true')
    ap.add_argument('--encerrar', action='store_true', help='encerra o sistema aberto para esta pasta')
    ap.add_argument('--verificar', action='store_true', help='confere os arquivos do programa e sai (usado na atualização)')
    args = ap.parse_args()

    if args.verificar:
        faltando = [v['item'] for v in verificar_dependencias(somente_programa=True) if v['critico'] and not v['ok']]
        print('VERIFICACAO-FALHOU: ' + ', '.join(faltando) if faltando else f'VERIFICACAO-OK {VERSAO}')
        sys.exit(1 if faltando else 0)

    if os.name != 'nt':
        os.umask(0o077)
    preparar_saida()
    definir_pastas(args.pasta)
    if args.encerrar:
        print('Sistema encerrado.' if encerrar_instancia() else 'O sistema não estava aberto.')
        return

    atu = atualizacao.Atualizador(BASE_DIR, pasta_estado_local(), VERSAO, log=print)
    aplicando = atu.estado.get('aplicando')
    if atu.estado.get('copiando') and atu.reverter('a instalação foi interrompida no meio'):
        return relancar()
    if aplicando and aplicando.get('versao') == VERSAO:
        aplicando['tentativas'] = aplicando.get('tentativas', 0) + 1
        atu.salvar()
        if aplicando['tentativas'] > 2 and atu.reverter('não abriu depois de duas tentativas'):
            return relancar()
    elif aplicando:
        atu.estado['aplicando'] = None
        atu.salvar()

    existente = instancia_ativa()
    if existente:
        url = f'http://127.0.0.1:{existente["porta"]}/entrar?t={existente["token"]}'
        print(f'O sistema já está aberto: {url}')
        if not args.sem_navegador:
            webbrowser.open(url)
        return

    print('=' * 64)
    print(f'  Loja ERP {VERSAO}')
    print(f'  {CREDITO}')
    print('=' * 64)
    print('\n  Verificando dependências...')
    for v in verificar_dependencias():
        marca = 'OK ' if v['ok'] else ('ERRO' if v['critico'] else 'AVISO')
        print(f'  [{marca}] {v["item"]}: {v["detalhe"]}')
        if not v['ok'] and v['critico']:
            alertar(f'Não é possível iniciar o Loja ERP.\n\n{v["item"]}: {v["detalhe"]}')
            return
    if atu.automatica and atu.pode_aplicar():
        try:
            print(f'\n  Instalando a atualização {atu.estado["pronta"]["versao"]}...')
            atu.aplicar()
            return relancar()
        except (OSError, ValueError) as e:
            atu.estado['erro'] = f'Não foi possível instalar a atualização: {e}'
            atu.salvar()
            if atu.estado.get('aplicando'):
                atu.reverter(str(e))
    falha_dados = ''
    try:
        banco = Banco()
    except (RuntimeError, OSError) as e:
        banco = None
        falha_dados = str(e)
        print(f'\n  MODO DE RECUPERAÇÃO: {falha_dados}')
    porta_herdada = os.environ.pop('LOJA_ERP_PORTA', '')
    token_herdado = os.environ.pop('LOJA_ERP_TOKEN', '')
    porta = porta_livre(int(porta_herdada) if porta_herdada.isdigit() else args.porta, '127.0.0.1')
    servidor = Servidor(('127.0.0.1', porta), Manipulador)
    servidor.app = Aplicacao(banco, porta)
    if re.fullmatch(r'[A-Za-z0-9_-]{32,64}', token_herdado):
        servidor.app.token = token_herdado   # reinício após atualização: a aba aberta continua valendo
    if not falha_dados and servidor.app.usuarios_perdidos():
        falha_dados = AVISO_USUARIOS_PERDIDOS
        print(f'\n  MODO DE RECUPERAÇÃO: {falha_dados}')
    servidor.app.recuperacao = falha_dados
    servidor.app.aviso_uso = verificar_uso_concorrente()
    token = servidor.app.token
    url = f'http://127.0.0.1:{porta}/entrar?t={token}'
    try:
        with open(arquivo_instancia(), 'w', encoding='utf-8') as f:
            json.dump({'porta': porta, 'token': token, 'instancia': servidor.app.id_instancia, 'pid': os.getpid()}, f)
    except OSError:
        pass
    print(f'\n  Pasta da loja: {PASTA_LOJA}')
    if servidor.app.aviso_uso:
        print('\n  ' + servidor.app.aviso_uso)
    print(f'\n  Endereço desta sessão:\n  {url}')
    servidor.app.atualizador.confirmar_inicio()
    registrar_versao_windows()
    if servidor.app.celular.get('ativo'):
        try:
            servidor.app.ligar_celular()
        except (ErroNegocio, OSError, ssl.SSLError) as e:
            print(f'\n  Acesso pelo celular não foi ligado: {e}')
    if TEM_CONSOLE:
        print('\n  Mantenha esta janela aberta enquanto usa o sistema.')
        print('  Para sair, use "Encerrar sistema" no menu ou feche esta janela.\n')
    parar = threading.Event()
    threading.Thread(target=vigiar, args=(servidor, parar), daemon=True).start()
    threading.Thread(target=verificar_atualizacoes, args=(servidor.app, parar), daemon=True).start()
    # Depois de atualizar, a aba aberta continua valendo; só abre outra se a porta tiver mudado.
    if not args.sem_navegador and (not token_herdado or str(porta) != porta_herdada):
        threading.Timer(0.8, webbrowser.open, [url]).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        parar.set()
        servidor.app.desligar_celular(lembrar=False)
        servidor.server_close()
        for arq in (ARQ_EM_USO, arquivo_instancia()):
            try:
                os.remove(arq)
            except OSError:
                pass
        print('  Sistema encerrado. Seus dados estão salvos.')
    if servidor.app.pedido_reinicio:
        reiniciar_atualizado(servidor.app, porta)


def registrar_versao_windows():
    """Mantém a versão mostrada em "Aplicativos instalados" igual à que está rodando (após atualizar)."""
    if sys.platform != 'win32':
        return
    import winreg
    for chave, nome in ((r'Software\Microsoft\Windows\CurrentVersion\Uninstall\LojaERP', 'DisplayVersion'),
                        (r'Software\LojaERP', 'Versao')):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, chave, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
                if winreg.QueryValueEx(k, nome)[0] != VERSAO:
                    winreg.SetValueEx(k, nome, 0, winreg.REG_SZ, VERSAO)
        except OSError:
            pass


def verificar_atualizacoes(app, parar):
    """Procura versão nova 2 minutos depois de abrir e a cada 12 horas (só baixa e testa; instala ao reabrir)."""
    if parar.wait(120):
        return
    while True:
        atu = app.atualizador
        ultima = atu.estado.get('ultima_verificacao') or ''
        try:
            vencida = time.time() - time.mktime(time.strptime(ultima, '%Y-%m-%dT%H:%M:%S')) > atualizacao.INTERVALO_VERIFICACAO
        except ValueError:
            vencida = True
        if vencida:
            atu.verificar(baixar=atu.automatica)
        if parar.wait(3600):
            return


def relancar(extra_env=None):
    """Abre o programa de novo (já com os arquivos novos) e encerra este processo."""
    env = dict(os.environ, **(extra_env or {}))
    # Herda as saídas do processo atual: sem console (pythonw), a versão nova também grava no loja.log.
    return subprocess.Popen([sys.executable] + sys.argv, env=env, cwd=BASE_DIR, close_fds=True)


def reiniciar_atualizado(app, porta):
    """Instala a atualização pedida pela tela e reabre na mesma porta e com o mesmo endereço.
    Se a versão nova não responder em 60 segundos, volta para a anterior."""
    atu = app.atualizador
    env = {'LOJA_ERP_TOKEN': app.token, 'LOJA_ERP_PORTA': str(porta)}
    try:
        atu.aplicar()
    except (OSError, ValueError) as e:
        atu.estado['erro'] = f'Não foi possível instalar a atualização: {e}'
        atu.salvar()
        if atu.estado.get('aplicando'):
            atu.reverter(str(e))
        return relancar(env)
    novo = relancar(env)
    for _ in range(60):
        time.sleep(1)
        if instancia_ativa():
            return
        if novo.poll() is not None:
            break   # a versão nova fechou sozinha: não adianta esperar
    motivo = 'fechou ao abrir' if novo.poll() is not None else 'não respondeu em 60 segundos'
    if novo.poll() is None:
        novo.terminate()   # lenta demais: não deixa duas versões abertas na mesma pasta
        try:
            novo.wait(15)
        except subprocess.TimeoutExpired:
            novo.kill()
    if atu.reverter(motivo):
        relancar(env)


if __name__ == '__main__':
    main()
