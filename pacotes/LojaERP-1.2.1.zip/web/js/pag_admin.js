/* Loja ERP — relatórios, agenda, cadastros auxiliares e configurações.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

/* --------------------------------------------------------------- relatórios */
App.paginas.relatorios = async (el, id, params) => {
  const dia = hojeISO();
  const presets = { hoje: [dia, dia], '7d': [somarDias(dia, -6), dia], mes: [dia.slice(0, 7) + '-01', dia],
    mesant: [somarMeses(dia.slice(0, 7), -1) + '-01', ultimoDiaMes(somarMeses(dia.slice(0, 7), -1))], '90d': [somarDias(dia, -89), dia], ano: [dia.slice(0, 4) + '-01-01', dia] };
  const st = { de: params.de || presets.mes[0], ate: params.ate || presets.mes[1], sec: params.sec || 'resumo' };
  const secoes = [['resumo', 'Resumo'], ['categorias', 'Por categoria'], ['produtos', 'Produtos (curva ABC)'], ['grade', 'Tamanhos e cores'], ['pagamentos', 'Formas de pagamento'],
    ['horarios', 'Dias e horários'], ['clientes', 'Clientes'], ['colecoes', 'Coleções (sell-through)'], ['fornecedores', 'Fornecedores'], ['parados', 'Estoque parado'], ['promocoes', 'Promoções e descontos']];
  el.innerHTML = `<div class="card compacto"><div class="linha-acoes" style="margin:0">
      <div class="chips">${[['hoje', 'Hoje'], ['7d', '7 dias'], ['mes', 'Este mês'], ['mesant', 'Mês anterior'], ['90d', '90 dias'], ['ano', 'Ano']].map(([k, t]) => `<button class="chip" data-click="preset" data-k="${k}">${t}</button>`).join('')}</div>
      <label class="campo"><span>De</span><input type="date" data-change="de" value="${st.de}"></label><label class="campo"><span>Até</span><input type="date" data-change="ate" value="${st.ate}"></label></div></div>
    ${abas(secoes, st.sec)}<div id="rel"></div>`;
  const nav = () => ir(`#/relatorios?sec=${st.sec}&de=${st.de}&ate=${st.ate}`);
  ligar(el, { preset: b => { [st.de, st.ate] = presets[b.dataset.k]; nav(); }, de: i => { st.de = i.value; nav(); }, ate: i => { st.ate = i.value; nav(); }, aba: b => { st.sec = b.dataset.k; nav(); } });
  const vendas = vendasPeriodo(st.de, st.ate);
  const itens = vendas.flatMap(v => v.itens.map(i => ({ ...i, venda: v })));
  const box = el.querySelector('#rel');
  const r = resumoVendas(vendas);
  const grupoItens = (f, nome) => [...agrupar(itens, f)].map(([k, l]) => {
    const receita = soma(l, i => i.total), custo = soma(l, i => i.custo_unit * i.qtd);
    return { k, nome: nome(k, l), qtd: soma(l, i => i.qtd), receita, custo, lucro: receita - custo, margem: receita ? (receita - custo) / receita * 100 : 0 };
  }).sort((a, b) => b.receita - a.receita);
  const colsGrupo = t => [{ t, v: x => x.nome }, { t: 'Peças', v: x => x.qtd, cls: 'num', total: l => numBR(soma(l, x => x.qtd)) },
    { t: 'Receita', v: x => r2(x.receita), h: x => moeda(x.receita), cls: 'num', total: true }, { t: '% receita', v: x => r.fat ? r2(x.receita / r.fat * 100) : 0, h: x => pct(r.fat ? x.receita / r.fat * 100 : 0), cls: 'num' },
    { t: 'Custo', v: x => r2(x.custo), h: x => moeda(x.custo), cls: 'num', total: true }, { t: 'Lucro bruto', v: x => r2(x.lucro), h: x => moeda(x.lucro), cls: 'num', total: true },
    { t: 'Margem', v: x => r2(x.margem), h: x => pct(x.margem), cls: 'num' }];
  const secao = (titulo, grafico, idTab) => `<div class="card"><div class="card-cab"><h3>${titulo}</h3></div>${grafico || ''}<div id="${idTab}" style="margin-top:12px"></div></div>`;

  switch (st.sec) {
    case 'resumo': {
      const dias = [];
      for (let d = st.de; d <= st.ate && dias.length < 400; d = somarDias(d, 1)) dias.push({ rotulo: dataBR(d), curto: d.slice(8) + '/' + d.slice(5, 7), valor: faturamentoDia(d) });
      const trocas = App.d.trocas.filter(t => t.data.slice(0, 10) >= st.de && t.data.slice(0, 10) <= st.ate);
      box.innerHTML = `<div class="kpis">${kpi('Faturamento', moeda(r.fat), `${r.n} vendas`)}${kpi('Ticket médio', moeda(r.ticket))}${kpi('Peças por atendimento', numBR(r.pa, 2), `${r.pecas} peças`)}
        ${kpi('Lucro bruto', moeda(r.lucroBruto), 'Margem ' + pct(r.margem))}${kpi('Descontos', moeda(r.desc), r.fat ? pct(r.desc / (r.fat + r.desc) * 100) + ' do bruto' : '')}
        ${kpi('Trocas/devoluções', moeda(soma(trocas, t => t.total)), `${trocas.length} ocorrência(s)`)}${kpi('Clientes identificadas', pct(r.n ? vendas.filter(v => v.cliente_id).length / r.n * 100 : 0, 0), 'das vendas')}
        ${kpi('Markup realizado', r.cmv ? numBR(r.fat / r.cmv, 2) + 'x' : '—')}</div>${secao('Faturamento por dia', graficoBarras(dias), 'x')}`;
      break;
    }
    case 'categorias': {
      const g = grupoItens(i => i.categoria_id || 'servicos', k => (App.idx.cat[k] || {}).nome || (k === 'servicos' ? 'Serviços' : 'Sem categoria'));
      box.innerHTML = secao('Vendas por categoria', barrasH(g.slice(0, 12).map(x => ({ rotulo: x.nome, valor: x.receita }))), 't');
      tabela(box.querySelector('#t'), { linhas: g, busca: false, exportar: 'vendas-categoria', colunas: colsGrupo('Categoria') });
      break;
    }
    case 'produtos': {
      const g = grupoItens(i => i.produto_id || i.servico_id, (k, l) => l[0].nome);
      let acum = 0;
      g.forEach(x => { acum += x.receita; x.acum = r.fat ? acum / r.fat * 100 : 0; x.classe = x.acum <= 80 ? 'A' : x.acum <= 95 ? 'B' : 'C'; });
      box.innerHTML = `<div class="caixa-aviso"><b>Curva ABC:</b> A = produtos que somam 80% do faturamento (nunca deixe faltar), B = próximos 15%, C = últimos 5% (avalie se vale recomprar).</div>${secao('Ranking de produtos', '', 't')}`;
      tabela(box.querySelector('#t'), { linhas: g, exportar: 'curva-abc', colunas: [{ t: 'Classe', v: x => x.classe, h: x => etiqueta(x.classe, x.classe === 'A' ? 'ok' : x.classe === 'B' ? 'info' : '') }, ...colsGrupo('Produto'), { t: '% acumulado', v: x => r2(x.acum), h: x => pct(x.acum), cls: 'num' }] });
      break;
    }
    case 'grade': {
      const prod = itens.filter(i => i.produto_id);
      const tam = [...agrupar(prod, i => i.tamanho)].map(([k, l]) => ({ rotulo: k, valor: soma(l, i => i.qtd) })).sort((a, b) => b.valor - a.valor);
      const cor = [...agrupar(prod, i => i.cor)].map(([k, l]) => ({ rotulo: k, valor: soma(l, i => i.qtd) })).sort((a, b) => b.valor - a.valor);
      const estTam = {};
      App.d.produtos.forEach(p => p.ativo !== false && p.variacoes.forEach(v => { estTam[v.tamanho] = (estTam[v.tamanho] || 0) + Math.max(0, v.estoque); }));
      box.innerHTML = `<div class="caixa-aviso">Use para montar a grade dos próximos pedidos: compre mais dos tamanhos e cores que giram e menos dos que encalham.</div>
        <div class="grade g2"><div class="card"><h3>Peças vendidas por tamanho</h3>${barrasH(tam, v => v + ' pç')}</div><div class="card"><h3>Peças vendidas por cor</h3>${barrasH(cor.slice(0, 15), v => v + ' pç')}</div></div>
        <div class="card"><h3>Vendido × em estoque por tamanho</h3><div id="t"></div></div>`;
      tabela(box.querySelector('#t'), { linhas: [...new Set([...tam.map(x => x.rotulo), ...Object.keys(estTam)])].map(k => ({ k, vend: (tam.find(x => x.rotulo === k) || {}).valor || 0, est: estTam[k] || 0 })), busca: false, exportar: 'vendas-tamanho',
        colunas: [{ t: 'Tamanho', v: x => x.k }, { t: 'Vendidas no período', v: x => x.vend, cls: 'num' }, { t: 'Em estoque', v: x => x.est, cls: 'num' }, { t: 'Sell-through', v: x => x.vend + x.est ? r2(x.vend / (x.vend + x.est) * 100) : 0, h: x => pct(x.vend + x.est ? x.vend / (x.vend + x.est) * 100 : 0), cls: 'num' }] });
      break;
    }
    case 'pagamentos': {
      const pags = vendas.flatMap(v => v.pagamentos.map(p => ({ ...p, valor: p.forma === 'dinheiro' ? p.valor - v.troco : p.valor })));
      const g = [...agrupar(pags, p => p.forma + (p.forma === 'credito' ? (p.parcelas > 1 ? ' parcelado' : ' à vista') : ''))].map(([k, l]) => ({ k, valor: soma(l, p => p.valor), taxa: soma(l, p => p.taxa), n: l.length }))
        .map(x => ({ ...x, nome: x.k.replace(/^\w+/, f => FORMAS_PAG[f] || f) })).sort((a, b) => b.valor - a.valor);
      box.innerHTML = secao('Recebido por forma de pagamento', barrasH(g.map(x => ({ rotulo: x.nome, valor: x.valor }))), 't');
      tabela(box.querySelector('#t'), { linhas: g, busca: false, exportar: 'formas-pagamento', colunas: [{ t: 'Forma', v: x => x.nome }, { t: 'Transações', v: x => x.n, cls: 'num' },
        { t: 'Valor', v: x => r2(x.valor), h: x => moeda(x.valor), cls: 'num', total: true }, { t: 'Taxas pagas', v: x => r2(x.taxa), h: x => moeda(x.taxa), cls: 'num', total: true }, { t: '% taxa', v: x => x.valor ? r2(x.taxa / x.valor * 100) : 0, h: x => pct(x.valor ? x.taxa / x.valor * 100 : 0), cls: 'num' }] });
      break;
    }
    case 'horarios': {
      const porDia = DIAS_SEMANA.map((d, k) => { const l = vendas.filter(v => new Date(v.data.slice(0, 10) + 'T12:00').getDay() === k); return { rotulo: d, curto: d.slice(0, 3), valor: soma(l, v => v.total), n: l.length }; });
      const porHora = Array.from({ length: 15 }, (_, k) => k + 7).map(h => { const l = vendas.filter(v => +v.data.slice(11, 13) === h); return { rotulo: `${h}h`, valor: soma(l, v => v.total), n: l.length }; });
      box.innerHTML = `<div class="grade g2"><div class="card"><h3>Faturamento por dia da semana</h3>${graficoBarras(porDia)}</div><div class="card"><h3>Faturamento por horário</h3>${graficoBarras(porHora)}</div></div>
        <div class="caixa-aviso">Use para decidir horário de abertura, dias de promoção (ex.: "Terça das Amigas" no dia mais fraco) e quando postar nas redes.</div>`;
      break;
    }
    case 'clientes': {
      const g = [...agrupar(vendas.filter(v => v.cliente_id), v => v.cliente_id)].map(([k, l]) => ({ c: App.idx.cli[k] || { nome: '?' }, n: l.length, total: soma(l, v => v.total), pecas: soma(l, v => soma(v.itens, i => i.qtd)) })).sort((a, b) => b.total - a.total);
      const novas = App.d.clientes.filter(c => c.criado_em && c.criado_em.slice(0, 10) >= st.de && c.criado_em.slice(0, 10) <= st.ate).length;
      box.innerHTML = `<div class="kpis">${kpi('Clientes que compraram', g.length)}${kpi('Novos cadastros', novas)}${kpi('Recompra', pct(g.length ? g.filter(x => x.n > 1).length / g.length * 100 : 0, 0), 'compraram mais de uma vez no período')}
        ${kpi('Vendas sem cliente', pct(r.n ? vendas.filter(v => !v.cliente_id).length / r.n * 100 : 0, 0), 'Identifique para fidelizar')}</div>${secao('Clientes que mais compraram', '', 't')}`;
      tabela(box.querySelector('#t'), { linhas: g, exportar: 'ranking-clientes', colunas: [{ t: 'Cliente', v: x => x.c.nome }, { t: 'Compras', v: x => x.n, cls: 'num' }, { t: 'Peças', v: x => x.pecas, cls: 'num' },
        { t: 'Total', v: x => r2(x.total), h: x => moeda(x.total), cls: 'num', total: true }, { t: 'Ticket médio', v: x => r2(x.total / x.n), h: x => moeda(x.total / x.n), cls: 'num' }] });
      break;
    }
    case 'colecoes': {
      const recebidas = {}, vendidasTot = {};
      App.d.movimentos.forEach(m => { const p = App.idx.prod[m.produto_id]; if (!p) return; const k = p.colecao_id || '-';
        if (['entrada', 'estoque_inicial'].includes(m.tipo)) recebidas[k] = (recebidas[k] || 0) + m.qtd; if (m.tipo === 'venda') vendidasTot[k] = (vendidasTot[k] || 0) - m.qtd; if (m.tipo === 'cancelamento' || m.tipo === 'devolucao') vendidasTot[k] = (vendidasTot[k] || 0) - m.qtd; });
      const g = grupoItens(i => i.colecao_id || '-', k => (App.idx.col[k] || {}).nome || 'Sem coleção');
      box.innerHTML = `<div class="caixa-aviso"><b>Sell-through</b> = peças vendidas ÷ peças recebidas da coleção (desde sempre). Abaixo de 60% no fim da estação indica compra exagerada — hora de liquidar.</div>${secao('Coleções', '', 't')}`;
      tabela(box.querySelector('#t'), { linhas: g, busca: false, exportar: 'colecoes', colunas: [...colsGrupo('Coleção'), { t: 'Recebidas (total)', v: x => recebidas[x.k] || 0, cls: 'num' },
        { t: 'Sell-through', v: x => recebidas[x.k] ? r2((vendidasTot[x.k] || 0) / recebidas[x.k] * 100) : 0, h: x => recebidas[x.k] ? pct((vendidasTot[x.k] || 0) / recebidas[x.k] * 100) : '—', cls: 'num' }] });
      break;
    }
    case 'fornecedores': {
      const g = grupoItens(i => (App.idx.prod[i.produto_id] || {}).fornecedor_id || '-', k => (App.idx.forn[k] || {}).nome || 'Sem fornecedor');
      box.innerHTML = `<div class="caixa-aviso">Mostra quais fornecedores trazem as peças que mais vendem e com melhor margem — base para negociar e decidir recompras.</div>${secao('Desempenho por fornecedor', '', 't')}`;
      tabela(box.querySelector('#t'), { linhas: g, busca: false, exportar: 'fornecedores-desempenho', colunas: colsGrupo('Fornecedor') });
      break;
    }
    case 'parados': {
      const ult = ultimaVendaPorProduto();
      const lista = App.d.produtos.filter(p => p.ativo !== false && estoqueProduto(p) > 0).map(p => ({ p, ult: ult[p.id] || '', dias: diasEntre(ult[p.id] || p.criado_em || hojeISO(), hojeISO()), est: estoqueProduto(p) })).sort((a, b) => b.dias - a.dias);
      box.innerHTML = `<div class="caixa-aviso">Peças paradas são dinheiro parado. Ideias: queima de estoque, kits, leve-3-pague-2, brinde acima de um valor, venda para revendedoras.</div>${secao('Produtos com estoque, por tempo sem venda', '', 't')}`;
      tabela(box.querySelector('#t'), { linhas: lista, exportar: 'estoque-parado', colunas: [{ t: 'Produto', v: x => x.p.nome }, { t: 'Coleção', v: x => (App.idx.col[x.p.colecao_id] || {}).nome || '' },
        { t: 'Última venda', v: x => x.ult, h: x => x.ult ? dataBR(x.ult) : 'nunca vendeu' }, { t: 'Dias parado', v: x => x.dias, h: x => `<b class="${x.dias > (App.cfg.estoque.dias_parado || 90) ? 'negativo' : ''}">${x.dias}</b>`, cls: 'num' },
        { t: 'Peças', v: x => x.est, cls: 'num', total: l => numBR(soma(l, x => x.est)) }, { t: 'Valor a custo', v: x => r2(x.est * n(x.p.custo)), h: x => moeda(x.est * n(x.p.custo)), cls: 'num', total: true }],
        aoClicar: x => ir('#/produto/' + x.p.id) });
      break;
    }
    case 'promocoes': {
      const g = {};
      vendas.forEach(v => { (v.promocoes || []).forEach(p => { g[p] = g[p] || { n: 0, fat: 0 }; g[p].n++; g[p].fat += v.total; }); });
      const manual = vendas.filter(v => !(v.promocoes || []).length && v.desconto_itens + v.desconto_carrinho > 0);
      box.innerHTML = `<div class="kpis">${kpi('Total de descontos', moeda(r.desc))}${kpi('Vendas com promoção', pct(r.n ? vendas.filter(v => (v.promocoes || []).length).length / r.n * 100 : 0, 0))}${kpi('Descontos manuais', moeda(soma(manual, v => v.desconto_itens + v.desconto_carrinho)), `${manual.length} venda(s)`)}</div>${secao('Vendas por promoção', '', 't')}`;
      tabela(box.querySelector('#t'), { linhas: Object.entries(g).map(([k, x]) => ({ k, ...x })), busca: false, exportar: 'promocoes', colunas: [{ t: 'Promoção', v: x => x.k }, { t: 'Vendas', v: x => x.n, cls: 'num' }, { t: 'Faturamento dessas vendas', v: x => r2(x.fat), h: x => moeda(x.fat), cls: 'num' }] });
      break;
    }
  }
};

/* --------------------------------------------------------------- cadastros */
App.paginas.cadastros = async (el, id, params) => {
  const aba = params.aba || 'categorias';
  const defs = {
    categorias: { titulo: 'Categorias', campos: [{ n: 'nome', r: 'Nome', w: 6, obr: 1 }, { n: 'margem', r: 'Margem de lucro desejada (%)', t: 'pct', w: 3, aj: 'Usada no preço sugerido' }, { n: 'markup', r: 'Markup (x)', t: 'number', step: 0.05, w: 3 }, { n: 'ativo', r: 'Ativa', t: 'check', w: 12, padrao: true }],
      colunas: [{ t: 'Categoria', v: x => x.nome }, { t: 'Margem desejada', v: x => n(x.margem), h: x => pct(x.margem, 0), cls: 'num' }, { t: 'Markup', v: x => n(x.markup), h: x => numBR(x.markup, 2) + 'x', cls: 'num' }, { t: 'Produtos', v: x => App.d.produtos.filter(p => p.categoria_id === x.id).length, cls: 'num' }] },
    marcas: { titulo: 'Marcas', campos: [{ n: 'nome', r: 'Nome', w: 12, obr: 1 }, { n: 'ativo', r: 'Ativa', t: 'check', w: 12, padrao: true }],
      colunas: [{ t: 'Marca', v: x => x.nome }, { t: 'Produtos', v: x => App.d.produtos.filter(p => p.marca_id === x.id).length, cls: 'num' }] },
    colecoes: { titulo: 'Coleções', campos: [{ n: 'nome', r: 'Nome', w: 12, obr: 1 }, { n: 'inicio', r: 'Início', t: 'date', w: 6 }, { n: 'fim', r: 'Fim', t: 'date', w: 6 }, { n: 'ativo', r: 'Ativa', t: 'check', w: 12, padrao: true }],
      colunas: [{ t: 'Coleção', v: x => x.nome }, { t: 'Período', v: x => `${dataBR(x.inicio)} a ${dataBR(x.fim)}` }, { t: 'Produtos', v: x => App.d.produtos.filter(p => p.colecao_id === x.id).length, cls: 'num' }] },
    plano_contas: { titulo: 'Plano de contas', campos: [{ n: 'nome', r: 'Nome', w: 8, obr: 1 }, { n: 'tipo', r: 'Tipo', t: 'select', w: 4, vazio: false, op: [['despesa', 'Despesa'], ['receita', 'Receita']] },
      { n: 'grupo', r: 'Onde entra no DRE', t: 'select', w: 12, vazio: false, op: Object.entries(GRUPOS_DRE).filter(([k]) => k !== 'receita_vendas') }, { n: 'ativo', r: 'Ativa', t: 'check', w: 12, padrao: true }],
      colunas: [{ t: 'Conta', v: x => x.nome, h: x => esc(x.nome) + (x.sistema ? ' ' + etiqueta('sistema') : '') }, { t: 'Tipo', v: x => x.tipo }, { t: 'Grupo no DRE', v: x => GRUPOS_DRE[x.grupo] || x.grupo }] }
  };
  const def = defs[aba];
  el.innerHTML = `${abas(Object.entries(defs).map(([k, d]) => [k, d.titulo]), aba)}<div class="linha-acoes"><span class="espaco"></span><button class="btn pri" data-click="novo">Novo</button></div><div class="card" id="tab-cad"></div>`;
  const form = x => modal({ titulo: x ? x.nome : 'Novo — ' + def.titulo, largura: 'largo', corpo: formHTML(def.campos.map(c => x && x.sistema && ['tipo', 'grupo'].includes(c.n) ? { ...c, ro: true } : c), x || {}), botoes: [
    ...(x && !x.sistema ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { await api('excluir/' + aba, { id: x.id }); recarregarPagina(); } }] : []),
    { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => { await api('salvar/' + aba, { obj: { ...(x || {}), ...lerForm(m, def.campos) } }); recarregarPagina(); } }] });
  tabela(el.querySelector('#tab-cad'), { linhas: App.d[aba], colunas: def.colunas, exportar: aba, aoClicar: x => form(x) });
  ligar(el, { aba: b => ir('#/cadastros?aba=' + b.dataset.k), novo: () => form(null) });
};

/* ---------------------------------------------------------- configurações */
App.paginas.config = async (el, id, params) => {
  const c = App.cfg;
  let secs = [['loja', 'Loja'], ['fiscal', 'Impostos e taxas'], ['preco', 'Precificação'], ['pix', 'Pix'], ['operacao', 'Operação'], ['aparencia', 'Aparência'], ['whatsapp', 'Mensagens'], ['grades', 'Grades e cores'], ['seguranca', 'Usuários e permissões'], ['dados', 'Backup e dados'], ['auditoria', 'Auditoria'], ['sobre', 'Sobre']];
  if (!gestora()) secs = secs.filter(([k]) => ['aparencia', 'seguranca', 'sobre'].includes(k));

  const aba = secs.some(([k]) => k === params.aba) ? params.aba : secs[0][0];
  el.innerHTML = abas(secs, aba) + '<div id="cfg"></div>';
  ligar(el, { aba: b => ir('#/config?aba=' + b.dataset.k) });
  const box = el.querySelector('#cfg');
  const salvarBloco = async (chave, valor) => { await api('config', { config: { [chave]: valor } }); await carregar([]); toast('Configurações salvas.', 'ok'); recarregarPagina(); };
  const formSecao = (titulo, chave, campos, aviso = '') => {
    box.innerHTML = `<div class="card"><h3>${titulo}</h3>${aviso}<div id="f">${formHTML(campos, c[chave])}</div><button class="btn pri" style="margin-top:14px" data-click="salvar">Salvar</button></div>`;
    ligar(box, { salvar: () => salvarBloco(chave, { ...c[chave], ...lerForm(box.querySelector('#f'), campos) }) });
  };
  switch (aba) {
    case 'loja':
      formSecao('Dados da loja (aparecem no recibo e nas etiquetas)', 'loja', [{ n: 'nome', r: 'Nome da loja', w: 6, obr: 1 }, { n: 'razao_social', r: 'Razão social', w: 6 }, { n: 'cnpj', r: 'CNPJ', w: 4 },
        { n: 'telefone', r: 'Telefone', w: 4 }, { n: 'whatsapp', r: 'WhatsApp', w: 4 }, { n: 'instagram', r: 'Instagram', w: 4 }, { n: 'email', r: 'E-mail', w: 8 }, { n: 'endereco', r: 'Endereço', w: 8 }, { n: 'cidade', r: 'Cidade/UF', w: 4 },
        { n: 'mensagem_recibo', r: 'Mensagem no rodapé do recibo', t: 'textarea', w: 12 }]);
      break;
    case 'fiscal': {
      const campos = [{ n: 'regime', r: 'Regime tributário', t: 'select', w: 6, vazio: false, op: [['mei', 'MEI'], ['simples', 'Simples Nacional'], ['outro', 'Outro']] },
        { n: 'aliquota_simples', r: 'Alíquota efetiva sobre vendas (%)', t: 'pct', w: 6, aj: 'Simples Nacional, Anexo I (comércio). Peça a alíquota efetiva atual ao seu contador. MEI: deixe 0 e cadastre o DAS em Despesas fixas.' }];
      const tx = [{ n: 'debito', r: 'Débito (%)', t: 'pct', w: 3 }, { n: 'credito_1', r: 'Crédito à vista (%)', t: 'pct', w: 3 }, { n: 'credito_2_6', r: 'Crédito 2 a 6x (%)', t: 'pct', w: 3 }, { n: 'credito_7_12', r: 'Crédito 7 a 12x (%)', t: 'pct', w: 3 }, { n: 'pix', r: 'Pix (%)', t: 'pct', w: 3, aj: 'Normalmente 0; algumas maquininhas cobram.' }];
      const pr = [{ n: 'debito', r: 'Débito cai em (dias)', t: 'number', w: 4 }, { n: 'credito', r: 'Crédito cai em (dias por parcela)', t: 'number', w: 4 }];
      box.innerHTML = `<div class="card"><h3>Impostos</h3><div id="f1">${formHTML(campos, c.fiscal)}</div></div>
        <div class="card"><h3>Taxas da maquininha</h3><div id="f2">${formHTML(tx, c.taxas)}</div><h3 style="margin-top:14px">Prazos de recebimento</h3><div id="f3">${formHTML(pr, c.prazos)}</div>
        <div id="f4" style="margin-top:10px">${formHTML([{ n: 'antecipacao_credito', r: 'Uso antecipação automática (todo crédito cai em 1 dia)', t: 'check', w: 12 }, { n: 'baixa_automatica_cartao', r: 'Dar baixa automática nos recebíveis de cartão na data prevista', t: 'check', w: 12 }], c)}</div></div>
        <button class="btn pri" data-click="salvar">Salvar</button>`;
      ligar(box, { salvar: async () => {
        await api('config', { config: { fiscal: lerForm(box.querySelector('#f1'), campos), taxas: { ...c.taxas, ...lerForm(box.querySelector('#f2'), tx) }, prazos: { ...c.prazos, ...lerForm(box.querySelector('#f3'), pr) },
          ...lerForm(box.querySelector('#f4'), [{ n: 'antecipacao_credito', t: 'check' }, { n: 'baixa_automatica_cartao', t: 'check' }]) } });
        await carregar([]); toast('Salvo.', 'ok'); recarregarPagina();
      } });
      break;
    }
    case 'preco':
      formSecao('Precificação', 'precificacao', [{ n: 'metodo', r: 'Método principal do preço sugerido', t: 'select', w: 6, vazio: false, op: [['margem', 'Pela margem de lucro desejada (recomendado)'], ['markup', 'Pelo markup da categoria']] },
        { n: 'arredondamento', r: 'Arredondar preço para', t: 'select', w: 6, vazio: false, op: [['90', 'R$ xx,90'], ['99', 'R$ xx,99'], ['00', 'Reais inteiros'], ['nenhum', 'Não arredondar']] },
        { n: 'margem_padrao', r: 'Margem de lucro padrão (%)', t: 'pct', w: 4, aj: 'Usada quando a categoria não define' }, { n: 'markup_padrao', r: 'Markup padrão (x)', t: 'number', step: 0.05, w: 4 },
        { n: 'despesas_fixas_pct', r: 'Despesas fixas sobre o faturamento (%)', t: 'pct', w: 4, aj: 'Aluguel + contas + pró-labore ÷ faturamento médio' },
        { n: 'taxa_cartao_media', r: 'Taxa média de cartão (%)', t: 'pct', w: 4 }, { n: 'comissao', r: 'Comissão de venda (%)', t: 'pct', w: 4 }],
        `<div class="caixa-aviso">Preço pela margem = custo ÷ (1 − (imposto + cartão + comissão + despesas fixas + lucro desejado)). Assim cada peça paga sua parte das despesas e ainda dá o lucro que você quer.
         Despesas fixas atuais (recorrentes): <b>${moeda(soma(App.d.recorrentes.filter(r => r.ativo), r => n(r.valor)))}</b>/mês.</div>`);
      break;
    case 'aparencia':
      renderAparencia(box);
      break;
    case 'pix':
      formSecao('Chave Pix da loja', 'pix', [{ n: 'tipo_chave', r: 'Tipo de chave', t: 'select', w: 4, vazio: false, op: [['cpf', 'CPF'], ['cnpj', 'CNPJ'], ['telefone', 'Celular'], ['email', 'E-mail'], ['aleatoria', 'Chave aleatória']] },
        { n: 'chave', r: 'Chave Pix', w: 8, aj: 'Exatamente como cadastrada no banco. Celular com DDD; o +55 é colocado automaticamente.' },
        { n: 'nome', r: 'Nome do recebedor', w: 8, aj: 'Nome que aparece para a cliente ao pagar (até 25 letras, sem acentos).' }, { n: 'cidade', r: 'Cidade', w: 4, aj: 'Cidade do recebedor (até 15 letras).' }],
        '<div class="caixa-aviso">Usada para gerar QR Codes Pix no caixa e na página Pix. Faça um teste pagando R$ 0,01 depois de configurar.</div>');
      break;
    case 'operacao': {
      const blocos = [['condicional', 'Condicional', [{ n: 'prazo_dias', r: 'Prazo padrão (dias)', t: 'number', w: 4 }, { n: 'max_pecas', r: 'Máximo de peças', t: 'number', w: 4 }]],
        ['crediario', 'Crediário', [{ n: 'max_parcelas', r: 'Máximo de parcelas', t: 'number', w: 4 }]],
        ['vales', 'Vale-troca', [{ n: 'validade_dias', r: 'Validade (dias)', t: 'number', w: 4 }]],
        ['estoque', 'Estoque', [{ n: 'permitir_negativo', r: 'Permitir vender sem estoque (não recomendado)', t: 'check', w: 8 }, { n: 'dias_parado', r: 'Considerar parado após (dias)', t: 'number', w: 4 }]]];
      box.innerHTML = blocos.map(([k, t, cs]) => `<div class="card"><h3>${t}</h3><div data-bloco="${k}">${formHTML(cs, c[k])}</div></div>`).join('') + '<button class="btn pri" data-click="salvar">Salvar</button>';
      ligar(box, { salvar: async () => { const cfg = {}; blocos.forEach(([k, , cs]) => { cfg[k] = { ...c[k], ...lerForm(box.querySelector(`[data-bloco=${k}]`), cs) }; }); await api('config', { config: cfg }); await carregar([]); toast('Salvo.', 'ok'); recarregarPagina(); } });
      break;
    }
    case 'whatsapp': {
      const nomes = { aniversario: 'Aniversário', novidades: 'Novidades', cobranca: 'Cobrança de crediário', condicional: 'Lembrete de condicional', recibo: 'Agradecimento / recibo', reativacao: 'Reativação de cliente inativa', cashback: 'Lembrete de cashback' };
      formSecao('Modelos de mensagem', 'whatsapp', Object.keys(c.whatsapp).map(k => ({ n: k, r: nomes[k] || k, t: 'textarea', w: 12 })), '<div class="caixa-aviso">Variáveis: {nome}, {loja}, {valor}, {vencimento}, {prazo}, {validade}, {numero}.</div>');
      break;
    }
    case 'grades': {
      box.innerHTML = `<div class="card"><h3>Grades de tamanho</h3><p class="suave">Uma por linha, no formato <code>Nome: P,M,G</code></p><textarea id="grades" rows="9">${esc(Object.entries(c.grades).map(([k, v]) => `${k}: ${v}`).join('\n'))}</textarea>
        <h3 style="margin-top:14px">Cores sugeridas</h3><textarea id="cores" rows="3">${esc(c.cores)}</textarea><button class="btn pri" style="margin-top:12px" data-click="salvar">Salvar</button></div>`;
      ligar(box, { salvar: async () => {
        const grades = {};
        box.querySelector('#grades').value.split('\n').forEach(l => { const i = l.indexOf(':'); if (i > 0) grades[l.slice(0, i).trim()] = l.slice(i + 1).split(',').map(x => x.trim()).filter(Boolean).join(','); });
        await api('config', { config: { grades, cores: box.querySelector('#cores').value.split(',').map(x => x.trim()).filter(Boolean).join(',') } }); await carregar([]); toast('Salvo.', 'ok');
      } });
      break;
    }
    case 'seguranca':
      box.innerHTML = `<div class="grade g2"><div class="card"><h3>Trocar minha senha</h3><div id="fs">${formHTML([{ n: 'atual', r: 'Senha atual', t: 'password', w: 12 }, { n: 'nova', r: 'Nova senha', t: 'password', w: 6 }, { n: 'nova2', r: 'Repita', t: 'password', w: 6 }])}</div>
          <button class="btn pri" style="margin-top:12px" data-click="senha">Alterar senha</button></div>
        ${App.papel === 'dona' ? `<div class="card"><h3>Código de recuperação</h3><p class="suave">Gere um novo código se perdeu o anterior ou se alguém pode tê-lo visto. O código antigo deixa de funcionar.</p><button class="btn" data-click="codigo">Gerar novo código</button></div>` : ''}</div>
        <div class="card"><div class="card-cab"><h3>Usuários</h3>${App.papel === 'dona' ? '<button class="btn" data-click="addUser">Adicionar usuário</button>' : ''}</div>
          ${App.usuarios.map(u => `<div class="tarefa"><span style="flex:1"><b>${esc(u.nome)}</b> <small>${esc(u.login)}</small></span>
            ${App.papel === 'dona' && u.login !== App.usuario ? `<select class="input-inline" data-change="papel" data-l="${esc(u.login)}">${Object.entries(App.papeis).map(([k, t]) => `<option value="${k}" ${k === u.papel ? 'selected' : ''}>${esc(t.split(' — ')[0])}</option>`).join('')}</select>
              <button class="btn pequeno" data-click="senhaUser" data-l="${esc(u.login)}">Nova senha</button>
              <button class="btn pequeno perigo" data-click="remUser" data-l="${esc(u.login)}">Remover</button>` : etiqueta((App.papeis[u.papel] || u.papel).split(' — ')[0], 'pri')}</div>`).join('')}
          <h4 style="margin:14px 0 6px">Perfis de acesso</h4>${Object.values(App.papeis).map(t => `<div class="suave">• ${esc(t)}</div>`).join('')}
          <p class="suave" style="margin-top:8px">Cada ação fica registrada na auditoria com o nome de quem fez.</p></div>
        ${gestora() ? `<div class="card"><h3>Bloqueio automático</h3><p class="suave">Depois desse tempo sem mexer no sistema, ele volta para a tela de senha. Útil se o computador fica no balcão.</p>
          <div id="fb">${formHTML([{ n: 'bloqueio_min', r: 'Bloquear após', t: 'select', w: 6, vazio: false, op: [[0, 'Nunca'], [10, '10 minutos'], [30, '30 minutos'], [60, '1 hora'], [120, '2 horas']] }], App.cfg.seguranca || { bloqueio_min: 30 })}</div>
          <button class="btn pri" style="margin-top:10px" data-click="bloqueio">Salvar</button></div>` : ''}
        <div class="card"><h3>Proteção dos dados</h3><p class="suave">Os dados pessoais das clientes (CPF, telefone, e-mail, endereço, nascimento e observações) ficam cifrados nos arquivos com uma chave aleatória de 256 bits.
          Essa chave só é liberada com a senha de um usuário ou com o código de recuperação. Os backups diários são compactados e criptografados com a mesma chave.
          O sistema só aceita conexões deste computador, exige um endereço com token novo a cada abertura, bloqueia tentativas repetidas de senha e registra cada ação numa auditoria encadeada que denuncia alterações.</p></div>`;
      ligar(box, {
        senha: async () => { const d = lerForm(box.querySelector('#fs'), [{ n: 'atual', r: 'Senha atual', obr: 1 }, { n: 'nova', r: 'Nova senha', obr: 1 }, { n: 'nova2', r: 'Repita', obr: 1 }]); if (d.nova !== d.nova2) throw new Error('As senhas não conferem.'); await api('senha', d); toast('Senha alterada.', 'ok'); recarregarPagina(); },
        codigo: async () => { const s = await pedirSenha('Novo código de recuperação', 'Confirme sua senha para gerar um novo código.'); if (!s) return; const r = await api('nova_recuperacao', { senha: s }); modal({ titulo: 'Novo código de recuperação', corpo: `<p>Anote e guarde em local seguro:</p><div class="codigo-rec">${esc(r.recuperacao)}</div>`, botoes: [{ texto: 'Anotei', classe: 'pri' }] }); },
        bloqueio: async () => { await api('config', { config: { seguranca: { ...(App.cfg.seguranca || {}), bloqueio_min: n(box.querySelector('#fb [name=bloqueio_min]').value) } } }); await carregar([]); toast('Salvo.', 'ok'); },
        papel: async s => { await api('usuario/papel', { login: s.dataset.l, papel: s.value }); await carregar([]); toast('Perfil alterado.', 'ok'); },
        addUser: () => { const cs = [{ n: 'nome', r: 'Nome', w: 12, obr: 1 }, { n: 'login', r: 'Usuário', w: 6, obr: 1 }, { n: 'senha', r: 'Senha', t: 'password', w: 6, obr: 1 },
          { n: 'papel', r: 'Perfil de acesso', t: 'select', w: 12, vazio: false, padrao: 'vendedora', op: Object.entries(App.papeis) }];
          modal({ titulo: 'Novo usuário', corpo: formHTML(cs), botoes: [{ texto: 'Cancelar' }, { texto: 'Adicionar', classe: 'pri', acao: async m => { await api('usuario/adicionar', lerForm(m, cs)); await carregar([]); recarregarPagina(); } }] }); },
        senhaUser: b => { const cs = [{ n: 'senha', r: `Nova senha para ${b.dataset.l}`, t: 'password', w: 12, obr: 1, aj: 'Combine a senha com a pessoa e peça para ela trocar depois em Configurações › Usuários e permissões › Trocar minha senha.' },
            { n: 'minha_senha', r: 'Sua senha (proprietária), para confirmar', t: 'password', w: 12, obr: 1 }];
          modal({ titulo: 'Definir nova senha', corpo: formHTML(cs), botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => { await api('usuario/senha', { login: b.dataset.l, ...lerForm(m, cs) }); toast('Senha redefinida. A pessoa precisa entrar de novo.', 'ok'); } }] }); },
        remUser: async b => { if (!await confirmar(`Remover o usuário ${b.dataset.l}?`, 'Remover', 'perigo')) return; await api('usuario/remover', { login: b.dataset.l }); await carregar([]); recarregarPagina(); }
      });
      break;
    case 'dados':
      await renderBackup(box);
      break;
    case 'auditoria': {
      const r = await api('auditoria');
      box.innerHTML = `<div class="card">${r.integro ? '<div class="caixa-aviso">Registro íntegro: cada linha está encadeada à anterior e nenhuma foi alterada ou apagada no meio.</div>'
        : `<div class="caixa-aviso erro">O registro de auditoria foi alterado por fora do sistema a partir da linha ${r.linha_alterada}.</div>`}
        <p class="suave">Últimas 400 ações registradas (arquivo dados/auditoria.log).</p><div id="t"></div></div>`;
      tabela(box.querySelector('#t'), { linhas: r.linhas.map(l => l.split(' | ')), exportar: 'auditoria', colunas: [{ t: 'Data', v: x => x[0], h: x => dataHoraBR(x[0]) }, { t: 'Usuário', v: x => x[1] }, { t: 'Ação', v: x => x[2] }, { t: 'Detalhe', v: x => x[3] || '' }] });
      break;
    }
    case 'sobre':
      box.innerHTML = `<div class="card"><h2>Loja ERP ${esc(App.versao)}</h2><p>Sistema de gestão para loja de roupas de pequeno porte: caixa, estoque com grade, condicional, trocas, clientes, ofertas, financeiro, DRE e relatórios.</p>
        <p><b>Infinity Technology</b><br>Victor Hugo R. Moura<br>victorhugormoura@gmail.com</p>
        <p class="suave">Este sistema não emite NF-e/NFC-e. O comprovante impresso não tem valor fiscal. Consulte seu contador sobre a obrigatoriedade de emissão de nota no seu regime e estado.</p></div>
        <div id="box-atualizacao"></div>`;
      if (gestora() && !App.celular) await renderAtualizacao(box.querySelector('#box-atualizacao'));
      break;
  }
};

/* ------------------------------------------------------------- atualizações */
async function renderAtualizacao(box) {
  const a = await api('atualizacao');
  const dona = App.papel === 'dona';
  const notas = x => (x && x.notas && x.notas.length ? `<ul>${x.notas.map(t => `<li>${esc(t)}</li>`).join('')}</ul>` : '');
  let situacao;
  if (a.desenvolvimento) situacao = '<div class="caixa-aviso">Cópia de desenvolvimento (pasta com Git): as atualizações automáticas ficam desligadas aqui.</div>';
  else if (a.pronta) situacao = `<div class="caixa-aviso ok">A versão <b>${esc(a.pronta.versao)}</b> já foi baixada, conferida e testada. Ela é instalada sozinha na próxima vez que o sistema for aberto${dona ? ', ou agora pelo botão abaixo' : ''}.${notas(a.pronta)}</div>`;
  else if (a.disponivel && a.disponivel.aviso) situacao = `<div class="caixa-aviso alerta">Versão ${esc(a.disponivel.versao)} disponível: ${esc(a.disponivel.aviso)}</div>`;
  else if (a.disponivel) situacao = `<div class="caixa-aviso">Versão ${esc(a.disponivel.versao)} disponível.${notas(a.disponivel)}</div>`;
  else situacao = `<p>Você está com a versão mais recente${a.ultima_verificacao ? ` (conferido em ${dataHoraBR(a.ultima_verificacao)})` : ''}.</p>`;
  if (a.ultima_instalada && a.ultima_instalada.versao === App.versao && a.ultima_instalada.notas && a.ultima_instalada.notas.length)
    situacao += `<div class="caixa-aviso ok"><b>Novidades da versão ${esc(App.versao)}</b> (instalada em ${dataHoraBR(a.ultima_instalada.quando)}):${notas(a.ultima_instalada)}</div>`;
  box.innerHTML = `<div class="card"><div class="card-cab"><h3>Atualizações</h3>${etiqueta(a.automatica ? 'automáticas' : 'manuais', a.automatica ? 'ok' : 'alerta')}</div>
    ${situacao}${a.erro ? `<div class="caixa-aviso alerta">${esc(a.erro)}</div>` : ''}
    <p class="suave">O sistema procura versões novas sozinho (ao abrir e a cada 12 horas). Cada pacote é assinado digitalmente pelo autor e só é instalado se a assinatura conferir; antes de trocar, a versão nova é testada e a atual fica guardada para voltar atrás se algo der errado. Seus dados não são enviados para lugar nenhum.</p>
    <div class="linha-acoes"><button class="btn" data-click="verificar">Procurar agora</button>
      ${dona && a.pronta && !a.desenvolvimento ? '<button class="btn pri" data-click="instalar">Instalar agora</button>' : ''}<span class="espaco"></span>
      ${dona ? `<label class="check"><input type="checkbox" id="atu-auto" ${a.automatica ? 'checked' : ''}> <span>Instalar automaticamente</span></label>` : ''}</div></div>`;
  ligar(box, {
    verificar: async b => { b.disabled = true; b.textContent = 'Procurando...'; await api('atualizacao/verificar', {}).catch(e => toast(e.message, 'erro')); renderAtualizacao(box); },
    instalar: async () => {
      if (!await confirmar('Instalar a atualização agora? O sistema fecha e abre de novo sozinho em alguns segundos. Termine a venda em andamento antes.', 'Instalar agora')) return;
      await api('atualizacao/instalar', {});
      aguardarReinicio(a.versao);
    }
  });
  const auto = box.querySelector('#atu-auto');
  if (auto) auto.onchange = async () => { await api('atualizacao/config', { automatica: auto.checked }); renderAtualizacao(box); };
}

function aguardarReinicio(versaoAntiga) {
  document.body.insertAdjacentHTML('beforeend', '<div class="tela-reinicio"><div><h2>Atualizando o Loja ERP...</h2><p>A página volta sozinha em alguns segundos. Não feche esta aba.</p></div></div>');
  let tentativas = 0;
  const testar = async () => {
    tentativas++;
    try {
      const e = await (await fetch('/api/estado', { cache: 'no-store' })).json();
      if (e.versao && (e.versao !== versaoAntiga || tentativas > 40)) { location.reload(); return; }
    } catch (err) { /* ainda reiniciando */ }
    if (tentativas === 40) document.querySelector('.tela-reinicio p').textContent = 'Está demorando mais que o normal. Se uma nova aba do Loja ERP abriu, use ela; senão, abra pelo atalho Loja ERP.';
    setTimeout(testar, 1500);
  };
  setTimeout(testar, 3000);
}

/* Mostra uma vez as novidades da versão recém-instalada. */
async function mostrarNovidades() {
  if (App.papel === 'vendedora') return;
  let a;
  try { a = await api('atualizacao'); } catch (e) { return; }
  const u = a.ultima_instalada;
  const chave = 'loja-erp-novidades-vistas';
  let vistas = '';
  try { vistas = localStorage.getItem(chave) || ''; } catch (e) { /* armazenamento indisponível */ }
  if (!u || u.versao !== App.versao || vistas === u.versao) return;
  try { localStorage.setItem(chave, u.versao); } catch (e) { /* ignora */ }
  toast(`O Loja ERP foi atualizado para a versão ${u.versao}. Veja as novidades em Configurações › Sobre.`, 'ok');
}

function exportarColecao(nome) {
  const lista = App.d[nome] || [];
  if (!lista.length) throw new Error('Nada para exportar.');
  if (nome === 'produtos') {
    const linhas = [['SKU', 'Produto', 'Categoria', 'Coleção', 'Marca', 'Fornecedor', 'Tamanho', 'Cor', 'Código de barras', 'Estoque', 'Mínimo', 'Custo', 'Preço', 'Ativo']];
    lista.forEach(p => p.variacoes.forEach(v => linhas.push([p.sku, p.nome, (App.idx.cat[p.categoria_id] || {}).nome || '', (App.idx.col[p.colecao_id] || {}).nome || '', (App.idx.marca[p.marca_id] || {}).nome || '', (App.idx.forn[p.fornecedor_id] || {}).nome || '', v.tamanho, v.cor, v.codigo_barras, v.estoque, n(v.estoque_min), n(p.custo), n(p.preco), p.ativo === false ? 'não' : 'sim'])));
    return baixarCSV('produtos', linhas);
  }
  if (nome === 'vendas') {
    const linhas = [['Nº', 'Data', 'Cliente', 'Situação', 'SKU', 'Produto', 'Tamanho', 'Cor', 'Qtd', 'Preço', 'Desconto', 'Total item', 'Custo', 'Total venda', 'Pagamento']];
    lista.forEach(v => v.itens.forEach(i => linhas.push([v.numero, v.data.replace('T', ' '), v.cliente_nome, v.status, i.sku, i.nome, i.tamanho, i.cor, i.qtd, i.preco_unit, i.desconto, i.total, r2(i.custo_unit * i.qtd), v.total, v.pagamentos.map(p => FORMAS_PAG[p.forma]).join('+')])));
    return baixarCSV('vendas-itens', linhas);
  }
  const chaves = [...new Set(lista.flatMap(o => Object.keys(o)))].filter(k => !['variacoes', 'itens', 'pagamentos', 'feitas', 'movimentos', 'usos', 'escopo', 'faixas'].includes(k));
  baixarCSV(nome, [chaves, ...lista.map(o => chaves.map(k => typeof o[k] === 'object' && o[k] !== null ? JSON.stringify(o[k]) : o[k]))]);
}
