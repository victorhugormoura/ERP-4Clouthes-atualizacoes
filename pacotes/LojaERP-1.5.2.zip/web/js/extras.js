/* Loja ERP — ajuda contextual, aparência/temas, painel personalizável, agenda integrada e balanço.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

/* ================================================================ AJUDA */
const AJUDA_CAMPOS = {
  nome: 'Nome usado nas telas, recibos e relatórios.', sku: 'Código interno do produto. Deixe em branco para o sistema criar (P00001, P00002...).',
  categoria_id: 'Agrupa os produtos nos relatórios e define a margem/markup usados no preço sugerido.',
  colecao_id: 'Estação ou coleção (ex.: Primavera-Verão). Usada para medir sell-through e fazer queima de estoque.',
  marca_id: 'Marca da peça, para filtros e relatórios.', fornecedor_id: 'De quem você compra. Ajuda a comparar desempenho e a recomprar.',
  genero: 'Público da peça.', referencia: 'Código que o fornecedor usa para esta peça — facilita recompras.',
  tags: 'Palavras extras para encontrar a peça na busca do caixa.', localizacao: 'Onde a peça fica na loja ou no estoque (arara, prateleira).',
  ncm: 'Código fiscal de mercadoria. Só é necessário se um dia emitir nota fiscal.', ativo: 'Desmarcado: o cadastro some do caixa e das listas, mas o histórico é mantido.',
  descricao: 'Detalhes como tecido, modelagem e cuidados de lavagem.',
  custo: 'Quanto você paga por peça. Nas entradas, vira custo médio já com frete rateado.', preco: 'Preço de venda na etiqueta.',
  telefone: 'Com DDD. Usado para o WhatsApp. Fica criptografado.', cpf: 'Opcional. Fica criptografado. Recomendado para crediário.',
  nascimento: 'Ativa o desconto de aniversariante e os lembretes do mês. Fica criptografado.', email: 'Fica criptografado.',
  instagram: 'Perfil da cliente, para marcar em posts.', endereco: 'Para entregas. Fica criptografado.', apelido: 'Como a cliente gosta de ser chamada nas mensagens.',
  tam_superior: 'Tamanho que ela veste em blusas — aparece no caixa para agilizar.', tam_inferior: 'Tamanho em calças e saias.', tam_calcado: 'Número do calçado.',
  estilo: 'Estilo predominante, útil para indicar novidades.', preferencias: 'Cores, marcas e peças que ela ama.', como_conheceu: 'Mostra quais canais trazem mais clientes.',
  limite_crediario: 'Valor máximo em aberto no crediário. 0 = sem limite.', aceita_mensagens: 'Consentimento da LGPD para mensagens de promoção. Mensagens de cobrança e condicional podem ser enviadas mesmo assim.',
  observacoes: 'Anotações internas sobre a cliente. Ficam criptografadas.',
  fantasia: 'Nome comercial conhecido.', cnpj: 'CNPJ (ou CPF) — aparece no recibo quando é da loja.', ie: 'Inscrição estadual, se houver.',
  contato: 'Pessoa com quem você fala (vendedor, representante).', whatsapp: 'Número com DDD para abrir conversa pelo sistema.',
  prazo_pagamento: 'Condição usual (ex.: 30/60/90 dias). Lembrete para as entradas.', pedido_minimo: 'Valor mínimo de pedido exigido pelo fornecedor.',
  prazo_entrega: 'Tempo médio para chegar.', frete: 'Quem paga o frete.', desconto_avista: 'Desconto que o fornecedor dá para pagamento à vista.',
  fornece: 'Tipos de peça que o fornecedor oferece.', dados_bancarios: 'Chave Pix ou conta para pagar o fornecedor.', avaliacao: 'Sua nota para o fornecedor (qualidade, prazo, atendimento).',
  valor: 'Valor em reais.', vencimento: 'Data de vencimento. Entra na previsão de caixa nesta data.', competencia: 'Mês em que a despesa/receita "pertence" no DRE (pode ser diferente do vencimento).',
  categoria_id_fin: 'Categoria do plano de contas: define em qual linha do DRE o valor aparece.',
  parcelas: 'Quantidade de parcelas ou de meses a repetir.', modo_parcelas: 'Dividir: o valor total é repartido. Repetir: o valor inteiro se repete todo mês.',
  pago: 'Marque se já foi pago/recebido; a baixa é registrada hoje.', forma: 'Meio de pagamento.', usar_caixa: 'Se for em dinheiro, o valor entra/sai da gaveta e aparece no fechamento do caixa.',
  obs: 'Anotação livre.', dia: 'Dia do mês em que vence.', tipo: 'Escolha o tipo.',
  margem: 'Lucro líquido desejado em % do preço, depois de pagar impostos, taxas e despesas fixas.', markup: 'Multiplicador sobre o custo. Ex.: 2,2 = custo × 2,2.',
  regime: 'MEI paga DAS fixo. Simples Nacional paga um % do faturamento. Na dúvida, pergunte ao contador.',
  aliquota_simples: 'Alíquota efetiva do Simples sobre as vendas (pergunte ao contador). Entra automaticamente no DRE e no preço sugerido.',
  razao_social: 'Nome jurídico da empresa.', cidade: 'Cidade e UF.', mensagem_recibo: 'Texto impresso no fim do comprovante (política de trocas, agradecimento).',
  login: 'Nome de usuário para entrar. Letras minúsculas, sem espaços.', senha: 'Mínimo 10 caracteres para proprietária e gerente, 8 para a equipe. Use letras, números e um símbolo; não use o nome de usuário.', senha2: 'Digite a mesma senha.',
  chave: 'Sua chave Pix cadastrada no banco.', tipo_chave: 'Tipo da chave Pix.', percentual: 'Percentual de desconto.', minimo: 'Valor mínimo da compra para valer.',
  inicio: 'Data em que começa a valer (vazio = já vale).', fim: 'Data em que deixa de valer (vazio = sem fim).', cumulativa: 'Se marcada, soma com outras ofertas em vez de valer só a maior.',
  codigo: 'Código que a cliente informa no caixa.', max_usos: 'Quantas vezes o cupom pode ser usado no total. 0 = ilimitado.',
  prazo: 'Data limite para a cliente devolver ou comprar as peças.', contado: 'Total em dinheiro contado na gaveta.', valor_pago: 'Valor efetivamente pago/recebido. Diferenças viram juros ou desconto no DRE.',
  data: 'Data do registro.', recorrencia: 'Com que frequência a tarefa se repete.', titulo: 'Descrição curta da tarefa.',
  aquisicao: 'Data de compra do bem.', vida_util_meses: 'Por quantos meses o bem será depreciado.',
  saldo_inicial: 'Quanto havia somando gaveta + banco nesta data.', data_saldo_inicial: 'Data de referência do saldo inicial.',
  formato: 'Tipo de papel da etiqueta.', mostrarPreco: 'Imprime o preço de venda.', promo: 'Mostra o preço "de/por" quando há promoção ativa para a peça.',
  qtd: 'Quantidade.', exemplo: 'Cria produtos, clientes e vendas fictícias para você testar. Remova depois em Configurações > Backup e dados.',
  despesas_fixas_pct: 'Quanto as despesas fixas representam do faturamento. Ex.: R$ 6.000 de despesas ÷ R$ 30.000 de vendas = 20%.',
  taxa_cartao_media: 'Média das taxas da maquininha considerando o seu mix de vendas.', comissao: 'Comissão paga sobre vendas (0 se a dona vende sozinha).',
  arredondamento: 'Preços terminados em ,90 ou ,99 vendem melhor.', metodo: 'Margem: considera todos os custos. Markup: só multiplica o custo.',
  margem_padrao: 'Margem usada quando a categoria não tem uma própria.', markup_padrao: 'Markup usado quando a categoria não tem um próprio.'
};

const AJUDA_PAGINAS = {
  painel: ['Painel', 'Resumo do dia e do mês. Clique em <b>Personalizar</b> para escolher quais blocos e indicadores aparecem e em que ordem. Os indicadores são clicáveis e levam ao detalhe.'],
  pdv: ['Vender (caixa)', 'Leia o código de barras ou busque pelo nome. Identifique a cliente para aplicar aniversário, primeira compra e cashback. As ofertas ativas entram sozinhas. <kbd>F2</kbd> finaliza. Combine formas de pagamento (ex.: parte Pix, parte cartão). Com Pix, o botão <b>QR</b> gera o código com o valor.'],
  vendas: ['Vendas', 'Histórico com filtros. Clique numa venda para reimprimir, enviar por WhatsApp, registrar troca ou cancelar (as peças voltam ao estoque).'],
  condicional: ['Condicional', 'A cliente leva peças para provar em casa. As peças saem do estoque até o retorno. No retorno, marque o que ela ficou: o resto volta ao estoque e o escolhido vai para o caixa.'],
  trocas: ['Trocas e vales', 'Registre devoluções a partir do número da venda. O valor pode virar <b>vale-troca</b> ou ser devolvido em dinheiro/Pix/estorno. Aqui também se vende o <b>vale-presente</b>. Cada vale tem código, saldo e validade (uma data ou "sem prazo"), que a proprietária ou a gerente pode mudar depois.'],
  caixa: ['Caixa', 'Controla o dinheiro em espécie da gaveta. Abra no início do dia, registre sangrias e feche contando o dinheiro: o sistema mostra a diferença.'],
  produtos: ['Produtos', 'Cadastro com grade de tamanhos e cores. Cada variação tem estoque, mínimo e código de barras próprios. O preço sugerido considera custo, impostos, taxas, despesas fixas e a margem da categoria.'],
  produto: ['Produto', 'Escolha a grade e as cores e clique em <b>Gerar variações</b>. O estoque inicial só pode ser informado em variações novas; depois, use Entradas e Ajustes para manter o histórico.'],
  estoque: ['Estoque', 'Visão por variação com filtros de estoque baixo, zerado e parado. Cobertura = quantos dias o estoque dura no ritmo atual. Giro = quantas vezes o estoque "gira" no ano.'],
  entradas: ['Entradas', 'Cada compra de mercadoria. O estorno retira as peças e cancela as parcelas pendentes.'],
  entrada: ['Nova entrada', 'Adicione os produtos da nota, informe custo e quantidade por variação. Frete e despesas são rateados no custo. Escolha se a compra foi à vista ou a prazo: as parcelas viram contas a pagar.'],
  movimentacoes: ['Movimentações', 'Tudo o que mexeu no estoque, com data, usuária e saldo após a operação (kardex).'],
  inventario: ['Inventário', 'Conte as peças e digite o número encontrado. Só as diferenças geram ajuste. Faça uma categoria por mês (inventário rotativo).'],
  etiquetas: ['Etiquetas', 'Imprime etiquetas com código de barras em impressora térmica (50×30 mm) ou folha A4 Pimaco. Na impressão, escolha "Sem margens" e escala 100%.'],
  clientes: ['Clientes', 'Cadastro com tamanhos, estilo e consentimento LGPD. Os dados pessoais ficam criptografados. Use os filtros (aniversariantes, em risco, inativas) para campanhas pelo WhatsApp.'],
  fornecedores: ['Fornecedores', 'Contatos, condições comerciais, avaliação, histórico de compras e valores a pagar de cada fornecedor.'],
  ofertas: ['Ofertas e cupons', 'Promoções aplicadas automaticamente no caixa: % por categoria/coleção, leve X pague Y, progressivo, valor mínimo, aniversariante, primeira compra, à vista e cupons. Datas comemorativas já vêm agendadas.'],
  servicos: ['Serviços', 'Itens sem estoque vendidos no caixa: ajustes de costura, embalagem para presente, entrega.'],
  pix: ['Pix', 'Gera QR Code Pix no padrão do Banco Central, com ou sem valor. Baixe em JPG ou SVG para imprimir ou enviar.'],
  contas: ['Contas a pagar e receber', 'Lançamentos manuais, despesas fixas, parcelas de compras, cartões e crediário. Clique em Pagar/Receber para dar baixa. A diferença entre valor e valor pago vira juros ou desconto no DRE.'],
  fluxo: ['Previsão de caixa', 'Saldo projetado semana a semana com o que já está lançado. Ative a previsão de vendas para incluir a média diária recente.'],
  dre: ['DRE e indicadores', 'Demonstrativo de resultado por competência: receita, CMV, lucro bruto, despesas, <b>EBITDA</b>, depreciação e lucro líquido, mês a mês. Ponto de equilíbrio = faturamento mínimo para não ter prejuízo.'],
  balanco: ['Balanço patrimonial', 'Fotografia do que a loja tem (caixa, recebíveis, estoque, bens) e do que deve (fornecedores, contas, vales e cashback a honrar). Patrimônio líquido = diferença.'],
  metas: ['Metas', 'Meta de faturamento por mês, comparada ao realizado, ao ponto de equilíbrio e ao mesmo mês do ano anterior.'],
  recorrentes: ['Despesas fixas', 'Aluguel, contas, pró-labore... O sistema gera as contas a pagar do mês atual e do próximo automaticamente.'],
  ativos: ['Bens e depreciação', 'Móveis, equipamentos e reformas. A depreciação entra no DRE entre o EBITDA e o lucro operacional.'],
  relatorios: ['Relatórios', 'Análises por período: categoria, curva ABC, tamanhos e cores, formas de pagamento, horários, clientes, coleções, fornecedores, estoque parado e promoções. Todas as tabelas exportam para Excel (CSV).'],
  agenda: ['Agenda', 'Calendário com tarefas, contas, condicionais, aniversários e promoções. Clique num dia para ver detalhes e adicionar ao Google Agenda. Exporte tudo em .ics para Google, Outlook ou celular.'],
  cadastros: ['Cadastros auxiliares', 'Categorias (com margem e markup), marcas, coleções e plano de contas (onde cada despesa entra no DRE).'],
  config: ['Configurações', 'Dados da loja, impostos, taxas, precificação, Pix, aparência, mensagens, usuários e permissões, backup e auditoria. Em "Backup e dados" você vê se os dados estão protegidos, faz backup na hora e restaura uma cópia em 1 clique.'],
  celular: ['Usar no celular', 'Ligue o acesso e toque em <b>Conectar um celular</b>: um QR Code aparece. Com o celular no mesmo Wi-Fi, aponte a câmera para ele. O aviso de "conexão não particular" é esperado (o endereço é deste computador): toque em <b>Avançado</b> e em <b>Ir para… (não seguro)</b>. Confira o código de 4 números que aparece no celular e aqui, clique em <b>Permitir</b> e cada pessoa entra com o próprio usuário e senha. Celular perdido ou trocado: desconecte-o aqui.'],
  mei: ['Modo MEI', 'Acompanha o limite de faturamento do ano (proporcional no ano de abertura), avisa quando passar de 80%, gera o relatório mensal de receitas brutas pronto para imprimir e lista as notas fiscais que as clientes pediram.']
};

const GUIAS = [
  ['Usar o celular como leitor e terminal', ['No computador: menu "Usar no celular" > "Ligar acesso pelo celular" > "Conectar um celular".', 'Com o celular no mesmo Wi-Fi da loja, aponte a câmera para o QR Code e toque no link.', 'Apareceu "Sua conexão não é particular"? É normal: toque em "Avançado" e depois em "Ir para … (não seguro)". No iPhone: "Mostrar detalhes" > "visitar este site".', 'O celular mostra um código de 4 números: confira no computador e clique em "Permitir".', 'Entre com seu usuário e senha. Na tela do celular: "Consultar peça" lê a etiqueta; no caixa, o botão "Câmera" lê as peças.', 'Dica: no menu do navegador do celular, toque em "Adicionar à tela inicial".']],
  ['Lançar uma conta pelo boleto ou Pix', ['Vá em "Contas a pagar/receber" e clique em "Ler boleto ou Pix" (no celular: "Conta a pagar").', 'Aponte a câmera para o código de barras do boleto (deite o celular) ou para o QR Code Pix. Sem câmera, cole a linha digitável ou o "Pix copia e cola".', 'Valor, vencimento e descrição já vêm preenchidos. Escolha a categoria e salve.', 'O código fica guardado na observação para você pagar depois no app do banco.']],
  ['Atualizar o Loja ERP', ['Não precisa fazer nada: o sistema procura versões novas sozinho e instala na próxima vez que for aberto.', 'Para ver a versão e as novidades: Configurações > Sobre.', 'A proprietária pode clicar em "Instalar agora" quando houver uma versão pronta (termine a venda em andamento antes).', 'Se uma versão nova não abrir, o sistema volta sozinho para a anterior.']],
  ['Fazer uma venda', ['Clique em "Vender (caixa)".', 'Leia o código de barras da etiqueta ou digite o nome da peça e escolha o tamanho/cor.', 'Clique em "Identificar cliente" e escolha a cliente (assim ela ganha cashback e aparece nos aniversários).', 'Clique em "Finalizar" (ou aperte F2).', 'Escolha a forma de pagamento (pode combinar, ex.: parte no Pix, parte no cartão) e clique em "Confirmar venda".', 'Imprima o comprovante ou envie pelo WhatsApp.']],
  ['Desfazer uma venda errada', ['Logo depois de vender, aparece um aviso no canto da tela com o botão "Desfazer" — clique nele.', 'Se o aviso já sumiu: vá em "Vendas", clique na venda e em "Cancelar venda".', 'As peças voltam para o estoque automaticamente.']],
  ['Receber no Pix com QR Code', ['Na hora de pagar, clique em "+ Pix".', 'Clique em "QR Code Pix": o código já sai com o valor da venda.', 'A cliente lê com o celular. Confira no aplicativo do banco se o dinheiro entrou.', 'Clique em "Fechar" e depois em "Confirmar venda".']],
  ['Dar desconto ou usar cupom', ['No caixa, digite o código no campo "Cupom" (ex.: BEMVINDA10).', 'Para desconto livre, use "Desconto manual" em R$ ou %.', 'Para desconto em uma peça só, clique em "desconto" embaixo do valor dela.', 'Promoções cadastradas (aniversário, leve 3 pague 2...) entram sozinhas.']],
  ['Vender fiado e receber as parcelas', ['A cliente precisa estar identificada na venda.', 'No pagamento, escolha "+ Fiado (crediário)", o número de parcelas e o 1º vencimento.', 'Imprima o comprovante: ele traz as parcelas e o espaço para assinatura.', 'Para receber: abra a ficha da cliente ou "Contas a pagar/receber" › "Contas a receber" e clique em "Receber".', 'Para cobrar com educação: botão "Cobrar" abre o WhatsApp com a mensagem pronta.']],
  ['Fazer uma malinha (condicional)', ['No caixa, adicione as peças e identifique a cliente.', 'Clique em "Condicional", escolha a data de devolução e imprima o termo para ela assinar.', 'Quando ela voltar: menu "Condicional (malinha)" › "Retorno".', 'Marque as peças que ela vai ficar. As outras voltam ao estoque e as escolhidas vão para o caixa.']],
  ['Trocar uma peça', ['Menu "Trocas e vales" › "Nova troca / devolução".', 'Digite o número da venda (está no comprovante) e informe quantas peças voltam.', 'Escolha "Gerar vale-troca", confira a validade (ou marque "Sem prazo de validade") e imprima o vale com o código.', 'A cliente usa o vale no caixa, na forma de pagamento "Vale (troca ou presente)".']],
  ['Vender um vale-presente', ['No caixa, botão "Vale-presente" (ou menu "Trocas e vales" › "Vender vale-presente").', 'Informe o valor, como foi pago, para quem é e, se quiser, uma mensagem.', 'Escolha a validade (30 dias, 90 dias, 6 meses, 1 ano, outra data ou sem prazo) e clique em "Gerar vale".', 'Imprima o vale. Quem ganhou usa no caixa em "Vale (troca ou presente)", numa compra ou em várias até acabar o saldo.', 'O valor só conta como venda quando o vale é usado. Para devolver o dinheiro de um vale que não foi usado: "Trocas e vales" › "Vales" › "Cancelar".']],
  ['Cadastrar um produto', ['Menu "Produtos" › "Novo produto".', 'Preencha nome, categoria, custo (quanto você pagou) e preço — o sistema sugere um preço justo.', 'Escolha a grade de tamanhos, digite as cores e clique em "Gerar variações".', 'Informe quantas peças tem de cada tamanho/cor em "estoque inicial" e salve.', 'Clique em "Etiquetas" para imprimir as etiquetas com código de barras.']],
  ['Lançar mercadoria que chegou', ['Menu "Entradas (compras)" › "Nova entrada".', 'Escolha o fornecedor, busque cada produto da nota e informe a quantidade por tamanho/cor.', 'Informe frete e outras despesas: elas entram no custo de cada peça.', 'Diga se foi à vista ou parcelado (as parcelas viram contas a pagar) e clique em "Lançar entrada".']],
  ['Imprimir etiquetas', ['Menu "Etiquetas", busque as peças e ajuste as quantidades.', 'Escolha rolo térmico 50×30 mm ou folha A4 Pimaco.', 'Clique em "Imprimir etiquetas". Na janela de impressão, escolha a impressora, margens "Nenhuma" e escala 100%.']],
  ['Abrir e fechar o caixa', ['De manhã: menu "Caixa", informe o troco na gaveta e clique em "Abrir caixa".', 'Durante o dia: retirada de dinheiro = "Sangria"; reforço de troco = "Suprimento".', 'No fim do dia: conte o dinheiro da gaveta, clique em "Fechar caixa" e informe o valor. O sistema mostra se sobrou ou faltou.']],
  ['Mandar mensagem para clientes', ['Menu "Clientes": use os filtros "Aniversariantes do mês", "Em risco" ou "Inativas".', 'Clique em "WhatsApp" na cliente, escolha o modelo de mensagem e envie.', 'Para várias: botão "Campanha WhatsApp" abre uma conversa por vez com a mensagem pronta.']],
  ['Fazer e restaurar backup', ['O backup é feito sozinho todo dia, compactado e criptografado.', 'Para conferir: o selo no topo da tela fica verde ("Dados protegidos"). Clique nele para ver detalhes.', 'Para restaurar: Configurações › Backup e dados › "Restaurar" na data desejada › digite sua senha.', 'Os dados atuais nunca são apagados: ficam guardados ao lado, numa pasta "dados-antes-da-restauracao".']],
  ['MEI: relatório mensal de receitas', ['Menu "Modo MEI" (aparece quando o regime da loja é MEI).', 'Em "Relatório mensal das receitas brutas", escolha o mês e clique em "Imprimir".', 'Assine e guarde junto com as notas de compra do mês.']]
];
function guiasHTML(filtro = '') {
  const f = semAcento(filtro);
  const lista = GUIAS.filter(([t, passos]) => !f || semAcento(t + ' ' + passos.join(' ')).includes(f));
  return lista.map(([t, passos]) => `<details class="guia"${f ? ' open' : ''}><summary>${esc(t)}</summary><ol>${passos.map(p => `<li>${esc(p)}</li>`).join('')}</ol></details>`).join('')
    || '<p class="suave">Nenhum guia encontrado.</p>';
}

function abrirAjuda() {
  const p = document.getElementById('painel-ajuda');
  const [titulo, texto] = AJUDA_PAGINAS[App.rotaAtual] || ['Ajuda', 'Passe o mouse no símbolo <b>?</b> ao lado de cada campo para ver para que ele serve.'];
  p.innerHTML = `<h2>${esc(titulo)} <button class="btn-icone" data-click="fechar" title="Fechar">&times;</button></h2><p>${texto}</p>
    <h4>Como fazer</h4><input type="search" id="busca-guia" placeholder="Ex.: troca, fiado, etiqueta, Pix..."><div id="lista-guias" style="margin-top:8px">${guiasHTML()}</div>
    <h4>Atalhos</h4><p><kbd>F1</kbd> abre esta ajuda · <kbd>F2</kbd> finaliza a venda no caixa · <kbd>Esc</kbd> fecha janelas · <kbd>Enter</kbd> na busca adiciona o produto lido.</p>
    <h4>Primeiros passos</h4><ol><li>Revise os dados da loja, impostos e taxas da maquininha em Configurações.</li><li>Cadastre despesas fixas e a meta do mês.</li>
      <li>Cadastre produtos (ou lance uma entrada de mercadorias) e imprima as etiquetas.</li><li>Abra o caixa e venda!</li><li>No fim do dia, feche o caixa.</li></ol>
    <h4>Boas práticas</h4><ul><li>Deixe a pasta do sistema no Google Drive/Dropbox e copie um backup para um pendrive todo mês.</li>
      <li>Não abra o sistema em dois computadores ao mesmo tempo com a mesma pasta.</li><li>Guarde o código de recuperação longe do computador.</li>
      <li>Identifique a cliente em toda venda: é o que alimenta fidelidade, aniversários e reativação.</li><li>Sempre lance entradas de mercadoria — o custo médio e o DRE dependem disso.</li></ul>
    <h4>Sobre</h4><p class="suave">Loja ERP ${esc(App.versao)} — ${esc(App.credito)}</p>`;
  ligar(p, { fechar: fecharAjuda });
  p.querySelector('#busca-guia').oninput = e => { p.querySelector('#lista-guias').innerHTML = guiasHTML(e.target.value); };
  p.classList.add('aberto');
}
function fecharAjuda() { document.getElementById('painel-ajuda').classList.remove('aberto'); }
document.addEventListener('keydown', e => {
  if (e.key === 'F1') { e.preventDefault(); const p = document.getElementById('painel-ajuda'); if (p.classList.contains('aberto')) fecharAjuda(); else abrirAjuda(); }
  if (e.key === 'Escape') fecharAjuda();
});

/* ============================================================ APARÊNCIA */
const TEMAS = {
  claro: ['Ameixa (padrão)', '#7a3e5c', '#f6f3f0', '#2b2228'], escuro: ['Escuro', '#c98bab', '#17181b', '#121316'], rosa: ['Rosa', '#d14d8a', '#fff5f9', '#5c1e3d'],
  marrom: ['Marrom / café', '#8a5a3b', '#f7f2ec', '#3b2a1f'], verde: ['Verde', '#2f7d62', '#f3f7f5', '#1d3229'], azul: ['Azul', '#2f5d9c', '#f3f6fa', '#1b2638'], pb: ['Preto e branco', '#222222', '#f4f4f4', '#111111']
};
const FONTES = {
  sistema: ['Padrão do sistema', '"Segoe UI", system-ui, -apple-system, Roboto, Arial, sans-serif'], arial: ['Arial', 'Arial, Helvetica, sans-serif'],
  verdana: ['Verdana (mais legível)', 'Verdana, Geneva, sans-serif'], trebuchet: ['Trebuchet', '"Trebuchet MS", sans-serif'],
  georgia: ['Georgia (serifada)', 'Georgia, "Times New Roman", serif'], tahoma: ['Tahoma', 'Tahoma, Geneva, sans-serif'], mono: ['Monoespaçada', 'Consolas, "Courier New", monospace']
};
const APARENCIA_PADRAO = { tema: 'claro', cor: '', fonte: 'sistema', tamanho: 14, densidade: 1, menu: 'padrao', cantos: 'padrao', largura_menu: 232 };

function misturar(hex, alvo, t) {
  const h = x => parseInt(x, 16);
  const a = [h(hex.slice(1, 3)), h(hex.slice(3, 5)), h(hex.slice(5, 7))], b = [h(alvo.slice(1, 3)), h(alvo.slice(3, 5)), h(alvo.slice(5, 7))];
  return '#' + a.map((v, i) => Math.round(v + (b[i] - v) * t).toString(16).padStart(2, '0')).join('');
}
function aplicarAparencia(ap) {
  const a = { ...APARENCIA_PADRAO, ...(ap || {}) };
  const b = document.body, r = document.documentElement.style;
  b.dataset.tema = a.tema === 'claro' ? '' : a.tema;
  b.dataset.menu = a.menu === 'padrao' ? '' : a.menu;
  b.dataset.cantos = a.cantos === 'padrao' ? '' : a.cantos;
  r.setProperty('--fonte', (FONTES[a.fonte] || FONTES.sistema)[1]);
  r.setProperty('--tam', (+a.tamanho || 14) + 'px');
  r.setProperty('--dens', +a.densidade || 1);
  r.setProperty('--menu-larg', (+a.largura_menu || 232) + 'px');
  ['--pri', '--pri-esc', '--pri-cla'].forEach(v => b.style.removeProperty(v));
  if (/^#[0-9a-f]{6}$/i.test(a.cor || '')) {
    const escuro = a.tema === 'escuro';
    b.style.setProperty('--pri', a.cor);
    b.style.setProperty('--pri-esc', misturar(a.cor, escuro ? '#ffffff' : '#000000', 0.22));
    b.style.setProperty('--pri-cla', misturar(a.cor, escuro ? '#000000' : '#ffffff', escuro ? 0.7 : 0.86));
  }
  try { localStorage.setItem('lojaerp-aparencia', JSON.stringify(a)); } catch (e) { /* armazenamento indisponível */ }
}
function aparenciaGuardada() { try { return JSON.parse(localStorage.getItem('lojaerp-aparencia') || 'null'); } catch (e) { return null; } }

function seletorTema(atual, acao = 'tema') {
  return `<div class="amostra-tema">${Object.entries(TEMAS).map(([k, [nome, pri, fundo, menu]]) => `<button type="button" class="${k === atual ? 'ativo' : ''}" data-click="${acao}" data-k="${k}">
    <span class="cores"><i style="background:${menu}"></i><i style="background:${fundo}"></i><i style="background:${pri}"></i></span><small>${esc(nome)}</small></button>`).join('')}</div>`;
}

function renderAparencia(box) {
  const a = { ...APARENCIA_PADRAO, ...(App.cfg.aparencia || {}) };
  const campos = [
    { n: 'cor', r: 'Cor principal personalizada', t: 'color', w: 4, aj: 'Substitui a cor de destaque do tema. Use "Restaurar" para voltar.' },
    { n: 'fonte', r: 'Fonte', t: 'select', w: 4, vazio: false, op: Object.entries(FONTES).map(([k, [nm]]) => [k, nm]) },
    { n: 'tamanho', r: 'Tamanho da letra', t: 'select', w: 4, vazio: false, op: [[12, 'Pequeno'], [13, 'Médio-pequeno'], [14, 'Normal'], [15, 'Médio-grande'], [16, 'Grande'], [18, 'Muito grande']] },
    { n: 'densidade', r: 'Espaçamento', t: 'select', w: 4, vazio: false, op: [[0.75, 'Compacto'], [1, 'Normal'], [1.25, 'Confortável']] },
    { n: 'menu', r: 'Menu lateral', t: 'select', w: 4, vazio: false, op: [['padrao', 'Do tema'], ['claro', 'Claro'], ['cor', 'Na cor principal']] },
    { n: 'cantos', r: 'Cantos', t: 'select', w: 4, vazio: false, op: [['padrao', 'Levemente arredondados'], ['redondos', 'Bem arredondados'], ['retos', 'Retos']] },
    { n: 'largura_menu', r: 'Largura do menu', t: 'select', w: 4, vazio: false, op: [[200, 'Estreito'], [232, 'Normal'], [270, 'Largo']] }
  ];
  box.innerHTML = `<div class="card"><h3>Tema</h3>${seletorTema(a.tema)}</div>
    <div class="card"><h3>Personalização</h3><p class="suave">As mudanças aparecem na hora. Cada usuária tem a sua aparência.</p><div id="f-ap">${formHTML(campos, { ...a, cor: a.cor || TEMAS[a.tema][1] })}</div>
    <div class="linha-acoes" style="margin-top:14px"><button class="btn" data-click="restaurar">Restaurar padrão</button><span class="espaco"></span><button class="btn pri" data-click="salvar">Salvar aparência</button></div></div>`;
  const ler = () => { const f = lerForm(box.querySelector('#f-ap'), campos); f.cor = f.cor && f.cor.toLowerCase() !== TEMAS[a.tema][1] ? f.cor : ''; return f; };
  box.querySelectorAll('#f-ap input, #f-ap select').forEach(e => e.addEventListener('input', () => { Object.assign(a, ler()); aplicarAparencia(a); }));
  ligar(box, {
    tema: b => { a.tema = b.dataset.k; a.cor = ''; aplicarAparencia(a); App.cfg.aparencia = a; renderAparencia(box); },
    restaurar: () => { Object.assign(a, APARENCIA_PADRAO); aplicarAparencia(a); App.cfg.aparencia = a; renderAparencia(box); },
    salvar: async () => { Object.assign(a, ler()); await api('config', { config: { aparencia: a } }); App.cfg.aparencia = a; aplicarAparencia(a); toast('Aparência salva.', 'ok'); }
  });
}

/* ======================================================= PAINEL INICIAL */
const WIDGETS = {
  primeiros: ['Primeiros passos', 'cheio'], hoje: ['Hoje na loja', 'cheio'], kpis: ['Indicadores', 'cheio'], atalhos: ['Atalhos rápidos', 'cheio'], grafico: ['Gráfico de faturamento', 'largo'], avisos: ['Avisos e alertas', ''],
  meta: ['Meta do mês', ''], tarefas: ['Tarefas de hoje', ''], top: ['Mais vendidos', ''], categorias: ['Vendas por categoria', ''], pagamentos: ['Formas de pagamento', ''],
  aniversariantes: ['Aniversariantes', ''], condicionais: ['Condicionais em aberto', ''], vencimentos: ['Próximos vencimentos', ''], estoque_baixo: ['Estoque baixo', '']
};
const KPIS = {
  hoje: 'Vendas hoje', mes: 'Faturamento do mês', ticket: 'Ticket médio', pa: 'Peças por atendimento', lucro: 'Lucro bruto do mês', ebitda: 'EBITDA do mês',
  estoque: 'Valor do estoque', saldo: 'Saldo financeiro', receber7: 'A receber (7 dias)', pagar7: 'A pagar (7 dias)', clientes: 'Clientes atendidas no mês', caixa: 'Dinheiro na gaveta'
};
const KPIS_RESTRITOS = ['lucro', 'ebitda', 'estoque', 'saldo', 'receber7', 'pagar7'];
const PAINEL_PADRAO = { versao: 2, widgets: ['primeiros', 'hoje', 'atalhos', 'kpis', 'grafico', 'avisos', 'meta', 'top', 'aniversariantes', 'condicionais', 'vencimentos'], kpis: ['hoje', 'mes', 'ticket', 'lucro', 'estoque', 'saldo', 'receber7', 'pagar7'], periodo: 30 };

/* Itens do bloco "Hoje na loja": [situação (feito|pendente|atencao), texto, link]. */
function itensHoje() {
  const dia = hojeISO(), hora = new Date().getHours(), itens = [];
  const cx = App.d.caixa.find(c => c.status === 'aberto');
  itens.push(cx ? ['feito', `Caixa aberto às ${cx.aberto_em.slice(11, 16)}`, '#/caixa'] : ['pendente', 'Abrir o caixa (informe o troco da gaveta)', '#/caixa']);
  const conds = App.d.condicionais.filter(c => c.status === 'aberto' && c.prazo <= dia);
  itens.push(conds.length ? ['atencao', `${conds.length} malinha(s) com devolução hoje ou atrasada: ${conds.map(c => c.cliente_nome.split(' ')[0]).join(', ')}`, '#/condicional'] : ['feito', 'Nenhuma malinha vencendo hoje', '#/condicional']);
  const fiado = App.d.financeiro.filter(f => f.status === 'pendente' && f.forma === 'crediario' && f.vencimento <= dia);
  itens.push(fiado.length ? ['atencao', `${fiado.length} parcela(s) de fiado vencendo ou atrasada(s): ${moeda(soma(fiado, f => f.valor))}`, gestora() ? '#/contas?aba=receber' : '#/clientes?filtro=crediario'] : ['feito', 'Nenhum fiado vencendo hoje', '']);
  if (gestora()) {
    const pagar = App.d.financeiro.filter(f => f.status === 'pendente' && f.tipo === 'pagar' && f.vencimento <= dia);
    itens.push(pagar.length ? ['atencao', `${pagar.length} conta(s) a pagar hoje ou atrasada(s): ${moeda(soma(pagar, f => f.valor))}`, '#/contas?aba=pagar'] : ['feito', 'Nenhuma conta para pagar hoje', '']);
  }
  const aniv = App.d.clientes.filter(c => c.ativo !== false && c.nascimento && c.nascimento.slice(5) === dia.slice(5));
  if (aniv.length) itens.push(['atencao', `Aniversário hoje: ${aniv.map(c => c.nome).join(', ')} — mande uma mensagem`, '#/clientes?filtro=aniversario']);
  const tp = tarefasPendentes(dia);
  const pend = tp.hoje.length + tp.atrasadas.length;
  itens.push(pend ? ['pendente', `${pend} tarefa(s) da agenda para hoje`, '#/agenda'] : ['feito', 'Tarefas da agenda em dia', '#/agenda']);
  if (cx && hora >= 17) itens.push(['atencao', 'Fim do dia: conte o dinheiro e feche o caixa', '#/caixa']);
  if (gestora() && App.saude) itens.push(App.saude.nivel === 'ok' ? ['feito', 'Backup de hoje feito e conferido', '#/config?aba=dados'] : ['atencao', App.saude.mensagens[0] || 'Verifique o backup', '#/config?aba=dados']);
  return itens;
}

/* Itens do bloco "Primeiros passos": [id, texto, concluído, link]. */
function passosIniciais(conf) {
  const real = l => (l || []).some(x => !x.exemplo);
  const manual = id => (conf.feitos || []).includes(id);
  const l = App.cfg.loja || {};
  return [
    ['loja', 'Completar os dados da loja (telefone e endereço saem no recibo)', !!((l.telefone || l.whatsapp) && l.endereco), '#/config?aba=loja'],
    ['pix', 'Cadastrar a chave Pix para gerar QR Code no caixa', !!(App.cfg.pix || {}).chave, '#/config?aba=pix'],
    ['taxas', 'Conferir as taxas da sua maquininha de cartão', manual('taxas'), '#/config?aba=fiscal'],
    ['exemplo', 'Remover os dados de exemplo e começar de verdade', !Object.values(App.d).some(x => Array.isArray(x) && x.some(y => y.exemplo)), '#/config?aba=dados'],
    ['produto', 'Cadastrar seu primeiro produto (com tamanhos e cores)', real(App.d.produtos), '#/produto/novo'],
    ['etiquetas', 'Imprimir as etiquetas com código de barras', manual('etiquetas'), '#/etiquetas'],
    ['despesas', 'Informar as despesas fixas (aluguel, luz, pró-labore...)', App.d.recorrentes.some(r => r.ativo && n(r.valor) > 0 && !r.exemplo), '#/recorrentes'],
    ['meta', 'Definir a meta de vendas do mês', !!n((App.cfg.metas || {})[mesAtual()]), '#/metas'],
    ['cliente', 'Cadastrar a primeira cliente', real(App.d.clientes), '#/clientes'],
    ['caixa', 'Abrir o caixa pela primeira vez', App.d.caixa.length > 0, '#/caixa'],
    ['venda', 'Fazer a primeira venda', real(App.d.vendas), '#/pdv'],
    ['nuvem', 'Deixar os dados com cópia na nuvem (Google Drive/OneDrive)', !!(App.saude && App.saude.nuvem), '#/config?aba=dados']
  ];
}

function gestora() { return App.papel === 'dona' || App.papel === 'gerente'; }

App.paginas.painel = async el => {
  const conf = { ...PAINEL_PADRAO, ...(App.cfg.painel || {}) };
  if (!conf.versao) { conf.widgets = ['primeiros', 'hoje', ...conf.widgets.filter(w => w !== 'tarefas')]; conf.versao = 2; }
  const dia = hojeISO(), mes = dia.slice(0, 7);
  const vMes = vendasPeriodo(mes + '-01', dia);
  const rHoje = resumoVendas(vendasPeriodo(dia, dia)), rMes = resumoVendas(vMes);
  const mesAnt = somarMeses(mes, -1), diaAnt = Math.min(+dia.slice(8), +ultimoDiaMes(mesAnt).slice(8));
  const rAnt = resumoVendas(vendasPeriodo(mesAnt + '-01', `${mesAnt}-${pad(diaAnt)}`));
  const meta = n((App.cfg.metas || {})[mes]);
  const diasMes = +ultimoDiaMes(mes).slice(8), projecao = rMes.fat / +dia.slice(8) * diasMes;
  const fin = App.d.financeiro.filter(f => f.status === 'pendente'), ate7 = somarDias(dia, 7);
  const variacao = rAnt.fat ? (rMes.fat / rAnt.fat - 1) * 100 : 0;

  const kpiDef = {
    hoje: () => [moeda(rHoje.fat), `${rHoje.n} venda(s) · ${rHoje.pecas} peça(s)`, '#/vendas'],
    mes: () => [moeda(rMes.fat), rAnt.fat ? `<span class="${variacao >= 0 ? 'positivo' : 'negativo'}">${variacao >= 0 ? '+' : ''}${pct(variacao)}</span> vs. mês anterior` : 'Projeção ' + moeda(projecao), '#/relatorios'],
    ticket: () => [moeda(rMes.ticket), 'no mês', '#/relatorios'], pa: () => [numBR(rMes.pa, 2), 'peças por venda no mês', '#/relatorios'],
    lucro: () => [moeda(rMes.lucroBruto), 'Margem bruta ' + pct(rMes.margem), '#/dre'],
    ebitda: () => { const d = dre(mes); return [`<span class="${d.ebitda < 0 ? 'negativo' : ''}">${moeda(d.ebitda)}</span>`, 'Margem ' + pct(d.margemEbitda), '#/dre']; },
    estoque: () => { const e = valorEstoque(); return [moeda(e.custo), `${numBR(e.pecas)} peças · ${moeda(e.venda)} na etiqueta`, '#/estoque']; },
    saldo: () => [moeda(saldoAtual()), 'gaveta + banco (estimado)', '#/fluxo'],
    receber7: () => [moeda(soma(fin.filter(f => f.tipo === 'receber' && f.vencimento <= ate7), f => f.liquido)), 'cartões, crediário e outros', '#/contas?aba=receber'],
    pagar7: () => [moeda(soma(fin.filter(f => f.tipo === 'pagar' && f.vencimento <= ate7), f => f.valor)), 'inclui vencidas', '#/contas?aba=pagar'],
    clientes: () => [numBR(new Set(vMes.filter(v => v.cliente_id).map(v => v.cliente_id)).size), `${pct(rMes.n ? vMes.filter(v => v.cliente_id).length / rMes.n * 100 : 0, 0)} das vendas identificadas`, '#/clientes'],
    caixa: () => { const c = App.d.caixa.find(x => x.status === 'aberto'); return [c ? 'Aberto' : 'Fechado', c ? 'desde ' + dataHoraBR(c.aberto_em) : 'Abra no início do dia', '#/caixa']; }
  };
  const serie = [];
  for (let k = conf.periodo - 1; k >= 0; k--) { const d = somarDias(dia, -k); serie.push({ rotulo: dataBR(d), curto: d.slice(8) + '/' + d.slice(5, 7), valor: faturamentoDia(d) }); }
  const card = (titulo, corpo, link) => `<div class="card"><div class="card-cab"><h3>${titulo}</h3>${link ? `<a class="btn pequeno" href="${link}">Ver</a>` : ''}</div>${corpo}</div>`;
  const tp = tarefasPendentes(dia);
  const passos = passosIniciais(conf);
  const feitos = passos.filter(x => x[2]).length;
  const render = {
    primeiros: () => !gestora() || conf.primeiros_ocultos || feitos === passos.length ? '' : `<div class="card"><div class="card-cab"><h3>Primeiros passos — ${feitos} de ${passos.length}</h3>
        <button class="btn pequeno" data-click="ocultarPassos">Ocultar</button></div><div class="barra-prog" style="margin-bottom:8px"><div style="width:${feitos / passos.length * 100}%"></div></div>
      <div class="checklist grade g2" style="gap:0 24px">${passos.map(([id, texto, ok, link]) => `<div class="item ${ok ? 'feito' : ''}"><span class="marca">${ok ? '✓' : ''}</span><span>${esc(texto)}</span>
        ${ok ? '' : `<a class="btn pequeno" href="${link}">Fazer</a>${['taxas', 'etiquetas'].includes(id) ? ` <button class="btn pequeno" data-click="marcarPasso" data-id="${id}">Já fiz</button>` : ''}`}</div>`).join('')}</div></div>`,
    hoje: () => `<div class="card"><div class="card-cab"><h3>Hoje na loja — ${DIAS_SEMANA[new Date(dia + 'T12:00').getDay()]}, ${dataBR(dia)}</h3></div>
      <div class="checklist grade g2" style="gap:0 24px">${itensHoje().map(([sit, texto, link]) => `<div class="item ${sit === 'feito' ? 'feito' : sit === 'atencao' ? 'atencao' : ''}">
        <span class="marca">${sit === 'feito' ? '✓' : sit === 'atencao' ? '!' : ''}</span><span>${esc(texto)}</span>${link && sit !== 'feito' ? `<a class="btn pequeno" href="${link}">Ver</a>` : ''}</div>`).join('')}</div></div>`,
    kpis: () => `<div class="kpis" style="margin:0">${conf.kpis.filter(k => kpiDef[k] && (gestora() || !KPIS_RESTRITOS.includes(k))).map(k => { const [v, det, link] = kpiDef[k](); return `<div class="kpi clicavel" data-link="${link}"><div class="rot">${KPIS[k]}</div><div class="val">${v}</div><div class="det">${det}</div></div>`; }).join('')}</div>`,
    atalhos: () => `<div class="linha-acoes" style="margin:0"><a class="btn pri grande" href="#/pdv">Nova venda</a>${gestora() ? '<a class="btn" href="#/entrada">Entrada de mercadorias</a><a class="btn" href="#/produto/novo">Novo produto</a>' : ''}<a class="btn" href="#/caixa">Caixa</a><a class="btn" href="#/pix">QR Pix</a><a class="btn" href="#/agenda">Agenda</a><span class="espaco"></span><button class="btn pequeno" data-click="personalizar">Personalizar painel</button></div>`,
    grafico: () => card(`Faturamento — últimos ${conf.periodo} dias`, `<div class="chips" style="margin-bottom:8px">${[7, 30, 60, 90].map(p => `<button class="chip ${p === conf.periodo ? 'ativo' : ''}" data-click="periodo" data-p="${p}">${p} dias</button>`).join('')}</div>${graficoBarras(serie)}
      <small class="suave">Total: ${moeda(soma(serie, s => s.valor))} · média diária ${moeda(soma(serie, s => s.valor) / serie.length)}</small>`),
    avisos: () => card('Avisos', `<ul class="alertas">${alertas().filter(([, , l]) => gestora() || !/contas|recorrentes|metas|relatorios/.test(l)).map(([t, m, l]) => `<li class="${t}"><span>${esc(m)}</span>${l ? `<a href="${l}" class="btn pequeno">Ver</a>` : ''}</li>`).join('') || '<li class="ok">Tudo em ordem.</li>'}</ul>`),
    meta: () => card('Meta do mês', meta ? `<div class="val" style="font-size:22px;font-weight:650">${pct(rMes.fat / meta * 100, 0)}</div><div class="barra-prog"><div style="width:${Math.min(100, rMes.fat / meta * 100)}%"></div></div>
      <div class="totais" style="margin-top:8px"><div><span>Meta</span><b>${moeda(meta)}</b></div><div><span>Realizado</span><b>${moeda(rMes.fat)}</b></div><div><span>Projeção do mês</span><b>${moeda(projecao)}</b></div>
      <div><span>Falta vender por dia</span><b>${moeda(Math.max(0, meta - rMes.fat) / Math.max(1, diasMes - +dia.slice(8) + 1))}</b></div></div>` : `<p class="suave">Nenhuma meta definida.</p>${gestora() ? '<a class="btn pequeno" href="#/metas">Definir meta</a>' : ''}`),
    tarefas: () => card('Tarefas de hoje', [...tp.atrasadas.map(x => ({ ...x, atr: true })), ...tp.hoje].map(x => `<label class="tarefa"><input type="checkbox" data-change="tarefa" data-id="${esc(x.t.id)}" data-dia="${esc(x.dia)}"><span>${esc(x.t.titulo)}${x.atr ? ` <small class="negativo">(${dataBR(x.dia)})</small>` : ''}</span></label>`).join('') || '<p class="suave">Nada pendente.</p>', '#/agenda'),
    top: () => card('Mais vendidos do mês', barrasH([...agrupar(vMes.flatMap(v => v.itens.filter(i => i.produto_id)), i => i.nome)].map(([k, l]) => ({ rotulo: k, valor: soma(l, i => i.qtd) })).sort((a, b) => b.valor - a.valor).slice(0, 6), v => numBR(v) + ' pç')),
    categorias: () => card('Vendas por categoria (mês)', barrasH([...agrupar(vMes.flatMap(v => v.itens), i => (App.idx.cat[i.categoria_id] || {}).nome || 'Serviços')].map(([k, l]) => ({ rotulo: k, valor: soma(l, i => i.total) })).sort((a, b) => b.valor - a.valor).slice(0, 8))),
    pagamentos: () => card('Formas de pagamento (mês)', barrasH([...agrupar(vMes.flatMap(v => v.pagamentos.map(p => ({ ...p, valor: p.forma === 'dinheiro' ? p.valor - v.troco : p.valor }))), p => FORMAS_PAG[p.forma])].map(([k, l]) => ({ rotulo: k, valor: soma(l, p => p.valor) })).sort((a, b) => b.valor - a.valor))),
    aniversariantes: () => { const l = App.d.clientes.filter(c => c.ativo !== false && c.nascimento && c.nascimento.slice(5, 7) === dia.slice(5, 7)).sort((a, b) => a.nascimento.slice(8).localeCompare(b.nascimento.slice(8)));
      return card(`Aniversariantes de ${MESES_LONGOS[+dia.slice(5, 7) - 1]}`, l.map(c => `<div class="tarefa"><span style="flex:1">${esc(c.nome)} <small>${c.nascimento.slice(8)}/${c.nascimento.slice(5, 7)}</small></span>${c.telefone && c.aceita_mensagens !== false ? `<button class="btn pequeno" data-click="parabens" data-id="${c.id}">WhatsApp</button>` : ''}</div>`).join('') || '<p class="suave">Nenhuma neste mês.</p>', '#/clientes?filtro=aniversario'); },
    condicionais: () => { const l = App.d.condicionais.filter(c => c.status === 'aberto');
      return card('Condicionais em aberto', l.map(c => `<div class="tarefa"><span style="flex:1">Nº ${c.numero} — ${esc(c.cliente_nome)} · ${soma(c.itens, i => i.qtd)} pç</span>${c.prazo < dia ? etiqueta('vencido', 'erro') : etiqueta('até ' + dataBR(c.prazo), 'info')}</div>`).join('') || '<p class="suave">Nenhum.</p>', '#/condicional'); },
    vencimentos: () => { const l = fin.filter(f => f.vencimento <= somarDias(dia, 10) && (gestora() || f.forma === 'crediario')).sort((a, b) => a.vencimento.localeCompare(b.vencimento)).slice(0, 8);
      return card('Próximos vencimentos', l.map(f => `<div class="tarefa"><small style="width:72px">${dataBR(f.vencimento)}</small><span style="flex:1">${esc(f.descricao)}</span><b class="${f.tipo === 'pagar' ? 'negativo' : 'positivo'}">${moeda(f.tipo === 'pagar' ? f.valor : f.liquido)}</b></div>`).join('') || '<p class="suave">Nada nos próximos 10 dias.</p>', gestora() ? '#/contas' : ''); },
    estoque_baixo: () => { const l = App.d.produtos.filter(p => p.ativo !== false).flatMap(p => p.variacoes.filter(v => v.estoque <= n(v.estoque_min)).map(v => ({ p, v }))).slice(0, 10);
      return card('Estoque baixo', l.map(x => `<div class="tarefa"><span style="flex:1">${esc(x.p.nome)} <small>${esc(x.v.tamanho)}/${esc(x.v.cor)}</small></span><b class="${x.v.estoque <= 0 ? 'negativo' : ''}">${x.v.estoque}</b></div>`).join('') || '<p class="suave">Tudo abastecido.</p>', '#/estoque?filtro=baixo'); }
  };
  el.innerHTML = `<div class="widgets">${conf.widgets.filter(w => render[w]).map(w => [w, render[w]()]).filter(([, h]) => h).map(([w, h]) => `<div class="w ${WIDGETS[w][1]}">${h}</div>`).join('')}</div>
    ${conf.widgets.includes('atalhos') ? '' : '<div style="margin-top:12px"><button class="btn pequeno" data-click="personalizar">Personalizar painel</button></div>'}`;
  el.querySelectorAll('.kpi[data-link]').forEach(k => k.onclick = () => ir(k.dataset.link));
  ligar(el, {
    periodo: async b => { conf.periodo = +b.dataset.p; App.cfg.painel = conf; await api('config', { config: { painel: conf } }); recarregarPagina(); },
    tarefa: async inp => { const t = App.d.tarefas.find(x => x.id === inp.dataset.id); await api('salvar/tarefas', { obj: { ...t, feitas: { ...(t.feitas || {}), [inp.dataset.dia]: true } } }); toast('Tarefa concluída.', 'ok'); recarregarPagina(); },
    parabens: b => { const c = App.idx.cli[b.dataset.id]; abrirWhatsApp(c.telefone, textoModelo('aniversario', { nome: c.apelido || c.nome.split(' ')[0] })); },
    personalizar: () => personalizarPainel(conf),
    ocultarPassos: async () => { const novo = { ...conf, primeiros_ocultos: true }; App.cfg.painel = novo; await api('config', { config: { painel: novo } }); toast('Você pode reativar em "Personalizar painel".'); recarregarPagina(); },
    marcarPasso: async b => { const novo = { ...conf, feitos: [...(conf.feitos || []), b.dataset.id] }; App.cfg.painel = novo; await api('config', { config: { painel: novo } }); recarregarPagina(); }
  });
};

function personalizarPainel(conf) {
  const ws = [...conf.widgets, ...Object.keys(WIDGETS).filter(k => !conf.widgets.includes(k))].map(k => ({ k, on: conf.widgets.includes(k) }));
  const ks = [...conf.kpis, ...Object.keys(KPIS).filter(k => !conf.kpis.includes(k))].filter(k => gestora() || !KPIS_RESTRITOS.includes(k)).map(k => ({ k, on: conf.kpis.includes(k) }));
  const m = modal({ titulo: 'Personalizar painel', largura: 'largo', corpo: `<div class="grade g2"><div><h3>Blocos</h3><div class="lista-ordem" id="lw"></div></div><div><h3>Indicadores</h3><div class="lista-ordem" id="lk"></div></div></div>`,
    botoes: [{ texto: 'Restaurar padrão', acao: async () => { await api('config', { config: { painel: PAINEL_PADRAO } }); App.cfg.painel = PAINEL_PADRAO; recarregarPagina(); } },
      { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async () => {
        const novo = { ...conf, widgets: ws.filter(x => x.on).map(x => x.k), kpis: ks.filter(x => x.on).map(x => x.k), primeiros_ocultos: !ws.find(x => x.k === 'primeiros').on };
        await api('config', { config: { painel: novo } }); App.cfg.painel = novo; recarregarPagina();
      } }] });
  const lista = (sel, arr, nomes) => {
    const box = m.querySelector(sel);
    box.innerHTML = arr.map((x, i) => `<div class="item"><input type="checkbox" data-i="${i}" ${x.on ? 'checked' : ''}><span>${esc(nomes[x.k])}</span>
      <button class="btn pequeno" data-sobe="${i}" ${i === 0 ? 'disabled' : ''}>↑</button><button class="btn pequeno" data-desce="${i}" ${i === arr.length - 1 ? 'disabled' : ''}>↓</button></div>`).join('');
    box.querySelectorAll('[data-i]').forEach(c => c.onchange = () => { arr[+c.dataset.i].on = c.checked; });
    box.querySelectorAll('[data-sobe]').forEach(b => b.onclick = () => { const i = +b.dataset.sobe; [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]; lista(sel, arr, nomes); });
    box.querySelectorAll('[data-desce]').forEach(b => b.onclick = () => { const i = +b.dataset.desce; [arr[i + 1], arr[i]] = [arr[i], arr[i + 1]]; lista(sel, arr, nomes); });
  };
  lista('#lw', ws, Object.fromEntries(Object.entries(WIDGETS).map(([k, v]) => [k, v[0]])));
  lista('#lk', ks, KPIS);
}

/* ================================================================ AGENDA */
function eventosDoDia(dia) {
  const ev = [];
  (App.d.tarefas || []).forEach(t => { if (tarefaDoDia(t, dia) && t.recorrencia !== 'diaria') ev.push({ tipo: 'tarefa-ev', titulo: t.titulo, feita: !!(t.feitas || {})[dia], tarefa: t }); });
  if (gestora()) {
    const fin = App.d.financeiro.filter(f => f.status === 'pendente' && f.vencimento === dia);
    const pag = fin.filter(f => f.tipo === 'pagar'), rec = fin.filter(f => f.tipo === 'receber');
    pag.forEach(f => ev.push({ tipo: 'pagar', titulo: `Pagar: ${f.descricao}`, valor: f.valor }));
    if (rec.length) ev.push({ tipo: 'receber', titulo: `Receber ${moeda(soma(rec, f => f.liquido))} (${rec.length})`, valor: soma(rec, f => f.liquido) });
  } else {
    App.d.financeiro.filter(f => f.status === 'pendente' && f.vencimento === dia && f.forma === 'crediario').forEach(f => ev.push({ tipo: 'receber', titulo: `Crediário: ${(App.idx.cli[f.cliente_id] || {}).nome || ''}`, valor: f.valor }));
  }
  App.d.condicionais.filter(c => c.status === 'aberto' && c.prazo === dia).forEach(c => ev.push({ tipo: 'cond', titulo: `Condicional ${c.numero}: ${c.cliente_nome}` }));
  App.d.clientes.filter(c => c.ativo !== false && c.nascimento && c.nascimento.slice(5) === dia.slice(5)).forEach(c => ev.push({ tipo: 'aniv', titulo: `Aniversário: ${c.nome}`, cliente: c }));
  App.d.promocoes.filter(p => p.ativo && (p.inicio === dia || p.fim === dia)).forEach(p => ev.push({ tipo: 'promo', titulo: `${p.inicio === dia ? 'Começa' : 'Termina'}: ${p.nome}` }));
  return ev;
}
function linkGoogleAgenda(titulo, dia, detalhes = '') {
  const d = dia.replace(/-/g, ''), f = somarDias(dia, 1).replace(/-/g, '');
  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(titulo)}&dates=${d}/${f}&details=${encodeURIComponent(detalhes || 'Loja ERP — ' + App.cfg.loja.nome)}`;
}
function exportarICS(dias = 90) {
  const linhas = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Infinity Technology//Loja ERP//PT-BR', 'CALSCALE:GREGORIAN', `X-WR-CALNAME:${App.cfg.loja.nome}`];
  const escICS = s => String(s).replace(/\\/g, '\\\\').replace(/[,;]/g, m => '\\' + m).replace(/\n/g, '\\n');
  const carimbo = new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z';
  let k = 0;
  for (let i = 0; i < dias; i++) {
    const dia = somarDias(hojeISO(), i);
    for (const e of eventosDoDia(dia)) {
      linhas.push('BEGIN:VEVENT', `UID:lojaerp-${dia}-${k++}@local`, `DTSTAMP:${carimbo}`, `DTSTART;VALUE=DATE:${dia.replace(/-/g, '')}`, `DTEND;VALUE=DATE:${somarDias(dia, 1).replace(/-/g, '')}`, `SUMMARY:${escICS(e.titulo)}`, 'END:VEVENT');
    }
  }
  linhas.push('END:VCALENDAR');
  baixarArquivo(`agenda-${hojeISO()}.ics`, new Blob([linhas.join('\r\n')], { type: 'text/calendar;charset=utf-8' }));
}

App.paginas.agenda = async (el, id, params) => {
  const mes = params.mes || mesAtual();
  const dia = hojeISO();
  const [a, mm] = mes.split('-').map(Number);
  const primeiro = new Date(a, mm - 1, 1);
  const inicio = somarDias(`${mes}-01`, -primeiro.getDay());
  const celulas = Array.from({ length: 42 }, (_, i) => somarDias(inicio, i));
  const tp = tarefasPendentes(dia);
  el.innerHTML = `<div class="linha-acoes"><button class="btn" data-click="mes" data-m="${somarMeses(mes, -1)}">‹</button><h2 style="margin:0">${MESES_LONGOS[mm - 1]} de ${a}</h2>
      <button class="btn" data-click="mes" data-m="${somarMeses(mes, 1)}">›</button><button class="btn pequeno" data-click="mes" data-m="${mesAtual()}">Hoje</button><span class="espaco"></span>
      <button class="btn" data-click="ics" title="Importe no Google Agenda, Outlook ou celular">Exportar .ics (90 dias)</button><button class="btn pri" data-click="nova">Nova tarefa</button></div>
    <div class="chips" style="margin-bottom:10px">${[['tarefa-ev', 'Tarefas'], ['pagar', 'Contas a pagar'], ['receber', 'A receber'], ['cond', 'Condicionais'], ['aniv', 'Aniversários'], ['promo', 'Promoções']].map(([c, t]) => `<span class="ev ${c}" style="display:inline-block">${t}</span>`).join('')}</div>
    <div class="card" style="padding:0;overflow:hidden"><div class="calendario">${DIAS_SEMANA.map(d => `<div class="cab">${d.slice(0, 3)}</div>`).join('')}
      ${celulas.map(d => { const ev = eventosDoDia(d); return `<div class="dia ${d.slice(0, 7) !== mes ? 'fora' : ''} ${d === dia ? 'hoje' : ''}" data-dia="${d}"><div class="num-dia">${+d.slice(8)}</div>
        ${ev.slice(0, 4).map(e => `<span class="ev ${e.tipo}" title="${esc(e.titulo)}">${e.feita ? '✓ ' : ''}${esc(e.titulo)}</span>`).join('')}${ev.length > 4 ? `<small class="suave">+${ev.length - 4}</small>` : ''}</div>`; }).join('')}</div></div>
    <div class="grade g2"><div class="card"><h3>Hoje</h3>${[...tp.atrasadas.map(x => ({ ...x, atr: true })), ...tp.hoje].map(x => `<label class="tarefa"><input type="checkbox" data-change="feita" data-id="${esc(x.t.id)}" data-dia="${esc(x.dia)}"><span>${esc(x.t.titulo)}${x.atr ? ` <small class="negativo">atrasada (${dataBR(x.dia)})</small>` : ''}</span></label>`).join('') || '<p class="suave">Nada pendente hoje.</p>'}</div>
      <div class="card"><h3>Integração com Google Agenda</h3><p class="suave">Clique num dia do calendário e use <b>Google Agenda</b> em cada compromisso, ou exporte o arquivo <b>.ics</b> e importe em
        Google Agenda (Configurações › Importar e exportar), Outlook ou no celular.</p></div></div>
    <div class="card"><h3>Tarefas cadastradas</h3><div id="tab-tar"></div></div>`;
  el.querySelectorAll('.dia[data-dia]').forEach(c => c.onclick = () => detalheDia(c.dataset.dia));
  tabela(el.querySelector('#tab-tar'), { linhas: App.d.tarefas, colunas: [{ t: 'Tarefa', v: t => t.titulo }, { t: 'Quando', v: t => descRecorrencia(t) }, { t: 'Situação', v: t => t.ativo === false ? 'Inativa' : 'Ativa', h: t => t.ativo === false ? etiqueta('Inativa') : etiqueta('Ativa', 'ok') }], aoClicar: t => formTarefa(t) });
  ligar(el, { mes: b => ir('#/agenda?mes=' + b.dataset.m), ics: () => exportarICS(), nova: () => formTarefa(null, params.dia),
    feita: async i => { await marcarTarefa(i.dataset.id, i.dataset.dia); recarregarPagina(); } });
};
function descRecorrencia(t) {
  return { diaria: 'Todo dia', semanal: 'Toda ' + (DIAS_SEMANA[t.dia_semana] || '').toLowerCase(), mensal: `Todo dia ${t.dia_mes}`, anual: `Todo ano em ${(t.data || '').split('-').reverse().join('/')}`, unica: dataBR(t.data) }[t.recorrencia] || '';
}
async function marcarTarefa(id, dia, feita = true) {
  const t = App.d.tarefas.find(x => x.id === id);
  const feitas = { ...(t.feitas || {}) };
  if (feita) feitas[dia] = true; else delete feitas[dia];
  await api('salvar/tarefas', { obj: { ...t, feitas } });
}
function detalheDia(dia) {
  const ev = eventosDoDia(dia);
  const m = modal({ titulo: `${DIAS_SEMANA[new Date(dia + 'T12:00').getDay()]}, ${dataBR(dia)}`, largura: 'largo', corpo: ev.length ? ev.map((e, i) => `<div class="tarefa"><span class="ev ${e.tipo}" style="flex:1">${esc(e.titulo)}${e.valor ? ' — ' + moeda(e.valor) : ''}</span>
      ${e.tarefa ? `<label class="check"><input type="checkbox" data-t="${i}" ${e.feita ? 'checked' : ''}>feita</label>` : ''}${e.cliente && e.cliente.telefone ? `<button class="btn pequeno" data-w="${i}">WhatsApp</button>` : ''}
      <a class="btn pequeno" target="_blank" rel="noopener" href="${linkGoogleAgenda(e.titulo, dia)}">Google Agenda</a></div>`).join('') : '<p class="suave">Nenhum compromisso.</p>',
    botoes: [{ texto: 'Nova tarefa neste dia', acao: () => formTarefa(null, dia) }, { texto: 'Fechar', classe: 'pri' }] });
  m.querySelectorAll('[data-t]').forEach(c => c.onchange = async () => { await marcarTarefa(ev[+c.dataset.t].tarefa.id, dia, c.checked); toast('Atualizado.', 'ok'); if (App.rotaAtual === 'agenda') recarregarPagina(); });
  m.querySelectorAll('[data-w]').forEach(b => b.onclick = () => { const c = ev[+b.dataset.w].cliente; abrirWhatsApp(c.telefone, textoModelo('aniversario', { nome: c.apelido || c.nome.split(' ')[0] })); });
}
function formTarefa(t, diaPadrao) {
  const campos = [{ n: 'titulo', r: 'Tarefa', w: 12, obr: 1 }, { n: 'recorrencia', r: 'Repetição', t: 'select', w: 4, vazio: false, op: [['unica', 'Uma vez'], ['diaria', 'Todo dia'], ['semanal', 'Toda semana'], ['mensal', 'Todo mês'], ['anual', 'Todo ano']] },
    { n: 'dia_semana', r: 'Dia da semana', t: 'select', w: 4, op: DIAS_SEMANA.map((d, k) => [k, d]), aj: 'Para tarefas semanais.' }, { n: 'dia_mes', r: 'Dia do mês', t: 'number', w: 4, min: 1, aj: 'Para tarefas mensais.' },
    { n: 'data', r: 'Data', w: 6, aj: 'Uma vez: AAAA-MM-DD. Anual: MM-DD.', ph: diaPadrao || 'AAAA-MM-DD' }, { n: 'ativo', r: 'Ativa', t: 'check', w: 6, padrao: true }];
  modal({ titulo: t ? 'Editar tarefa' : 'Nova tarefa', largura: 'largo', corpo: formHTML(campos, t || { recorrencia: 'unica', data: diaPadrao || '' }), botoes: [
    ...(t ? [{ texto: 'Excluir', classe: 'perigo', acao: async () => { await api('excluir/tarefas', { id: t.id }); recarregarPagina(); } }] : []),
    { texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async m => {
      const o = lerForm(m, campos);
      o.dia_semana = o.dia_semana === '' ? null : +o.dia_semana;
      if (o.recorrencia === 'unica' && !/^\d{4}-\d{2}-\d{2}$/.test(o.data)) throw new Error('Informe a data no formato AAAA-MM-DD.');
      if (o.recorrencia === 'anual' && /^\d{4}-/.test(o.data)) o.data = o.data.slice(5);
      await api('salvar/tarefas', { obj: { feitas: {}, ...(t || {}), ...o } }); recarregarPagina();
    } }] });
}

/* =============================================================== BALANÇO */
App.paginas.balanco = async el => {
  const dia = hojeISO(), mes = dia.slice(0, 7);
  const pend = App.d.financeiro.filter(f => f.status === 'pendente');
  const caixaBanco = saldoAtual();
  const receberCartao = soma(pend.filter(f => f.tipo === 'receber' && ['debito', 'credito'].includes(f.forma)), f => f.liquido);
  const receberCred = soma(pend.filter(f => f.tipo === 'receber' && f.forma === 'crediario'), f => f.liquido);
  const receberOutros = soma(pend.filter(f => f.tipo === 'receber' && !['debito', 'credito', 'crediario'].includes(f.forma)), f => f.liquido);
  const est = valorEstoque();
  const imob = soma(App.d.ativos.filter(a => a.ativo !== false), a => n(a.valor));
  let deprAcum = 0;
  App.d.ativos.filter(a => a.ativo !== false && a.aquisicao && n(a.vida_util_meses) > 0).forEach(a => {
    const decorridos = (+mes.slice(0, 4) - +a.aquisicao.slice(0, 4)) * 12 + (+mes.slice(5) - +a.aquisicao.slice(5, 7)) + 1;
    deprAcum += n(a.valor) / n(a.vida_util_meses) * Math.max(0, Math.min(n(a.vida_util_meses), decorridos));
  });
  const fornecedores = soma(pend.filter(f => f.tipo === 'pagar' && f.origem === 'compra'), f => f.valor);
  const outrasPagar = soma(pend.filter(f => f.tipo === 'pagar' && f.origem !== 'compra'), f => f.valor);
  const vales = soma(App.d.vales.filter(v => v.status === 'ativo' && (!v.validade || v.validade >= dia)), v => v.saldo);
  const cashback = soma(App.d.clientes, c => cashbackDisponivel(c));
  const ac = caixaBanco + receberCartao + receberCred + receberOutros + est.custo;
  const anc = imob - deprAcum;
  const pc = fornecedores + outrasPagar + vales + cashback;
  const pl = ac + anc - pc;
  const linha = (rot, v, cls = '') => `<tr class="${cls}"><td>${rot}</td><td class="num ${v < 0 ? 'negativo' : ''}">${moeda(v)}</td></tr>`;
  el.innerHTML = `<div class="caixa-aviso">Posição em ${dataBR(dia)}, calculada a partir dos lançamentos do sistema (balanço gerencial). Para o balanço contábil oficial, consulte seu contador.</div>
    <div class="kpis">${kpi('Patrimônio líquido', `<span class="${pl < 0 ? 'negativo' : ''}">${moeda(pl)}</span>`, 'O que é seu, descontadas as dívidas')}
      ${kpi('Capital de giro', moeda(ac - pc), 'Ativo circulante − passivo circulante')}${kpi('Liquidez corrente', pc ? numBR(ac / pc, 2) : '—', 'Acima de 1,0 = consegue pagar o curto prazo')}
      ${kpi('Liquidez seca', pc ? numBR((ac - est.custo) / pc, 2) : '—', 'Sem contar o estoque')}</div>
    <div class="grade g2"><div class="card"><h3>Ativo (o que a loja tem)</h3><table class="tab balanco"><tbody>
      <tr class="grupo"><td colspan="2">Ativo circulante</td></tr>${linha('Caixa e bancos (estimado)', caixaBanco)}${linha('Cartões a receber', receberCartao)}${linha('Crediário a receber', receberCred)}${linha('Outras contas a receber', receberOutros)}${linha('Estoque (a custo)', est.custo)}
      ${linha('Total do circulante', ac, 'total')}<tr class="grupo"><td colspan="2">Ativo não circulante</td></tr>${linha('Imobilizado (bens)', imob)}${linha('(−) Depreciação acumulada', -deprAcum)}${linha('Total não circulante', anc, 'total')}
      ${linha('TOTAL DO ATIVO', ac + anc, 'total')}</tbody></table></div>
    <div class="card"><h3>Passivo (o que a loja deve) e patrimônio</h3><table class="tab balanco"><tbody>
      <tr class="grupo"><td colspan="2">Passivo circulante</td></tr>${linha('Fornecedores a pagar', fornecedores)}${linha('Outras contas a pagar', outrasPagar)}${linha('Vales-troca e vales-presente em aberto', vales)}${linha('Cashback a utilizar pelas clientes', cashback)}
      ${linha('Total do passivo', pc, 'total')}<tr class="grupo"><td colspan="2">Patrimônio líquido</td></tr>${linha('Capital + lucros acumulados', pl)}${linha('TOTAL PASSIVO + PATRIMÔNIO', pc + pl, 'total')}</tbody></table></div></div>
    <div class="linha-acoes"><span class="espaco"></span><button class="btn" data-click="imprimir">Imprimir</button></div>`;
  ligar(el, { imprimir: () => imprimir(`<div class="documento"><h3>${esc(App.cfg.loja.nome)} — Balanço gerencial em ${dataBR(dia)}</h3>${[...el.querySelectorAll('.card table')].map(t => t.outerHTML).join('<br>')}</div>`) });
};
