/* Loja ERP — núcleo da interface: API, utilidades, componentes.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const App = {
  d: {}, cfg: {}, idx: {}, usuario: null, usuarios: [], papel: null, papeis: {}, hoje: '', paginas: {},
  carrinho: null, rascunhoEntrada: null, rotaAtual: '', credito: '', versao: ''
};

/* ------------------------------------------------------------ formatação */
const _moeda = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
function moeda(v) { return _moeda.format(+v || 0); }
function numBR(v, casas = 0) {
  return (+v || 0).toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
}
function pct(v, casas = 1) { return isFinite(v) ? numBR(v, casas) + '%' : '—'; }
function n(v) { const x = parseFloat(String(v ?? '').replace(',', '.')); return isFinite(x) ? x : 0; }
function r2(v) { return Math.round((v + (v >= 0 ? 1e-9 : -1e-9)) * 100) / 100; }
function pad(x) { return String(x).padStart(2, '0'); }
function isoData(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function hojeISO() { return isoData(new Date()); }
function mesAtual() { return hojeISO().slice(0, 7); }
function dataBR(iso) { if (!iso) return ''; const [a, m, d] = iso.slice(0, 10).split('-'); return `${d}/${m}/${a}`; }
function dataHoraBR(iso) { return iso ? `${dataBR(iso)} ${iso.slice(11, 16)}` : ''; }
function somarDias(iso, dias) { const d = new Date(iso.slice(0, 10) + 'T12:00:00'); d.setDate(d.getDate() + dias); return isoData(d); }
function somarMeses(mes, k) { const [a, m] = mes.split('-').map(Number); const d = new Date(a, m - 1 + k, 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; }
function diasEntre(a, b) { return Math.round((new Date(b.slice(0, 10) + 'T12:00:00') - new Date(a.slice(0, 10) + 'T12:00:00')) / 864e5); }
const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const MESES_LONGOS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const DIAS_SEMANA = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
function mesNome(mes) { const [a, m] = mes.split('-'); return `${MESES[+m - 1]}/${a}`; }
function mesLongo(mes) { const [a, m] = mes.split('-'); return `${MESES_LONGOS[+m - 1]} de ${a}`; }
function ultimoDiaMes(mes) { const [a, m] = mes.split('-').map(Number); return `${mes}-${pad(new Date(a, m, 0).getDate())}`; }
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function semAcento(s) { return String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }
function fone(t) {
  const d = String(t || '').replace(/\D/g, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return t || '';
}
function cpfFmt(c) { const d = String(c || '').replace(/\D/g, ''); return d.length === 11 ? `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}` : (c || ''); }
function iniciais(nome) { return String(nome || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(p => p[0]).join('').toUpperCase(); }
function soma(lista, f) { return lista.reduce((t, x) => t + (+f(x) || 0), 0); }
function agrupar(lista, f) { const m = new Map(); for (const x of lista) { const k = f(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; }
function mapa(lista) { const m = {}; for (const x of lista || []) m[x.id] = x; return m; }

/* -------------------------------------------------------------------- API */
async function api(rota, corpo) {
  const opcoes = corpo === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Loja': '1' }, body: JSON.stringify(corpo)
  };
  let resp, json;
  try { resp = await fetch('/api/' + rota, opcoes); } catch (e) {
    throw new Error('Sem comunicação com o programa. Abra o Loja ERP pelo atalho e tente de novo.');
  }
  try { json = await resp.json(); } catch (e) { throw new Error('Resposta inválida do programa.'); }
  if (resp.status === 401 && !['login', 'setup', 'recuperar', 'estado'].includes(rota)) {
    mostrarEntrada();
    throw new Error(json.erro || 'Sessão encerrada.');
  }
  if (!resp.ok) throw new Error(json.erro || 'Erro na operação.');
  if (json.alterados) await carregar(json.alterados);
  return json;
}

async function carregar(colecoes) {
  const q = colecoes && colecoes.length ? '?c=' + colecoes.join(',') : '';
  const resp = await fetch('/api/dados' + q);
  if (resp.status === 401) { mostrarEntrada(); throw new Error('Sessão encerrada.'); }
  const j = await resp.json();
  Object.assign(App.d, j.dados);
  App.cfg = j.config; App.hoje = j.hoje; App.usuarios = j.usuarios || []; App.papel = j.papel; App.papeis = j.papeis || {}; App.pastaLoja = j.pasta_loja || '';
  if (typeof aplicarAparencia === 'function') aplicarAparencia(App.cfg.aparencia);
  App.licenca = j.licenca || null;
  const aviso = document.getElementById('aviso-global');
  const partes = [];
  if (j.aviso_uso) partes.push(esc(j.aviso_uso));
  if (App.licenca && App.licenca.estado !== 'ativa') {
    partes.push(`${esc(App.licenca.mensagem)} <a href="#/config?aba=licenca">Ver planos e renovar</a>`);
  }
  aviso.hidden = !partes.length; aviso.innerHTML = partes.join('<br>');
  aviso.classList.toggle('erro', !!App.licenca && App.licenca.estado === 'bloqueada');
  indexar();
}

function indexar() {
  const I = App.idx = {};
  I.prod = mapa(App.d.produtos); I.cat = mapa(App.d.categorias); I.marca = mapa(App.d.marcas);
  I.forn = mapa(App.d.fornecedores); I.col = mapa(App.d.colecoes); I.cli = mapa(App.d.clientes);
  I.pc = mapa(App.d.plano_contas); I.serv = mapa(App.d.servicos); I.venda = mapa(App.d.vendas);
  I.var = {}; I.cod = {};
  for (const p of App.d.produtos || []) for (const v of p.variacoes || []) {
    I.var[v.id] = { p, v };
    if (v.codigo_barras) I.cod[String(v.codigo_barras).toUpperCase()] = { p, v };
  }
  I.cliStats = {}; I.fatDia = {};
  for (const v of App.d.vendas || []) {
    if (v.status !== 'concluida') continue;
    const dia = v.data.slice(0, 10);
    I.fatDia[dia] = (I.fatDia[dia] || 0) + v.total;
    if (!v.cliente_id) continue;
    const s = I.cliStats[v.cliente_id] || (I.cliStats[v.cliente_id] = { total: 0, compras: 0, pecas: 0, ultima: '', primeira: '' });
    s.total += v.total; s.compras++; s.pecas += soma(v.itens, i => i.qtd);
    if (v.data > s.ultima) s.ultima = v.data;
    if (!s.primeira || v.data < s.primeira) s.primeira = v.data;
  }
  const totais = Object.values(I.cliStats).map(x => x.total).sort((a, b) => b - a);
  I.corteVip = totais.length ? totais[Math.max(0, Math.ceil(totais.length * 0.1) - 1)] : Infinity;
}

/* ---------------------------------------------------------- componentes */
/* Aviso rápido no canto da tela. Com "acao", mostra um botão (ex.: Desfazer) enquanto o aviso estiver visível. */
function toast(msg, tipo = '', acao = null) {
  const el = document.createElement('div');
  el.className = 'toast ' + tipo;
  const texto = document.createElement('span');
  texto.textContent = msg;
  el.appendChild(texto);
  if (acao && acao.texto) {
    const bt = document.createElement('button');
    bt.className = 'toast-acao'; bt.textContent = acao.texto;
    bt.onclick = async () => { bt.disabled = true; el.remove(); try { await acao.acao(); } catch (e) { toast(e.message, 'erro'); } };
    el.appendChild(bt);
  }
  document.getElementById('toasts').appendChild(el);
  setTimeout(() => el.remove(), acao ? acao.tempo || 15000 : tipo === 'erro' ? 6000 : 3200);
}

/* Liga eventos declarados em data-click / data-change / data-input / data-enter. */
function ligar(raiz, acoes) {
  const tipos = [['click', 'click'], ['change', 'change'], ['input', 'input']];
  for (const [attr, evento] of tipos) {
    raiz.querySelectorAll(`[data-${attr}]`).forEach(el => {
      const fn = acoes[el.dataset[attr]];
      if (!fn) return;
      el.addEventListener(evento, async e => {
        if (attr === 'click') e.preventDefault();
        try { await fn(el, e); } catch (err) { toast(err.message, 'erro'); }
      });
    });
  }
  raiz.querySelectorAll('[data-enter]').forEach(el => {
    const fn = acoes[el.dataset.enter];
    if (fn) el.addEventListener('keydown', async e => {
      if (e.key === 'Enter') { e.preventDefault(); try { await fn(el, e); } catch (err) { toast(err.message, 'erro'); } }
    });
  });
}

function modal({ titulo, corpo, botoes = [], largura = '', aoAbrir, acoes }) {
  const fundo = document.createElement('div');
  fundo.className = 'modal-fundo';
  fundo.innerHTML = `<div class="modal ${largura}" role="dialog"><div class="modal-cab"><h3>${esc(titulo)}</h3>
    <button class="fechar" title="Fechar">&times;</button></div><div class="modal-corpo">${corpo}</div><div class="modal-rod"></div></div>`;
  const fechar = () => { fundo.remove(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape' && document.getElementById('modais').lastElementChild === fundo) fechar(); };
  document.addEventListener('keydown', esc_);
  fundo.fechar = fechar;
  fundo.querySelector('.fechar').onclick = fechar;
  const rod = fundo.querySelector('.modal-rod');
  for (const b of botoes) {
    const bt = document.createElement('button');
    bt.className = 'btn ' + (b.classe || ''); bt.textContent = b.texto;
    bt.onclick = async () => {
      if (b.acao) {
        bt.disabled = true;
        try { const r = await b.acao(fundo); if (r === false) { bt.disabled = false; return; } }
        catch (e) { toast(e.message, 'erro'); bt.disabled = false; return; }
      }
      fechar();
    };
    rod.appendChild(bt);
  }
  document.getElementById('modais').appendChild(fundo);
  if (acoes) ligar(fundo, acoes);
  if (aoAbrir) aoAbrir(fundo);
  const foco = fundo.querySelector('[autofocus], input:not([type=hidden]):not([readonly]), select, textarea');
  if (foco) setTimeout(() => foco.focus(), 30);
  return fundo;
}

function confirmar(mensagem, textoOk = 'Confirmar', classe = 'pri') {
  return new Promise(res => {
    let ok = false;
    const m = modal({ titulo: 'Confirmação', corpo: `<p>${esc(mensagem)}</p>`, botoes: [
      { texto: 'Cancelar' }, { texto: textoOk, classe, acao: () => { ok = true; } }] });
    const obs = new MutationObserver(() => { if (!m.isConnected) { obs.disconnect(); res(ok); } });
    obs.observe(document.getElementById('modais'), { childList: true });
  });
}

function pedirSenha(titulo, texto) {
  return new Promise(res => {
    let valor = null;
    const m = modal({ titulo, corpo: `<p>${esc(texto)}</p><label class="campo"><span>Sua senha</span><input type="password" name="senha" autocomplete="current-password"></label>`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Confirmar', classe: 'pri', acao: f => { valor = f.querySelector('[name=senha]').value; } }] });
    const obs = new MutationObserver(() => { if (!m.isConnected) { obs.disconnect(); res(valor); } });
    obs.observe(document.getElementById('modais'), { childList: true });
  });
}

/* Formulários declarativos.
   campo: {n, r (rótulo), t (tipo), op ([[valor, texto]]), w (largura), aj (ajuda), obr, ph, min, step, sec} */
function campoHTML(c, valor) {
  if (c.sec) return `<div class="titulo-secao">${esc(c.sec)}</div>`;
  const w = c.w ? `w${c.w}` : '';
  const v = valor ?? c.padrao ?? '';
  const comum = `name="${c.n}" ${c.obr ? 'required' : ''} ${c.ph ? `placeholder="${esc(c.ph)}"` : ''} ${c.ro ? 'readonly' : ''} ${c.id ? `id="${c.id}"` : ''} ${c.dataInput ? `data-input="${c.dataInput}"` : ''} ${c.dataChange ? `data-change="${c.dataChange}"` : ''}`;
  let input;
  switch (c.t) {
    case 'select': {
      const ops = (typeof c.op === 'function' ? c.op() : c.op) || [];
      input = `<select ${comum}>${c.vazio !== false ? `<option value="">${esc(c.vazio || '—')}</option>` : ''}${ops.map(([k, t]) =>
        `<option value="${esc(k)}" ${String(k) === String(v) ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>`;
      break;
    }
    case 'textarea': input = `<textarea ${comum}>${esc(v)}</textarea>`; break;
    case 'check':
      return `<label class="check ${w}"><input type="checkbox" ${comum} ${v ? 'checked' : ''}><span>${esc(c.r)}${iconeAjuda(c)}</span></label>`;
    case 'money': input = `<input type="number" step="0.01" min="${c.min ?? 0}" inputmode="decimal" ${comum} value="${v === '' ? '' : esc(v)}">`; break;
    case 'number': input = `<input type="number" step="${c.step ?? 1}" ${c.min !== undefined ? `min="${c.min}"` : ''} ${comum} value="${esc(v)}">`; break;
    case 'pct': input = `<input type="number" step="0.01" ${comum} value="${esc(v)}">`; break;
    default: input = `<input type="${c.t || 'text'}" ${comum} value="${esc(v)}" ${c.t === 'email' ? 'autocomplete="off"' : ''}>`;
  }
  return `<label class="campo ${w}"><span>${esc(c.r)}${c.obr ? ' *' : ''}${iconeAjuda(c)}</span>${input}</label>`;
}
function iconeAjuda(c) {
  const texto = c.aj || (typeof AJUDA_CAMPOS !== 'undefined' ? AJUDA_CAMPOS[c.n] : '');
  return texto ? `<i class="ajuda-ico" tabindex="0" data-ajuda="${esc(texto)}" aria-label="Ajuda">?</i>` : '';
}
function formHTML(campos, obj = {}) { return `<div class="grade-form">${campos.map(c => campoHTML(c, c.n ? obj[c.n] : undefined)).join('')}</div>`; }
function lerForm(raiz, campos) {
  const o = {};
  for (const c of campos) {
    if (!c.n) continue;
    const el = raiz.querySelector(`[name="${c.n}"]`);
    if (!el) continue;
    let v;
    if (c.t === 'check') v = el.checked;
    else if (['money', 'number', 'pct'].includes(c.t)) v = el.value === '' ? (c.obr ? null : 0) : n(el.value);
    else v = el.value.trim();
    if (c.obr && (v === '' || v === null)) { el.focus(); throw new Error(`Preencha o campo "${c.r}".`); }
    o[c.n] = v;
  }
  return o;
}
function opcoes(lista, rotulo = x => x.nome, filtro = x => x.ativo !== false) {
  return (lista || []).filter(filtro).slice().sort((a, b) => String(rotulo(a)).localeCompare(String(rotulo(b)), 'pt-BR')).map(x => [x.id, rotulo(x)]);
}

/* Tabela com busca, ordenação, paginação e exportação CSV.
   colunas: {t, v(row) valor, h(row) html, cls, semOrdem, total: true|fn} */
function tabela(el, cfg) {
  const st = { busca: '', ordem: cfg.ordem ?? null, desc: cfg.desc ?? false, pagina: 0 };
  const porPagina = cfg.porPagina || 50;
  const valor = (c, r) => c.v ? c.v(r) : '';
  function filtradas() {
    let linhas = cfg.linhas;
    if (st.busca) {
      const termos = semAcento(st.busca).split(/\s+/).filter(Boolean);
      linhas = linhas.filter(r => {
        const txt = semAcento((cfg.textoBusca ? cfg.textoBusca(r) : '') + ' ' + cfg.colunas.map(c => valor(c, r)).join(' '));
        return termos.every(t => txt.includes(t));
      });
    }
    if (st.ordem !== null) {
      const c = cfg.colunas[st.ordem];
      linhas = linhas.slice().sort((a, b) => {
        const x = valor(c, a), y = valor(c, b);
        const r = (typeof x === 'number' && typeof y === 'number') ? x - y : String(x ?? '').localeCompare(String(y ?? ''), 'pt-BR', { numeric: true });
        return st.desc ? -r : r;
      });
    }
    return linhas;
  }
  function render() {
    const linhas = filtradas();
    const total = linhas.length;
    const paginas = Math.max(1, Math.ceil(total / porPagina));
    st.pagina = Math.min(st.pagina, paginas - 1);
    const vis = linhas.slice(st.pagina * porPagina, (st.pagina + 1) * porPagina);
    const temTotal = cfg.colunas.some(c => c.total);
    el.innerHTML = `
      ${cfg.busca === false && !cfg.exportar ? '' : `<div class="tab-barra">
        ${cfg.busca === false ? '' : `<input type="search" placeholder="${esc(cfg.placeholder || 'Buscar...')}" value="${esc(st.busca)}" class="tab-busca">`}
        <span class="espaco"></span><small>${numBR(total)} registro(s)</small>
        ${cfg.exportar ? '<button class="btn pequeno tab-csv">Exportar CSV</button>' : ''}</div>`}
      <div class="tabela-wrap"><table class="tab"><thead><tr>${cfg.colunas.map((c, i) =>
        `<th class="${c.semOrdem ? '' : 'ordenavel'} ${c.cls === 'num' ? 'th-num' : ''}" data-i="${i}">${esc(c.t)}${st.ordem === i ? (st.desc ? ' ▾' : ' ▴') : ''}</th>`).join('')}</tr></thead>
      <tbody>${vis.length ? vis.map((r, i) => `<tr data-i="${i}" class="${cfg.aoClicar ? 'clicavel' : ''} ${cfg.classeLinha ? cfg.classeLinha(r) : ''}">${cfg.colunas.map(c =>
        `<td class="${c.cls || ''}">${c.h ? c.h(r) : esc(valor(c, r))}</td>`).join('')}</tr>`).join('')
        : `<tr><td colspan="${cfg.colunas.length}" class="vazio">${esc(cfg.vazio || 'Nenhum registro encontrado.')}</td></tr>`}</tbody>
      ${temTotal && linhas.length ? `<tfoot><tr>${cfg.colunas.map((c, i) => `<td class="${c.cls || ''}">${i === 0 ? 'Total' : c.total ? (typeof c.total === 'function' ? c.total(linhas) : moeda(soma(linhas, r => valor(c, r)))) : ''}</td>`).join('')}</tr></tfoot>` : ''}
      </table></div>
      ${paginas > 1 ? `<div class="paginacao"><button class="btn pequeno pg-ant" ${st.pagina === 0 ? 'disabled' : ''}>Anterior</button>
        <span>Página ${st.pagina + 1} de ${paginas}</span><button class="btn pequeno pg-prox" ${st.pagina >= paginas - 1 ? 'disabled' : ''}>Próxima</button></div>` : ''}`;
    const busca = el.querySelector('.tab-busca');
    if (busca) busca.oninput = () => { st.busca = busca.value; st.pagina = 0; const pos = busca.selectionStart; render(); const b2 = el.querySelector('.tab-busca'); b2.focus(); b2.setSelectionRange(pos, pos); };
    el.querySelectorAll('th.ordenavel').forEach(th => th.onclick = () => {
      const i = +th.dataset.i; if (st.ordem === i) st.desc = !st.desc; else { st.ordem = i; st.desc = false; } render();
    });
    const ant = el.querySelector('.pg-ant'), prox = el.querySelector('.pg-prox');
    if (ant) ant.onclick = () => { st.pagina--; render(); };
    if (prox) prox.onclick = () => { st.pagina++; render(); };
    const csv = el.querySelector('.tab-csv');
    if (csv) csv.onclick = () => baixarCSV(cfg.exportar, [cfg.colunas.filter(c => c.v).map(c => c.t), ...linhas.map(r => cfg.colunas.filter(c => c.v).map(c => valor(c, r)))]);
    el.querySelectorAll('tbody tr[data-i]').forEach(tr => {
      const r = vis[+tr.dataset.i];
      tr.querySelectorAll('[data-acao]').forEach(b => b.addEventListener('click', async e => {
        e.stopPropagation(); e.preventDefault();
        try { await cfg.acoes[b.dataset.acao](r, b); } catch (err) { toast(err.message, 'erro'); }
      }));
      if (cfg.aoClicar) tr.addEventListener('click', e => { if (!e.target.closest('input,select,button,a')) cfg.aoClicar(r); });
    });
  }
  render();
  return { render, atualizar(linhas) { cfg.linhas = linhas; render(); } };
}

function baixarCSV(nome, linhas) {
  const cel = v => {
    if (typeof v === 'number') return String(r2(v)).replace('.', ',');
    let s = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;   // o Excel não executa como fórmula o que veio de um cadastro
    return /[;"\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const texto = '﻿' + linhas.map(l => l.map(cel).join(';')).join('\r\n');
  baixarArquivo(`${nome}-${hojeISO()}.csv`, new Blob([texto], { type: 'text/csv;charset=utf-8' }));
}
function baixarArquivo(nome, blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = nome;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

function imprimir(html, pagina = '') {
  const area = document.getElementById('impressao');
  let estilo = document.getElementById('estilo-pagina');
  if (!estilo) { estilo = document.createElement('style'); estilo.id = 'estilo-pagina'; document.head.appendChild(estilo); }
  estilo.textContent = pagina ? `@page { ${pagina} }` : '@page { margin: 8mm; }';
  area.innerHTML = html;
  document.body.classList.add('imprimindo');
  const limpar = () => { document.body.classList.remove('imprimindo'); area.innerHTML = ''; window.removeEventListener('afterprint', limpar); };
  window.addEventListener('afterprint', limpar);
  setTimeout(() => { window.print(); setTimeout(limpar, 800); }, 120);
}

function abas(lista, ativa, acao = 'aba') {
  return `<div class="abas">${lista.map(([k, t]) => `<button data-click="${acao}" data-k="${k}" class="${k === ativa ? 'ativo' : ''}">${esc(t)}</button>`).join('')}</div>`;
}
function etiqueta(texto, tipo = '') { return `<span class="etiqueta ${tipo ? 'et-' + tipo : ''}">${esc(texto)}</span>`; }
function kpi(rotulo, valor, detalhe = '', extra = '') {
  return `<div class="kpi"><div class="rot">${esc(rotulo)}</div><div class="val">${valor}</div><div class="det">${detalhe}</div>${extra}</div>`;
}
function fotoHTML(p, classe = 'foto-mini') {
  return p && p.foto ? `<img class="${classe}" src="/fotos/${esc(p.foto)}" alt="">` : `<div class="${classe}">${esc(iniciais(p ? p.nome : '?'))}</div>`;
}

/* ------------------------------------------------------------- gráficos */
function graficoBarras(itens, { altura = 190, fmt = moeda, cor = 'var(--pri)', linha = null } = {}) {
  if (!itens.length) return '<p class="vazio">Sem dados no período.</p>';
  const larg = 720, margemE = 56, margemB = 26, margemT = 10;
  const vals = itens.map(i => i.valor).concat(linha ? itens.map(i => i.linha || 0) : []);
  const max = Math.max(1, ...vals), min = Math.min(0, ...vals);
  const faixa = max - min;
  const h = altura - margemB - margemT;
  const y = v => margemT + h - ((v - min) / faixa) * h;
  const bw = (larg - margemE) / itens.length;
  const passo = Math.ceil(itens.length / 14);
  let svg = `<svg viewBox="0 0 ${larg} ${altura}" role="img">`;
  for (let k = 0; k <= 4; k++) {
    const v = min + faixa * k / 4;
    svg += `<line x1="${margemE}" x2="${larg}" y1="${y(v)}" y2="${y(v)}" style="stroke:var(--linha)"/><text x="${margemE - 6}" y="${y(v) + 3}" text-anchor="end">${esc(fmt(v).replace('R$', '').trim())}</text>`;
  }
  itens.forEach((it, i) => {
    const x = margemE + i * bw + bw * 0.15, w = bw * 0.7;
    const y0 = y(Math.max(0, it.valor)), y1 = y(Math.min(0, it.valor));
    svg += `<rect x="${x}" y="${y0}" width="${w}" height="${Math.max(0.5, y1 - y0)}" rx="2" style="fill:${it.valor < 0 ? 'var(--erro)' : cor}"><title>${esc(it.rotulo)}: ${esc(fmt(it.valor))}</title></rect>`;
    if (i % passo === 0) svg += `<text x="${x + w / 2}" y="${altura - 8}" text-anchor="middle">${esc(it.curto || it.rotulo)}</text>`;
  });
  if (linha) {
    const pts = itens.map((it, i) => `${margemE + i * bw + bw / 2},${y(it.linha || 0)}`).join(' ');
    svg += `<polyline points="${pts}" style="fill:none;stroke:${linha};stroke-width:2"/>`;
  }
  return `<div class="grafico">${svg}</svg></div>`;
}
function barrasH(itens, fmt = moeda) {
  if (!itens.length) return '<p class="vazio">Sem dados.</p>';
  const max = Math.max(...itens.map(i => i.valor), 1);
  return `<div class="barras-h">${itens.map(i => `<div class="linha"><span class="rot" title="${esc(i.rotulo)}">${esc(i.rotulo)}</span>
    <div class="trilho"><div style="width:${Math.max(1, i.valor / max * 100)}%"></div></div><span class="num">${esc(fmt(i.valor))}</span></div>`).join('')}</div>`;
}

/* --------------------------------------------------- código de barras 128 */
const C128 = ['212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213', '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132', '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211', '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313', '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331', '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111', '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214', '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111', '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141', '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141', '114131', '311141', '411131', '211412', '211214', '211232', '2331112'];
function code128SVG(texto) {
  const s = String(texto || '').replace(/[^\x20-\x7e]/g, '');
  const codigos = [104];
  for (const ch of s) codigos.push(ch.charCodeAt(0) - 32);
  let check = 104;
  for (let i = 1; i < codigos.length; i++) check += codigos[i] * i;
  codigos.push(check % 103, 106);
  const padrao = codigos.map(c => C128[c]).join('');
  let x = 10, rects = '';
  for (let i = 0; i < padrao.length; i++) {
    const w = +padrao[i];
    if (i % 2 === 0) rects += `<rect x="${x}" y="0" width="${w}" height="40"/>`;
    x += w;
  }
  return `<svg viewBox="0 0 ${x + 10} 40" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">${rects}</svg>`;
}

/* ----------------------------------------------------- imagens (fotos) */
function redimensionarImagem(arquivo, max = 900) {
  return new Promise((res, rej) => {
    const leitor = new FileReader();
    leitor.onerror = () => rej(new Error('Não foi possível ler a imagem.'));
    leitor.onload = () => {
      const img = new Image();
      img.onerror = () => rej(new Error('Formato de imagem não suportado.'));
      img.onload = () => {
        const esc_ = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * esc_); c.height = Math.round(img.height * esc_);
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(img, 0, 0, c.width, c.height);
        res(c.toDataURL('image/jpeg', 0.84));
      };
      img.src = leitor.result;
    };
    leitor.readAsDataURL(arquivo);
  });
}
