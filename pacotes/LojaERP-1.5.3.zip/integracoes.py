"""Loja ERP — integrações opcionais: nota fiscal (Focus NFe) e Pix por API (Mercado Pago e padrão do Banco Central).

Tudo aqui é opcional e fica desligado até a proprietária ligar e colocar as credenciais. Sem integração, o
sistema funciona como sempre. Só fala com os endereços HTTPS dos serviços configurados.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import base64
import datetime as dt
import hashlib
import ipaddress
import json
import os
import re
import secrets
import ssl
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

TEMPO_LIMITE = 25
TAMANHO_MAXIMO = 8 * 1024 * 1024


class ErroIntegracao(Exception):
    """Falha ao falar com um serviço externo. A mensagem é para a usuária."""


# ------------------------------------------------------------------ cliente HTTPS

def validar_url(url, permitir_local=False):
    """Só HTTPS para nome público (ou http://127.0.0.1 nos testes). Evita mandar credenciais para a rede interna."""
    p = urllib.parse.urlparse(str(url or ''))
    host = p.hostname or ''
    if permitir_local and p.scheme == 'http' and host in ('127.0.0.1', 'localhost'):
        return url
    if p.scheme != 'https' or not host:
        raise ErroIntegracao(f'Endereço inválido: {url}. Use o endereço https:// informado pelo serviço.')
    host = host.rstrip('.').lower()
    # Os serviços usam nome (api.focusnfe.com.br...). Número no lugar do nome, inclusive formas como 2130706433 ou
    # 0x7f.1 (que o sistema transforma em 127.0.0.1), e localhost ficam de fora.
    numerico = all(re.fullmatch(r'0x[0-9a-f]*|\d+', parte) for parte in host.split('.'))
    try:
        ipaddress.ip_address(host)
        literal = True
    except ValueError:
        literal = False
    if literal or numerico or ':' in host or host == 'localhost' or host.endswith('.localhost') or '.' not in host:
        raise ErroIntegracao('Use o endereço com nome informado pelo serviço (endereços numéricos e da rede interna não são aceitos).')
    return url


LOCAL_PERMITIDO = os.environ.get('LOJA_ERP_INTEGRACAO_LOCAL') == '1'   # só para os testes automáticos


class _SemRedirecionar(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def requisicao(metodo, url, cabecalhos=None, json_corpo=None, form_corpo=None, certificado=None, bruto=False):
    """Faz a chamada e devolve (status, corpo decodificado). Não segue redirecionamentos (credenciais não vazam).

    certificado: (pem_certificado, pem_chave) em texto, para os bancos que exigem mTLS."""
    validar_url(url, LOCAL_PERMITIDO)
    cab = {'Accept': 'application/json', 'User-Agent': 'LojaERP'}
    cab.update(cabecalhos or {})
    dados = None
    if json_corpo is not None:
        dados = json.dumps(json_corpo, ensure_ascii=False).encode('utf-8')
        cab['Content-Type'] = 'application/json'
    elif form_corpo is not None:
        dados = urllib.parse.urlencode(form_corpo).encode('ascii')
        cab['Content-Type'] = 'application/x-www-form-urlencoded'
    contexto = ssl.create_default_context()
    temporarios = []
    try:
        if certificado:
            # O ssl da biblioteca padrão só lê o certificado de arquivo: grava num temporário e apaga em seguida.
            for conteudo in certificado:
                fd, caminho = tempfile.mkstemp(suffix='.pem')
                with os.fdopen(fd, 'w', encoding='ascii') as f:
                    f.write(conteudo)
                temporarios.append(caminho)
            try:
                contexto.load_cert_chain(temporarios[0], temporarios[1])
            except (ssl.SSLError, ValueError) as e:
                raise ErroIntegracao(f'Certificado do banco inválido ({e}). Use o certificado e a chave em formato PEM.')
            finally:
                for caminho in temporarios:        # a chave fica só na memória do contexto TLS
                    try:
                        os.remove(caminho)
                    except OSError:
                        pass
        abridor = urllib.request.build_opener(urllib.request.HTTPSHandler(context=contexto), _SemRedirecionar)
        pedido = urllib.request.Request(url, data=dados, headers=cab, method=metodo)
        try:
            with abridor.open(pedido, timeout=TEMPO_LIMITE) as r:
                status, corpo = r.status, r.read(TAMANHO_MAXIMO + 1)
        except urllib.error.HTTPError as e:
            with e:                    # fecha a conexão da resposta de erro (sem isso, sobra socket aberto)
                status, corpo = e.code, e.read(TAMANHO_MAXIMO + 1)
        except urllib.error.URLError as e:
            raise ErroIntegracao(f'Sem conexão com o serviço ({getattr(e, "reason", e)}). Confira a internet e tente de novo.')
        except (TimeoutError, OSError) as e:
            raise ErroIntegracao(f'O serviço não respondeu a tempo ({e}). Tente de novo em instantes.')
    finally:
        for caminho in temporarios:
            try:
                os.remove(caminho)
            except OSError:
                pass
    if len(corpo) > TAMANHO_MAXIMO:
        raise ErroIntegracao('Resposta grande demais do serviço.')
    if bruto:
        return status, corpo
    try:
        return status, json.loads(corpo.decode('utf-8')) if corpo.strip() else {}
    except (ValueError, UnicodeDecodeError):
        return status, {'_texto': corpo[:500].decode('utf-8', 'replace')}


def _mensagem_erro(corpo):
    if not isinstance(corpo, dict):
        return str(corpo)[:300]
    partes = [str(corpo.get(k)) for k in ('mensagem', 'message', 'mensagem_sefaz', 'error_description', 'detail', 'title', 'error', '_texto')
              if corpo.get(k)]
    for e in corpo.get('erros') or corpo.get('cause') or corpo.get('violacoes') or []:
        if isinstance(e, dict):
            partes.append(str(e.get('mensagem') or e.get('description') or e.get('razao') or e))
    return ' — '.join(dict.fromkeys(partes))[:600] or 'erro sem descrição'


# ------------------------------------------------------------------ Focus NFe

FOCUS_URL = {'homologacao': 'https://homologacao.focusnfe.com.br', 'producao': 'https://api.focusnfe.com.br'}
# Formas de pagamento da NFC-e (tabela "tPag" do leiaute da nota). Pix: 17 = dinâmico (cobrança pela API, com
# confirmação), 20 = estático (QR Code fixo da loja).
TPAG = {'dinheiro': '01', 'credito': '03', 'debito': '04', 'crediario': '05', 'vale': '99', 'cashback': '19', 'pix': '20'}


class FocusNFe:
    def __init__(self, token, ambiente='homologacao', url_base=None):
        if not token:
            raise ErroIntegracao('Informe o token da Focus NFe.')
        self.url = (url_base or FOCUS_URL.get(ambiente) or FOCUS_URL['homologacao']).rstrip('/')
        self.auth = 'Basic ' + base64.b64encode(f'{token}:'.encode()).decode()

    def _chamar(self, metodo, caminho, corpo=None):
        return requisicao(metodo, self.url + caminho, {'Authorization': self.auth}, json_corpo=corpo)

    def testar(self):
        status, corpo = self._chamar('GET', '/v2/nfce/teste-conexao-loja-erp')
        if status in (401, 403):
            raise ErroIntegracao('Token da Focus NFe recusado. Confira o token do ambiente escolhido (homologação ou produção).')
        return {'ok': status in (200, 404), 'status': status}

    def emitir_nfce(self, ref, dados):
        status, corpo = self._chamar('POST', '/v2/nfce?ref=' + urllib.parse.quote(ref), dados)
        return self._resultado(status, corpo)

    def consultar_nfce(self, ref):
        status, corpo = self._chamar('GET', '/v2/nfce/' + urllib.parse.quote(ref))
        return self._resultado(status, corpo)

    def cancelar_nfce(self, ref, justificativa):
        status, corpo = self._chamar('DELETE', '/v2/nfce/' + urllib.parse.quote(ref), {'justificativa': justificativa})
        return self._resultado(status, corpo)

    def baixar(self, caminho):
        """Baixa XML ou DANFE pelo caminho que a Focus devolveu. Só caminho relativo, no mesmo endereço: o token
        não vai para outro servidor mesmo que a resposta (ou o arquivo de dados) traga um endereço diferente."""
        if not caminho:
            return b''
        caminho = str(caminho)
        if not caminho.startswith('/') or caminho.startswith('//') or '\\' in caminho or '@' in caminho:
            raise ErroIntegracao('Caminho de arquivo da nota inválido.')
        url = self.url + caminho
        if urllib.parse.urlparse(url).netloc != urllib.parse.urlparse(self.url).netloc:
            raise ErroIntegracao('Caminho de arquivo da nota inválido.')
        status, corpo = requisicao('GET', url, {'Authorization': self.auth, 'Accept': '*/*'}, bruto=True)
        if status != 200:
            raise ErroIntegracao(f'Não foi possível baixar o arquivo da nota (HTTP {status}).')
        return corpo

    def _resultado(self, status, corpo):
        if status in (401, 403):
            raise ErroIntegracao('Token da Focus NFe recusado. Confira o token e o ambiente.')
        if status == 429:
            raise ErroIntegracao('Muitos pedidos à Focus NFe em pouco tempo. Espere um minuto e tente de novo.')
        if not isinstance(corpo, dict):
            corpo = {}
        if status == 404 and not corpo.get('status'):
            return {'status': 'nao_encontrada', 'http': 404, 'mensagem': _mensagem_erro(corpo), 'status_sefaz': '', 'chave': '',
                    'numero': '', 'serie': '', 'xml': '', 'danfe': '', 'qrcode': '', 'consulta': '', 'xml_cancelamento': ''}
        situacao = corpo.get('status') or ''
        if status >= 400 and not situacao:
            situacao = 'erro'
        return {
            'status': situacao, 'http': status, 'mensagem': _mensagem_erro(corpo) if situacao.startswith('erro') or status >= 400 else (corpo.get('mensagem_sefaz') or ''),
            'status_sefaz': str(corpo.get('status_sefaz') or ''), 'chave': corpo.get('chave_nfe') or '',
            'numero': corpo.get('numero') or '', 'serie': corpo.get('serie') or '',
            'xml': corpo.get('caminho_xml_nota_fiscal') or '', 'danfe': corpo.get('caminho_danfe') or '',
            'qrcode': corpo.get('qrcode_url') or '', 'consulta': corpo.get('url_consulta_nf') or '',
            'xml_cancelamento': corpo.get('caminho_xml_cancelamento') or '',
        }


def so_digitos(texto):
    return re.sub(r'\D', '', str(texto or ''))


def montar_nfce(venda, produtos_por_id, categorias_por_id, cfg_nfe, loja, documento='', tipos_vale=None):
    """Monta o JSON da NFC-e (consumidor final, venda no balcão) a partir da venda do sistema."""
    cnpj = so_digitos(loja.get('cnpj'))
    if len(cnpj) != 14:
        raise ErroIntegracao('Preencha o CNPJ da loja em Configurações › Loja antes de emitir nota.')
    itens = []
    total_desc_itens = 0.0
    for n, it in enumerate(venda['itens'], 1):
        p = produtos_por_id.get(it.get('produto_id')) or {}
        cat = categorias_por_id.get(p.get('categoria_id')) or {}
        ncm = so_digitos(p.get('ncm') or cat.get('ncm') or cfg_nfe.get('ncm_padrao'))
        if len(ncm) != 8:
            raise ErroIntegracao(f'Falta o NCM (8 números) de "{it.get("nome")}". Informe no produto, na categoria ou o NCM padrão da nota.')
        qtd = it['qtd']
        bruto = round(it['preco_unit'] * qtd, 2)
        desconto = round(max(0.0, bruto - it['total']), 2)
        total_desc_itens += desconto
        descricao = ' '.join(x for x in (it.get('nome'), it.get('tamanho'), it.get('cor')) if x)[:120]
        item = {
            'numero_item': n, 'codigo_produto': (it.get('variacao_id') or it.get('servico_id') or it.get('produto_id') or str(n))[:60],
            'descricao': descricao, 'cfop': cfg_nfe.get('cfop') or '5102', 'codigo_ncm': ncm,
            'unidade_comercial': 'UN', 'quantidade_comercial': qtd, 'valor_unitario_comercial': round(it['preco_unit'], 2),
            'unidade_tributavel': 'UN', 'quantidade_tributavel': qtd, 'valor_unitario_tributavel': round(it['preco_unit'], 2),
            'valor_bruto': bruto, 'icms_origem': str(cfg_nfe.get('origem') or '0'),
            'icms_situacao_tributaria': str(cfg_nfe.get('csosn') or '102'),
            'pis_situacao_tributaria': str(cfg_nfe.get('pis_cst') or '49'),
            'cofins_situacao_tributaria': str(cfg_nfe.get('cofins_cst') or '49'),
        }
        if desconto > 0:
            item['valor_desconto'] = desconto
        cest = so_digitos(p.get('cest') or cat.get('cest'))
        if cest:
            item['cest'] = cest
        itens.append(item)
    # Desconto no total da compra: rateado entre os itens, como a nota exige.
    desc_carrinho = round(venda.get('desconto_carrinho') or 0, 2)
    if desc_carrinho > 0:
        base = sum(i['valor_bruto'] - i.get('valor_desconto', 0) for i in itens) or 1
        restante = desc_carrinho
        for k, i in enumerate(itens):
            parte = restante if k == len(itens) - 1 else round(desc_carrinho * (i['valor_bruto'] - i.get('valor_desconto', 0)) / base, 2)
            i['valor_desconto'] = round(i.get('valor_desconto', 0) + parte, 2)
            restante = round(restante - parte, 2)
    pagamentos = []
    for pg in venda['pagamentos']:
        valor = round(pg['valor'], 2)
        forma = '17' if pg['forma'] == 'pix' and pg.get('cobranca_id') else TPAG.get(pg['forma'], '99')
        if pg['forma'] == 'vale' and (tipos_vale or {}).get(pg.get('codigo')) == 'presente':
            forma = '12'                      # vale-presente; o vale-troca vai como outros (99)
        p = {'forma_pagamento': forma, 'valor_pagamento': valor}
        if forma in ('03', '04'):
            p['tipo_integracao'] = 2          # maquininha não integrada ao emissor (POS)
        if forma == '99':
            p['descricao_pagamento'] = {'vale': 'Vale-troca'}.get(pg['forma'], 'Outros')[:60]
        pagamentos.append(p)
    dados = {
        'cnpj_emitente': cnpj, 'data_emissao': dt.datetime.now().astimezone().isoformat(timespec='seconds'),
        'presenca_comprador': 4 if venda.get('distancia') else 1,
        'modalidade_frete': 9, 'local_destino': 1, 'items': itens, 'formas_pagamento': pagamentos,
    }
    if venda.get('troco'):
        dados['valor_troco'] = round(venda['troco'], 2)
    doc = so_digitos(documento)
    if len(doc) == 11:
        dados['cpf_destinatario'] = doc
    elif len(doc) == 14:
        dados['cnpj_destinatario'] = doc
    obs = str(cfg_nfe.get('informacoes_adicionais') or '').strip()
    if obs:
        dados['informacoes_adicionais_contribuinte'] = obs[:500]
    return dados


# ------------------------------------------------------------------ Pix por API

def novo_txid():
    """txid da API Pix: 26 a 35 letras e números."""
    return 'LOJAERP' + secrets.token_hex(12).upper()


class PixMercadoPago:
    URL = 'https://api.mercadopago.com'

    def __init__(self, token, url_base=None):
        if not token:
            raise ErroIntegracao('Informe o Access Token do Mercado Pago.')
        self.url = (url_base or self.URL).rstrip('/')
        self.cab = {'Authorization': 'Bearer ' + token}

    def testar(self):
        status, corpo = requisicao('GET', self.url + '/users/me', self.cab)
        if status != 200:
            raise ErroIntegracao(f'Mercado Pago recusou o token ({_mensagem_erro(corpo)}).')
        return {'ok': True, 'conta': corpo.get('nickname') or corpo.get('email') or ''}

    def criar(self, valor, descricao, email_pagador, minutos=30):
        minutos = max(30, minutos)
        expira = (dt.datetime.now().astimezone() + dt.timedelta(minutes=minutos)).isoformat(timespec='milliseconds')
        corpo = {'transaction_amount': round(valor, 2), 'description': descricao[:100], 'payment_method_id': 'pix',
                 'payer': {'email': email_pagador}, 'date_of_expiration': expira}
        cab = dict(self.cab, **{'X-Idempotency-Key': secrets.token_hex(16)})
        status, r = requisicao('POST', self.url + '/v1/payments', cab, json_corpo=corpo)
        if status not in (200, 201):
            raise ErroIntegracao(f'Mercado Pago não criou o Pix ({_mensagem_erro(r)}).')
        dados = (r.get('point_of_interaction') or {}).get('transaction_data') or {}
        return {'externo_id': str(r.get('id')), 'status': self._status(r.get('status')),
                'copia_cola': dados.get('qr_code') or '', 'qr_base64': dados.get('qr_code_base64') or ''}

    def consultar(self, externo_id):
        status, r = requisicao('GET', f'{self.url}/v1/payments/{urllib.parse.quote(str(externo_id))}', self.cab)
        if status != 200:
            raise ErroIntegracao(f'Não foi possível consultar o Pix no Mercado Pago ({_mensagem_erro(r)}).')
        return {'status': self._status(r.get('status')), 'valor_pago': r.get('transaction_amount'),
                'pago_em': (r.get('date_approved') or '')[:19], 'e2e': ''}

    def cancelar(self, externo_id):
        status, r = requisicao('PUT', f'{self.url}/v1/payments/{urllib.parse.quote(str(externo_id))}', self.cab,
                               json_corpo={'status': 'cancelled'})
        if status >= 400:
            raise ErroIntegracao(f'O Mercado Pago não cancelou o Pix ({_mensagem_erro(r)}).')

    @staticmethod
    def _status(s):
        return {'approved': 'paga', 'pending': 'aguardando', 'in_process': 'aguardando', 'authorized': 'aguardando',
                'cancelled': 'cancelada', 'rejected': 'cancelada', 'refunded': 'devolvida',
                'charged_back': 'devolvida', 'expired': 'cancelada'}.get(s or '', 'aguardando')


# Endereços conferidos na documentação oficial de cada banco (novembro de 2026; ver docs/integracoes/README.md).
# Para os outros bancos a loja preenche o que o banco informar na contratação da API Pix.
# modo_token: 'basic_form' (padrão OAuth2: Basic + formulário), 'corpo_form' (client_id e secret no formulário),
# 'basic_json' (Basic + JSON).
BANCOS_PIX = {
    'inter': {'nome': 'Banco Inter', 'url_api': 'https://cdpj.partners.bancointer.com.br/pix/v2',
              'url_token': 'https://cdpj.partners.bancointer.com.br/oauth/v2/token', 'modo_token': 'corpo_form'},
    'inter_sandbox': {'nome': 'Banco Inter (sandbox de testes)', 'url_api': 'https://cdpj-sandbox.partners.uatinter.co/pix/v2',
                      'url_token': 'https://cdpj-sandbox.partners.uatinter.co/oauth/v2/token', 'modo_token': 'corpo_form'},
    'efi': {'nome': 'Efí (Gerencianet)', 'url_api': 'https://pix.api.efipay.com.br/v2',
            'url_token': 'https://pix.api.efipay.com.br/oauth/token', 'modo_token': 'basic_json'},
    'efi_homologacao': {'nome': 'Efí (homologação)', 'url_api': 'https://pix-h.api.efipay.com.br/v2',
                        'url_token': 'https://pix-h.api.efipay.com.br/oauth/token', 'modo_token': 'basic_json'},
}


_TOKENS = {}     # (endereço do token, client id, resumo do segredo) -> (token, expira em)


class PixBacen:
    """API Pix no padrão do Banco Central (cobrança imediata), com OAuth2 e certificado do banco (mTLS)."""

    def __init__(self, cfg, segredos):
        self.base = (cfg.get('url_api') or '').rstrip('/')
        self.url_token = cfg.get('url_token') or ''
        if not self.base or not self.url_token:
            raise ErroIntegracao('Informe o endereço da API Pix e o endereço do token informados pelo banco.')
        self.client_id = cfg.get('client_id') or ''
        self.secret = segredos.get('client_secret') or ''
        self.chave = cfg.get('chave_pix') or ''
        if not (self.client_id and self.secret and self.chave):
            raise ErroIntegracao('Informe o Client ID, o Client Secret e a chave Pix da conta.')
        cert, chave = segredos.get('certificado') or '', segredos.get('chave_certificado') or ''
        self.cert = (cert, chave) if cert and chave else None
        self.extra = {k: v for k, v in (cfg.get('cabecalhos') or {}).items() if k and v}
        self.param = cfg.get('parametro_url') or ''       # ex.: gw-dev-app-key=... (Banco do Brasil)
        self.escopo = cfg.get('escopo') or 'cob.write cob.read pix.read'
        self.modo_token = cfg.get('modo_token') if cfg.get('modo_token') in ('basic_form', 'corpo_form', 'basic_json') else 'basic_form'

    def _url(self, caminho):
        url = self.base + caminho
        if self.param:
            url += ('&' if '?' in url else '?') + self.param
        return url

    def token(self):
        chave = (self.url_token, self.client_id, hashlib.sha256(self.secret.encode()).hexdigest())
        guardado = _TOKENS.get(chave)
        if guardado and time.time() < guardado[1] - 30:
            return guardado[0]
        basic = {'Authorization': 'Basic ' + base64.b64encode(f'{self.client_id}:{self.secret}'.encode()).decode()}
        if self.modo_token == 'basic_json':
            status, r = requisicao('POST', self.url_token, basic, json_corpo={'grant_type': 'client_credentials'},
                                   certificado=self.cert)
        elif self.modo_token == 'corpo_form':
            status, r = requisicao('POST', self.url_token, {}, certificado=self.cert, form_corpo={
                'client_id': self.client_id, 'client_secret': self.secret, 'grant_type': 'client_credentials',
                'scope': self.escopo})
        else:
            status, r = requisicao('POST', self.url_token, basic, certificado=self.cert,
                                   form_corpo={'grant_type': 'client_credentials', 'scope': self.escopo})
        if status != 200 or not r.get('access_token'):
            raise ErroIntegracao(f'O banco não liberou o acesso (HTTP {status}: {_mensagem_erro(r)}). Confira Client ID, Secret e certificado.')
        _TOKENS.clear()          # um banco por loja: não guarda tokens antigos
        _TOKENS[chave] = (r['access_token'], time.time() + int(r.get('expires_in') or 300))
        return r['access_token']

    def _chamar(self, metodo, caminho, corpo=None):
        cab = dict(self.extra, Authorization='Bearer ' + self.token())
        return requisicao(metodo, self._url(caminho), cab, json_corpo=corpo, certificado=self.cert)

    def testar(self):
        self.token()
        return {'ok': True}

    def criar(self, valor, descricao, minutos=30):
        txid = novo_txid()
        corpo = {'calendario': {'expiracao': minutos * 60}, 'valor': {'original': f'{valor:.2f}'}, 'chave': self.chave,
                 'solicitacaoPagador': descricao[:140]}
        status, r = self._chamar('PUT', '/cob/' + txid, corpo)
        if status not in (200, 201):
            raise ErroIntegracao(f'O banco não criou a cobrança Pix (HTTP {status}: {_mensagem_erro(r)}).')
        return {'externo_id': r.get('txid') or txid, 'status': self._status(r), 'copia_cola': r.get('pixCopiaECola') or '',
                'qr_base64': ''}

    def consultar(self, txid):
        status, r = self._chamar('GET', '/cob/' + urllib.parse.quote(txid))
        if status != 200:
            raise ErroIntegracao(f'Não foi possível consultar a cobrança Pix (HTTP {status}: {_mensagem_erro(r)}).')
        pix = (r.get('pix') or [{}])[0]
        return {'status': self._status(r), 'valor_pago': float(pix.get('valor') or 0) or None,
                'pago_em': (pix.get('horario') or '')[:19], 'e2e': pix.get('endToEndId') or ''}

    def cancelar(self, txid):
        status, r = self._chamar('PATCH', '/cob/' + urllib.parse.quote(txid), {'status': 'REMOVIDA_PELO_USUARIO_RECEBEDOR'})
        if status >= 400:
            raise ErroIntegracao(f'O banco não removeu a cobrança Pix (HTTP {status}: {_mensagem_erro(r)}).')

    @staticmethod
    def _status(r):
        return {'ATIVA': 'aguardando', 'CONCLUIDA': 'paga', 'REMOVIDA_PELO_USUARIO_RECEBEDOR': 'cancelada',
                'REMOVIDA_PELO_PSP': 'cancelada'}.get(r.get('status') or '', 'aguardando')
