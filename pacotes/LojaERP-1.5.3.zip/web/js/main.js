/* Loja ERP — menu, permissões, rotas, assistente de primeira configuração e login.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

const MENU = [
  ['Dia a dia', [['painel', 'Painel'], ['pdv', 'Vender (caixa)'], ['vendas', 'Vendas'], ['condicional', 'Condicional (malinha)', () => App.d.condicionais.filter(c => c.status === 'aberto').length],
    ['trocas', 'Trocas e vales'], ['caixa', 'Caixa'], ['pix', 'QR Code Pix']]],
  ['Produtos e estoque', [['produtos', 'Produtos'], ['estoque', 'Estoque'], ['entradas', 'Entradas (compras)'], ['movimentacoes', 'Movimentações'], ['inventario', 'Inventário'], ['etiquetas', 'Etiquetas']]],
  ['Pessoas', [['clientes', 'Clientes'], ['fornecedores', 'Fornecedores']]],
  ['Comercial', [['ofertas', 'Ofertas e cupons'], ['servicos', 'Serviços']]],
  ['Financeiro', [['contas', 'Contas a pagar/receber', () => App.d.financeiro.filter(f => f.status === 'pendente' && f.vencimento < hojeISO() && f.tipo === 'pagar').length],
    ['mei', 'Modo MEI'], ['fluxo', 'Previsão de caixa'], ['dre', 'DRE e indicadores'], ['balanco', 'Balanço patrimonial'], ['metas', 'Metas'], ['recorrentes', 'Despesas fixas'], ['ativos', 'Bens e depreciação'], ['conciliacao', 'Conciliação (banco e cartões)']]],
  ['Gestão', [['relatorios', 'Relatórios'], ['agenda', 'Agenda', () => tarefasPendentes().hoje.length], ['cadastros', 'Cadastros auxiliares'], ['celular', 'Usar no celular'], ['config', 'Configurações']]]
];
const ROTAS_COMPLETAS = ['movimentacoes', 'inventario', 'servicos', 'fluxo', 'dre', 'balanco', 'recorrentes', 'ativos', 'relatorios', 'cadastros'];
const ROTAS_VENDEDORA = ['celular', 'painel', 'pdv', 'vendas', 'condicional', 'trocas', 'caixa', 'pix', 'produtos', 'produto', 'estoque', 'etiquetas', 'clientes', 'agenda', 'config'];
const TITULOS = Object.fromEntries(MENU.flatMap(([, itens]) => itens.map(([k, t]) => [k, t])));
TITULOS.produto = 'Produto'; TITULOS.celular = 'Usar no celular'; TITULOS.entrada = 'Nova entrada de mercadorias';

function podeAcessar(rota) { return App.papel === 'dona' || App.papel === 'gerente' || ROTAS_VENDEDORA.includes(rota); }
function modoSimples() { return (App.cfg.aparencia || {}).modo !== 'completo'; }
function noMenu(rota) {
  if (!podeAcessar(rota)) return false;
  if (rota === 'celular') return !App.celular && App.papel !== 'vendedora';
  if (rota === 'mei') return ehMei();
  return !(modoSimples() && ROTAS_COMPLETAS.includes(rota));
}

function montarMenu() {
  const nav = document.getElementById('menu-itens');
  nav.innerHTML = MENU.map(([grupo, itens]) => {
    const vis = itens.filter(([k]) => noMenu(k));
    if (!vis.length) return '';
    return `<div class="grupo">${esc(grupo)}</div>` + vis.map(([k, t, cont]) => {
      const c = cont ? cont() : 0;
      return `<a href="#/${k}" data-rota="${k}">${esc(t)}${c ? `<span class="contador">${c}</span>` : ''}</a>`;
    }).join('');
  }).join('') + `${modoSimples() && App.papel !== 'vendedora' ? '<a href="#" id="menu-completo" class="suave">+ Mostrar menu completo</a>' : ''}<div class="grupo">Sessão</div><a href="#" id="menu-ajuda">Ajuda (F1)</a>${App.celular ? '' : '<a href="#" id="menu-encerrar">Encerrar sistema</a>'}`;
  if (App.celular) nav.insertAdjacentHTML('afterbegin', '<a href="#/celular" data-rota="celular" class="cel-menu-inicio">Início do celular</a>');
  const completo = document.getElementById('menu-completo');
  if (completo) completo.onclick = e => { e.preventDefault(); alternarModo(); };
  const bm = document.getElementById('btn-modo');
  bm.hidden = App.papel === 'vendedora';
  bm.textContent = modoSimples() ? 'Menu completo' : 'Menu simples';
  document.getElementById('menu-ajuda').onclick = e => { e.preventDefault(); abrirAjuda(); };
  if (!App.celular) document.getElementById('menu-encerrar').onclick = async e => {
    e.preventDefault();
    if (!await confirmar('Encerrar o sistema? Todos os dados já estão salvos. Para voltar, abra o atalho "Loja ERP" novamente.', 'Encerrar')) return;
    await api('encerrar', {}).catch(() => {});
    document.body.innerHTML = '<div style="display:grid;place-items:center;height:100vh;font-family:sans-serif"><div><h2>Sistema encerrado.</h2><p>Seus dados estão salvos. Pode fechar esta aba.</p></div></div>';
  };
  nav.querySelectorAll('a[data-rota]').forEach(a => a.classList.toggle('ativo', a.dataset.rota === App.rotaAtual));
  document.getElementById('menu-loja').textContent = App.cfg.loja ? App.cfg.loja.nome : 'Loja';
  const cx = App.d.caixa.find(c => c.status === 'aberto');
  const topo = document.getElementById('topo-caixa');
  topo.className = 'etiqueta ' + (cx ? 'et-ok' : 'et-alerta');
  topo.textContent = cx ? 'Caixa aberto' : 'Caixa fechado';
}

async function alternarModo() {
  const ap = { ...(App.cfg.aparencia || {}), modo: modoSimples() ? 'completo' : 'simples' };
  App.cfg.aparencia = ap;
  await api('config', { config: { aparencia: ap } });
  toast(ap.modo === 'completo' ? 'Menu completo: DRE, balanço, relatórios e cadastros avançados visíveis.' : 'Menu simples: só o essencial do dia a dia.');
  montarMenu();
}

/* Bloqueio automático: depois de um tempo sem uso, volta para a tela de senha. */
const Bloqueio = { ultimo: Date.now(), timer: null, aviso: Date.now() };
function iniciarBloqueio() {
  ['click', 'keydown', 'mousemove', 'touchstart'].forEach(ev => document.addEventListener(ev, () => { Bloqueio.ultimo = Date.now(); }, { passive: true }));
  clearInterval(Bloqueio.timer);
  Bloqueio.timer = setInterval(async () => {
    const minutos = n((App.cfg.seguranca || {}).bloqueio_min);
    if (!minutos || document.getElementById('app').hidden) return;
    // Quem está digitando num formulário está usando o sistema: avisa o servidor (ele também conta a inatividade).
    if (Date.now() - Bloqueio.ultimo < 60000 && Date.now() - Bloqueio.aviso > 120000) {
      Bloqueio.aviso = Date.now();
      api('estado').catch(() => {});
    }
    if (Date.now() - Bloqueio.ultimo > minutos * 60000) {
      await api('logout', {}).catch(() => {});
      await mostrarEntrada();
      toast('Sistema bloqueado por inatividade. Entre de novo para continuar.');
    }
  }, 30000);
}

function lerRota() {
  const h = location.hash.replace(/^#\/?/, '') || (App.celular ? 'celular' : 'painel');
  const [caminho, query] = h.split('?');
  const partes = caminho.split('/');
  return { nome: partes[0], id: partes[1], params: Object.fromEntries(new URLSearchParams(query || '')) };
}

async function navegar() {
  const r = lerRota();
  const pagina = App.paginas[r.nome];
  App.rotaAtual = r.nome;
  document.getElementById('menu').classList.remove('aberto');
  const el = document.getElementById('conteudo');
  document.getElementById('titulo').textContent = TITULOS[r.nome] || '';
  document.title = `${TITULOS[r.nome] || ''} — ${App.cfg.loja ? App.cfg.loja.nome : 'Loja ERP'}`;
  montarMenu();
  if (document.getElementById('painel-ajuda').classList.contains('aberto')) abrirAjuda();
  if (!pagina) { el.innerHTML = '<div class="card vazio">Página não encontrada.</div>'; return; }
  if (!podeAcessar(r.nome)) { el.innerHTML = '<div class="card caixa-aviso alerta">Seu perfil de acesso não permite abrir esta página. Fale com a proprietária.</div>'; return; }
  try { await pagina(el, r.id, r.params); }
  catch (e) { el.innerHTML = `<div class="card caixa-aviso erro">Erro ao abrir a página: ${esc(e.message)}</div>`; }
  window.scrollTo(0, 0);
}
function recarregarPagina() { return navegar(); }
function ir(hash) { if (location.hash === hash) navegar(); else location.hash = hash; }

/* ------------------------------------------------------------- login */
async function mostrarEntrada() {
  const est = await (await fetch('/api/estado')).json();
  App.credito = est.credito; App.versao = est.versao; App.papeis = est.papeis || {};
  App.celular = !!est.celular; document.body.classList.toggle('celular', App.celular);
  aplicarAparencia(aparenciaGuardada());
  document.getElementById('app').hidden = true;
  fecharAjuda();
  document.querySelectorAll('.modal-fundo').forEach(m => m.fechar && m.fechar());
  const tela = document.getElementById('tela-entrada');
  tela.hidden = false;
  if (App.celular && (est.recuperacao || est.precisa_setup)) {
    tela.innerHTML = `<div class="entrada-box"><img class="logo" src="img/icone.svg" alt=""><h1>Loja ERP</h1>
      <p>${est.recuperacao ? 'O sistema está em modo de recuperação.' : 'O sistema ainda não foi configurado.'} Faça isso no computador da loja e depois volte aqui.</p></div>`;
    return;
  }
  if (est.recuperacao) return telaRecuperacao(tela, est);
  if (est.precisa_setup) return assistenteInicial(tela, est);
  telaLogin(tela, est);
}

function telaLogin(tela, est) {
  tela.innerHTML = `<div class="entrada-box"><img class="logo" src="img/icone.svg" alt="">
    <h1>${esc(est.loja || 'Loja ERP')}</h1><p class="suave">Entre para continuar.</p>
    ${est.aviso_uso ? `<div class="caixa-aviso alerta">${esc(est.aviso_uso)}</div>` : ''}
    <form id="f-login"><label class="campo"><span>Usuário</span><input name="login" autocomplete="username" required></label>
    <label class="campo"><span>Senha</span><input name="senha" type="password" autocomplete="current-password" required></label>
    <button class="btn pri grande" style="width:100%">Entrar</button>
    <button type="button" class="btn-link" id="esqueci">Esqueci minha senha</button></form>
    <div class="credito">Loja ERP ${esc(est.versao)} — ${esc(est.credito)}</div></div>`;
  const f = tela.querySelector('#f-login');
  f.querySelector('[name=login]').focus();
  f.onsubmit = async e => {
    e.preventDefault();
    try { await api('login', { login: f.querySelector('[name=login]').value, senha: f.querySelector('[name=senha]').value }); await iniciarApp(); }
    catch (err) { toast(err.message, 'erro'); f.querySelector('[name=senha]').select(); }
  };
  tela.querySelector('#esqueci').onclick = () => {
    const cs = [{ n: 'login', r: 'Usuário', w: 12, obr: 1 }, { n: 'codigo', r: 'Código de recuperação', w: 12, obr: 1, ph: 'XXXX-XXXX-XXXX-XXXX-XXXX', aj: 'Mostrado uma única vez na configuração inicial. Só a proprietária tem.' }, { n: 'nova_senha', r: 'Nova senha', t: 'password', w: 12, obr: 1 }];
    modal({ titulo: 'Recuperar acesso', corpo: `<p>Vendedoras e gerentes: peça à proprietária — ela define uma senha nova em Configurações › Usuários e permissões › "Nova senha". Proprietária: use o código de recuperação.</p>${formHTML(cs)}`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Redefinir e entrar', classe: 'pri', acao: async m => { await api('recuperar', lerForm(m, cs)); toast('Senha redefinida.', 'ok'); await iniciarApp(); } }] });
  };
}

/* --------------------------------------------- assistente de primeira configuração */
function forcaSenha(s) {
  let p = 0;
  if (s.length >= 8) p++; if (s.length >= 12) p++;
  if (/[a-z]/.test(s) && /[A-Z]/.test(s)) p++; if (/\d/.test(s)) p++; if (/[^A-Za-z0-9]/.test(s)) p++;
  return [...[['Muito fraca', '#b3261e'], ['Fraca', '#d9534f'], ['Razoável', '#b7791f'], ['Boa', '#5a9e3a'], ['Forte', '#2e7d4f'], ['Muito forte', '#1f6e43']][p], p];
}

function assistenteInicial(tela, est) {
  const W = { passo: 0, loja: { nome: '', mensagem_recibo: 'Obrigada pela preferência! Trocas em até 30 dias, com etiqueta e este comprovante.' }, dona: {}, usuarios: [],
    fiscal: { regime: 'simples', aliquota: 4 }, pix: { tipo_chave: 'cpf' }, aparencia: { tema: 'claro' }, exemplo: true };
  const navegador = [
    ['Comunicação com o programa', typeof fetch === 'function'], ['Armazenamento local do navegador', (() => { try { localStorage.setItem('t', '1'); localStorage.removeItem('t'); return true; } catch (e) { return false; } })()],
    ['Formatação brasileira (moeda e datas)', typeof Intl !== 'undefined' && moeda(1).includes('R$')], ['Desenho de gráficos e QR Code', !!document.createElement('canvas').getContext],
    ['Impressão', typeof window.print === 'function'], ['Área de transferência (copiar Pix)', !!(navigator.clipboard)]
  ];
  const CAMPOS_EMPRESA = [{ n: 'nome', r: 'Nome da loja (fantasia)', w: 6, obr: 1 }, { n: 'razao_social', r: 'Razão social', w: 6 }, { n: 'cnpj', r: 'CNPJ', w: 4 },
    { n: 'telefone', r: 'Telefone', w: 4, aj: 'Aparece no recibo.' }, { n: 'whatsapp', r: 'WhatsApp da loja', w: 4, aj: 'Aparece no recibo.' }, { n: 'email', r: 'E-mail', t: 'email', w: 6 },
    { n: 'instagram', r: 'Instagram', w: 6, ph: '@sualoja' }, { n: 'endereco', r: 'Endereço', w: 8 }, { n: 'cidade', r: 'Cidade/UF', w: 4 },
    { n: 'mensagem_recibo', r: 'Mensagem no recibo', t: 'textarea', w: 12 }];
  const CAMPOS_DONA = [{ n: 'nome', r: 'Seu nome', w: 12, obr: 1 }, { n: 'login', r: 'Usuário para entrar', w: 12, obr: 1, ph: 'ex.: ana' },
    { n: 'senha', r: 'Senha', t: 'password', w: 6, obr: 1 }, { n: 'senha2', r: 'Repita a senha', t: 'password', w: 6, obr: 1 }];
  const titulos = ['Verificação do sistema', 'Dados da empresa', 'Proprietária e senha', 'Equipe e permissões', 'Impostos e Pix', 'Aparência e boas práticas'];

  function render() {
    const p = W.passo;
    let corpo = '';
    if (p === 0) {
      const criticos = (est.verificacoes || []).filter(v => v.critico && !v.ok);
      corpo = `<p class="suave">Conferindo se este computador tem tudo o que o sistema precisa.</p>
        <h4>Programa</h4>${(est.verificacoes || []).map(v => `<div class="verif"><b class="${v.ok ? 'positivo' : v.critico ? 'negativo' : ''}">${v.ok ? '✓' : v.critico ? '✕' : '!'}</b><div><b>${esc(v.item)}</b><br><small class="suave">${esc(v.detalhe)}</small></div></div>`).join('')}
        <h4>Navegador</h4>${navegador.map(([t, ok]) => `<div class="verif"><b class="${ok ? 'positivo' : ''}">${ok ? '✓' : '!'}</b><div>${esc(t)}</div></div>`).join('')}
        ${criticos.length ? '<div class="caixa-aviso erro" style="margin-top:12px">Há itens obrigatórios com problema. Corrija e reinicie o programa.</div>' : '<div class="caixa-aviso" style="margin-top:12px">Tudo certo para continuar.</div>'}
        <details class="guia" style="margin-top:12px"><summary>Já uso o Loja ERP em outro computador / tenho um backup</summary><div style="padding:0 12px 12px">
          <p class="suave">Restaure o backup em vez de criar uma loja nova. Você vai precisar da sua senha da época ou do código de recuperação.</p>
          <div id="w-backups"></div><label class="btn pequeno" style="margin-top:6px">Escolher arquivo de backup<input type="file" id="w-arq" accept=".lojabkp" hidden></label></div></details>`;
      W.bloqueado = criticos.length > 0;
    } else if (p === 1) corpo = `<p class="suave">Estes dados aparecem no recibo, nas etiquetas e nos documentos.</p>${formHTML(CAMPOS_EMPRESA, W.loja)}`;
    else if (p === 2) corpo = `<p class="suave">Você será a <b>proprietária</b>, com acesso total.</p>${formHTML(CAMPOS_DONA, W.dona)}
        <div class="forca"><div id="forca-barra" style="width:0"></div></div><small id="forca-txt" class="suave"></small>
        <div class="caixa-aviso" style="margin-top:12px"><b>Boas práticas de senha:</b> a sua senha (proprietária) precisa de pelo menos 10 caracteres — a da equipe, 8 — misturando letras maiúsculas, minúsculas, números e símbolos;
        não use datas de nascimento nem o nome da loja; não compartilhe sua senha — crie um usuário para cada pessoa.</div>`;
    else if (p === 3) corpo = `<p class="suave">Opcional. Crie um acesso para cada pessoa que usa o sistema. Você pode fazer isso depois em Configurações.</p>
        <div class="card compacto" style="background:var(--cab)"><b>Perfis de acesso</b>${Object.values(App.papeis).map(t => `<div class="suave">• ${esc(t)}</div>`).join('')}</div>
        <div id="lista-equipe">${W.usuarios.map((u, i) => `<div class="grade-form" style="margin-bottom:8px;align-items:end"><label class="campo w3"><span>Nome</span><input data-u="${i}" data-c="nome" value="${esc(u.nome || '')}"></label>
          <label class="campo w2"><span>Usuário</span><input data-u="${i}" data-c="login" value="${esc(u.login || '')}"></label><label class="campo w2"><span>Senha</span><input type="password" data-u="${i}" data-c="senha" value="${esc(u.senha || '')}"></label>
          <label class="campo w3"><span>Perfil</span><select data-u="${i}" data-c="papel">${Object.entries(App.papeis).filter(([k]) => k !== 'dona').map(([k, t]) => `<option value="${k}" ${u.papel === k ? 'selected' : ''}>${esc(t.split(' — ')[0])}</option>`).join('')}</select></label>
          <div class="w2"><button class="btn pequeno perigo" data-rem="${i}">Remover</button></div></div>`).join('')}</div>
        <button class="btn" data-click="addUser">+ Adicionar pessoa</button>`;
    else if (p === 4) corpo = `${formHTML([{ n: 'regime', r: 'Regime tributário', t: 'select', w: 6, vazio: false, op: [['mei', 'MEI (DAS fixo mensal)'], ['simples', 'Simples Nacional (% sobre vendas)'], ['outro', 'Outro / não sei ainda']], dataChange: 'regime' },
        ...(W.fiscal.regime !== 'mei' ? [{ n: 'aliquota', r: 'Alíquota efetiva sobre vendas (%)', t: 'pct', w: 6, aj: 'Pergunte ao contador. Comércio no início do Simples: cerca de 4%.' }] : [])], W.fiscal)}
        ${W.fiscal.regime === 'mei' ? '<div class="caixa-aviso" style="margin-top:8px">No MEI, informe o valor do DAS em Financeiro › Despesas fixas depois de entrar.</div>' : ''}
        <h4 style="margin-top:16px">Chave Pix (para gerar QR Code no caixa)</h4>
        ${formHTML([{ n: 'tipo_chave', r: 'Tipo de chave', t: 'select', w: 4, vazio: false, op: [['cpf', 'CPF'], ['cnpj', 'CNPJ'], ['telefone', 'Celular'], ['email', 'E-mail'], ['aleatoria', 'Chave aleatória']] },
          { n: 'chave', r: 'Chave Pix', w: 8 }, { n: 'nome', r: 'Nome do recebedor', w: 8, aj: 'Como aparece para quem paga.' }, { n: 'cidade', r: 'Cidade', w: 4 }], W.pix)}`;
    else if (p === 5) corpo = `<h4>Escolha o visual</h4>${seletorTema(W.aparencia.tema)}<p class="suave">Fontes, tamanho de letra e cores podem ser ajustados depois em Configurações › Aparência.</p>
        <label class="check" style="margin:14px 0"><input type="checkbox" id="exemplo" ${W.exemplo ? 'checked' : ''}><span>Carregar dados de exemplo para conhecer o sistema${iconeAjuda({ n: 'exemplo' })}</span></label>
        <div class="caixa-aviso"><b>Boas práticas para começar bem</b><ul style="margin:6px 0 0;padding-left:18px">
          <li>Deixe a pasta do sistema dentro do Google Drive, Dropbox ou OneDrive: os dados ficam com cópia na nuvem.</li>
          <li>Um backup automático é feito por dia; copie um para pendrive todo mês.</li><li>Use o sistema em um computador por vez (a mesma pasta aberta em dois PCs pode gerar conflito).</li>
          <li>Guarde o código de recuperação (próxima tela) em papel, longe do computador.</li><li>Abra e feche o caixa todos os dias; lance todas as compras como entradas.</li>
          <li>Peça sempre o nome/telefone da cliente: aniversários, cashback e campanhas dependem disso.</li></ul></div>`;
    tela.innerHTML = `<div class="entrada-box largo" style="max-width:760px"><div style="display:flex;gap:12px;align-items:center"><img class="logo" src="img/icone.svg" alt=""><div><h1 style="margin:0">Configuração inicial</h1>
      <small class="suave">Passo ${p + 1} de ${titulos.length} — ${titulos[p]}</small></div></div>
      <div class="passos">${titulos.map((_, i) => `<span class="${i <= p ? 'feito' : ''}"></span>`).join('')}</div><div id="w-corpo">${corpo}</div>
      <div class="linha-acoes" style="margin-top:18px"><button class="btn" data-click="voltar" ${p === 0 ? 'disabled' : ''}>Voltar</button><span class="espaco"></span>
      <button class="btn pri grande" data-click="avancar" ${W.bloqueado && p === 0 ? 'disabled' : ''}>${p === titulos.length - 1 ? 'Criar e entrar' : 'Continuar'}</button></div>
      <div class="credito">${esc(App.credito)}</div></div>`;
    const corpoEl = tela.querySelector('#w-corpo');
    if (p === 0) {
      listaBackupsPublicos(corpoEl.querySelector('#w-backups'), est.backups || [], true);
      corpoEl.querySelector('#w-arq').onchange = async e => {
        try { const nome = await enviarBackup(e.target.files[0]); modalRestaurar({ nome, criado_em: '' }, { pedirUsuario: true }); }
        catch (err) { toast(err.message, 'erro'); }
      };
    }
    if (p === 2) {
      const s = corpoEl.querySelector('[name=senha]');
      const atual = () => {
        const [t, cor, nivel] = forcaSenha(s.value), b = corpoEl.querySelector('#forca-barra');
        b.style.width = s.value ? ((nivel + 1) / 6 * 100) + '%' : '0'; b.style.background = cor;
        corpoEl.querySelector('#forca-txt').textContent = s.value ? 'Força da senha: ' + t : '';
      };
      s.addEventListener('input', atual); atual();
    }
    if (p === 3) {
      corpoEl.querySelectorAll('[data-u]').forEach(i => i.addEventListener('input', () => { W.usuarios[+i.dataset.u][i.dataset.c] = i.value; }));
      corpoEl.querySelectorAll('[data-rem]').forEach(b => b.onclick = () => { W.usuarios.splice(+b.dataset.rem, 1); render(); });
    }
    ligar(tela, {
      voltar: () => { coletar(false); W.passo--; render(); },
      avancar: async () => { coletar(true); if (W.passo < titulos.length - 1) { W.passo++; render(); } else await concluir(); },
      addUser: () => { W.usuarios.push({ papel: 'vendedora' }); render(); },
      regime: s => { W.fiscal.regime = s.value; render(); },
      tema: b => { W.aparencia.tema = b.dataset.k; aplicarAparencia(W.aparencia); render(); }
    });
  }
  function coletar(validar) {
    const c = tela.querySelector('#w-corpo');
    const ler = campos => validar ? lerForm(c, campos) : (() => { try { return lerForm(c, campos.map(x => ({ ...x, obr: 0 }))); } catch (e) { return {}; } })();
    if (W.passo === 1) Object.assign(W.loja, ler(CAMPOS_EMPRESA));
    if (W.passo === 2) {
      Object.assign(W.dona, ler(CAMPOS_DONA));
      if (validar) {
        W.dona.login = W.dona.login.toLowerCase();
        if (!/^[a-z0-9._-]{3,30}$/.test(W.dona.login)) throw new Error('Usuário: de 3 a 30 letras minúsculas, números, ponto ou traço, sem espaços.');
        if (W.dona.senha.length < 10) throw new Error('A senha da proprietária deve ter pelo menos 10 caracteres.');
        if (W.dona.senha !== W.dona.senha2) throw new Error('As senhas não conferem.');
      }
    }
    if (W.passo === 3 && validar) {
      W.usuarios = W.usuarios.filter(u => u.login || u.nome || u.senha);
      for (const u of W.usuarios) {
        u.login = String(u.login || '').toLowerCase().trim();
        if (!/^[a-z0-9._-]{3,30}$/.test(u.login)) throw new Error(`Usuário inválido para ${u.nome || 'pessoa da equipe'}.`);
        const min = ['dona', 'gerente'].includes(u.papel) ? 10 : 8;
        if (String(u.senha || '').length < min) throw new Error(`A senha de ${u.login} deve ter pelo menos ${min} caracteres.`);
        if (u.login === W.dona.login) throw new Error('Cada pessoa precisa de um usuário diferente.');
      }
    }
    if (W.passo === 4) {
      Object.assign(W.fiscal, ler([{ n: 'regime' }, { n: 'aliquota', t: 'pct' }]));
      Object.assign(W.pix, ler([{ n: 'tipo_chave' }, { n: 'chave' }, { n: 'nome' }, { n: 'cidade' }]));
    }
    if (W.passo === 5) W.exemplo = tela.querySelector('#exemplo').checked;
  }
  async function concluir() {
    const bt = tela.querySelector('[data-click=avancar]');
    bt.disabled = true; bt.textContent = 'Preparando a loja...';
    try {
      const r = await api('setup', { loja: W.loja, nome: W.dona.nome, login: W.dona.login, senha: W.dona.senha, regime: W.fiscal.regime, aliquota: W.fiscal.aliquota,
        pix: { ...W.pix, nome: W.pix.nome || W.loja.nome, cidade: W.pix.cidade || W.loja.cidade || '' }, usuarios: W.usuarios, aparencia: W.aparencia, exemplo: W.exemplo });
      tela.innerHTML = `<div class="entrada-box largo"><h1>Guarde seu código de recuperação</h1>
        <p>Os dados das clientes ficam protegidos por criptografia ligada à sua senha. <b>Se esquecer a senha, só este código permite recuperar o acesso.</b>
        Anote em papel e guarde em local seguro (não deixe na mesma pasta do sistema).</p><div class="codigo-rec">${esc(r.recuperacao)}</div>
        <p class="suave">Seu período grátis de 6 meses começa hoje. A situação da licença e os planos ficam em Configurações › Licença e plano.</p>
        <label class="check" style="margin:16px 0"><input type="checkbox" id="anotei"> <span>Anotei o código em local seguro.</span></label>
        <button class="btn pri grande" id="continuar" style="width:100%" disabled>Começar a usar</button></div>`;
      tela.querySelector('#anotei').onchange = e => { tela.querySelector('#continuar').disabled = !e.target.checked; };
      tela.querySelector('#continuar').onclick = iniciarApp;
    } catch (err) { toast(err.message, 'erro'); bt.disabled = false; bt.textContent = 'Criar e entrar'; }
  }
  render();
}

async function iniciarApp() {
  await carregar();
  const est = await (await fetch('/api/estado')).json();
  App.usuario = est.usuario; App.credito = est.credito; App.versao = est.versao;
  App.celular = !!est.celular; document.body.classList.toggle('celular', App.celular);
  App.carrinho = App.carrinho || novoCarrinho();
  document.getElementById('tela-entrada').hidden = true;
  document.getElementById('app').hidden = false;
  const u = App.usuarios.find(x => x.login === App.usuario);
  document.getElementById('topo-usuario').textContent = u ? `${u.nome} · ${(App.papeis[u.papel] || '').split(' — ')[0]}` : App.usuario;
  document.getElementById('rodape').innerHTML = `Loja ERP ${esc(App.versao)} — ${esc(App.credito)}`;
  Bloqueio.ultimo = Date.now();
  navegar();
  atualizarSaude();
  if (!App.celular) mostrarNovidades();
}
setInterval(() => { if (!document.getElementById('app').hidden) atualizarSaude(); }, 10 * 60000);
iniciarBloqueio();

window.addEventListener('hashchange', () => { if (!document.getElementById('app').hidden) navegar(); });
document.getElementById('btn-menu').onclick = () => document.getElementById('menu').classList.toggle('aberto');
document.getElementById('btn-ajuda').onclick = () => abrirAjuda();
document.getElementById('btn-modo').onclick = () => alternarModo();
document.getElementById('topo-saude').onclick = () => ir('#/config?aba=dados');
document.getElementById('aba-ajuda').onclick = () => abrirAjuda();
document.getElementById('btn-bloquear').onclick = async () => { await api('logout', {}).catch(() => {}); App.carrinho = novoCarrinho(); mostrarEntrada(); };

(async () => {
  aplicarAparencia(aparenciaGuardada());
  try {
    const est = await (await fetch('/api/estado')).json();
    if (est.logado) await iniciarApp(); else await mostrarEntrada();
  } catch (e) {
    document.body.innerHTML = '<p style="padding:30px;font-family:sans-serif">Não foi possível conectar ao programa. Abra pelo atalho "Loja ERP".</p>';
  }
})();
