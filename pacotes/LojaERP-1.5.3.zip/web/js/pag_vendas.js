/* Loja ERP — painel, caixa (PDV), vendas, condicional, trocas e controle de caixa.
   Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com */
'use strict';

function novoCarrinho() {
  return { itens: [], cliente_id: null, cupom: '', avista: false, desc_manual: 0, desc_manual_tipo: 'valor', condicional_id: null, obs: '' };
}

/* ---------------------------------------------------- busca de produtos */
function buscaProdutos(termo, limite = 20, inativos = false) {
  const t = semAcento(termo).trim();
  if (!t) return [];
  const termos = t.split(/\s+/);
  const exato = [], parcial = [];
  for (const p of App.d.produtos) {
    if (!inativos && p.ativo === false) continue;
    if (semAcento(p.sku) === t || (p.variacoes || []).some(v => semAcento(v.codigo_barras) === t)) { exato.push(p); continue; }
    const txt = semAcento([p.nome, p.sku, p.referencia, p.tags, (App.idx.cat[p.categoria_id] || {}).nome, (App.idx.marca[p.marca_id] || {}).nome,
      ...(p.variacoes || []).map(v => `${v.cor} ${v.codigo_barras}`)].join(' '));
    if (termos.every(x => txt.includes(x))) parcial.push(p);
  }
  return exato.concat(parcial).slice(0, limite);
}

function seletorProduto(cont, opts) {
  cont.innerHTML = `<input type="search" class="${opts.grande ? 'pdv-busca' : ''}" placeholder="${esc(opts.ph || 'Buscar por nome, SKU ou código de barras (Enter)')}" autocomplete="off"><div class="sel-res"></div>`;
  const inp = cont.querySelector('input'), res = cont.querySelector('.sel-res');
  if (App.celular) Leitor.botao(inp, () => inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' })), 'Ler código da peça');
  const permitirZerado = opts.permitirZerado || (App.cfg.estoque || {}).permitir_negativo;
  const escolher = (p, v) => { opts.aoEscolher(p, v); inp.value = ''; render(); inp.focus(); };
  function render() {
    const t = inp.value.trim();
    if (!t) { res.innerHTML = opts.vazio || ''; return; }
    const lista = buscaProdutos(t, opts.limite || 15, opts.inativos);
    res.innerHTML = lista.length ? lista.map(p => `<div class="res-prod">${fotoHTML(p, 'foto')}<div class="info">
      <div class="nome">${esc(p.nome)} <small>${esc(p.sku)}</small>${p.ativo === false ? ' ' + etiqueta('inativo') : ''}</div>
      <div><b>${moeda(p.preco)}</b> <small>${esc((App.idx.cat[p.categoria_id] || {}).nome || '')} · estoque ${estoqueProduto(p)}</small></div>
      ${opts.modo === 'produto' ? `<button class="var-chip" data-prod="${p.id}">Selecionar produto</button>` :
        p.variacoes.map(v => `<button class="var-chip ${v.estoque <= 0 ? 'zerado' : ''}" data-v="${v.id}" ${!permitirZerado && v.estoque <= 0 ? 'disabled' : ''}>${esc(v.tamanho)} / ${esc(v.cor)} <small>(${v.estoque})</small></button>`).join('')}
      </div></div>`).join('') : '<p class="vazio">Nenhum produto encontrado.</p>';
    res.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { const x = App.idx.var[b.dataset.v]; escolher(x.p, x.v); });
    res.querySelectorAll('[data-prod]').forEach(b => b.onclick = () => escolher(App.idx.prod[b.dataset.prod]));
  }
  inp.addEventListener('input', render);
  inp.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const t = inp.value.trim();
    if (!t) return;
    const cod = App.idx.cod[t.toUpperCase()];
    if (cod) { opts.modo === 'produto' ? escolher(cod.p) : escolher(cod.p, cod.v); return; }
    const lista = buscaProdutos(t, 2, opts.inativos);
    if (lista.length === 1) {
      if (opts.modo === 'produto') return escolher(lista[0]);
      const vs = lista[0].variacoes.filter(v => v.estoque > 0 || permitirZerado);
      if (vs.length === 1) return escolher(lista[0], vs[0]);
    }
    if (!lista.length) toast('Produto não encontrado.', 'erro');
  });
  render();
  return { foco: () => inp.focus() };
}

function escolherCliente(aoEscolher) {
  const m = modal({ titulo: 'Selecionar cliente', largura: 'largo', corpo: `<div class="linha-acoes"><span class="espaco"></span><button class="btn pri" data-click="nova">Nova cliente</button></div><div id="lista-cli"></div>`,
    acoes: { nova: () => formCliente(null, c => { m.fechar(); aoEscolher(c); }) } });
  tabela(m.querySelector('#lista-cli'), {
    placeholder: 'Nome, telefone, CPF ou Instagram', porPagina: 12,
    linhas: App.d.clientes.filter(c => c.ativo !== false && !c.anonimizada),
    textoBusca: c => `${c.telefone} ${c.cpf} ${c.instagram} ${c.apelido}`,
    colunas: [{ t: 'Nome', v: c => c.nome }, { t: 'Telefone', v: c => fone(c.telefone) }, { t: 'Segmento', v: c => segmentoCliente(c)[0], h: c => etiqueta(...segmentoCliente(c)) },
      { t: 'Cashback', v: c => cashbackDisponivel(c), h: c => moeda(cashbackDisponivel(c)), cls: 'num' }],
    aoClicar: c => { m.fechar(); aoEscolher(c); }
  });
  setTimeout(() => m.querySelector('.tab-busca').focus(), 50);
}

/* -------------------------------------------------------------------- PDV */
App.paginas.pdv = async el => {
  el.innerHTML = `<div class="pdv"><div><div class="card"><div id="pdv-sel"></div>
      ${(App.d.servicos || []).some(s => s.ativo !== false) ? `<div style="margin-top:10px"><small class="suave">Serviços:</small> <div class="chips" style="display:inline-flex">${App.d.servicos.filter(s => s.ativo !== false).map(s => `<button class="chip" data-click="servico" data-id="${esc(s.id)}">${esc(s.nome)} · ${moeda(s.preco)}</button>`).join('')}</div></div>` : ''}
    </div></div><div><div class="card" id="pdv-car"></div></div></div>`;
  const sel = seletorProduto(el.querySelector('#pdv-sel'), {
    grande: true, ph: 'Leia o código de barras ou digite nome / SKU',
    vazio: '<p class="suave" style="margin-top:12px">Dica: use um leitor de código de barras USB — ele funciona como teclado. <b>F2</b> finaliza a venda.</p>',
    aoEscolher: (p, v) => { adicionarAoCarrinho(p, v); renderCarrinho(); }
  });
  ligar(el, { servico: b => { const s = App.idx.serv[b.dataset.id]; App.carrinho.itens.push({ servico_id: s.id, qtd: 1, preco_unit: n(s.preco), desc_manual: 0 }); renderCarrinho(); } });
  renderCarrinho();
  sel.foco();
  if (App.buscaPendente) {
    const inp = el.querySelector('#pdv-sel input');
    inp.value = App.buscaPendente; App.buscaPendente = null;
    inp.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter' }));
  }
};

function adicionarAoCarrinho(p, v, qtd = 1) {
  const car = App.carrinho;
  const ex = car.itens.find(i => i.variacao_id === v.id);
  const atual = ex ? ex.qtd : 0;
  if (atual + qtd > v.estoque && !(App.cfg.estoque || {}).permitir_negativo) { toast(`Estoque insuficiente: ${p.nome} ${v.tamanho}/${v.cor} (${v.estoque}).`, 'erro'); return false; }
  if (ex) ex.qtd += qtd; else car.itens.push({ produto_id: p.id, variacao_id: v.id, qtd, preco_unit: n(p.preco), desc_manual: 0 });
  return true;
}

function renderCarrinho() {
  const box = document.getElementById('pdv-car');
  if (!box) return;
  const car = App.carrinho;
  const calc = calcularCarrinho(car);
  const cli = App.idx.cli[car.cliente_id];
  const st = cli ? App.idx.cliStats[cli.id] : null;
  const cred = cli ? soma(crediarioAberto(cli.id), f => f.valor) : 0;
  box.innerHTML = `
    <div class="cliente-box">${cli ? `<div style="display:flex;justify-content:space-between;gap:8px"><div><b>${esc(cli.nome)}</b> <small>${esc(fone(cli.telefone))}</small><div class="chips" style="margin-top:4px">
        ${etiqueta(...segmentoCliente(cli))}${aniversarianteMes(cli) ? etiqueta('Aniversariante do mês', 'ok') : ''}${!st ? etiqueta('Primeira compra', 'info') : ''}
        ${cashbackDisponivel(cli) ? etiqueta('Cashback ' + moeda(cashbackDisponivel(cli)), 'pri') : ''}${cred ? etiqueta('Crediário em aberto ' + moeda(cred), 'alerta') : ''}
        ${cli.tam_superior || cli.tam_inferior ? `<small>Tam.: ${esc([cli.tam_superior, cli.tam_inferior, cli.tam_calcado].filter(Boolean).join(' / '))}</small>` : ''}</div></div>
        <div><button class="btn pequeno" data-click="cliente">Trocar</button> <button class="btn pequeno" data-click="semCliente">Remover</button></div></div>`
      : `<div style="display:flex;justify-content:space-between;align-items:center"><span class="suave">Venda sem cliente identificada</span><button class="btn pequeno pri" data-click="cliente">Identificar cliente</button></div>`}</div>
    ${car.condicional_id ? `<div class="caixa-aviso">Venda originada do condicional. Ao finalizar, ele fica vinculado a esta venda.</div>` : ''}
    <div>${calc.linhas.length ? calc.linhas.map((l, i) => {
      const x = l.servico_id ? null : App.idx.var[l.variacao_id];
      const nome = l.servico_id ? (App.idx.serv[l.servico_id] || {}).nome + ' (serviço)' : `${x.p.nome} — ${x.v.tamanho}/${x.v.cor}`;
      return `<div class="carrinho-item"><div><div>${esc(nome)}</div><small class="suave">${moeda(l.preco_unit)} cada${l.desc_manual ? ` · desconto manual ${moeda(l.desc_manual)}` : ''}</small>
        ${l.promocoes.length ? `<div class="promo">${esc(l.promocoes.join(' + '))}</div>` : ''}</div>
        <div class="qtd-ctrl"><button data-click="menos" data-i="${i}">−</button><span style="min-width:22px;text-align:center">${l.qtd}</span><button data-click="mais" data-i="${i}">+</button></div>
        <div class="num">${l.desconto ? `<small class="suave"><s>${moeda(l.bruto)}</s></small><br>` : ''}<b>${moeda(l.total)}</b><br>
        <button class="btn-link" data-click="descItem" data-i="${i}">desconto</button> · <button class="btn-link" data-click="remover" data-i="${i}">remover</button></div></div>`;
    }).join('') : '<p class="vazio">Carrinho vazio. Busque um produto ao lado.</p>'}</div>
    <div class="grade-form" style="margin-top:12px">
      <label class="campo w5"><span>Cupom</span><input data-change="cupom" value="${esc(car.cupom)}" placeholder="CÓDIGO"></label>
      <label class="campo w4"><span>Desconto manual</span><input type="number" step="0.01" min="0" data-change="descManual" value="${car.desc_manual || ''}"></label>
      <label class="campo w3"><span>Tipo</span><select data-change="descTipo"><option value="valor">R$</option><option value="pct" ${car.desc_manual_tipo === 'pct' ? 'selected' : ''}>%</option></select></label>
      ${calc.temPromoPagamento ? `<label class="check w12"><input type="checkbox" data-change="avista" ${car.avista ? 'checked' : ''}><span>${esc(calc.pagamentoPromo.nome)} (−${pct(calc.pagamentoPromo.percentual, 0)})</span></label>` : ''}
    </div>
    ${calc.erroCupom && car.cupom ? `<div class="caixa-aviso erro" style="margin-top:8px">${esc(calc.erroCupom)}</div>` : ''}
    <div class="totais" style="margin-top:12px">
      <div><span>Subtotal (${soma(calc.linhas, l => l.qtd)} itens)</span><span>${moeda(calc.subtotal)}</span></div>
      ${calc.descItens ? `<div class="positivo"><span>Descontos nos itens</span><span>−${moeda(calc.descItens)}</span></div>` : ''}
      ${calc.descPromoCarrinho ? `<div class="positivo"><span>Promoções no total</span><span>−${moeda(calc.descPromoCarrinho)}</span></div>` : ''}
      ${calc.descManual ? `<div class="positivo"><span>Desconto manual</span><span>−${moeda(calc.descManual)}</span></div>` : ''}
      ${calc.aplicadas.length ? `<small class="positivo">${esc(calc.aplicadas.join(' · '))}</small>` : ''}
      <div class="total"><span>Total</span><span>${moeda(calc.total)}</span></div>
    </div>
    <div class="linha-acoes" style="margin-top:14px;margin-bottom:0">
      <button class="btn" data-click="limpar">Limpar</button>
      <button class="btn" data-click="condicional" title="Cliente leva as peças para provar em casa">Condicional</button>
      <button class="btn" data-click="valePresente" title="Vender um vale-presente com valor e validade">Vale-presente</button>
      <span class="espaco"></span><button class="btn pri grande" data-click="finalizar" ${calc.linhas.length ? '' : 'disabled'}>Finalizar (F2)</button>
    </div>`;
  ligar(box, {
    cliente: () => escolherCliente(c => { car.cliente_id = c.id; renderCarrinho(); }),
    semCliente: () => { car.cliente_id = null; renderCarrinho(); },
    valePresente: () => venderValePresente(car.cliente_id),
    mais: b => {
      const it = car.itens[+b.dataset.i];
      if (it.servico_id) it.qtd++; else { const x = App.idx.var[it.variacao_id]; adicionarAoCarrinho(x.p, x.v); }
      renderCarrinho();
    },
    menos: b => { const it = car.itens[+b.dataset.i]; it.qtd--; if (it.qtd <= 0) car.itens.splice(+b.dataset.i, 1); renderCarrinho(); },
    remover: b => { car.itens.splice(+b.dataset.i, 1); renderCarrinho(); },
    descItem: b => {
      const it = car.itens[+b.dataset.i];
      modal({ titulo: 'Desconto no item', corpo: formHTML([{ n: 'valor', r: 'Desconto em R$ (total da linha)', t: 'money', w: 12, padrao: it.desc_manual || '' }]),
        botoes: [{ texto: 'Cancelar' }, { texto: 'Aplicar', classe: 'pri', acao: m => { it.desc_manual = Math.max(0, n(m.querySelector('[name=valor]').value)); renderCarrinho(); } }] });
    },
    cupom: inp => { car.cupom = inp.value.trim().toUpperCase(); renderCarrinho(); },
    descManual: inp => { car.desc_manual = Math.max(0, n(inp.value)); renderCarrinho(); },
    descTipo: s => { car.desc_manual_tipo = s.value; renderCarrinho(); },
    avista: c => { car.avista = c.checked; renderCarrinho(); },
    limpar: async () => { if (car.itens.length && !await confirmar('Esvaziar o carrinho?', 'Esvaziar', 'perigo')) return; App.carrinho = novoCarrinho(); renderCarrinho(); },
    condicional: () => abrirCondicionalDoCarrinho(),
    finalizar: () => abrirPagamento()
  });
}

document.addEventListener('keydown', e => {
  if (e.key === 'F2' && App.rotaAtual === 'pdv' && !document.querySelector('.modal-fundo')) { e.preventDefault(); try { abrirPagamento(); } catch (err) { toast(err.message, 'erro'); } }
});

function abrirPagamento() {
  const car = App.carrinho;
  const calc = calcularCarrinho(car);
  if (!calc.linhas.length) throw new Error('O carrinho está vazio.');
  if (car.cupom && calc.erroCupom) throw new Error(calc.erroCupom);
  const cli = App.idx.cli[car.cliente_id];
  const fid = App.cfg.fidelidade || {};
  const total = calc.total;
  const formas = calc.avistaFormas || Object.keys(FORMAS_PAG);
  const pags = [];
  const taxas = App.cfg.taxas || {};
  const maxCred = n((App.cfg.crediario || {}).max_parcelas) || 1;
  const pago = () => r2(soma(pags, p => p.valor));
  const cbLimite = () => {
    if (!cli || !fid.ativo || total < n(fid.uso_minimo_compra)) return 0;
    return r2(Math.min(cashbackDisponivel(cli), total * n(fid.uso_max_pct || 100) / 100));
  };
  const m = modal({ titulo: 'Pagamento', largura: 'largo', corpo: `
    <div style="display:flex;justify-content:space-between;align-items:baseline"><span>Total a pagar</span><span style="font-size:28px;font-weight:700;color:var(--pri-esc)">${moeda(total)}</span></div>
    ${calc.avistaFormas ? `<div class="caixa-aviso">Desconto à vista aplicado: pagamento somente em ${calc.avistaFormas.map(f => FORMAS_PAG[f]).join(' ou ')}.</div>` : ''}
    <div class="chips" style="margin:12px 0">${formas.filter(f => (f !== 'crediario' && f !== 'cashback') || cli).map(f => `<button class="chip" data-click="add" data-f="${f}">+ ${FORMAS_PAG[f]}</button>`).join('')}</div>
    ${cli ? '' : '<small class="suave">Crediário e cashback exigem cliente identificada.</small>'}
    <div class="chips" id="pix-soltos"></div>
    <div id="pag-linhas"></div>
    <div class="totais" id="pag-resumo" style="margin-top:12px"></div>
    <div class="grade-form" style="margin-top:10px">
      <label class="check w5"><input type="checkbox" name="nota_pedida"><span>Cliente pediu nota fiscal${iconeAjuda({ aj: 'Marque quando a cliente quiser nota. Emita no emissor do seu estado e depois registre o número na venda.' })}</span></label>
      <label class="campo w7"><span>CPF ou CNPJ para a nota</span><input name="nota_doc" inputmode="numeric" value="${esc(cli && cli.cpf ? cli.cpf : '')}" data-input="docNota"></label>
      <div class="w12" id="aviso-cnpj"></div>
      ${nfeAtiva() ? `<label class="check w12"><input type="checkbox" name="emitir_nfe" ${integ('nfe').emitir === 'sempre' ? 'checked disabled' : ''}><span>Emitir nota fiscal (NFC-e)${integ('nfe').ambiente === 'homologacao' ? ' — homologação, sem valor fiscal' : ''}</span></label>` : ''}
      <label class="check w12"><input type="checkbox" name="distancia"><span>Venda fora da loja (WhatsApp, internet, telefone ou entrega)${iconeAjuda({ aj: 'Nessas vendas a cliente pode desistir em até 7 dias do recebimento e receber todo o valor de volta (Código de Defesa do Consumidor, art. 49). O comprovante avisa isso.' })}</span></label>
      <label class="campo w12"><span>Observação da venda</span><input name="obs" value="${esc(car.obs)}"></label></div>`,
    botoes: [{ texto: 'Voltar' }, { texto: 'Confirmar venda', classe: 'ok', acao: async mm => {
      const falta = r2(total - pago());
      if (falta > 0.009) throw new Error(`Faltam ${moeda(falta)}.`);
      for (const p of pags) if (p.forma === 'vale' && !p.codigo) throw new Error('Informe o código do vale (troca ou presente).');
      const troco = r2(pago() - total);
      if (troco > 0.009 && troco > soma(pags.filter(p => p.forma === 'dinheiro'), p => p.valor) + 0.009) throw new Error('Troco só é possível com pagamento em dinheiro.');
      const r = await api('venda', {
        itens: calc.linhas.map(l => ({ produto_id: l.produto_id, variacao_id: l.variacao_id, servico_id: l.servico_id, qtd: l.qtd, preco_unit: l.preco_unit, desconto: l.desconto, promocoes: l.promocoes })),
        cliente_id: car.cliente_id, desconto_carrinho: calc.descCarrinho, pagamentos: pags, promocoes: calc.aplicadas,
        cupom: calc.cupom ? calc.cupom.codigo : '', cupom_id: calc.cupom ? calc.cupom.id : null, condicional_id: car.condicional_id,
        obs: mm.querySelector('[name=obs]').value, distancia: mm.querySelector('[name=distancia]').checked,
        nota: (() => {
          const doc = mm.querySelector('[name=nota_doc]').value, nfe = mm.querySelector('[name=emitir_nfe]');
          const pedida = mm.querySelector('[name=nota_pedida]').checked || doc.replace(/\D/g, '').length === 14 || !!(nfe && nfe.checked);
          return { pedida, documento: pedida ? doc : '' };      // CPF/CNPJ só vai junto quando a nota foi pedida (LGPD)
        })()
      });
      App.carrinho = novoCarrinho();
      if (App.rotaAtual === 'pdv') renderCarrinho();
      const nf = mm.querySelector('[name=emitir_nfe]');
      const venda = nf && nf.checked ? await emitirNotaVenda(r.venda, mm.querySelector('[name=nota_doc]').value) : r.venda;
      mostrarRecibo(venda);
      toast(`Venda nº ${r.venda.numero} registrada.`, 'ok', { texto: 'Desfazer', tempo: 20000, acao: async () => {
        await api('venda/cancelar', { id: r.venda.id, motivo: 'Desfeita logo após a venda' });
        document.querySelectorAll('.modal-fundo').forEach(m => m.fechar && m.fechar());
        toast('Venda desfeita. As peças voltaram ao estoque.', 'ok');
        if (App.rotaAtual === 'pdv') renderCarrinho();
      } });
    } }],
    acoes: {
      docNota: inp => {
        const d = inp.value.replace(/\D/g, '');
        const nf = m.querySelector('[name=emitir_nfe]');
        if (nf && (d.length === 11 || d.length === 14)) nf.checked = true;
        m.querySelector('#aviso-cnpj').innerHTML = d.length === 14 && (App.cfg.mei || {}).cnpj_avisar !== false
          ? '<div class="caixa-aviso alerta">Venda para empresa (CNPJ): é obrigatório emitir NF-e. Emita no emissor do seu estado e registre o número em Vendas.</div>' : '';
      },
      add: b => {
        const f = b.dataset.f;
        const resta = Math.max(0, r2(total - pago()));
        let valor = resta;
        if (f === 'cashback') { valor = Math.min(resta, cbLimite()); if (!valor) { toast('Sem cashback disponível para esta compra.', 'erro'); return; } }
        pags.push({ forma: f, valor, parcelas: 1, codigo: '', primeiro_vencimento: somarDias(hojeISO(), 30) });
        renderLinhas();
      }
    }
  });
  function renderPixSoltos() {
    // Pix confirmado pelo banco que não entrou em venda (ex.: a tela de pagamento foi fechada): dá para usar aqui.
    const usados = new Set(pags.map(p => p.cobranca_id).filter(Boolean));
    const soltos = (App.d.cobrancas || []).filter(c => c.status === 'paga' && !c.venda_id && !usados.has(c.id) && String(c.criado_em).slice(0, 10) === hojeISO());
    const box = m.querySelector('#pix-soltos');
    box.innerHTML = soltos.map(c => `<button class="chip ok" data-solto="${esc(c.id)}">Usar Pix já recebido: ${moeda(c.valor)} às ${esc(String(c.pago_em || c.criado_em).slice(11, 16))}</button>`).join('');
    box.querySelectorAll('[data-solto]').forEach(bt => bt.onclick = () => {
      const c = soltos.find(x => x.id === bt.dataset.solto);
      pags.push({ forma: 'pix', valor: c.valor, parcelas: 1, codigo: '', primeiro_vencimento: '', cobranca_id: c.id });
      renderLinhas();
    });
  }
  function renderLinhas() {
    renderPixSoltos();
    const cont = m.querySelector('#pag-linhas');
    cont.innerHTML = pags.map((p, i) => {
      let extra = '<span></span>';
      if (p.forma === 'credito') extra = `<select data-i="${i}" data-campo="parcelas">${Array.from({ length: 12 }, (_, k) => k + 1).map(k => {
        const tx = k === 1 ? taxas.credito_1 : k <= 6 ? taxas.credito_2_6 : taxas.credito_7_12;
        return `<option value="${k}" ${p.parcelas === k ? 'selected' : ''}>${k}x de ${moeda(p.valor / k)} (taxa ${pct(n(tx))})</option>`;
      }).join('')}</select>`;
      if (p.forma === 'crediario') extra = `<div style="display:flex;gap:6px"><select data-i="${i}" data-campo="parcelas">${Array.from({ length: maxCred }, (_, k) => k + 1).map(k => `<option value="${k}" ${p.parcelas === k ? 'selected' : ''}>${k}x de ${moeda(p.valor / k)}</option>`).join('')}</select>
        <input type="date" data-i="${i}" data-campo="primeiro_vencimento" value="${p.primeiro_vencimento}" title="1º vencimento"></div>`;
      if (p.forma === 'vale') {
        const vale = p.codigo ? App.d.vales.find(v => v.codigo === p.codigo) : null;
        const [sit] = vale ? situacaoVale(vale) : [''];
        const info = !vale ? '' : sit === 'Ativo' ? `${nomeVale(vale)} · saldo ${moeda(vale.saldo)}${vale.validade ? ' · até ' + dataBR(vale.validade) : ''}`
          : sit === 'Vencido' ? `${nomeVale(vale)} vencido em ${dataBR(vale.validade)}` : `${nomeVale(vale)} ${sit.toLowerCase()}`;
        extra = `<div><input data-i="${i}" data-campo="codigo" placeholder="Código do vale (VT... ou VP...)" value="${esc(p.codigo)}">${info ? `<small class="${sit === 'Ativo' ? 'suave' : 'negativo'}" style="display:block">${esc(info)}</small>` : ''}</div>`;
      }
      if (p.forma === 'cashback') extra = `<small class="suave">Disponível para esta compra: ${moeda(cbLimite())}</small>`;
      if (p.forma === 'debito') extra = `<small class="suave">Taxa ${pct(n(taxas.debito))}</small>`;
      if (p.forma === 'pix') extra = p.cobranca_id ? `<span class="positivo"><b>✔ Pix recebido</b> (confirmado pelo banco)</span>`
        : `${pixApiAtivo() ? `<button class="btn pequeno ok" data-pixapi="${i}" title="QR Code do banco: o sistema confirma o pagamento sozinho">Cobrar Pix</button>` : ''}<button class="btn pequeno" data-qr="${i}" title="QR Code estático: confira o pagamento no app do banco">QR Code Pix</button>`;
      return `<div class="pag-linha"><b>${FORMAS_PAG[p.forma]}</b><input type="number" step="0.01" min="0" data-i="${i}" data-campo="valor" value="${p.valor}" ${p.cobranca_id ? 'readonly' : ''}>${extra}${p.cobranca_id ? '' : `<button class="btn pequeno perigo" data-rem="${i}">Remover</button>`}</div>`;
    }).join('') || '<p class="suave">Escolha a forma de pagamento acima. É possível combinar várias.</p>';
    cont.querySelectorAll('[data-campo]').forEach(inp => inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
      const p = pags[+inp.dataset.i], c = inp.dataset.campo;
      p[c] = c === 'valor' ? Math.max(0, n(inp.value)) : c === 'parcelas' ? +inp.value : (c === 'codigo' ? inp.value.trim().toUpperCase() : inp.value);
      if (c === 'codigo') {
        const vale = App.d.vales.find(v => v.codigo === p.codigo);
        if (vale && !p._ajustado) {
          if (situacaoVale(vale)[0] === 'Ativo') p.valor = Math.min(vale.saldo, p.valor || vale.saldo);
          p._ajustado = true; renderLinhas(); return;
        }
      }
      if (c === 'valor' && (p.forma === 'credito' || p.forma === 'crediario')) {
        const sel = cont.querySelector(`select[data-i="${inp.dataset.i}"]`);
        if (sel) [...sel.options].forEach((o, k) => o.textContent = o.textContent.replace(/de R\$\s?[\d.,]+/, 'de ' + moeda(p.valor / (k + 1))));
      }
      resumo();
    }));
    cont.querySelectorAll('[data-rem]').forEach(b => b.onclick = () => { pags.splice(+b.dataset.rem, 1); renderLinhas(); });
    cont.querySelectorAll('[data-qr]').forEach(b => b.onclick = () => modalPix(pags[+b.dataset.qr].valor, App.cfg.loja.nome, 'VENDA' + ((App.cfg.seq || {}).venda + 1 || '')));
    cont.querySelectorAll('[data-pixapi]').forEach(b => b.onclick = async () => {
      const p = pags[+b.dataset.pixapi];
      if (!(p.valor > 0)) { toast('Informe o valor do Pix.', 'erro'); return; }
      b.disabled = true;
      const cob = await cobrarPixApi(r2(p.valor), `Compra na ${App.cfg.loja.nome}`);
      if (cob) { p.cobranca_id = cob.id; p.valor = cob.valor; }
      renderLinhas();
    });
    resumo();
  }
  function resumo() {
    const p = pago(), dif = r2(p - total);
    m.querySelector('#pag-resumo').innerHTML = `<div><span>Recebido</span><span>${moeda(p)}</span></div>
      ${dif < 0 ? `<div class="negativo forte"><span>Falta</span><span>${moeda(-dif)}</span></div>` : `<div class="positivo forte"><span>Troco</span><span>${moeda(dif)}</span></div>`}`;
  }
  renderLinhas();
}

function mostrarRecibo(v) {
  const cli = App.idx.cli[v.cliente_id];
  modal({ titulo: `Venda nº ${v.numero} concluída`, corpo: `<div style="display:flex;justify-content:center;background:#f6f3f0;padding:12px;border-radius:8px;max-height:55vh;overflow:auto"><div style="background:#fff;padding:10px">${reciboHTML(v)}</div></div>`,
    botoes: [
      ...(cli && cli.telefone ? [{ texto: 'Enviar por WhatsApp', acao: () => { abrirWhatsApp(cli.telefone, textoModelo('recibo', { nome: cli.apelido || cli.nome.split(' ')[0], numero: v.numero, valor: moeda(v.total) })); return false; } }] : []),
      { texto: 'Imprimir', acao: () => { imprimir(reciboHTML(v), 'size: 80mm auto; margin: 3mm;'); return false; } },
      { texto: 'Nova venda', classe: 'pri', acao: () => { if (App.rotaAtual !== 'pdv') ir('#/pdv'); } }
    ] });
}

/* ------------------------------------------------------------- condicional */
function abrirCondicionalDoCarrinho() {
  const car = App.carrinho;
  if (!car.itens.some(i => i.variacao_id)) throw new Error('Adicione as peças ao carrinho primeiro.');
  if (!car.cliente_id) { escolherCliente(c => { car.cliente_id = c.id; renderCarrinho(); abrirCondicionalDoCarrinho(); }); return; }
  const cli = App.idx.cli[car.cliente_id];
  const prazo = somarDias(hojeISO(), n((App.cfg.condicional || {}).prazo_dias) || 3);
  modal({ titulo: 'Levar em condicional', corpo: `<p>As peças saem do estoque e ficam com <b>${esc(cli.nome)}</b> até a data de devolução.</p>
    ${formHTML([{ n: 'prazo', r: 'Devolver até', t: 'date', w: 6, padrao: prazo }, { n: 'obs', r: 'Observação', w: 12 }])}`,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Registrar e imprimir termo', classe: 'pri', acao: async m => {
      const d = lerForm(m, [{ n: 'prazo', r: 'Prazo', obr: 1 }, { n: 'obs' }]);
      const r = await api('condicional/abrir', { cliente_id: car.cliente_id, prazo: d.prazo, obs: d.obs,
        itens: car.itens.filter(i => i.variacao_id).map(i => ({ produto_id: i.produto_id, variacao_id: i.variacao_id, qtd: i.qtd, preco_unit: i.preco_unit })) });
      App.carrinho = novoCarrinho(); renderCarrinho();
      toast(`Condicional nº ${r.condicional.numero} registrado.`, 'ok');
      imprimir(termoCondicionalHTML(r.condicional));
    } }] });
}

App.paginas.condicional = async el => {
  el.innerHTML = `<div class="caixa-aviso">Para abrir um condicional, adicione as peças no <a href="#/pdv">caixa</a>, identifique a cliente e clique em <b>Condicional</b>.</div><div class="card" id="tab-cond"></div>`;
  const dia = hojeISO();
  const linhas = App.d.condicionais.slice().sort((a, b) => (a.status === 'aberto' ? 0 : 1) - (b.status === 'aberto' ? 0 : 1) || b.numero - a.numero);
  tabela(el.querySelector('#tab-cond'), {
    linhas, exportar: 'condicionais',
    colunas: [{ t: 'Nº', v: c => c.numero, cls: 'num' }, { t: 'Retirada', v: c => c.data, h: c => dataBR(c.data) }, { t: 'Cliente', v: c => c.cliente_nome },
      { t: 'Peças', v: c => soma(c.itens, i => i.qtd), cls: 'num' }, { t: 'Valor', v: c => soma(c.itens, i => i.qtd * i.preco_unit), h: c => moeda(soma(c.itens, i => i.qtd * i.preco_unit)), cls: 'num' },
      { t: 'Prazo', v: c => c.prazo, h: c => dataBR(c.prazo) },
      { t: 'Situação', v: c => c.status, h: c => c.status === 'aberto' ? (c.prazo < dia ? etiqueta('Vencido', 'erro') : etiqueta('Com a cliente', 'info')) : etiqueta(`Devolvido · comprou ${c.pecas_compradas || 0}`, 'ok') },
      { t: '', semOrdem: true, h: c => c.status === 'aberto' ? `<button class="btn pequeno pri" data-acao="retorno">Retorno</button> <button class="btn pequeno" data-acao="termo">Termo</button> <button class="btn pequeno" data-acao="whats">WhatsApp</button>` : `<button class="btn pequeno" data-acao="termo">Termo</button>` }],
    acoes: {
      termo: c => imprimir(termoCondicionalHTML(c)),
      whats: c => { const cli = App.idx.cli[c.cliente_id] || {}; abrirWhatsApp(cli.telefone, textoModelo('condicional', { nome: (cli.apelido || cli.nome || '').split(' ')[0], prazo: dataBR(c.prazo) })); },
      retorno: c => {
        modal({ titulo: `Retorno do condicional nº ${c.numero}`, corpo: `<p>Marque as peças que <b>${esc(c.cliente_nome)}</b> decidiu comprar. As demais voltam para o estoque.</p>
          ${c.itens.map((i, k) => `<label class="tarefa"><input type="checkbox" value="${k}"><span>${esc(i.nome)} — ${esc(i.tamanho)}/${esc(i.cor)} · ${i.qtd} un. · ${moeda(i.preco_unit)}</span></label>`).join('')}`,
          botoes: [{ texto: 'Cancelar' }, { texto: 'Confirmar retorno', classe: 'pri', acao: async m => {
            const ficou = [...m.querySelectorAll('input:checked')].map(x => +x.value);
            const r = await api('condicional/fechar', { id: c.id, ficou });
            if (ficou.length) {
              const car = novoCarrinho();
              car.cliente_id = c.cliente_id; car.condicional_id = c.id;
              for (const k of ficou) { const i = r.condicional.itens[k]; car.itens.push({ produto_id: i.produto_id, variacao_id: i.variacao_id, qtd: i.qtd, preco_unit: i.preco_unit, desc_manual: 0 }); }
              App.carrinho = car;
              toast('Peças devolvidas ao estoque. Finalize a compra das peças escolhidas.', 'ok');
              ir('#/pdv');
            } else { toast('Todas as peças voltaram ao estoque.', 'ok'); recarregarPagina(); }
          } }] });
      }
    }
  });
};

/* ------------------------------------------------------------------ vendas */
App.paginas.vendas = async (el, id, params) => {
  const st = { de: params.de || somarDias(hojeISO(), -30), ate: params.ate || hojeISO(), status: params.status || 'concluida' };
  el.innerHTML = `<div class="card"><div class="linha-acoes">
      <label class="campo"><span>De</span><input type="date" data-change="de" value="${st.de}"></label>
      <label class="campo"><span>Até</span><input type="date" data-change="ate" value="${st.ate}"></label>
      <label class="campo"><span>Situação</span><select data-change="status"><option value="concluida">Concluídas</option><option value="cancelada" ${st.status === 'cancelada' ? 'selected' : ''}>Canceladas</option><option value="todas" ${st.status === 'todas' ? 'selected' : ''}>Todas</option></select></label>
      <span class="espaco"></span><a class="btn pri" href="#/pdv">Nova venda</a></div><div id="resumo-vendas"></div><div id="tab-vendas"></div></div>`;
  const filtrar = () => App.d.vendas.filter(v => v.data.slice(0, 10) >= st.de && v.data.slice(0, 10) <= st.ate && (st.status === 'todas' || v.status === st.status)).sort((a, b) => b.numero - a.numero);
  const t = tabela(el.querySelector('#tab-vendas'), {
    linhas: filtrar(), exportar: 'vendas', placeholder: 'Número, cliente, produto...',
    textoBusca: v => v.itens.map(i => i.nome + ' ' + i.sku).join(' '),
    colunas: [{ t: 'Nº', v: v => v.numero, cls: 'num' }, { t: 'Data', v: v => v.data, h: v => dataHoraBR(v.data) }, { t: 'Cliente', v: v => v.cliente_nome || '' },
      { t: 'Itens', v: v => soma(v.itens, i => i.qtd), cls: 'num' }, { t: 'Desconto', v: v => r2(v.desconto_itens + v.desconto_carrinho), h: v => moeda(v.desconto_itens + v.desconto_carrinho), cls: 'num', total: true },
      { t: 'Total', v: v => v.total, h: v => `<b>${moeda(v.total)}</b>`, cls: 'num', total: true },
      { t: 'Pagamento', v: v => v.pagamentos.map(p => FORMAS_PAG[p.forma] + (p.parcelas > 1 ? ` ${p.parcelas}x` : '')).join(' + ') },
      { t: 'Situação', v: v => v.status, h: v => v.status === 'concluida' ? etiqueta('Concluída', 'ok') : etiqueta('Cancelada', 'erro') }],
    aoClicar: v => detalheVenda(v)
  });
  const resumo = () => { const r = resumoVendas(filtrar().filter(v => v.status === 'concluida')); el.querySelector('#resumo-vendas').innerHTML = `<div class="kpis">${kpi('Faturamento', moeda(r.fat), `${r.n} vendas`)}${kpi('Ticket médio', moeda(r.ticket), `${numBR(r.pa, 1)} peças/venda`)}${kpi('Lucro bruto', moeda(r.lucroBruto), 'Margem ' + pct(r.margem))}${kpi('Descontos concedidos', moeda(r.desc))}</div>`; };
  resumo();
  ligar(el, { de: i => { st.de = i.value; t.atualizar(filtrar()); resumo(); }, ate: i => { st.ate = i.value; t.atualizar(filtrar()); resumo(); }, status: s => { st.status = s.value; t.atualizar(filtrar()); resumo(); } });
};

function detalheVenda(v) {
  const cli = App.idx.cli[v.cliente_id];
  const fin = App.d.financeiro.filter(f => f.ref === v.id);
  const trocas = App.d.trocas.filter(t => t.venda_id === v.id);
  const custo = soma(v.itens, i => i.custo_unit * i.qtd);
  modal({ titulo: `Venda nº ${v.numero} — ${dataHoraBR(v.data)}`, largura: 'largo', corpo: `
    ${v.status === 'cancelada' ? `<div class="caixa-aviso erro">Cancelada em ${dataHoraBR(v.cancelada_em)}. ${esc(v.motivo_cancelamento || '')}</div>` : ''}
    <p>Cliente: <b>${esc(v.cliente_nome || 'não identificada')}</b> · Atendida por: ${esc(v.usuario)}</p>
    <table class="tab"><thead><tr><th>Produto</th><th>Var.</th><th class="th-num">Qtd</th><th class="th-num">Preço</th><th class="th-num">Desconto</th><th class="th-num">Total</th><th class="th-num">Custo</th></tr></thead><tbody>
    ${v.itens.map(i => `<tr><td>${esc(i.nome)}${i.promocoes && i.promocoes.length ? `<br><small class="positivo">${esc(i.promocoes.join(', '))}</small>` : ''}</td><td>${esc(i.tamanho)} ${esc(i.cor)}</td><td class="num">${i.qtd}</td><td class="num">${moeda(i.preco_unit)}</td><td class="num">${moeda(i.desconto)}</td><td class="num">${moeda(i.total)}</td><td class="num">${moeda(i.custo_unit * i.qtd)}</td></tr>`).join('')}
    </tbody></table>
    <div class="grade g2" style="margin-top:12px"><div class="totais"><div><span>Subtotal</span><span>${moeda(v.subtotal)}</span></div><div><span>Descontos</span><span>−${moeda(v.desconto_itens + v.desconto_carrinho)}</span></div>
      <div class="total"><span>Total</span><span>${moeda(v.total)}</span></div><div><span>Lucro bruto</span><span>${moeda(v.total - custo)} (${pct(v.total ? (v.total - custo) / v.total * 100 : 0)})</span></div></div>
      <div><b>Pagamentos</b>${v.pagamentos.map(p => `<div>${FORMAS_PAG[p.forma]}${p.parcelas > 1 ? ` ${p.parcelas}x` : ''}${p.codigo ? ' ' + esc(p.codigo) : ''}: ${moeda(p.valor)} <small class="suave">(taxa ${moeda(p.taxa)})</small></div>`).join('')}
      ${v.troco ? `<div>Troco: ${moeda(v.troco)}</div>` : ''}${v.cashback_gerado ? `<div>Cashback gerado: ${moeda(v.cashback_gerado)}</div>` : ''}
      ${(v.promocoes || []).length ? `<div class="positivo">Promoções: ${esc(v.promocoes.join(', '))}</div>` : ''}${v.obs ? `<div>Obs.: ${esc(v.obs)}</div>` : ''}
      ${notaVendaHTML(v)}
      ${v.nota && (v.nota.pedida || v.nota.numero) && !v.nfe ? `<div>Nota fiscal: ${v.nota.numero ? etiqueta('nº ' + v.nota.numero, 'ok') : etiqueta('pedida, falta registrar', 'alerta')}${v.nota.documento ? ' · doc. ' + esc(v.nota.documento) : ''}</div>` : ''}</div></div>
    ${fin.length ? `<h3 style="margin-top:14px">Recebimentos</h3>${fin.map(f => `<div>${esc(f.descricao)} · venc. ${dataBR(f.vencimento)} · ${moeda(f.liquido)} ${etiqueta(...statusFin(f))}</div>`).join('')}` : ''}
    ${trocas.length ? `<h3 style="margin-top:14px">Trocas</h3>${trocas.map(t => `<div>Troca nº ${t.numero} · ${dataBR(t.data)} · ${moeda(t.total)} (${t.destino === 'vale' ? 'vale ' + t.vale_codigo : 'devolução'})</div>`).join('')}` : ''}`,
    botoes: [
      { texto: 'Imprimir', acao: () => { imprimir(reciboHTML(v), 'size: 80mm auto; margin: 3mm;'); return false; } },
      ...botoesNotaVenda(v),
      ...(v.status === 'concluida' && !(v.nfe && v.nfe.status === 'autorizado') ? [{ texto: v.nota && v.nota.numero ? 'Alterar nº da nota' : 'Registrar nota fiscal', acao: () => registrarNota(v) }] : []),
      ...(cli && cli.telefone ? [{ texto: 'WhatsApp', acao: () => { abrirWhatsApp(cli.telefone, textoModelo('recibo', { nome: cli.apelido || cli.nome.split(' ')[0], numero: v.numero, valor: moeda(v.total) })); return false; } }] : []),
      ...(v.status === 'concluida' ? [
        { texto: 'Troca / devolução', acao: () => ir(`#/trocas?venda=${v.id}`) },
        { texto: 'Cancelar venda', classe: 'perigo', acao: async () => {
          const ok = await confirmar(`Cancelar a venda nº ${v.numero}? As peças voltam ao estoque e os recebimentos são cancelados. Se houve pagamento, devolva o valor à cliente.`, 'Cancelar venda', 'perigo');
          if (!ok) return false;
          await api('venda/cancelar', { id: v.id, motivo: 'Cancelada pela loja' }); toast('Venda cancelada.', 'ok'); recarregarPagina();
        } }] : []),
      { texto: 'Fechar' }
    ] });
}

/* ------------------------------------------------------------------ trocas */
App.paginas.trocas = async (el, id, params) => {
  const aba = params.aba || 'trocas';
  el.innerHTML = `${abas([['trocas', 'Trocas e devoluções'], ['vales', 'Vales (troca e presente)']], aba)}
    <div class="linha-acoes"><button class="btn pri" data-click="nova">Nova troca / devolução</button><button class="btn" data-click="presente">Vender vale-presente</button></div><div class="card" id="tab-trocas"></div>`;
  ligar(el, { aba: b => ir('#/trocas?aba=' + b.dataset.k), nova: () => novaTroca(), presente: () => venderValePresente() });
  const box = el.querySelector('#tab-trocas');
  if (aba === 'trocas') {
    tabela(box, { linhas: App.d.trocas.slice().reverse(), exportar: 'trocas',
      colunas: [{ t: 'Nº', v: t => t.numero, cls: 'num' }, { t: 'Data', v: t => t.data, h: t => dataBR(t.data) }, { t: 'Venda', v: t => t.venda_numero || '—' },
        { t: 'Cliente', v: t => (App.idx.cli[t.cliente_id] || {}).nome || '' }, { t: 'Peças', v: t => t.itens.map(i => `${i.qtd}x ${i.nome} ${i.tamanho}/${i.cor}`).join('; ') },
        { t: 'Valor', v: t => t.total, h: t => moeda(t.total), cls: 'num', total: true }, { t: 'Destino', v: t => t.destino === 'vale' ? 'Vale ' + t.vale_codigo : t.destino === 'crediario' ? 'Abatido do crediário' : 'Devolução (' + t.destino + ')' }, { t: 'Motivo', v: t => t.motivo }] });
  } else {
    const pode = gestora();
    tabela(box, { linhas: App.d.vales.slice().reverse(), exportar: 'vales',
      colunas: [{ t: 'Código', v: v => v.codigo, h: v => `<b>${esc(v.codigo)}</b>` }, { t: 'Tipo', v: v => nomeVale(v) },
        { t: 'Cliente', v: v => (App.idx.cli[v.cliente_id] || {}).nome || '' }, { t: 'Para', v: v => v.para || '' },
        { t: 'Emissão', v: v => v.criado_em, h: v => dataBR(v.criado_em) }, { t: 'Validade', v: v => v.validade || '', h: v => v.validade ? dataBR(v.validade) : 'sem prazo' },
        { t: 'Valor', v: v => v.valor, h: v => moeda(v.valor), cls: 'num' }, { t: 'Saldo', v: v => v.saldo, h: v => moeda(v.saldo), cls: 'num', total: true },
        { t: 'Situação', v: v => situacaoVale(v)[0], h: v => etiqueta(...situacaoVale(v)) },
        { t: '', semOrdem: true, h: v => `<button class="btn pequeno" data-acao="imprimir">Imprimir</button>${pode && v.status === 'ativo' ? '<button class="btn pequeno" data-acao="validade">Validade</button>' : ''}${pode && v.tipo === 'presente' && v.status === 'ativo' && !(v.usos || []).length ? '<button class="btn pequeno perigo" data-acao="cancelar">Cancelar</button>' : ''}` }],
      acoes: { imprimir: v => imprimirVale(v), validade: v => alterarValidadeVale(v), cancelar: v => cancelarValePresente(v) } });
  }
  if (params.venda) novaTroca(params.venda);
};

function mostrarVale(vale, troca) {
  modal({ titulo: `${nomeVale(vale)} ${vale.codigo}`, corpo: `<div style="display:flex;justify-content:center">${valeHTML(vale, troca)}</div>`,
    botoes: [{ texto: 'Imprimir', classe: 'pri', acao: () => { imprimirVale(vale, troca); return false; } }, { texto: 'Fechar' }] });
}

function venderValePresente(clienteId) {
  const st = { cliente_id: clienteId || null };
  const nomeCli = () => (App.idx.cli[st.cliente_id] || {}).nome || 'Selecionar (opcional)';
  const m = modal({ titulo: 'Vender vale-presente', largura: 'largo', corpo: `
    <div class="grade-form">
      <label class="campo w4"><span>Valor do vale *</span><input type="number" step="0.01" min="1" inputmode="decimal" name="valor" autofocus></label>
      <label class="campo w4"><span>Forma de pagamento</span><select name="forma">${['dinheiro', 'pix', 'debito', 'credito'].map(f => `<option value="${f}">${FORMAS_PAG[f]}</option>`).join('')}</select></label>
      <label class="campo w4" id="vp-parcelas" hidden><span>Parcelas</span><select name="parcelas">${Array.from({ length: 12 }, (_, k) => `<option value="${k + 1}">${k + 1}x</option>`).join('')}</select></label>
      <label class="campo w4"><span>Quem está comprando</span><button class="btn" data-click="cliente" id="vp-cli" style="width:100%;text-align:left">${esc(nomeCli())}</button></label>
      <label class="campo w4"><span>Para quem é o presente</span><input name="para" maxlength="80" placeholder="ex.: Maria"></label>
      <label class="campo w12"><span>Mensagem no vale (opcional)</span><input name="mensagem" maxlength="200" placeholder="ex.: Feliz aniversário!"></label>
    </div>
    <div style="margin-top:6px">${campoValidadeHTML((App.cfg.vales || {}).presente_validade_dias ?? 365)}</div>
    <div class="caixa-aviso" style="margin-top:10px">O valor entra no caixa agora, mas só conta como venda (e no faturamento do MEI) quando o vale for usado. A validade sai impressa no vale.</div>`,
    aoAbrir: mm => {
      ligarValidade(mm);
      const forma = mm.querySelector('[name=forma]');
      forma.addEventListener('change', () => { mm.querySelector('#vp-parcelas').hidden = forma.value !== 'credito'; });
    },
    acoes: { cliente: () => escolherCliente(c => { st.cliente_id = c.id; m.querySelector('#vp-cli').textContent = c.nome; }) },
    botoes: [{ texto: 'Cancelar' }, { texto: 'Gerar vale', classe: 'ok', acao: async mm => {
      const valor = n(mm.querySelector('[name=valor]').value);
      if (!(valor > 0)) throw new Error('Informe o valor do vale-presente.');
      const forma = mm.querySelector('[name=forma]').value;
      const dados = { valor, forma, parcelas: +mm.querySelector('[name=parcelas]').value, cliente_id: st.cliente_id,
        para: mm.querySelector('[name=para]').value, mensagem: mm.querySelector('[name=mensagem]').value, validade: lerValidade(mm) };
      if (!await confirmar(`Confirmar o recebimento de ${moeda(valor)} em ${FORMAS_PAG[forma].toLowerCase()} pelo vale-presente?`, 'Confirmar')) return false;
      const r = await api('vale/presente', dados);
      toast(`Vale-presente ${r.vale.codigo} gerado.`, 'ok');
      mostrarVale(r.vale);
      if (App.rotaAtual === 'trocas') ir('#/trocas?aba=vales');
    } }] });
}

function alterarValidadeVale(vale) {
  modal({ titulo: `Validade do ${nomeVale(vale).toLowerCase()} ${vale.codigo}`, largura: 'largo',
    corpo: `<p>Saldo de ${moeda(vale.saldo)}. Validade atual: <b>${vale.validade ? dataBR(vale.validade) : 'sem prazo'}</b>.</p>${campoValidadeHTML(0, vale.validade && vale.validade >= hojeISO() ? vale.validade : '')}`,
    aoAbrir: ligarValidade,
    botoes: [{ texto: 'Cancelar' }, { texto: 'Salvar', classe: 'pri', acao: async mm => {
      const r = await api('vale/validade', { id: vale.id, validade: lerValidade(mm) });
      toast(r.vale.validade ? `Válido até ${dataBR(r.vale.validade)}.` : 'Vale sem prazo de validade.', 'ok');
      recarregarPagina();
    } }] });
}

async function cancelarValePresente(vale) {
  if (!await confirmar(`Cancelar o vale-presente ${vale.codigo} de ${moeda(vale.valor)}? Use quando devolver o dinheiro a quem comprou. O recebimento sai do financeiro e do caixa.`, 'Cancelar vale', 'perigo')) return;
  await api('vale/cancelar', { id: vale.id, motivo: 'Cancelado pela loja' });
  toast('Vale-presente cancelado.', 'ok');
  recarregarPagina();
}

function novaTroca(vendaId) {
  const st = { venda: vendaId ? App.idx.venda[vendaId] : null, itens: [], cliente_id: null };
  if (st.venda) st.cliente_id = st.venda.cliente_id;
  const m = modal({ titulo: 'Troca / devolução', largura: 'largo', corpo: `
    <div class="grade-form"><label class="campo w4"><span>Nº da venda (opcional)</span><input data-change="buscarVenda" data-enter="buscarVenda" value="${st.venda ? st.venda.numero : ''}" placeholder="ex.: 125"></label>
      <div class="w8" style="align-self:end"><small class="suave">Com a venda, o valor devolvido é o que a cliente pagou (com descontos). Sem venda, busque a peça abaixo.</small></div></div>
    <div id="troca-origem" style="margin-top:12px"></div>
    <div class="grade-form" style="margin-top:12px">
      <label class="campo w4"><span>Cliente</span><button class="btn" data-click="cliente" id="troca-cli" style="width:100%;text-align:left">${esc((App.idx.cli[st.cliente_id] || {}).nome || 'Selecionar (opcional)')}</button></label>
      <label class="campo w4"><span>Destino do valor</span><select name="destino"><option value="vale">Gerar vale-troca</option><option value="dinheiro">Devolver em dinheiro (caixa)</option><option value="pix">Devolver por Pix</option><option value="estorno_cartao">Estorno no cartão</option><option value="crediario">Abater do crediário (parcelas em aberto)</option></select></label>
      <label class="campo w4" id="troca-resto" hidden><span>O que passar do que foi pago por esse meio vai para</span><select name="resto"><option value="vale">Vale-troca</option><option value="dinheiro">Dinheiro (caixa)</option><option value="pix">Pix</option><option value="estorno_cartao">Estorno no cartão</option></select></label>
      <label class="campo w4"><span>Motivo</span><select name="motivo"><option>Tamanho</option><option>Não gostou / desistiu</option><option>Cor</option><option>Defeito</option><option>Presente</option><option>Outro</option></select></label>
    </div><div id="troca-direitos" style="margin-top:8px"></div><div id="troca-validade" style="margin-top:6px">${campoValidadeHTML((App.cfg.vales || {}).validade_dias ?? 90)}</div>
    <div class="totais" id="troca-total" style="margin-top:10px"></div>`,
    aoAbrir: mm => {
      ligarValidade(mm);
      const dest = mm.querySelector('[name=destino]');
      mm.querySelector('[name=resto]').addEventListener('change', () => dest.dispatchEvent(new Event('change')));
      dest.addEventListener('change', () => {
        mm.querySelector('#troca-validade').hidden = dest.value !== 'vale' && mm.querySelector('[name=resto]').value !== 'vale';
        mm.querySelector('#troca-resto').hidden = dest.value === 'vale' || !st.venda;
      });
      mm.querySelector('[name=motivo]').addEventListener('change', () => direitos());
    },
    botoes: [{ texto: 'Cancelar' }, { texto: 'Registrar', classe: 'pri', acao: async mm => {
      const itens = st.itens.filter(i => i.qtd > 0);
      if (!itens.length) throw new Error('Informe as peças devolvidas.');
      const destino = mm.querySelector('[name=destino]').value;
      if (destino === 'vale' && !st.cliente_id && !await confirmar('Gerar vale sem cliente identificada? Qualquer pessoa com o código poderá usá-lo.', 'Gerar mesmo assim')) return false;
      const validade = lerValidade(mm);
      const r = await api('troca', { venda_id: st.venda ? st.venda.id : null, cliente_id: st.cliente_id, destino, validade, resto: mm.querySelector('[name=resto]').value, motivo: mm.querySelector('[name=motivo]').value,
        itens: itens.map(i => ({ produto_id: i.produto_id, variacao_id: i.variacao_id, qtd: i.qtd })) });
      if (r.troca.vale_codigo) {
        const vale = App.d.vales.find(v => v.codigo === r.troca.vale_codigo);
        mostrarVale(vale, r.troca);
      } else toast(destino === 'crediario' ? `${moeda(r.troca.valor_destino)} abatidos do crediário.` : `Devolução de ${moeda(r.troca.total)} registrada.`, 'ok');
      if (App.rotaAtual === 'trocas') ir('#/trocas');
    } }],
    acoes: {
      buscarVenda: inp => {
        const num = +inp.value;
        st.venda = num ? App.d.vendas.find(v => v.numero === num && v.status === 'concluida') : null;
        if (num && !st.venda) toast('Venda não encontrada ou cancelada.', 'erro');
        st.itens = [];
        if (st.venda) { st.cliente_id = st.venda.cliente_id; m.querySelector('#troca-cli').textContent = (App.idx.cli[st.cliente_id] || {}).nome || 'Selecionar (opcional)'; }
        origem();
      },
      cliente: () => escolherCliente(c => { st.cliente_id = c.id; m.querySelector('#troca-cli').textContent = c.nome; })
    } });
  function total() { m.querySelector('#troca-total').innerHTML = `<div class="total"><span>Valor da troca</span><span>${moeda(soma(st.itens, i => i.qtd * i.valor_unit))}</span></div>`; }
  function origem() {
    const box = m.querySelector('#troca-origem');
    if (st.venda) {
      const ja = {};
      App.d.trocas.filter(t => t.venda_id === st.venda.id).forEach(t => t.itens.forEach(i => { ja[i.variacao_id] = (ja[i.variacao_id] || 0) + i.qtd; }));
      // Mesmo cálculo do sistema: o desconto no total da compra entra no valor devolvido.
      const fator = Math.min(1, st.venda.total / (soma(st.venda.itens, i => i.total) || 1));
      st.itens = st.venda.itens.filter(i => i.produto_id).map(i => ({ produto_id: i.produto_id, variacao_id: i.variacao_id, nome: `${i.nome} ${i.tamanho}/${i.cor}`, max: i.qtd - (ja[i.variacao_id] || 0), qtd: 0, valor_unit: r2(i.total / i.qtd * fator) }));
      box.innerHTML = `<p>Venda nº ${st.venda.numero} de ${dataBR(st.venda.data)} — ${esc(st.venda.cliente_nome || 'sem cliente')}</p>
        <table class="tab"><thead><tr><th>Peça</th><th class="th-num">Valor pago (un.)</th><th class="th-num">Disponível</th><th class="th-num">Devolver</th></tr></thead><tbody>
        ${st.itens.map((i, k) => `<tr><td>${esc(i.nome)}</td><td class="num">${moeda(i.valor_unit)}</td><td class="num">${i.max}</td><td class="num"><input type="number" class="input-qtd" min="0" max="${i.max}" data-k="${k}" value="0" ${i.max <= 0 ? 'disabled' : ''}></td></tr>`).join('')}</tbody></table>`;
      box.querySelectorAll('[data-k]').forEach(inp => inp.oninput = () => { const it = st.itens[+inp.dataset.k]; it.qtd = Math.max(0, Math.min(it.max, Math.round(n(inp.value)))); total(); });
    } else {
      box.innerHTML = `<div id="troca-sel"></div><div id="troca-itens" style="margin-top:8px"></div>`;
      seletorProduto(box.querySelector('#troca-sel'), { permitirZerado: true, inativos: true, aoEscolher: (p, v) => { st.itens.push({ produto_id: p.id, variacao_id: v.id, nome: `${p.nome} ${v.tamanho}/${v.cor}`, qtd: 1, valor_unit: n(p.preco) }); lista(); } });
      const lista = () => {
        // Sem a venda, o valor é o preço de etiqueta (o sistema não aceita valor digitado).
        box.querySelector('#troca-itens').innerHTML = st.itens.map((i, k) => `<div class="carrinho-item"><span>${esc(i.nome)}</span><input type="number" class="input-qtd" min="1" data-q="${k}" value="${i.qtd}"><span class="num" title="Preço de etiqueta">${moeda(i.valor_unit)}</span></div>`).join('')
          + (st.itens.length ? '<small class="suave">Sem o número da venda vale o preço de etiqueta. Devolução em dinheiro, Pix ou cartão sem a venda só pela proprietária ou gerente.</small>' : '');
        box.querySelectorAll('[data-q]').forEach(x => x.oninput = () => { st.itens[+x.dataset.q].qtd = Math.max(0, Math.round(n(x.value))); total(); });
        total();
      };
      lista();
    }
    total();
    direitos();
  }
  /* Direitos da cliente nesta troca (Código de Defesa do Consumidor), mostrados para quem atende. */
  function direitos() {
    const box = m.querySelector('#troca-direitos');
    if (!box) return;
    const motivo = m.querySelector('[name=motivo]').value;
    const avisos = [];
    if (motivo === 'Defeito') avisos.push(['alerta', 'Peça com defeito: a cliente escolhe entre consertar, trocar por outra igual, receber o dinheiro de volta ou ter abatimento no preço (CDC, art. 18). Se ela quiser o dinheiro, use "Devolver em dinheiro", "Pix" ou "Estorno no cartão": ela não é obrigada a aceitar vale.']);
    if (st.venda) {
      const dias = Math.round((new Date(hojeISO()) - new Date(st.venda.data.slice(0, 10))) / 86400000);
      if (st.venda.distancia && dias <= 7 + 3) avisos.push(['alerta', `Compra feita fora da loja há ${dias} dia(s): se a cliente desistiu dentro de 7 dias do recebimento, ela tem direito a receber de volta todo o valor pago, inclusive o frete (CDC, art. 49).`]);
      const prazo = n((App.cfg.consumidor || {}).prazo_troca_dias);
      if (motivo !== 'Defeito' && prazo > 0 && dias > prazo) avisos.push(['info', `A venda tem ${dias} dias, mais que o prazo de troca da loja (${prazo} dias). Fazer a troca agora é cortesia da loja.`]);
    }
    box.innerHTML = avisos.map(([t, x]) => `<div class="caixa-aviso ${t}" style="margin-bottom:6px">${esc(x)}</div>`).join('');
  }
  origem();
}

/* ------------------------------------------------------------------- caixa */
App.paginas.caixa = async el => {
  const r = await api('caixa/resumo');
  const c = r.caixa, s = r.resumo;
  const hist = App.d.caixa.filter(x => x.status === 'fechado').reverse();
  const ultimo = hist[0];
  el.innerHTML = `<div class="grade g2"><div class="card">${c ? `
      <div class="card-cab"><h2>Caixa aberto</h2>${etiqueta('desde ' + dataHoraBR(c.aberto_em), 'ok')}</div>
      <div class="totais"><div><span>Valor inicial (troco)</span><span>${moeda(s.inicial)}</span></div>
        <div><span>Vendas em dinheiro (líquido de troco)</span><span>${moeda(s.vendas_dinheiro)}</span></div>
        <div><span>Recebimentos em dinheiro (crediário etc.)</span><span>${moeda(s.recebimentos)}</span></div>
        <div><span>Suprimentos</span><span>${moeda(s.suprimentos)}</span></div>
        <div class="negativo"><span>Sangrias</span><span>−${moeda(s.sangrias)}</span></div>
        <div class="negativo"><span>Pagamentos/devoluções em dinheiro</span><span>−${moeda(s.pagamentos)}</span></div>
        <div class="total"><span>Esperado na gaveta</span><span>${moeda(s.esperado)}</span></div></div>
      <div class="linha-acoes" style="margin-top:14px"><button class="btn" data-click="mov" data-t="sangria">Sangria (retirada)</button><button class="btn" data-click="mov" data-t="suprimento">Suprimento (reforço)</button><span class="espaco"></span><button class="btn pri" data-click="fechar">Fechar caixa</button></div>
      ${c.movimentos.length ? `<h3>Movimentos</h3>${c.movimentos.map(x => `<div class="tarefa"><span style="flex:1">${dataHoraBR(x.data)} — ${x.tipo === 'sangria' ? 'Sangria' : 'Suprimento'} ${esc(x.obs)}</span><b>${moeda(x.valor)}</b></div>`).join('')}` : ''}`
    : `<h2>Abrir caixa</h2><p class="suave">Informe o valor em dinheiro na gaveta para troco.</p>
      ${formHTML([{ n: 'valor', r: 'Valor inicial', t: 'money', w: 6, padrao: ultimo ? r2(ultimo.contado) : 0 }])}
      <button class="btn pri" style="margin-top:12px" data-click="abrir">Abrir caixa</button>`}</div>
    <div class="card"><h3>Como funciona</h3><p class="suave">O caixa controla apenas o <b>dinheiro em espécie</b> da gaveta. Pix e cartões entram direto no financeiro.
      Ao fechar, conte o dinheiro e informe o valor: o sistema mostra a diferença em relação ao esperado.</p>
      <p class="suave">Sangria = retirada (ex.: depósito no banco). Suprimento = reforço de troco.</p></div></div>
    <div class="card"><h3>Fechamentos anteriores</h3><div id="tab-caixas"></div></div>`;
  tabela(el.querySelector('#tab-caixas'), { linhas: hist, busca: false, exportar: 'caixas', porPagina: 15,
    colunas: [{ t: 'Abertura', v: x => x.aberto_em, h: x => dataHoraBR(x.aberto_em) }, { t: 'Fechamento', v: x => x.fechado_em, h: x => dataHoraBR(x.fechado_em) },
      { t: 'Inicial', v: x => x.valor_inicial, h: x => moeda(x.valor_inicial), cls: 'num' }, { t: 'Esperado', v: x => x.esperado, h: x => moeda(x.esperado), cls: 'num' },
      { t: 'Contado', v: x => x.contado, h: x => moeda(x.contado), cls: 'num' },
      { t: 'Diferença', v: x => x.diferenca, h: x => `<span class="${x.diferenca < 0 ? 'negativo' : x.diferenca > 0 ? 'positivo' : ''}">${moeda(x.diferenca)}</span>`, cls: 'num', total: true }, { t: 'Obs.', v: x => x.obs || '' }] });
  ligar(el, {
    abrir: async () => { await api('caixa/abrir', { valor: n(el.querySelector('[name=valor]').value) }); toast('Caixa aberto.', 'ok'); recarregarPagina(); },
    mov: b => modal({ titulo: b.dataset.t === 'sangria' ? 'Sangria' : 'Suprimento', corpo: formHTML([{ n: 'valor', r: 'Valor', t: 'money', w: 6, obr: 1 }, { n: 'obs', r: 'Observação', w: 12, ph: b.dataset.t === 'sangria' ? 'ex.: depósito no banco' : '' }]),
      botoes: [{ texto: 'Cancelar' }, { texto: 'Registrar', classe: 'pri', acao: async m => { const d = lerForm(m, [{ n: 'valor', r: 'Valor', t: 'money', obr: 1 }, { n: 'obs' }]); await api('caixa/movimento', { tipo: b.dataset.t, ...d }); recarregarPagina(); } }] }),
    fechar: () => modal({ titulo: 'Fechar caixa', corpo: `<p>Conte o dinheiro da gaveta e informe o total.</p>${formHTML([{ n: 'contado', r: 'Valor contado', t: 'money', w: 6, obr: 1 }, { n: 'obs', r: 'Observação', w: 12 }])}`,
      botoes: [{ texto: 'Cancelar' }, { texto: 'Fechar caixa', classe: 'pri', acao: async m => {
        const d = lerForm(m, [{ n: 'contado', r: 'Valor contado', t: 'money', obr: 1 }, { n: 'obs' }]);
        const r2_ = await api('caixa/fechar', d);
        const dif = r2_.caixa.diferenca;
        modal({ titulo: 'Caixa fechado', corpo: `<p>Esperado: <b>${moeda(r2_.caixa.esperado)}</b><br>Contado: <b>${moeda(r2_.caixa.contado)}</b><br>Diferença: <b class="${dif < 0 ? 'negativo' : dif > 0 ? 'positivo' : ''}">${moeda(dif)}</b></p>${Math.abs(dif) < 0.01 ? '<p class="positivo">Caixa conferido sem diferenças.</p>' : '<p class="suave">Diferenças costumam vir de troco errado ou venda lançada em outra forma de pagamento.</p>'}`, botoes: [{ texto: 'Ok', classe: 'pri' }] });
        recarregarPagina();
      } }] })
  });
};
