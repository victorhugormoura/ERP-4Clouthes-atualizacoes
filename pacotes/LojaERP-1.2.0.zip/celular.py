"""Loja ERP — acesso pelo celular na rede local.

Certificado TLS próprio (ECDSA P-256), gerado só com a biblioteca padrão do Python, para que o
celular converse com o computador por HTTPS: os dados não trafegam abertos no Wi-Fi e o navegador
do celular libera a câmera (leitor de código de barras), que só funciona em conexão segura.

Infinity Technology — Victor Hugo R. Moura — victorhugormoura@gmail.com
"""
import datetime as dt
import hashlib
import ipaddress
import os
import secrets
import socket
import ssl
import sys

# ------------------------------------------------------------ curva P-256 (FIPS 186-4)
_P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
_A = _P - 3
_B = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
_N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
_G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
      0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)


def _somar(p, q):
    if p is None:
        return q
    if q is None:
        return p
    if p[0] == q[0]:
        if (p[1] + q[1]) % _P == 0:
            return None
        m = (3 * p[0] * p[0] + _A) * pow(2 * p[1], -1, _P) % _P
    else:
        m = (q[1] - p[1]) * pow(q[0] - p[0], -1, _P) % _P
    x = (m * m - p[0] - q[0]) % _P
    return x, (m * (p[0] - x) - p[1]) % _P


def _multiplicar(k, ponto):
    resultado = None
    while k:
        if k & 1:
            resultado = _somar(resultado, ponto)
        ponto = _somar(ponto, ponto)
        k >>= 1
    return resultado


def _no_curva(ponto):
    x, y = ponto
    return (y * y - (x * x * x + _A * x + _B)) % _P == 0


def _assinar(d, mensagem):
    z = int.from_bytes(hashlib.sha256(mensagem).digest(), 'big')
    while True:
        k = secrets.randbelow(_N - 1) + 1
        r = _multiplicar(k, _G)[0] % _N
        s = pow(k, -1, _N) * (z + r * d) % _N
        if r and s:
            return r, s


# ------------------------------------------------------------------- DER mínimo
def _tlv(tag, conteudo):
    n = len(conteudo)
    if n < 0x80:
        tam = bytes([n])
    else:
        b = n.to_bytes((n.bit_length() + 7) // 8, 'big')
        tam = bytes([0x80 | len(b)]) + b
    return bytes([tag]) + tam + conteudo


def _seq(*partes):
    return _tlv(0x30, b''.join(partes))


def _inteiro(v):
    b = v.to_bytes(max(1, (v.bit_length() + 8) // 8), 'big')
    return _tlv(0x02, b)


def _oid(texto):
    n = [int(x) for x in texto.split('.')]
    corpo = bytes([40 * n[0] + n[1]])
    for v in n[2:]:
        partes = [v & 0x7f]
        v >>= 7
        while v:
            partes.append(0x80 | (v & 0x7f))
            v >>= 7
        corpo += bytes(reversed(partes))
    return _tlv(0x06, corpo)


def _bits(b):
    return _tlv(0x03, b'\x00' + b)


def _data(d):
    return _tlv(0x17, d.strftime('%y%m%d%H%M%SZ').encode())


def _nome(texto):
    return _seq(_tlv(0x31, _seq(_oid('2.5.4.3'), _tlv(0x0c, texto.encode('utf-8')))))


def _pem(rotulo, der):
    import base64
    b = base64.b64encode(der).decode()
    linhas = [b[i:i + 64] for i in range(0, len(b), 64)]
    return f'-----BEGIN {rotulo}-----\n' + '\n'.join(linhas) + f'\n-----END {rotulo}-----\n'


def gerar_certificado(ips, nome='Loja ERP (este computador)', anos=10):
    """Devolve (certificado PEM, chave PEM) autoassinados para os IPs informados."""
    d = secrets.randbelow(_N - 1) + 1
    qx, qy = _multiplicar(d, _G)
    publica = b'\x04' + qx.to_bytes(32, 'big') + qy.to_bytes(32, 'big')
    alg = _seq(_oid('1.2.840.10045.4.3.2'))
    agora = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
    nomes_alt = b''.join(_tlv(0x87, ipaddress.ip_address(ip).packed) for ip in ips) + _tlv(0x82, b'localhost')
    extensoes = _seq(
        _seq(_oid('2.5.29.17'), _tlv(0x04, _seq(nomes_alt))),
        _seq(_oid('2.5.29.15'), _tlv(0x01, b'\xff'), _tlv(0x04, _tlv(0x03, b'\x07\x80'))),
        _seq(_oid('2.5.29.37'), _tlv(0x04, _seq(_oid('1.3.6.1.5.5.7.3.1')))),
    )
    tbs = _seq(
        _tlv(0xa0, _inteiro(2)),
        _inteiro(int.from_bytes(secrets.token_bytes(16), 'big') >> 1),
        alg,
        _nome(nome),
        _seq(_data(agora - dt.timedelta(days=1)), _data(agora + dt.timedelta(days=365 * anos))),
        _nome(nome),
        _seq(_seq(_oid('1.2.840.10045.2.1'), _oid('1.2.840.10045.3.1.7')), _bits(publica)),
        _tlv(0xa3, extensoes),
    )
    r, s = _assinar(d, tbs)
    certificado = _seq(tbs, alg, _bits(_seq(_inteiro(r), _inteiro(s))))
    chave = _seq(_inteiro(1), _tlv(0x04, d.to_bytes(32, 'big')),
                 _tlv(0xa0, _oid('1.2.840.10045.3.1.7')), _tlv(0xa1, _bits(publica)))
    return _pem('CERTIFICATE', certificado), _pem('EC PRIVATE KEY', chave)


def impressao_digital(cert_pem):
    """SHA-256 do certificado, em blocos fáceis de comparar."""
    der = ssl.PEM_cert_to_DER_cert(cert_pem)
    h = hashlib.sha256(der).hexdigest().upper()
    return ' '.join(h[i:i + 4] for i in range(0, 16, 4))


def preparar_certificado(pasta, ips):
    """Cria (uma vez) o certificado desta instalação e devolve o contexto TLS e a impressão digital."""
    os.makedirs(pasta, exist_ok=True)
    arq_cert = os.path.join(pasta, 'celular-certificado.pem')
    arq_chave = os.path.join(pasta, 'celular-chave.pem')
    if not (os.path.isfile(arq_cert) and os.path.isfile(arq_chave)):
        cert, chave = gerar_certificado(ips)
        descritor = os.open(arq_chave, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descritor, 'w', encoding='ascii') as f:
            f.write(chave)
        with open(arq_cert, 'w', encoding='ascii') as f:
            f.write(cert)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(arq_cert, arq_chave)
    with open(arq_cert, 'r', encoding='ascii') as f:
        return ctx, impressao_digital(f.read())


# ------------------------------------------------------------------- rede local
def ip_privado(ip):
    try:
        a = ipaddress.ip_address(ip.split('%')[0])
    except ValueError:
        return False
    if a.version == 6 and a.ipv4_mapped:
        a = a.ipv4_mapped
    excluidas = ('169.254.0.0/16', '198.18.0.0/15', '240.0.0.0/4', 'fe80::/10')
    if any(a in ipaddress.ip_network(r) for r in excluidas if ipaddress.ip_network(r).version == a.version):
        return False
    return a.is_private and not a.is_unspecified and not a.is_multicast


def ips_locais():
    """IPs IPv4 privados deste computador; o da rota padrão vem primeiro."""
    vistos = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('10.255.255.255', 1))
            vistos.append(s.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            vistos.append(info[4][0])
    except OSError:
        pass
    saida = []
    for ip in vistos:
        if ip not in saida and ip_privado(ip) and not ipaddress.ip_address(ip).is_loopback \
                and not ipaddress.ip_address(ip).is_link_local:
            saida.append(ip)
    return saida


def nome_aparelho(agente):
    """Nome curto do aparelho a partir do navegador (ex.: "Android SM-A145M", "iPhone")."""
    a = agente or ''
    if 'iPhone' in a:
        return 'iPhone'
    if 'iPad' in a:
        return 'iPad'
    if 'Android' in a:
        try:
            trecho = a.split('Android', 1)[1].split(')', 1)[0]
            partes = [p.strip() for p in trecho.split(';') if p.strip()]
            modelo = next((p for p in reversed(partes) if p not in ('K', 'wv') and not p[0].isdigit()), '').split(' Build')[0]
            return f'Android {modelo}'.strip()[:40]
        except IndexError:
            return 'Android'
    return 'Navegador'


def liberar_firewall(porta):
    """Windows: pede permissão de administrador (janela do próprio Windows) e libera a porta do celular
    só para aparelhos da sub-rede local. Roda o netsh direto pelo ShellExecuteEx, sem PowerShell,
    e confere o código de saída."""
    if sys.platform != 'win32':
        return False, 'Disponível apenas no Windows.'
    programa = sys.executable
    if '"' in programa or '%' in programa:
        return False, 'O caminho do programa tem caracteres que o firewall não aceita. Use o aviso do Windows ao ligar.'
    import ctypes
    from ctypes import wintypes

    class INFO(ctypes.Structure):
        _fields_ = [('cbSize', wintypes.DWORD), ('fMask', ctypes.c_ulong), ('hwnd', wintypes.HWND),
                    ('lpVerb', wintypes.LPCWSTR), ('lpFile', wintypes.LPCWSTR), ('lpParameters', wintypes.LPCWSTR),
                    ('lpDirectory', wintypes.LPCWSTR), ('nShow', ctypes.c_int), ('hInstApp', wintypes.HINSTANCE),
                    ('lpIDList', ctypes.c_void_p), ('lpClass', wintypes.LPCWSTR), ('hkeyClass', wintypes.HKEY),
                    ('dwHotKey', wintypes.DWORD), ('hIcon', wintypes.HANDLE), ('hProcess', wintypes.HANDLE)]

    regra = 'Loja ERP (celular)'
    # profile=any porque o Windows costuma marcar o Wi-Fi da loja como "rede pública"; o que restringe é
    # remoteip=localsubnet (só a sub-rede local) e a porta específica deste programa.
    parametros = (f'/c netsh advfirewall firewall delete rule name="{regra}" >nul & '
                  f'netsh advfirewall firewall add rule name="{regra}" dir=in action=allow enable=yes '
                  f'program="{programa}" protocol=TCP localport={int(porta)} remoteip=localsubnet profile=any')
    info = INFO(cbSize=ctypes.sizeof(INFO), fMask=0x40, lpVerb='runas', lpFile='cmd.exe',
                lpParameters=parametros, nShow=0)   # 0x40 = SEE_MASK_NOCLOSEPROCESS
    if not ctypes.windll.shell32.ShellExecuteExW(ctypes.byref(info)) or not info.hProcess:
        return False, 'O Windows não liberou (a permissão de administrador foi negada?).'
    kernel = ctypes.windll.kernel32
    kernel.WaitForSingleObject(info.hProcess, 120000)
    codigo = wintypes.DWORD(1)
    kernel.GetExitCodeProcess(info.hProcess, ctypes.byref(codigo))
    kernel.CloseHandle(info.hProcess)
    if codigo.value != 0:
        return False, 'O firewall do Windows recusou a regra. Tente pelo aviso do Windows ao ligar o acesso.'
    return True, 'Liberado no firewall do Windows para aparelhos da rede local.'
